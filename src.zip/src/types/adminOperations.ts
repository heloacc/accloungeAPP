// TypeScript types for admin operations to ensure type safety

export type AdminAction = 
  | 'get_analytics'
  | 'get_dashboard_stats' 
  | 'bulk_import_users'
  | 'notify_join_request'
  | 'health_check'
  | 'get_all_users'
  | 'update_user_role';

export interface AdminOperationRequest {
  action: AdminAction;
  operation?: AdminAction; // For backward compatibility
  [key: string]: any; // Allow additional parameters
}

export interface AdminOperationResponse {
  success: boolean;
  correlation_id: string;
  error?: string;
  message?: string;
  [key: string]: any; // Allow additional response data
}

export interface AnalyticsResponse extends AdminOperationResponse {
  totalUsers?: number;
  totalGoals?: number;
  totalHabits?: number;
  completedGoals?: number;
  completedHabits?: number;
}