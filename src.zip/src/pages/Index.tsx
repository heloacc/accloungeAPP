import { Suspense, lazy, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { useUnifiedAuthContext } from '@/contexts/UnifiedAuthContext';
import EnhancedLoadingScreen from '@/components/EnhancedLoadingScreen';

// Lazy load heavy components
const OptimizedAppLayout = lazy(() => import('@/components/OptimizedAppLayout'));
const InviteLinkHandler = lazy(() => import('@/components/InviteLinkHandler'));

const Index = () => {
  const { currentUser, setActiveTab, isLoading, authError } = useUnifiedAuthContext();
  const location = useLocation();

  // Handle route-based tab navigation
  useEffect(() => {
    const path = location.pathname;
    if (path === '/subscription' || path === '/billing') {
      setActiveTab('billing');
    }
  }, [location.pathname, setActiveTab]);

  // Check for invite parameters in URL
  const urlParams = new URLSearchParams(location.search);
  const inviteToken = urlParams.get('token');
  const groupId = urlParams.get('invite');

  // Show loading screen while auth is initializing
  if (isLoading) {
    return <EnhancedLoadingScreen />;
  }

  // Show auth error if present
  if (authError && !currentUser) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-red-50 to-red-100">
        <div className="text-center max-w-md mx-auto p-6">
          <div className="text-red-600 mb-4">
            <svg className="w-12 h-12 mx-auto mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z" />
            </svg>
          </div>
          <h2 className="text-xl font-semibold text-red-700 mb-2">Authentication Error</h2>
          <p className="text-red-600 mb-4">{authError}</p>
          <button 
            onClick={() => window.location.reload()}
            className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 transition-colors"
          >
            Reload Page
          </button>
        </div>
      </div>
    );
  }

  // If there's an invite link, show the invitation handler
  if (inviteToken && groupId && currentUser) {
    return (
      <div className="min-h-screen bg-gray-50 p-4">
        <div className="max-w-md mx-auto pt-20">
          <Suspense fallback={<EnhancedLoadingScreen />}>
            <InviteLinkHandler inviteToken={inviteToken} groupId={groupId} />
          </Suspense>
        </div>
      </div>
    );
  }

  return (
    <Suspense fallback={<EnhancedLoadingScreen />}>
      <OptimizedAppLayout />
    </Suspense>
  );
};

export default Index;