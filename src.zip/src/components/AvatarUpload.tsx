import { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Camera, Upload, X } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface AvatarUploadProps {
  currentAvatar?: string;
  userName: string;
  onAvatarUpdate: (avatarUrl: string) => void;
  size?: 'sm' | 'md' | 'lg' | 'xl';
}

export default function AvatarUpload({ 
  currentAvatar, 
  userName, 
  onAvatarUpdate,
  size = 'xl' 
}: AvatarUploadProps) {
  const [uploading, setUploading] = useState(false);
  const [preview, setPreview] = useState<string | null>(currentAvatar || null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      // Create preview
      const reader = new FileReader();
      reader.onload = (e) => {
        setPreview(e.target?.result as string);
      };
      reader.readAsDataURL(file);
      
      // Upload file
      uploadAvatar(file);
    }
  };

  const uploadAvatar = async (file: File) => {
    setUploading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('No user found');

      const fileExt = file.name.split('.').pop();
      const fileName = `${user.id}-${Math.random()}.${fileExt}`;
      const filePath = `avatars/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('avatars')
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      const { data } = supabase.storage
        .from('avatars')
        .getPublicUrl(filePath);

      // Update profile with avatar URL
      await supabase.from('profiles').update({
        avatar_url: data.publicUrl
      }).eq('id', user.id);

      onAvatarUpdate(data.publicUrl);
    } catch (error: any) {
      console.error('Error uploading avatar:', error.message);
      setPreview(currentAvatar || null);
    } finally {
      setUploading(false);
    }
  };

  const removeAvatar = () => {
    setPreview(null);
    onAvatarUpdate('');
  };

  return (
    <div className="flex flex-col items-center space-y-4">
      <div className="relative">
        <Avatar size={size} className="border-4 border-white shadow-lg">
          {preview ? (
            <AvatarImage src={preview} alt={userName} />
          ) : (
            <AvatarFallback className="text-2xl bg-gradient-to-br from-blue-400 to-purple-500 text-white">
              {userName.charAt(0).toUpperCase()}
            </AvatarFallback>
          )}
        </Avatar>
        
        {preview && (
          <Button
            size="sm"
            variant="destructive"
            className="absolute -top-2 -right-2 h-6 w-6 rounded-full p-0"
            onClick={removeAvatar}
          >
            <X className="h-3 w-3" />
          </Button>
        )}
        
        <Button
          size="sm"
          className="absolute -bottom-2 -right-2 h-8 w-8 rounded-full p-0"
          onClick={() => fileInputRef.current?.click()}
          disabled={uploading}
        >
          {uploading ? (
            <div className="h-3 w-3 animate-spin rounded-full border border-white border-t-transparent" />
          ) : (
            <Camera className="h-3 w-3" />
          )}
        </Button>
      </div>

      <div className="text-center">
        <Button
          variant="outline"
          onClick={() => fileInputRef.current?.click()}
          disabled={uploading}
          className="mb-2"
        >
          <Upload className="h-4 w-4 mr-2" />
          {preview ? 'Change Photo' : 'Add Photo'}
        </Button>
        <p className="text-xs text-muted-foreground">
          JPG, PNG or GIF (max 5MB)
        </p>
      </div>

      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handleFileSelect}
        className="hidden"
      />
    </div>
  );
}