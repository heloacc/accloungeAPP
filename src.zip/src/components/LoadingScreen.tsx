import React, { useEffect, useState } from 'react';
import { useAppContext } from '@/contexts/OptimizedAppContext';

const LoadingScreen: React.FC = () => {
  const [showFallback, setShowFallback] = useState(false);
  const { refreshApp } = useAppContext();

  useEffect(() => {
    const timer = setTimeout(() => {
      setShowFallback(true);
    }, 2000);
    return () => clearTimeout(timer);
  }, []);

  const handleRefresh = async () => {
    try {
      await refreshApp();
    } catch (error) {
      window.location.reload();
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="text-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
        <h2 className="text-xl font-semibold text-gray-700 mb-2">Loading AccLounge</h2>
        <p className="text-gray-500 mb-4">Setting up your accountability journey...</p>
        
        {showFallback && (
          <div className="mt-6">
            <p className="text-sm text-gray-400 mb-2">Taking longer than expected?</p>
            <button 
              onClick={handleRefresh}
              className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
            >
              Refresh Session
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default LoadingScreen;