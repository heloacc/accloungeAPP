  const addRule = async () => {
    if (!newRule.page_path.trim()) {
      toast({
        title: "Error",
        description: "Page path is required",
        variant: "destructive"
      });
      return;
    }

    try {
      const { error } = await supabase
        .from('page_access_rules')
        .insert([{
          page_path: newRule.page_path.trim(),
          minimum_tier_id: newRule.minimum_tier_id,
          required_plan_id: newRule.required_plan_id
        }]);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Page access rule added"
      });

      setNewRule({
        page_path: '',
        minimum_tier_id: null,
        required_plan_id: null
      });

      loadRules();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    }
  };

  const deleteRule = async (id: string) => {
    try {
      const { error } = await supabase
        .from('page_access_rules')
        .delete()
        .eq('id', id);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Page access rule deleted"
      });

      loadRules();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    }
  };

  const getTierName = (tierId: string | null) => {
    if (!tierId) return 'Free Access';
    const tier = tiers.find(t => t.id === tierId);
    return tier?.name || 'Unknown Tier';
  };

  const getTierPrice = (tierId: string | null) => {
    if (!tierId) return '';
    const tier = tiers.find(t => t.id === tierId);
    return tier ? `$${tier.price_monthly}/mo` : '';
  };