import { useState } from 'react';
import { supabase } from '@/lib/supabase';
import { Button } from '@/components/ui/button';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger,
  DropdownMenuSeparator
} from '@/components/ui/dropdown-menu';
import { MoreVertical, Pin, PinOff, Trash2, Calendar, Clock } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useUserData } from '@/hooks/useUserData';

interface UniversalModerationActionsProps {
  postId: string;
  isPinned?: boolean;
  isScheduled?: boolean;
  tableName: 'posts' | 'group_posts' | 'partnership_messages';
  onPostUpdated?: () => void;
  onPostDeleted?: () => void;
}

const UniversalModerationActions: React.FC<UniversalModerationActionsProps> = ({
  postId,
  isPinned = false,
  isScheduled = false,
  tableName,
  onPostUpdated,
  onPostDeleted
}) => {
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();
  const { userData } = useUserData();

  // Check if user can moderate (admin or moderator)
  const canModerate = userData?.role === 'admin' || userData?.role === 'moderator';

  if (!canModerate) return null;

  const handlePin = async () => {
    setLoading(true);
    try {
      const { error } = await supabase
        .from(tableName)
        .update({ is_pinned: !isPinned })
        .eq('id', postId);

      if (error) throw error;

      toast({
        title: isPinned ? "Post Unpinned" : "Post Pinned",
        description: isPinned ? "Post removed from top of feed" : "Post pinned to top of feed"
      });

      onPostUpdated?.();
    } catch (error) {
      console.error('Error updating pin status:', error);
      toast({
        title: "Error",
        description: "Failed to update post pin status",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSchedule = async () => {
    const dateTime = prompt('Enter date and time (YYYY-MM-DD HH:MM):');
    if (!dateTime) return;

    try {
      const scheduledFor = new Date(dateTime);
      if (isNaN(scheduledFor.getTime())) {
        throw new Error('Invalid date format');
      }

      const { error } = await supabase
        .from('scheduled_notifications')
        .insert({
          post_id: postId,
          post_type: tableName,
          scheduled_for: scheduledFor.toISOString(),
          created_by: userData?.id
        });

      if (error) throw error;

      toast({
        title: "Post Scheduled",
        description: `Post scheduled for ${scheduledFor.toLocaleString()}`
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Invalid date format. Use YYYY-MM-DD HH:MM",
        variant: "destructive"
      });
    }
  };

  const handleDelete = async () => {
    if (!confirm('Are you sure you want to delete this post? This action cannot be undone.')) {
      return;
    }

    setLoading(true);
    try {
      const { error } = await supabase
        .from(tableName)
        .update({ recovery_status: 'deleted' })
        .eq('id', postId);

      if (error) throw error;

      toast({
        title: "Post Deleted",
        description: "Post has been removed from the feed"
      });

      onPostDeleted?.();
    } catch (error) {
      console.error('Error deleting post:', error);
      toast({
        title: "Error",
        description: "Failed to delete post",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="sm" disabled={loading} className="h-8 w-8 p-0">
          <MoreVertical className="h-4 w-4" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-48">
        <DropdownMenuItem onClick={handlePin}>
          {isPinned ? (
            <>
              <PinOff className="h-4 w-4 mr-2" />
              Unpin Post
            </>
          ) : (
            <>
              <Pin className="h-4 w-4 mr-2" />
              Pin Post
            </>
          )}
        </DropdownMenuItem>
        
        <DropdownMenuItem onClick={handleSchedule}>
          <Calendar className="h-4 w-4 mr-2" />
          Schedule Post
        </DropdownMenuItem>
        
        <DropdownMenuSeparator />
        
        <DropdownMenuItem onClick={handleDelete} className="text-red-600 focus:text-red-600">
          <Trash2 className="h-4 w-4 mr-2" />
          Delete Post
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
};

export default UniversalModerationActions;