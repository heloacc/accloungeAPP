import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { useUserRole } from '@/hooks/useUserRole';
import { useAppContext } from '@/contexts/OptimizedAppContext';
import { supabase } from '@/lib/supabase';
import { toast } from '@/components/ui/use-toast';
import { Users } from 'lucide-react';

const GroupCreationForm = ({ onNavigate }: { onNavigate?: (tab: string) => void }) => {
  const { currentUser } = useAppContext();
  const { canCreateGroups } = useUserRole();
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    is_private: false,
    max_members: 50
  });
  const [loading, setLoading] = useState(false);

  if (!canCreateGroups) {
    return (
      <Card className="max-w-2xl mx-auto">
        <CardContent className="pt-6 text-center">
          <p className="text-red-600">You don't have permission to create groups.</p>
          <Button onClick={() => onNavigate?.('groups')} className="mt-4">
            Back to Groups
          </Button>
        </CardContent>
      </Card>
    );
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim()) return;

    setLoading(true);
    try {
      const { error } = await supabase
        .from('acircle_groups')
        .insert({
          name: formData.name.trim(),
          description: formData.description.trim(),
          is_private: formData.is_private,
          created_by: currentUser?.id,
          max_members: formData.max_members
        });

      if (error) throw error;

      toast({
        title: "Success",
        description: `Group "${formData.name}" created successfully`
      });

      onNavigate?.('groups');
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to create group",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Users className="h-5 w-5" />
          Create New Group
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="name">Group Name</Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              placeholder="Enter group name"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="Describe the group's purpose"
              rows={3}
            />
          </div>

          <div className="flex items-center space-x-2">
            <Switch
              id="private"
              checked={formData.is_private}
              onCheckedChange={(checked) => setFormData({ ...formData, is_private: checked })}
            />
            <Label htmlFor="private">Private Group</Label>
          </div>

          <div className="flex gap-2">
            <Button type="submit" disabled={loading || !formData.name.trim()}>
              {loading ? 'Creating...' : 'Create Group'}
            </Button>
            <Button type="button" variant="outline" onClick={() => onNavigate?.('groups')}>
              Cancel
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
};

export default GroupCreationForm;