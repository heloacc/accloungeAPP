import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Trophy, Flame, Target, TrendingUp } from 'lucide-react';

interface WinsProgressBannerProps {
  userStats: {
    habits_count: number;
    goals_count: number;
    current_streak: number;
    total_completions: number;
  } | null;
  unlockedAchievements: number;
  userName: string;
}

const WinsProgressBanner = ({ userStats, unlockedAchievements, userName }: WinsProgressBannerProps) => {
  return (
    <Card className="bg-gradient-to-r from-[#001B30] to-[#2C2C44] border-none text-white overflow-hidden">
      <div className="p-4 sm:p-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold mb-2">
              Great progress, {userName}! 🎉
            </h2>
            <p className="text-[#7E8E9D] text-sm sm:text-base">
              Here's what you've accomplished so far
            </p>
          </div>
          
          <div className="flex flex-wrap gap-3">
            <Badge className="bg-green-600 text-white px-3 py-1">
              <Trophy className="h-4 w-4 mr-1" />
              {unlockedAchievements} Achievements
            </Badge>
            <Badge className="bg-orange-500 text-white px-3 py-1">
              <Flame className="h-4 w-4 mr-1" />
              {userStats?.current_streak || 0} Day Streak
            </Badge>
            <Badge className="bg-blue-600 text-white px-3 py-1">
              <Target className="h-4 w-4 mr-1" />
              {userStats?.total_completions || 0} Completions
            </Badge>
          </div>
        </div>
      </div>
    </Card>
  );
};

export default WinsProgressBanner;