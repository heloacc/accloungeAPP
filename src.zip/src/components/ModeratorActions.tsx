import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Shield, Eye, MessageSquare, Users, Flag } from 'lucide-react';
import { useUserRole } from '@/hooks/useUserRole';

interface ModeratorActionsProps {
  onModeratePost?: (postId: string, action: 'approve' | 'hide' | 'delete') => void;
  onModerateUser?: (userId: string, action: 'warn' | 'suspend' | 'ban') => void;
  onViewReports?: () => void;
}

const ModeratorActions: React.FC<ModeratorActionsProps> = ({
  onModeratePost,
  onModerateUser,
  onViewReports
}) => {
  const { role, isModerator, isAdmin, loading } = useUserRole();

  if (loading) {
    return <div className="animate-pulse bg-gray-200 h-32 rounded-lg"></div>;
  }

  if (!isModerator && !isAdmin) {
    return null;
  }

  return (
    <Card className="border-orange-200 bg-orange-50">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Shield className="h-5 w-5 text-orange-600" />
          Moderator Actions
          <Badge variant="outline" className="text-orange-700 border-orange-300">
            {role}
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={onViewReports}
            className="flex items-center gap-2"
          >
            <Flag className="h-4 w-4" />
            Reports
          </Button>
          
          <Button
            variant="outline"
            size="sm"
            className="flex items-center gap-2"
          >
            <MessageSquare className="h-4 w-4" />
            Posts
          </Button>
          
          <Button
            variant="outline"
            size="sm"
            className="flex items-center gap-2"
          >
            <Users className="h-4 w-4" />
            Users
          </Button>
          
          <Button
            variant="outline"
            size="sm"
            className="flex items-center gap-2"
          >
            <Eye className="h-4 w-4" />
            Monitor
          </Button>
        </div>
        
        <div className="text-sm text-muted-foreground">
          <p>As a {role.toLowerCase()}, you can moderate content and manage community interactions.</p>
        </div>
      </CardContent>
    </Card>
  );
};

export default ModeratorActions;