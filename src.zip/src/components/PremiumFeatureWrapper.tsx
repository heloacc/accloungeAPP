import React from 'react';
import { useUserTier, UserTier } from '@/hooks/useUserTier';
import { Button } from '@/components/ui/button';
import { Crown, Lock } from 'lucide-react';

interface PremiumFeatureWrapperProps {
  children: React.ReactNode;
  requiredTier: UserTier;
  blurContent?: boolean;
  showOverlay?: boolean;
}

const PremiumFeatureWrapper: React.FC<PremiumFeatureWrapperProps> = ({ 
  children, 
  requiredTier,
  blurContent = true,
  showOverlay = true
}) => {
  const { tier, loading, isPremium, isEnterprise } = useUserTier();

  if (loading) {
    return <div className="animate-pulse bg-gray-200 rounded h-32"></div>;
  }

  const hasAccess = () => {
    switch (requiredTier) {
      case 'freemium':
        return true;
      case 'premium':
        return isPremium;
      case 'enterprise':
        return isEnterprise;
      default:
        return false;
    }
  };

  if (hasAccess()) {
    return <>{children}</>;
  }

  return (
    <div className="relative">
      <div className={blurContent ? 'filter blur-sm pointer-events-none' : ''}>
        {children}
      </div>
      
      {showOverlay && (
        <div className="absolute inset-0 flex items-center justify-center bg-white/80 backdrop-blur-sm rounded-lg">
          <div className="text-center space-y-3 p-4">
            <div className="mx-auto p-2 bg-purple-100 rounded-full w-fit">
              {requiredTier === 'enterprise' ? (
                <Crown className="h-6 w-6 text-purple-600" />
              ) : (
                <Lock className="h-6 w-6 text-purple-600" />
              )}
            </div>
            <div>
              <h3 className="font-semibold text-gray-900">
                {requiredTier === 'enterprise' ? 'Enterprise Feature' : 'Premium Feature'}
              </h3>
              <p className="text-sm text-gray-600 mt-1">
                Upgrade to {requiredTier} to unlock this feature
              </p>
            </div>
            <Button 
              size="sm" 
              className="bg-purple-600 hover:bg-purple-700"
              onClick={() => window.dispatchEvent(new CustomEvent('navigate-to-tab', { 
                detail: { tab: 'billing' }
              }))}
            >
              <Crown className="h-4 w-4 mr-1" />
              Upgrade Now
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};

export default PremiumFeatureWrapper;