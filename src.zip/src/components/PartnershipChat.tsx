import React, { useState, useEffect, useRef } from 'react';
import { supabase } from '@/lib/supabase';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useToast } from '@/hooks/use-toast';
import { useAppContext } from '@/contexts/AppContext';
import { DataBackupManager } from '@/utils/dataBackupManager';
import { Send, User, MessageCircle } from 'lucide-react';
import UniversalModerationActions from './UniversalModerationActions';

interface Message {
  id: string;
  content: string;
  sender_id: string;
  created_at: string;
}

interface PartnershipChatProps {
  partnershipId: string;
  currentUserId: string;
  partnerName?: string;
}

export const PartnershipChat: React.FC<PartnershipChatProps> = ({ 
  partnershipId, 
  currentUserId,
  partnerName = 'Partner'
}) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();
  const messagesEndRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    loadMessages();
    
    // Set up real-time subscription
    const channel = supabase
      .channel(`partnership_messages_${partnershipId}`)
      .on('postgres_changes', 
        { event: 'INSERT', schema: 'public', table: 'partnership_messages', filter: `partnership_id=eq.${partnershipId}` },
        (payload) => {
          const newMsg = payload.new;
          setMessages(prev => [...prev, {
            id: newMsg.id,
            content: newMsg.content,
            sender_id: newMsg.sender_id,
            created_at: newMsg.created_at
          }]);
        }
      )
      .subscribe();

    return () => {
      channel.unsubscribe();
    };
  }, [partnershipId]);

  const loadMessages = async () => {
    try {
      const { data, error } = await supabase
        .from('partnership_messages')
        .select(`
          id,
          content,
          sender_id,
          created_at,
          profiles!sender_id(display_name)
        `)
        .eq('partnership_id', partnershipId)
        .order('created_at', { ascending: true });

      if (error) throw error;

      const messagesWithNames = data?.map(msg => ({
        ...msg,
        sender_name: msg.profiles?.display_name || 'Unknown User'
      })) || [];

      setMessages(messagesWithNames);
    } catch (error) {
      console.error('Error loading messages:', error);
    } finally {
      setLoading(false);
    }
  };

  const sendMessage = async () => {
    if (!newMessage.trim()) return;

    try {
      const { error } = await supabase
        .from('partnership_messages')
        .insert({
          partnership_id: partnershipId,
          sender_id: currentUserId,
          content: newMessage.trim()
        });

      if (error) throw error;

      setNewMessage('');
    } catch (error) {
      console.error('Error sending message:', error);
    }
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="p-4">
          <div className="text-center text-gray-500">Loading messages...</div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="text-left">{/* Left align all content */}
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <MessageCircle className="w-5 h-5" />
          Partnership Chat
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">{/* Left aligned content */}
        <div className="h-64 overflow-y-auto space-y-2 border rounded p-3">
          {messages.length === 0 ? (
            <div className="text-center text-gray-500 py-8">
              No messages yet. Start the conversation!
            </div>
          ) : (
            messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${
                  message.sender_id === currentUserId ? 'justify-end' : 'justify-start'
                }`}
              >
                <div className="flex items-start gap-2 max-w-xs">
                  <div
                    className={`px-3 py-2 rounded-lg ${
                      message.sender_id === currentUserId
                        ? 'bg-[#596D59] text-white'
                        : 'bg-gray-100 text-gray-800'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2 mb-1">
                      <div className="flex items-center gap-1">
                        <User className="w-3 h-3" />
                        <span className="text-xs opacity-75">
                          {message.sender_name}
                        </span>
                      </div>
                      <UniversalModerationActions
                        postId={message.id}
                        tableName="partnership_messages"
                        onPostUpdated={loadMessages}
                        onPostDeleted={loadMessages}
                      />
                    </div>
                    <p className="text-sm">{message.content}</p>
                    <p className="text-xs opacity-75 mt-1">
                      {new Date(message.created_at).toLocaleTimeString()}
                    </p>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
        
        <div className="flex gap-2">
          <Input
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            placeholder="Type your message..."
            onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
          />
          <Button onClick={sendMessage} disabled={!newMessage.trim()}>
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default PartnershipChat;