import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { MessageSquare, Crown, ArrowUpRight } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';
import { useUserTier } from '@/hooks/useUserTier';
import { useUserRole } from '@/hooks/useUserRole';
import { CheckInChat } from './CheckInChat';
import { NotificationBadge } from './NotificationBadge';
interface CheckInMessage {
  id: string;
  thread_id: string;
  message_text: string;
  is_admin_message: boolean;
  sender_name?: string;
  created_at: string;
}

interface PersonalCheckInsProps {
  onUpgrade?: () => void;
}

export const PersonalCheckIns: React.FC<PersonalCheckInsProps> = ({ 
  onUpgrade 
}) => {
  const { userTier, canAccessTier } = useUserTier();
  const { isAdmin, isModerator } = useUserRole();
  const [messages, setMessages] = useState<CheckInMessage[]>([]);
  const [loading, setLoading] = useState(true);
  const [chatOpen, setChatOpen] = useState(false);
  const [selectedThreadId, setSelectedThreadId] = useState<string | null>(null);
  const { toast } = useToast();

  // Check if user has access to Personal Check-ins
  const hasAllAccess = canAccessTier('All Access') || isAdmin || isModerator;

  useEffect(() => {
    if (hasAllAccess) {
      loadMessages();
    } else {
      setLoading(false);
    }
  }, [hasAllAccess]);

  const loadMessages = async () => {
    try {
      const { data: user } = await supabase.auth.getUser();
      if (!user.user) return;

      const { data, error } = await supabase
        .from('check_in_messages')
        .select('id, thread_id, message_text, is_admin_message, created_at, sender_id, recipient_id')
        .eq('recipient_id', user.user.id)
        .order('created_at', { ascending: true });

      if (error) throw error;
      setMessages(data || []);
    } catch (error) {
      console.error('Error loading messages:', error);
    } finally {
      setLoading(false);
    }
  };

  const openChat = (threadId: string) => {
    setSelectedThreadId(threadId);
    setChatOpen(true);
  };

  const groupMessagesByThread = () => {
    const threads: { [key: string]: CheckInMessage[] } = {};
    messages.forEach(msg => {
      if (!threads[msg.thread_id]) {
        threads[msg.thread_id] = [];
      }
      threads[msg.thread_id].push(msg);
    });
    return threads;
  };

  if (loading) {
    return (
      <Card className="mb-6">
        <CardContent className="p-6">
          <div className="animate-pulse">Loading messages...</div>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Card className="mb-4 sm:mb-6">
        <CardHeader className="pb-3 sm:pb-4">
          <CardTitle className="text-base sm:text-lg font-semibold flex items-center gap-2 flex-wrap relative">
            <MessageSquare className="h-4 w-4 sm:h-5 sm:w-5 flex-shrink-0" />
            <span className="min-w-0">Personal Check-ins</span>
            {hasAllAccess && (
              <>
                <Badge variant="default" className="bg-acclounge-brown text-xs px-1.5 py-0.5">All Access</Badge>
                <NotificationBadge />
              </>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          {hasAllAccess ? (
            <div className="space-y-3 sm:space-y-4">
              {Object.entries(groupMessagesByThread()).length > 0 ? (
                Object.entries(groupMessagesByThread()).map(([threadId, threadMessages]) => (
                  <div key={threadId} className="border rounded-lg p-3 sm:p-4">
                    <div className="space-y-2 sm:space-y-3 mb-3">
                      {threadMessages.slice(-2).map((message) => (
                        <div 
                          key={message.id} 
                          className={`flex ${!message.is_admin_message ? 'justify-end' : 'justify-start'}`}
                        >
                          <div className={`max-w-[85%] sm:max-w-xs lg:max-w-md px-3 py-2 rounded-lg ${
                            !message.is_admin_message 
                               ? 'bg-acclounge-brown text-white' 
                               : 'bg-acclounge-sage/20 text-acclounge-sage'
                          }`}>
                            <div className="flex items-center gap-2 mb-1 flex-wrap">
                              <span className="text-xs font-medium">
                                {message.is_admin_message ? 'Coach' : 'You'}
                              </span>
                              <span className="text-xs opacity-70 whitespace-nowrap">
                                {new Date(message.created_at).toLocaleDateString()}
                              </span>
                            </div>
                            <p className="text-xs sm:text-sm leading-relaxed break-words">{message.message_text}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                    
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={() => openChat(threadId)}
                      className="w-full text-xs"
                    >
                      <MessageSquare className="h-3 w-3 mr-2" />
                      Open Chat ({threadMessages.length} messages)
                    </Button>
                  </div>
                ))
              ) : (
                <div className="p-3 sm:p-4 rounded-lg bg-muted/50 text-center">
                  <p className="text-xs sm:text-sm text-muted-foreground">
                    No personal check-ins yet. Your coach will reach out when needed! 💪
                  </p>
                </div>
              )}
            </div>
          ) : (
            <div className={`p-4 sm:p-6 rounded-lg border-2 border-dashed text-center space-y-3 ${
              hasAllAccess ? 'border-muted-foreground/20' : 'border-muted-foreground/10 bg-muted/30'
            }`}>
              <Crown className={`h-8 w-8 sm:h-12 sm:w-12 mx-auto ${hasAllAccess ? 'text-acclounge-brown' : 'text-muted-foreground/40'}`} />
              <h4 className={`font-semibold text-sm sm:text-base ${hasAllAccess ? 'text-foreground' : 'text-muted-foreground'}`}>
                {hasAllAccess ? 'Personal Check-ins' : 'Unlock Personal Check-ins'}
              </h4>
              <p className="text-xs sm:text-sm text-muted-foreground leading-relaxed px-2">
                {hasAllAccess 
                  ? 'No personal check-ins yet. Your coach will reach out when needed! 💪'
                  : 'Upgrade to All Access for personalized accountability messages and coaching support.'
                }
              </p>
              {!hasAllAccess && (
                <Button 
                  onClick={onUpgrade} 
                  className="bg-acclounge-brown hover:bg-acclounge-brown/90 text-xs sm:text-sm px-3 py-2 sm:px-4 sm:py-2"
                  size="sm"
                >
                  <span className="truncate">Upgrade to All Access</span>
                  <ArrowUpRight className="h-3 w-3 sm:h-4 sm:w-4 ml-1 flex-shrink-0" />
                </Button>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={chatOpen} onOpenChange={setChatOpen}>
        <DialogContent className="max-w-2xl max-h-[80vh]">
          <DialogHeader>
            <DialogTitle>Chat with Coach</DialogTitle>
          </DialogHeader>
          {selectedThreadId && (
            <CheckInChat
              recipientId="admin" // This will be handled by the chat component
              recipientName="Coach"
              isAdminView={false}
              threadId={selectedThreadId}
            />
          )}
        </DialogContent>
      </Dialog>
    </>
  );
};