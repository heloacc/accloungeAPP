import React, { Suspense, lazy } from 'react';
import { useUnifiedAuthContext } from '@/contexts/UnifiedAuthContext';
import SimpleErrorBoundary from './SimpleErrorBoundary';
import SimpleLoadingScreen from './SimpleLoadingScreen';
import { Toaster } from '@/components/ui/toaster';

// Lazy load components for better performance
const ResponsiveNavigation = lazy(() => import('./ResponsiveNavigation'));
const RealDataDashboard = lazy(() => import('./RealDataDashboard'));
const UnifiedHabitsGoals = lazy(() => import('./UnifiedHabitsGoals'));
const Achievements = lazy(() => import('./Achievements'));
const NotificationCenter = lazy(() => import('./NotificationCenter'));
const RoleBasedGroupsView = lazy(() => import('./RoleBasedGroupsView'));
const ActiveCircle = lazy(() => import('./ActiveCircle'));
const CommunityFeedTabs = lazy(() => import('./CommunityFeedTabs'));
const FindPartners = lazy(() => import('./FindPartners'));
const HabitSocialHub = lazy(() => import('./HabitSocialHub'));
const ReminderManager = lazy(() => import('./ReminderManager'));
const Resources = lazy(() => import('./Resources'));
const EnhancedUserProfile = lazy(() => import('./EnhancedUserProfile'));
const MemberMomentumWithChat = lazy(() => import('./MemberMomentumWithChat'));
const AdminDashboard = lazy(() => import('./AdminDashboard'));
const AllGroupsManager = lazy(() => import('./AllGroupsManager'));
const AdminNotifications = lazy(() => import('./AdminNotifications'));
const PostRecovery = lazy(() => import('./PostRecovery'));
const DynamicPageAccessManager = lazy(() => import('./DynamicPageAccessManager'));
const SubscriptionManager = lazy(() => import('./SubscriptionManager'));
const TierBasedFeatureDemo = lazy(() => import('./TierBasedFeatureDemo'));
const AdminTierManager = lazy(() => import('./AdminTierManager'));
const SubscriptionPlans = lazy(() => import('./SubscriptionPlans'));
const UserManagement = lazy(() => import('./UserManagement'));
const ComprehensiveUserManagement = lazy(() => import('./ComprehensiveUserManagement'));
const EnhancedAnalytics = lazy(() => import('./EnhancedAnalytics'));
const SimpleAnalyticsDashboard = lazy(() => import('./SimpleAnalyticsDashboard'));
const BulkUserImport = lazy(() => import('./BulkUserImport'));
const TierAssignmentManager = lazy(() => import('./TierAssignmentManager'));
const AutomatedGoalProgressTracker = lazy(() => import('./AutomatedGoalProgressTracker'));
const GoalMilestoneManager = lazy(() => import('./GoalMilestoneManager'));
const GroupCreationWrapper = lazy(() => import('./GroupCreationWrapper'));
const SystemHealthMonitor = lazy(() => import('./SystemHealthMonitor'));
const EnhancedPWAPrompt = lazy(() => import('./EnhancedPWAPrompt'));
const NotificationDisplay = lazy(() => import('./NotificationDisplay'));

// Import guards
import NavigationGuard from './NavigationGuard';
import RouteGuard from './RouteGuard';
import { SubscriptionTierEnforcement } from './SubscriptionTierEnforcement';

const OptimizedAppLayout = () => {
  const { activeTab, setActiveTab, currentUser, isLoading } = useUnifiedAuthContext();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-acclounge-sage/10">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-acclounge-brown mx-auto mb-4"></div>
          <p className="text-acclounge-slate">Loading...</p>
        </div>
      </div>
    );
  }

  if (!currentUser) {
    return <div>Please sign in to continue.</div>;
  }

  const renderContent = () => {
    const content = (() => {
      switch (activeTab) {
        case 'dashboard': 
          return <RealDataDashboard />;
        
        case 'habits-goals': 
          return (
            <SubscriptionTierEnforcement pagePath="/habits">
              <UnifiedHabitsGoals />
            </SubscriptionTierEnforcement>
          );
        
        case 'achievements': 
          return <Achievements />;
        
        case 'notifications': 
          return <NotificationCenter />;
        
        case 'groups': 
          return (
            <SubscriptionTierEnforcement pagePath="/groups">
              <RoleBasedGroupsView onNavigate={setActiveTab} />
            </SubscriptionTierEnforcement>
          );
        
        case 'active-circle': 
          return <ActiveCircle />;
        
        case 'community-feed': 
          return <CommunityFeedTabs onNavigate={setActiveTab} />;
        
        case 'find-partners': 
          return (
            <SubscriptionTierEnforcement pagePath="/partnerships">
              <FindPartners />
            </SubscriptionTierEnforcement>
          );
        
        case 'social-habits':
          return (
            <SubscriptionTierEnforcement pagePath="/partnerships">
              <HabitSocialHub />
            </SubscriptionTierEnforcement>
          );
        
        case 'reminders': 
          return <ReminderManager />;
        
        case 'resources': 
          return <Resources />;
        
        case 'profile': 
          return <EnhancedUserProfile />;
        
        case 'member-momentum': 
          return (
            <NavigationGuard requiredCapability="member_momentum" fallbackMessage="Admin or Moderator access required">
              <MemberMomentumWithChat />
            </NavigationGuard>
          );

        // Admin routes
        case 'admin-dashboard': 
          return (
            <RouteGuard requiredRoute="/admin">
              <AdminDashboard />
            </RouteGuard>
          );
        
        case 'all-groups-manager': 
          return (
            <RouteGuard requiredRoute="/admin">
              <AllGroupsManager />
            </RouteGuard>
          );
        
        case 'admin-notifications': 
          return (
            <RouteGuard requiredRoute="/admin">
              <AdminNotifications />
            </RouteGuard>
          );
        
        case 'post-recovery': 
          return <PostRecovery />;
        
        case 'page-access-manager': 
          return (
            <RouteGuard requiredRoute="/admin">
              <DynamicPageAccessManager />
            </RouteGuard>
          );
        
        case 'subscription': 
          return <SubscriptionManager />;
        
        case 'tier-demo': 
          return <TierBasedFeatureDemo />;
        
        case 'admin-tier-manager':
          return (
            <RouteGuard requiredRoute="/admin">
              <AdminTierManager />
            </RouteGuard>
          );
        
        case 'billing':
          return (
            <RouteGuard requiredRoute="/billing">
              <SubscriptionPlans />
            </RouteGuard>
          );
        
        case 'group-creation': 
          return (
            <RouteGuard requiredRoute="/groups">
              <GroupCreationWrapper />
            </RouteGuard>
          );
        
        case 'users': 
          return (
            <RouteGuard requiredRoute="/admin">
              <UserManagement />
            </RouteGuard>
          );
        
        case 'comprehensive-user-management': 
          return (
            <RouteGuard requiredRoute="/admin">
              <ComprehensiveUserManagement />
            </RouteGuard>
          );
        
        case 'analytics': 
          return (
            <RouteGuard requiredRoute="/analytics">
              <EnhancedAnalytics />
            </RouteGuard>
          );
        
        case 'user-analytics':
          return <SimpleAnalyticsDashboard />;
        
        case 'bulk-import': 
          return (
            <RouteGuard requiredRoute="/admin">
              <BulkUserImport />
            </RouteGuard>
          );
        
        case 'tier-assignment':
          return (
            <RouteGuard requiredRoute="/admin">
              <TierAssignmentManager />
            </RouteGuard>
          );
        
        case 'goal-progress': 
          return <AutomatedGoalProgressTracker />;
        
        case 'goal-milestones': 
          return <GoalMilestoneManager />;
        
        default: 
          return <RealDataDashboard />;
      }
    })();
    
    return (
      <SimpleErrorBoundary>
        <Suspense fallback={<SimpleLoadingScreen />}>
          {content}
        </Suspense>
      </SimpleErrorBoundary>
    );
  };

  return (
    <SimpleErrorBoundary>
      <div className="flex min-h-screen bg-acclounge-sage/5">
        <SimpleErrorBoundary fallback={<div>Navigation Error</div>}>
          <Suspense fallback={<SimpleLoadingScreen message="Loading navigation..." />}>
            <ResponsiveNavigation activeTab={activeTab} setActiveTab={setActiveTab} />
          </Suspense>
        </SimpleErrorBoundary>
        
        <main className="flex-1 overflow-auto lg:ml-56">
          <div className="pt-16 lg:pt-4 w-full">
            <div className="w-full px-2 sm:px-4 lg:px-6 max-w-none">
              {/* System Health Monitor for Admin Users */}
              {currentUser?.isAdmin && (
                <div className="mb-4">
                  <Suspense fallback={<SimpleLoadingScreen message="Loading system monitor..." size="sm" />}>
                    <SystemHealthMonitor showDetails={false} />
                  </Suspense>
                </div>
              )}
              <div className="w-full overflow-x-hidden">
                {renderContent()}
              </div>
            </div>
          </div>
        </main>
        
        <SimpleErrorBoundary fallback={<div>Notification Error</div>}>
          <Suspense fallback={<SimpleLoadingScreen message="Loading notifications..." size="sm" />}>
            <NotificationDisplay />
          </Suspense>
        </SimpleErrorBoundary>
        
        <SimpleErrorBoundary fallback={<div>PWA Error</div>}>
          <Suspense fallback={<SimpleLoadingScreen message="Loading PWA..." size="sm" />}>
            <EnhancedPWAPrompt showOnLoad={true} />
          </Suspense>
        </SimpleErrorBoundary>
        
        <Toaster />
      </div>
    </SimpleErrorBoundary>
  );
};

export default OptimizedAppLayout;
