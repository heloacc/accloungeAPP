import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Plus, Edit, Trash2, Clock, Calendar, CheckCircle, Flame } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';
import { useHabitCompletion, HabitWithCompletion } from '@/hooks/useHabitCompletion';
import HabitScheduleForm from './HabitScheduleForm';
import HabitReminderForm from './HabitReminderForm';
import HabitStreakTracker from './HabitStreakTracker';

interface Goal {
  id: string;
  title: string;
}

interface HabitManagerProps {
  onDataChange?: () => void;
}

export default function HabitManager({ onDataChange }: HabitManagerProps) {
  const [habits, setHabits] = useState<HabitWithCompletion[]>([]);
  const [goals, setGoals] = useState<Goal[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingHabit, setEditingHabit] = useState<HabitWithCompletion | null>(null);
  const [formData, setFormData] = useState({
    title: '',
    linked_goal_id: '',
    is_active: true
  });
  const [scheduleData, setScheduleData] = useState({
    frequency: 'daily' as 'daily' | 'weekly' | 'custom',
    weekdays: [] as string[],
    customDays: 1
  });
  const [reminderData, setReminderData] = useState({
    enabled: false,
    time: '09:00',
    type: 'notification' as 'notification' | 'email' | 'both',
    message: ''
  });
  const { toast } = useToast();
  const { toggleHabitCompletion, loading: completionLoading } = useHabitCompletion();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const { data: user } = await supabase.auth.getUser();
      if (!user.user) return;

      const today = new Date().toISOString().split('T')[0];

      const [habitsRes, goalsRes] = await Promise.all([
        supabase
          .from('habits')
          .select('*')
          .eq('user_id', user.user.id),
        supabase.from('goals').select('id, title').eq('user_id', user.user.id).eq('status', 'active')
      ]);

      if (habitsRes.data) {
        // Get today's habit logs separately
        const { data: todayLogs } = await supabase
          .from('habit_logs')
          .select('habit_id, status')
          .eq('user_id', user.user.id)
          .eq('date', today);

        const processedHabits = habitsRes.data.map(habit => ({
          ...habit,
          completed_today: todayLogs?.some(log => 
            log.habit_id === habit.id && log.status === 'done'
          ) || false,
          current_streak: habit.current_streak || 0,
          longest_streak: habit.longest_streak || 0,
          total_completions: habit.total_completions || 0
        }));
        setHabits(processedHabits);
      }
      
      setGoals(goalsRes.data || []);
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to load data',
        variant: 'destructive'
      });
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const { data: user } = await supabase.auth.getUser();
      if (!user.user) return;

      const habitData = {
        ...formData,
        user_id: user.user.id,
        linked_goal_id: formData.linked_goal_id === 'none' ? null : formData.linked_goal_id || null,
        schedule: scheduleData,
        reminder: reminderData.enabled ? reminderData : null
      };

      if (editingHabit) {
        await supabase
          .from('habits')
          .update(habitData)
          .eq('id', editingHabit.id);
      } else {
        await supabase
          .from('habits')
          .insert(habitData);
      }

      toast({
        title: 'Success',
        description: `Habit ${editingHabit ? 'updated' : 'created'} successfully`
      });

      setIsDialogOpen(false);
      setEditingHabit(null);
      setFormData({ title: '', linked_goal_id: '', is_active: true });
      await loadData();
      onDataChange?.();
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to save habit',
        variant: 'destructive'
      });
    }
  };

  const deleteHabit = async (habitId: string) => {
    try {
      await supabase.from('habits').delete().eq('id', habitId);
      toast({
        title: 'Success',
        description: 'Habit deleted successfully'
      });
      await loadData();
      onDataChange?.();
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to delete habit',
        variant: 'destructive'
      });
    }
  };

  const openEditDialog = (habit: HabitWithCompletion) => {
    setEditingHabit(habit);
    setFormData({
      title: habit.title,
      linked_goal_id: habit.linked_goal_id || '',
      is_active: habit.is_active
    });
    setScheduleData(habit.schedule || { frequency: 'daily', weekdays: [], customDays: 1 });
    setReminderData(habit.reminder || { enabled: false, time: '09:00', type: 'notification', message: '' });
    setIsDialogOpen(true);
  };

  const handleHabitToggle = async (habitId: string) => {
    const wasCompleted = await toggleHabitCompletion(habitId);
    
    // Update local state immediately
    setHabits(prev => prev.map(habit => 
      habit.id === habitId 
        ? { 
            ...habit, 
            completed_today: wasCompleted,
            current_streak: wasCompleted ? habit.current_streak + 1 : Math.max(0, habit.current_streak - 1),
            total_completions: wasCompleted ? habit.total_completions + 1 : Math.max(0, habit.total_completions - 1)
          }
        : habit
    ));
    
    // Reload accurate data and notify parent immediately
    await loadData();
    onDataChange?.();
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Habit Tracking</h2>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {habits.map((habit) => (
          <div key={habit.id} className="space-y-4">
            <HabitStreakTracker habit={habit} />
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-lg">{habit.title}</CardTitle>
                <div className="flex items-center space-x-2">
                  <Button
                    size="sm"
                    variant={habit.completed_today ? "default" : "outline"}
                    onClick={() => handleHabitToggle(habit.id)}
                    disabled={completionLoading}
                    className={habit.completed_today ? "bg-green-600 hover:bg-green-700" : ""}
                  >
                    <CheckCircle className="w-4 h-4 mr-1" />
                    {habit.completed_today ? 'Done' : 'Complete'}
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => openEditDialog(habit)}
                  >
                    <Edit className="w-4 h-4" />
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => deleteHabit(habit.id)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Current Streak</span>
                    <div className="flex items-center gap-1">
                      <Flame className="w-4 h-4 text-orange-500" />
                      <span className="font-bold text-orange-500">{habit.current_streak} days</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Total Completions</span>
                    <span className="font-medium">{habit.total_completions}</span>
                  </div>
                  {habit.linked_goal_id && (
                    <p className="text-sm text-muted-foreground">
                      Linked to goal: {goals.find(g => g.id === habit.linked_goal_id)?.title}
                    </p>
                  )}
                  <p className="text-sm">
                    Status: {habit.is_active ? 'Active' : 'Inactive'}
                  </p>
                  {habit.schedule && (
                    <p className="text-sm text-muted-foreground">
                      Schedule: {habit.schedule.frequency}
                      {habit.schedule.weekdays?.length > 0 && 
                        ` (${habit.schedule.weekdays.join(', ')})`
                      }
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        ))}
      </div>

      {/* Add Habit Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogTrigger asChild>
          <Button 
            className="fixed bottom-6 right-6 rounded-full w-14 h-14 shadow-lg"
            onClick={() => {
              setEditingHabit(null);
              setFormData({ title: '', linked_goal_id: '', is_active: true });
            }}
          >
            <Plus className="w-6 h-6" />
          </Button>
        </DialogTrigger>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{editingHabit ? 'Edit Habit' : 'Create New Habit'}</DialogTitle>
          </DialogHeader>
          <Tabs defaultValue="basic" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="basic">Basic</TabsTrigger>
              <TabsTrigger value="schedule">
                <Calendar className="w-4 h-4 mr-2" />
                Schedule
              </TabsTrigger>
              <TabsTrigger value="reminders">
                <Clock className="w-4 h-4 mr-2" />
                Reminders
              </TabsTrigger>
            </TabsList>

            <form onSubmit={handleSubmit} className="space-y-4">
              <TabsContent value="basic" className="space-y-4">
                <div>
                  <Label htmlFor="title">Habit Title</Label>
                  <Input
                    id="title"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    placeholder="e.g., Run 3 miles daily"
                    required
                  />
                </div>
                
                <div>
                  <Label htmlFor="goal">Link to Goal (Optional)</Label>
                  <Select
                    value={formData.linked_goal_id}
                    onValueChange={(value) => setFormData({ ...formData, linked_goal_id: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select a goal to link" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">No Goal</SelectItem>
                      {goals.map((goal) => (
                        <SelectItem key={goal.id} value={goal.id}>
                          {goal.title}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-center space-x-2">
                  <Switch
                    id="active"
                    checked={formData.is_active}
                    onCheckedChange={(checked) => setFormData({ ...formData, is_active: checked })}
                  />
                  <Label htmlFor="active">Active</Label>
                </div>
              </TabsContent>

              <TabsContent value="schedule">
                <HabitScheduleForm
                  schedule={scheduleData}
                  onChange={setScheduleData}
                />
              </TabsContent>

              <TabsContent value="reminders">
                <HabitReminderForm
                  reminder={reminderData}
                  onChange={setReminderData}
                />
              </TabsContent>

              <div className="flex justify-end space-x-2 pt-4">
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit">
                  {editingHabit ? 'Update' : 'Create'} Habit
                </Button>
              </div>
            </form>
          </Tabs>
        </DialogContent>
      </Dialog>
    </div>
  );
}