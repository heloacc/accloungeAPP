import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Plus, Target, CheckCircle, Circle, Flame } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';
import { useHabitCompletion, HabitWithCompletion } from '@/hooks/useHabitCompletion';
import HabitManager from './HabitManager';
import GoalManager from './GoalManager';

interface Goal {
  id: string;
  title: string;
  description?: string;
  completion_percent: number;
  status: string;
  target_date?: string;
  goal_tasks?: Array<{
    id: string;
    title: string;
    type: string;
    status: string;
    auto_config?: any;
  }>;
}

export default function UnifiedHabitsGoals() {
  const [habits, setHabits] = useState<HabitWithCompletion[]>([]);
  const [goals, setGoals] = useState<Goal[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();
  const { toggleHabitCompletion, loading: completionLoading } = useHabitCompletion();

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      const { data: user } = await supabase.auth.getUser();
      if (!user.user) return;

      const today = new Date().toISOString().split('T')[0];
      
      const [habitsRes, goalsRes] = await Promise.all([
        supabase
          .from('habits')
          .select('*')
          .eq('user_id', user.user.id)
          .eq('is_active', true),
        supabase
          .from('goals')
          .select(`
            *,
            goal_tasks(*)
          `)
          .eq('user_id', user.user.id)
          .in('status', ['active', 'paused'])
      ]);

      if (habitsRes.error) throw habitsRes.error;
      if (goalsRes.error) throw goalsRes.error;

      // Get today's habit logs separately
      const { data: todayLogs } = await supabase
        .from('habit_logs')
        .select('habit_id, status')
        .eq('user_id', user.user.id)
        .eq('date', today);

      // Process habits with completion status
      const processedHabits = (habitsRes.data || []).map(habit => ({
        ...habit,
        completed_today: todayLogs?.some(log => 
          log.habit_id === habit.id && log.status === 'done'
        ) || false,
        current_streak: habit.current_streak || 0,
        longest_streak: habit.longest_streak || 0,
        total_completions: habit.total_completions || 0
      }));

      setHabits(processedHabits);
      setGoals(goalsRes.data || []);
    } catch (error) {
      console.error('Error loading dashboard data:', error);
      toast({
        title: 'Error',
        description: 'Failed to load data',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  const handleHabitToggle = async (habitId: string) => {
    const wasCompleted = await toggleHabitCompletion(habitId);
    
    // Reload data immediately to get accurate stats from database
    await loadDashboardData();
  };

  if (loading) {
    return <div className="flex items-center justify-center p-8">Loading...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Habits & Goals</h1>
      </div>

      <Tabs defaultValue="dashboard" className="space-y-4">
        <TabsList>
          <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
          <TabsTrigger value="habits">Habits</TabsTrigger>
          <TabsTrigger value="goals">Goals</TabsTrigger>
        </TabsList>

        <TabsContent value="dashboard" className="space-y-6">
          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CheckCircle className="w-5 h-5" />
                  Today's Habits
                </CardTitle>
                <CardDescription>
                  {habits.filter(h => h.completed_today).length}/{habits.length} completed
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {habits.map((habit) => (
                  <div key={habit.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <Button
                        size="sm"
                        variant={habit.completed_today ? "default" : "outline"}
                        onClick={() => handleHabitToggle(habit.id)}
                        disabled={completionLoading}
                        className={habit.completed_today ? "bg-green-600 hover:bg-green-700" : ""}
                      >
                        <CheckCircle className="w-4 h-4" />
                      </Button>
                      <div>
                        <h3 className={`font-medium ${habit.completed_today ? 'line-through text-muted-foreground' : ''}`}>
                          {habit.title}
                        </h3>
                        {habit.linked_goal_id && (
                          <Badge variant="secondary" className="mt-1">
                            Linked to Goal
                          </Badge>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Flame className="w-4 h-4 text-orange-500" />
                      <span className="font-bold text-orange-500">{habit.current_streak}</span>
                    </div>
                  </div>
                ))}
                {habits.length === 0 && (
                  <p className="text-center text-muted-foreground py-4">
                    No active habits. Add one to get started!
                  </p>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="w-5 h-5" />
                  Active Goals
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {goals.map((goal) => (
                  <div key={goal.id} className="p-3 border rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-medium">{goal.title}</h3>
                      <Badge variant={goal.status === 'active' ? 'default' : 'secondary'}>
                        {goal.status}
                      </Badge>
                    </div>
                    <Progress value={goal.completion_percent} className="mb-2" />
                    <p className="text-sm text-muted-foreground">
                      {goal.completion_percent}% complete
                    </p>
                    {goal.goal_tasks && (
                      <div className="mt-2 space-y-1">
                        {goal.goal_tasks.slice(0, 3).map((task) => (
                          <div key={task.id} className="flex items-center gap-2 text-sm">
                            {task.status === 'done' ? (
                              <CheckCircle className="w-4 h-4 text-green-600" />
                            ) : (
                              <Circle className="w-4 h-4 text-gray-400" />
                            )}
                            <span className={task.status === 'done' ? 'line-through text-muted-foreground' : ''}>
                              {task.title}
                            </span>
                            {task.type === 'auto' && (
                              <Badge variant="outline" className="text-xs">
                                Auto
                              </Badge>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
                {goals.length === 0 && (
                  <p className="text-center text-muted-foreground py-4">
                    No active goals. Create one to track your progress!
                  </p>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="habits">
          <HabitManager onDataChange={loadDashboardData} />
        </TabsContent>

        <TabsContent value="goals">
          <GoalManager />
        </TabsContent>
      </Tabs>
    </div>
  );
}