import React, { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import HabitTracker from './HabitTracker';
import GoalTracker from './GoalTracker';

const TrackYourProgress = () => {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Track Your Progress</h1>
        <p className="text-gray-600 mt-2">Monitor your habits and goals to stay on track</p>
      </div>

      <Tabs defaultValue="habits" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="habits">Habits</TabsTrigger>
          <TabsTrigger value="goals">Goals</TabsTrigger>
        </TabsList>
        
        <TabsContent value="habits" className="mt-6">
          <HabitTracker />
        </TabsContent>
        
        <TabsContent value="goals" className="mt-6">
          <GoalTracker />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default TrackYourProgress;