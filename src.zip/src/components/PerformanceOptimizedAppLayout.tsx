import React, { useEffect, lazy, memo, Suspense } from 'react';
import { useAppContext } from '@/contexts/OptimizedAppContext';
import ResponsiveNavigation from './ResponsiveNavigation';
import FeatureProtectionWrapper from './FeatureProtectionWrapper';
import SystemHealthMonitor from './SystemHealthMonitor';
import StreamlinedAuth from './StreamlinedAuth';
import NotificationDisplay from '@/components/NotificationDisplay';
import { EnhancedPWAPrompt } from './EnhancedPWAPrompt';
import { Toaster } from '@/components/ui/toaster';
import LazyLoadWrapper from './LazyLoadWrapper';

// Lazy load heavy components
const RealDataDashboard = lazy(() => import('./RealDataDashboard'));
const UnifiedHabitsGoals = lazy(() => import('./UnifiedHabitsGoals'));
const AdminDashboard = lazy(() => import('./AdminDashboard'));
const EnhancedAnalytics = lazy(() => import('./EnhancedAnalytics'));
const AllGroupsManager = lazy(() => import('./AllGroupsManager'));
const UserManagement = lazy(() => import('./UserManagement'));

const MemoizedNavigation = memo(ResponsiveNavigation);
const MemoizedSystemHealth = memo(SystemHealthMonitor);

const PerformanceOptimizedAppLayout = memo(() => {
  const { activeTab, setActiveTab, currentUser, isLoading } = useAppContext();

  useEffect(() => {
    const handleNavigateToTab = (event: CustomEvent) => {
      const { tab, data } = event.detail;
      setActiveTab(tab, data);
    };

    window.addEventListener('navigate-to-tab', handleNavigateToTab as EventListener);
    
    return () => {
      window.removeEventListener('navigate-to-tab', handleNavigateToTab as EventListener);
    };
  }, [setActiveTab]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-acclounge-sage/10">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-acclounge-brown mx-auto mb-4"></div>
          <p className="text-acclounge-slate">Loading...</p>
        </div>
      </div>
    );
  }

  if (!currentUser) {
    return <StreamlinedAuth onSuccess={() => {}} />;
  }

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard': 
        return (
          <LazyLoadWrapper>
            <RealDataDashboard />
          </LazyLoadWrapper>
        );
      case 'habits-goals': 
        return (
          <LazyLoadWrapper>
            <UnifiedHabitsGoals />
          </LazyLoadWrapper>
        );
      case 'admin-dashboard': 
        return (
          <LazyLoadWrapper>
            <AdminDashboard />
          </LazyLoadWrapper>
        );
      default: 
        return (
          <LazyLoadWrapper>
            <RealDataDashboard />
          </LazyLoadWrapper>
        );
    }
  };

  return (
    <div className="flex min-h-screen bg-acclounge-sage/5">
      <FeatureProtectionWrapper featureName="Navigation">
        <MemoizedNavigation activeTab={activeTab} setActiveTab={setActiveTab} />
      </FeatureProtectionWrapper>
      
      <main className="flex-1 overflow-auto lg:ml-56 p-2 sm:p-3 lg:p-4">
        <div className="pt-16 lg:pt-4 w-full max-w-none">
          <div className="max-w-7xl mx-auto px-2 sm:px-4 lg:px-6">
            {currentUser?.isAdmin && (
              <div className="mb-4">
                <MemoizedSystemHealth showDetails={false} />
              </div>
            )}
            <Suspense fallback={<div>Loading content...</div>}>
              {renderContent()}
            </Suspense>
          </div>
        </div>
      </main>
      
      <FeatureProtectionWrapper featureName="Notifications">
        <NotificationDisplay />
      </FeatureProtectionWrapper>
      
      <FeatureProtectionWrapper featureName="PWA Prompt">
        <EnhancedPWAPrompt showOnLoad={true} />
      </FeatureProtectionWrapper>
      
      <Toaster />
    </div>
  );
});

PerformanceOptimizedAppLayout.displayName = 'PerformanceOptimizedAppLayout';

export default PerformanceOptimizedAppLayout;