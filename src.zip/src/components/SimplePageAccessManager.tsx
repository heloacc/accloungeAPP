import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Trash2, Plus, Lock } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { toast } from '@/components/ui/use-toast';

interface PageAccessRule {
  id: string;
  page_path: string;
  required_plan_id: string | null;
  is_premium_only: boolean;
  created_at: string;
  updated_at: string;
}

const SimplePageAccessManager: React.FC = () => {
  const [rules, setRules] = useState<PageAccessRule[]>([]);
  const [loading, setLoading] = useState(false);
  const [newRule, setNewRule] = useState({
    page_path: '',
    is_premium_only: false,
    required_plan_id: null
  });

  const loadRules = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('page_access_rules')
        .select('*')
        .order('page_path');

      if (error) throw error;
      setRules(data || []);
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const addRule = async () => {
    if (!newRule.page_path.trim()) {
      toast({
        title: "Error",
        description: "Page path is required",
        variant: "destructive"
      });
      return;
    }

    try {
      const { error } = await supabase
        .from('page_access_rules')
        .insert([{
          page_path: newRule.page_path.trim(),
          is_premium_only: newRule.is_premium_only,
          required_plan_id: newRule.required_plan_id
        }]);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Page access rule added"
      });

      setNewRule({
        page_path: '',
        is_premium_only: false,
        required_plan_id: null
      });

      loadRules();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    }
  };

  const deleteRule = async (id: string) => {
    try {
      const { error } = await supabase
        .from('page_access_rules')
        .delete()
        .eq('id', id);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Page access rule deleted"
      });

      loadRules();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    }
  };

  const togglePremiumOnly = async (id: string, currentValue: boolean) => {
    try {
      const { error } = await supabase
        .from('page_access_rules')
        .update({ is_premium_only: !currentValue })
        .eq('id', id);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Page access rule updated"
      });

      loadRules();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    }
  };

  useEffect(() => {
    loadRules();
  }, []);

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Lock className="h-5 w-5" />
            Add New Page Access Rule
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <Label htmlFor="page-path">Page Path</Label>
              <Input
                id="page-path"
                placeholder="/admin, /premium-features, etc."
                value={newRule.page_path}
                onChange={(e) => setNewRule({ ...newRule, page_path: e.target.value })}
              />
            </div>
            <div className="flex items-center space-x-2">
              <Switch
                id="premium-only"
                checked={newRule.is_premium_only}
                onCheckedChange={(checked) => setNewRule({ ...newRule, is_premium_only: checked })}
              />
              <Label htmlFor="premium-only">Premium Only</Label>
            </div>
            <Button onClick={addRule} className="w-full">
              <Plus className="h-4 w-4 mr-2" />
              Add Rule
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Existing Page Access Rules</CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center py-4">Loading...</div>
          ) : rules.length === 0 ? (
            <div className="text-center py-4 text-muted-foreground">
              No page access rules configured
            </div>
          ) : (
            <div className="space-y-3">
              {rules.map((rule) => (
                <div key={rule.id} className="flex items-center justify-between p-4 border rounded-lg">
                  <div>
                    <h3 className="font-medium">{rule.page_path}</h3>
                    <div className="flex items-center gap-2 mt-1">
                      <Badge variant={rule.is_premium_only ? "default" : "secondary"}>
                        {rule.is_premium_only ? "Premium Only" : "Standard Access"}
                      </Badge>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Switch
                      checked={rule.is_premium_only}
                      onCheckedChange={() => togglePremiumOnly(rule.id, rule.is_premium_only)}
                    />
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => deleteRule(rule.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default SimplePageAccessManager;