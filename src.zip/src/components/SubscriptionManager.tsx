import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { CreditCard, Crown, Check } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAppContext } from '@/contexts/AppContext';
import { toast } from '@/components/ui/use-toast';
import SubscriptionCancellation from '@/components/SubscriptionCancellation';

interface SubscriptionPlan {
  id: string;
  name: string;
  price: number;
  features: string[];
}

interface UserSubscription {
  id: string;
  plan_name: string;
  status: string;
  current_period_end: string;
}

export default function SubscriptionManager() {
  const { currentUser } = useAppContext();
  const [plans, setPlans] = useState<SubscriptionPlan[]>([]);
  const [currentSubscription, setCurrentSubscription] = useState<UserSubscription | null>(null);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      // Load subscription plans
      const { data: plansData } = await supabase
        .from('subscription_plans')
        .select('*')
        .eq('is_active', true);

      // Load current user subscription
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        const { data: subData } = await supabase.functions.invoke('subscription-management', {
          body: { action: 'get_subscription_status', userId: user.id }
        });
        
        setCurrentSubscription(subData?.subscription);
      }

      setPlans(plansData || []);
    } catch (error) {
      toast({
        title: "Error loading subscription data",
        description: error instanceof Error ? error.message : "Unknown error",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSubscribe = async (plan: SubscriptionPlan) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data } = await supabase.functions.invoke('subscription-management', {
        body: {
          action: 'create_checkout_session',
          priceId: plan.stripe_price_id,
          userId: user.id,
          email: user.email,
          successUrl: `${window.location.origin}/subscription-success`,
          cancelUrl: `${window.location.origin}/subscription`
        }
      });

      if (data?.url) {
        window.location.href = data.url;
      }
    } catch (error) {
      toast({
        title: "Error creating checkout session",
        description: error instanceof Error ? error.message : "Unknown error",
        variant: "destructive"
      });
    }
  };

  const handleCancelSubscription = async () => {
    if (!currentSubscription) return;

    try {
      await supabase.functions.invoke('subscription-management', {
        body: {
          action: 'cancel_subscription',
          subscriptionId: currentSubscription.id
        }
      });

      toast({
        title: "Subscription canceled",
        description: "Your subscription will end at the current billing period."
      });

      loadData();
    } catch (error) {
      toast({
        title: "Error canceling subscription",
        description: error instanceof Error ? error.message : "Unknown error",
        variant: "destructive"
      });
    }
  };

  if (loading) return <div>Loading...</div>;

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">Subscription Management</h2>
      
      {currentSubscription && (
        <Card>
          <CardHeader>
            <CardTitle>Current Subscription</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex justify-between items-center">
              <div>
                <p className="font-semibold">{currentSubscription.subscription_plans?.name}</p>
                <p className="text-sm text-muted-foreground">
                  Status: <Badge>{currentSubscription.status}</Badge>
                </p>
                {currentSubscription.current_period_end && (
                  <p className="text-sm">
                    Next billing: {new Date(currentSubscription.current_period_end).toLocaleDateString()}
                  </p>
                )}
              </div>
              {currentSubscription.status === 'active' && (
                <Button variant="outline" onClick={handleCancelSubscription}>
                  Cancel Subscription
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {plans.map((plan) => (
          <Card key={plan.id} className="relative">
            <CardHeader>
              <CardTitle>{plan.name}</CardTitle>
              <div className="text-2xl font-bold">
                ${plan.price_monthly}/month
              </div>
              {plan.price_yearly > 0 && (
                <div className="text-sm text-muted-foreground">
                  ${plan.price_yearly}/year (save 20%)
                </div>
              )}
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 mb-4">
                {plan.features.map((feature, index) => (
                  <li key={index} className="text-sm">✓ {feature}</li>
                ))}
              </ul>
              <Button 
                onClick={() => handleSubscribe(plan)}
                className="w-full"
                disabled={currentSubscription?.subscription_plans?.id === plan.id}
              >
                {currentSubscription?.subscription_plans?.id === plan.id ? 'Current Plan' : 'Subscribe'}
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      {currentSubscription && currentSubscription.status === 'active' && (
        <SubscriptionCancellation />
      )}
    </div>
  );
}