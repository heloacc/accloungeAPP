import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ChevronDown, ChevronRight } from 'lucide-react';

interface NavigationItemProps {
  item: any;
  isSubItem?: boolean;
  activeTab: string;
  onItemClick: (itemId: string) => void;
  onDropdownToggle?: (itemId: string) => void;
  isDropdownOpen?: boolean;
  isMobile?: boolean;
}

const NavigationItem = ({ 
  item, 
  isSubItem = false, 
  activeTab, 
  onItemClick, 
  onDropdownToggle,
  isDropdownOpen = false,
  isMobile = false
}: NavigationItemProps) => {
  const Icon = item.icon;
  const isActive = activeTab === item.id || (item.subItems && item.subItems.some((sub: any) => sub.id === activeTab));
  const isAdminItem = item.id === 'admin-notifications' || item.id === 'admin-dashboard' || item.id === 'all-groups-manager' || item.id === 'post-recovery';
  const hasDropdown = item.subItems && (item.id === 'community' || (item.id === 'admin-dashboard' && item.subItems));
  
  return (
    <div>
      <Button
        variant={isActive ? "secondary" : "ghost"}
        className={`w-full justify-start text-left transition-all duration-200 ${
          isActive 
            ? 'bg-[#623822] text-white shadow-md' 
            : 'text-gray-700 hover:text-gray-900 hover:bg-gray-100 hover:shadow-sm'
        } ${isAdminItem ? 'border border-yellow-600/30' : ''} ${
          isSubItem 
            ? `ml-4 ${isMobile ? 'text-xs py-1.5' : 'text-sm py-2'}` 
            : `${isMobile ? 'py-2.5 text-sm' : 'py-3'}`
        }`}
        onClick={() => {
          if (hasDropdown && onDropdownToggle) {
            onDropdownToggle(item.id);
          } else {
            onItemClick(item.id);
          }
        }}
      >
        <Icon className={`mr-3 ${isSubItem ? 'h-3 w-3' : 'h-4 w-4'}`} />
        <span className="truncate">{item.label}</span>
        {hasDropdown && (
          <div className="ml-auto">
            {isDropdownOpen ? (
              <ChevronDown className="h-4 w-4" />
            ) : (
              <ChevronRight className="h-4 w-4" />
            )}
          </div>
        )}
        {isAdminItem && !hasDropdown && (
          <Badge className="ml-auto bg-yellow-600 text-white text-xs">
            Admin
          </Badge>
        )}
      </Button>
      
      {item.subItems && isDropdownOpen && (
        <div className={`mt-1 animate-in slide-in-from-top-2 duration-200 ${isMobile ? 'space-y-0.5' : 'space-y-1'}`}>
          {item.subItems.map((subItem: any) => (
            <NavigationItem
              key={subItem.id}
              item={subItem}
              isSubItem={true}
              activeTab={activeTab}
              onItemClick={onItemClick}
              isMobile={isMobile}
            />
          ))}
        </div>
      )}
    </div>
  );
};
export default NavigationItem;