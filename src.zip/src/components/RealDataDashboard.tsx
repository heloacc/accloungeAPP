import React, { useState, useEffect } from 'react';
import { useAppContext } from '@/contexts/OptimizedAppContext';
import { supabase } from '@/lib/supabase';
import { useHabitCompletion } from '@/hooks/useHabitCompletion';
import { MomentumSnapshot } from './MomentumSnapshot';
import { TodaysHabits } from './TodaysHabits';
import { GoalsProgress } from './GoalsProgress';
import { CommunityFeed } from './CommunityFeed';
import { DynamicCoachTips } from './DynamicCoachTips';
import { PersonalCheckIns } from './PersonalCheckIns';
import { AchievementsBadges } from './AchievementsBadges';
import { QuickActions } from './QuickActions';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Shield, Crown, Users, Database } from 'lucide-react';
const HERO_IMAGE = "https://d64gsuwffb70l.cloudfront.net/6887c9d1316b64cdd5d4aa13_1756446071451_a0b23b0f.webp";
const BADGE_IMAGES = [
  "https://d64gsuwffb70l.cloudfront.net/6887c9d1316b64cdd5d4aa13_1756446075867_8c332485.webp",
  "https://d64gsuwffb70l.cloudfront.net/6887c9d1316b64cdd5d4aa13_1756446077643_1c005897.webp",
  "https://d64gsuwffb70l.cloudfront.net/6887c9d1316b64cdd5d4aa13_1756446079606_7a8227d6.webp",
  "https://d64gsuwffb70l.cloudfront.net/6887c9d1316b64cdd5d4aa13_1756446081472_9b590a34.webp"
];

export const RealDataDashboard: React.FC = () => {
  const { currentUser, setActiveTab } = useAppContext();
  const { toggleHabitCompletion, loading: habitLoading } = useHabitCompletion();
  const [habits, setHabits] = useState([]);
  const [goals, setGoals] = useState([]);
  const [loading, setLoading] = useState(true);
  const [streakDays, setStreakDays] = useState(0);
  const [consistencyScore, setConsistencyScore] = useState(0);
  
  // Listen for habit completion events to update in real-time
  useEffect(() => {
    const handleHabitCompleted = (event: CustomEvent) => {
      const { habitId, completed } = event.detail;
      
      // Update habits state immediately
      setHabits(prevHabits => {
        const updatedHabits = prevHabits.map(h => 
          h.id === habitId ? { ...h, completed } : h
        );
        
        // Recalculate consistency score
        const totalHabits = updatedHabits.length;
        const completedToday = updatedHabits.filter(h => h.completed).length;
        const newConsistencyScore = totalHabits > 0 ? Math.round((completedToday / totalHabits) * 100) : 0;
        setConsistencyScore(newConsistencyScore);
        
        return updatedHabits;
      });
      
      // Refresh full data after a short delay to get updated streaks
      setTimeout(() => {
        fetchUserData();
      }, 500);
    };

    window.addEventListener('habitCompleted', handleHabitCompleted as EventListener);
    return () => window.removeEventListener('habitCompleted', handleHabitCompleted as EventListener);
  }, []);

  useEffect(() => {
    if (currentUser?.id) {
      fetchUserData();
    } else {
      setLoading(false);
    }
  }, [currentUser, fetchUserData]);

  const fetchUserData = useCallback(async () => {
    if (!currentUser?.id) {
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      
      // Reduced timeout to prevent long loading states
      const timeoutId = setTimeout(() => {
        // Removed console.log to reduce noise
        setHabits([]);
        setGoals([]);
        setStreakDays(0);
        setConsistencyScore(0);
        setLoading(false);
      }, 3000); // Reduced to 3 seconds
      
      const today = new Date().toISOString().split('T')[0];
      
      // Fetch habits with today's completion status
      const [habitsRes, goalsRes, completionsRes] = await Promise.all([
        supabase
          .from('habits')
          .select('id, title, current_streak, is_active, user_id, linked_goal_id')
          .eq('user_id', currentUser.id)
          .eq('is_active', true)
          .limit(10),
        supabase
          .from('goals')
          .select('id, title, target_date, status, user_id, updated_at')
          .eq('user_id', currentUser.id)
          .eq('status', 'active')
          .limit(10),
        // Load today's completions from habit_logs
        supabase
          .from('habit_logs')
          .select('habit_id, status')
          .eq('user_id', currentUser.id)
          .eq('date', today)
          .eq('status', 'done')
      ]);

      clearTimeout(timeoutId);

      // Create completion status map
      const completionMap = new Map();
      if (completionsRes.data) {
        completionsRes.data.forEach(log => {
          completionMap.set(log.habit_id, true);
        });
      }

      // Handle habits data with actual completion status
      if (habitsRes.data && !habitsRes.error) {
        const goalsData = goalsRes.data || [];
        
        const formattedHabits = habitsRes.data.map(habit => {
          const linkedGoal = goalsData.find(g => g.id === habit.linked_goal_id);
          
          return {
            id: habit.id,
            title: habit.title,
            current_streak: habit.current_streak || 0,
            done_today: completionMap.get(habit.id) || false, // Use actual completion status
            linked_goal_id: habit.linked_goal_id,
            linked_goal_title: linkedGoal?.title || null
          };
        });
        
        setHabits(formattedHabits);
        
        // Calculate max streak from all habits
        const maxStreak = Math.max(...formattedHabits.map(h => h.current_streak), 0);
        setStreakDays(maxStreak);
        
        // Calculate actual consistency score based on completed habits
        const completedCount = formattedHabits.filter(h => h.done_today).length;
        const totalHabits = formattedHabits.length;
        setConsistencyScore(totalHabits > 0 ? Math.round((completedCount / totalHabits) * 100) : 0);
      } else {
        setHabits([]);
        setStreakDays(0);
        setConsistencyScore(0);
      }
      // Handle goals data - simplified
      if (goalsRes.data && !goalsRes.error) {
        const formattedGoals = goalsRes.data.map(goal => ({
          id: goal.id,
          title: goal.title,
          progress_percent: 25, // Default progress
          state: 'active',
          target_date: goal.target_date,
          recent_activity: false
        }));
        setGoals(formattedGoals);
      } else {
        setGoals([]);
      }
    } catch (error) {
      console.error('Error fetching user data:', error);
      // Set fallback data on error
      setHabits([]);
      setGoals([]);
      setStreakDays(0);
      setConsistencyScore(0);
    } finally {
      setLoading(false);
    }
  }, [currentUser]);
  const handleToggleHabit = async (habitId: string) => {
    try {
      // Prevent multiple rapid toggles
      if (habitLoading) return;

      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const today = new Date().toISOString().split('T')[0];
      
      // Check current completion status from database first
      const { data: existingLog } = await supabase
        .from('habit_logs')
        .select('status')
        .eq('habit_id', habitId)
        .eq('user_id', user.id)
        .eq('date', today)
        .single();

      const currentlyCompleted = existingLog?.status === 'done';
      const newStatus = currentlyCompleted ? 'missed' : 'done';
      const newDoneToday = newStatus === 'done';

      // Optimistically update UI first for immediate feedback
      const updatedHabits = habits.map(h => {
        if (h.id === habitId) {
          return { ...h, done_today: newDoneToday };
        }
        return h;
      });
      
      setHabits(updatedHabits);

      // Recalculate consistency score using done_today
      const totalHabits = updatedHabits.length;
      const completedToday = updatedHabits.filter(h => h.done_today).length;
      const newConsistencyScore = totalHabits > 0 ? Math.round((completedToday / totalHabits) * 100) : 0;
      setConsistencyScore(newConsistencyScore);

      // Upsert habit log in database
      const { error: logError } = await supabase
        .from('habit_logs')
        .upsert({
          habit_id: habitId,
          user_id: user.id,
          date: today,
          status: newStatus
        }, {
          onConflict: 'habit_id,user_id,date'
        });

      if (logError) throw logError;

      // Recalculate streak and update habits table
      await recalculateHabitStats(habitId, user.id);
      
      // Refresh data after a shorter delay to get accurate streak info from database
      setTimeout(() => {
        fetchUserData();
      }, 500);

    } catch (error) {
      console.error('Error toggling habit:', error);
      // Revert optimistic update on error
      fetchUserData();
    }
  };

  // Add the recalculateHabitStats function from UnifiedHabitTracker
  const recalculateHabitStats = async (habitId: string, userId: string) => {
    try {
      // Get all habit logs for this habit, ordered by date
      const { data: logs } = await supabase
        .from('habit_logs')
        .select('date, status')
        .eq('habit_id', habitId)
        .eq('user_id', userId)
        .order('date', { ascending: false }); // Order by date descending (newest first)

      if (!logs) return;

      // Calculate current streak (consecutive days from today backwards)
      const today = new Date().toISOString().split('T')[0];
      let currentStreak = 0;
      
      // Create a map for faster lookup
      const logMap = new Map(logs.map(log => [log.date, log.status]));
      
      // Start checking from today and go backwards
      let checkDate = new Date(today);
      
      while (true) {
        const dateStr = checkDate.toISOString().split('T')[0];
        const status = logMap.get(dateStr);
        
        if (status === 'done') {
          // Completed day - add to streak
          currentStreak++;
        } else if (status === 'missed') {
          // Explicitly missed day - break streak
          break;
        } else {
          // No log for this day
          if (dateStr === today) {
            // If today has no log, it means habit wasn't completed yet
            // Don't break streak, just move to previous day
          } else {
            // Gap in past days breaks the streak
            break;
          }
        }
        
        // Move to previous day
        checkDate.setDate(checkDate.getDate() - 1);
        
        // Prevent infinite loop (max 365 days back)
        if (currentStreak > 365 || checkDate < new Date('2020-01-01')) break;
      }

      // Calculate longest streak by going through all logs chronologically
      let longestStreak = 0;
      let tempStreak = 0;
      
      // Sort logs chronologically for longest streak calculation
      const chronologicalLogs = [...logs].reverse();
      
      for (const log of chronologicalLogs) {
        if (log.status === 'done') {
          tempStreak++;
          longestStreak = Math.max(longestStreak, tempStreak);
        } else {
          tempStreak = 0;
        }
      }

      // Calculate total completions
      const totalCompletions = logs.filter(l => l.status === 'done').length;

      // Update habit record
      await supabase
        .from('habits')
        .update({
          current_streak: currentStreak,
          longest_streak: Math.max(longestStreak, currentStreak),
          total_completions: totalCompletions
        })
        .eq('id', habitId);

    } catch (error) {
      console.error('Error recalculating habit stats:', error);
    }
  };

  // Mock data for components that don't have real data yet
  const feedItems = [
    { id: '1', userName: 'Community', achievement: 'Welcome to your dashboard!', timeAgo: 'now', emoji: '👋' }
  ];

  const groupSprints = [];

  const achievements = [
    { id: '1', name: 'Getting Started', icon: 'trophy', unlocked: true },
    { id: '2', name: 'First Goal', icon: 'target', unlocked: goals.length > 0 },
    { id: '3', name: 'Habit Builder', icon: 'users', unlocked: habits.length > 0 },
    { id: '4', name: 'Consistency Master', icon: 'star', unlocked: false, progress: consistencyScore, requirement: 'Maintain 80% consistency' }
  ];

  // FIXED: Dynamic coach messages based on user activity
  const getCoachMessage = () => {
    if (habits.length === 0) {
      return 'Start by adding your first habit to begin tracking your progress.';
    }
    
    const completedToday = habits.filter(h => h.done_today).length; // Use done_today
    const hasActiveStreak = streakDays > 0;
    
    if (completedToday === habits.length && hasActiveStreak) {
      return `Amazing! You've completed all habits today and have a ${streakDays}-day streak going!`;
    } else if (completedToday > 0) {
      return `Great progress! You've completed ${completedToday}/${habits.length} habits today.`;
    } else if (hasActiveStreak) {
      return `Don't break your ${streakDays}-day streak! Complete your habits today.`;
    } else {
      return 'Ready to build some momentum? Complete your first habit today!';
    }
  };

  const coachMessages = [
    {
      id: '1',
      from: 'Your Coach',
      message: getCoachMessage(),
      timeAgo: '1 day ago',
      type: 'coach' as const
    }
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-64">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-2"></div>
          <p className="text-sm text-muted-foreground">Loading your dashboard...</p>
        </div>
      </div>
    );
  }
  return (
    <div className="space-y-3 sm:space-y-4 lg:space-y-6 p-2 sm:p-0">
      {/* Momentum Spotlight - moved back to top */}
      <MomentumSnapshot 
        userName={currentUser?.full_name?.split(' ')[0] || currentUser?.name?.split(' ')[0] || "User"}
        streakDays={streakDays}
        consistencyScore={consistencyScore}
        backgroundImage={HERO_IMAGE}
      />
      
      {/* 1. Loungers tip section */}
      <DynamicCoachTips 
        habits={habits}
        goals={goals}
        streakDays={streakDays}
        consistencyScore={consistencyScore}
      />
      
      {/* 2. Today's Habit section */}
      <TodaysHabits habits={habits} onToggleHabit={handleToggleHabit} />
      
      {/* 3. Your goal in progress section */}
      <GoalsProgress goals={goals} />
      
      {/* 4. Personal check-ins */}
      <PersonalCheckIns 
        onUpgrade={() => setActiveTab('subscription')}
      />
      
      {/* 5. Your Wins */}
      <AchievementsBadges achievements={achievements} badgeImages={BADGE_IMAGES} />
      
      {/* 6. Check-in with others */}
      <CommunityFeed feedItems={feedItems} groupSprints={groupSprints} />
      
      {/* 7. Quick actions */}
      <QuickActions 
        onLogHabits={() => setActiveTab('habits-goals')}
        onAddGoal={() => setActiveTab('habits-goals')}
        onJoinGroup={() => setActiveTab('groups')}
        onInvitePartner={() => setActiveTab('find-partners')}
      />
    </div>
  );
};