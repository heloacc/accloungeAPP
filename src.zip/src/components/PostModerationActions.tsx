import { useState } from 'react';
import { supabase } from '@/lib/supabase';
import { Button } from '@/components/ui/button';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';
import { MoreVertical, Pin, PinOff, Trash2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface PostModerationActionsProps {
  postId: string;
  isPinned: boolean;
  groupId: string;
  userRole: string;
  isAdmin: boolean;
  onPostUpdated: () => void;
  onPostDeleted: () => void;
}

const PostModerationActions: React.FC<PostModerationActionsProps> = ({
  postId,
  isPinned,
  groupId,
  userRole,
  isAdmin,
  onPostUpdated,
  onPostDeleted
}) => {
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  // Only show moderation actions for admins or moderators
  const canModerate = isAdmin || userRole === 'Moderator' || userRole === 'Admin';

  if (!canModerate) return null;

  const handlePin = async () => {
    setLoading(true);
    try {
      const { error } = await supabase
        .from('acircle_posts')
        .update({ is_pinned: !isPinned })
        .eq('id', postId);

      if (error) throw error;

      toast({
        title: isPinned ? "Post Unpinned" : "Post Pinned",
        description: isPinned ? "Post removed from top of feed" : "Post pinned to top of feed"
      });

      onPostUpdated();
    } catch (error) {
      console.error('Error updating pin status:', error);
      toast({
        title: "Error",
        description: "Failed to update post pin status",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async () => {
    if (!confirm('Are you sure you want to delete this post? This action cannot be undone.')) {
      return;
    }

    setLoading(true);
    try {
      const { error } = await supabase
        .from('acircle_posts')
        .update({ recovery_status: 'deleted' })
        .eq('id', postId);

      if (error) throw error;

      toast({
        title: "Post Deleted",
        description: "Post has been removed from the feed"
      });

      onPostDeleted();
    } catch (error) {
      console.error('Error deleting post:', error);
      toast({
        title: "Error",
        description: "Failed to delete post",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="sm" disabled={loading}>
          <MoreVertical className="h-4 w-4" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        <DropdownMenuItem onClick={handlePin}>
          {isPinned ? (
            <>
              <PinOff className="h-4 w-4 mr-2" />
              Unpin Post
            </>
          ) : (
            <>
              <Pin className="h-4 w-4 mr-2" />
              Pin Post
            </>
          )}
        </DropdownMenuItem>
        <DropdownMenuItem onClick={handleDelete} className="text-red-600">
          <Trash2 className="h-4 w-4 mr-2" />
          Delete Post
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
};

export default PostModerationActions;