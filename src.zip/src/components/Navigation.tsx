import { useState, useEffect, useCallback } from 'react';
import { useAppContext } from '@/contexts/UnifiedAppContext';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/lib/supabase';
import { 
  Home, 
  Target, 
  Users, 
  Trophy, 
  BookOpen, 
  MessageCircle,
  Menu,
  X,
  CheckSquare,
  UserCheck,
  Heart,
  Megaphone,
  Hash,
  Star,
  ChevronDown,
  ChevronRight,
  LogOut,
  Shield,
  BarChart3,
  Bell,
  RefreshCw
} from 'lucide-react';

interface NavigationProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const Navigation = ({ activeTab, setActiveTab }: NavigationProps) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isCommunityDropdownOpen, setIsCommunityDropdownOpen] = useState(false);
  const [isTrackProgressDropdownOpen, setIsTrackProgressDropdownOpen] = useState(false);
  const [isAdminDropdownOpen, setIsAdminDropdownOpen] = useState(false);
  const [unreadNotifications, setUnreadNotifications] = useState(0);
  const { currentUser, signOut } = useAppContext();

  useEffect(() => {
    if (currentUser) {
      fetchUnreadNotifications();
    }
  }, [currentUser, fetchUnreadNotifications]);

  const fetchUnreadNotifications = useCallback(async () => {
    try {
      const { data, error } = await supabase
        .from('notifications')
        .select('id')
        .eq('user_id', currentUser?.id)
        .eq('read', false);

      if (error) throw error;
      setUnreadNotifications(data?.length || 0);
    } catch (error) {
      console.error('Error fetching notifications:', error);
    }
  }, [currentUser?.id]);

  const handleSignOut = async () => {
    try {
      await signOut();
    } catch (error) {
      console.error('Error signing out:', error);
      // Fallback: force reload to clear state
      window.location.reload();
    }
  };

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: Home },
    { 
      id: 'track-progress', 
      label: 'Track My Progress', 
      icon: BarChart3,
      subItems: [
        { id: 'habits', label: 'Habits', icon: Target },
        { id: 'goals', label: 'Goals', icon: CheckSquare }
      ]
    },
    { 
      id: 'community', 
      label: 'Community', 
      icon: Users,
      subItems: [
        { id: 'community-feed', label: 'Feed', icon: Users },
        { id: 'gather', label: 'Gather', icon: Hash },
        { id: 'wins-wall', label: 'Wins Wall', icon: Star }
      ]
    },
    { id: 'active-circle', label: 'Your Active Groups', icon: Users },
    { id: 'groups', label: 'Groups', icon: UserCheck },
    { id: 'partner-matching', label: 'Partner Match', icon: Heart },
    { id: 'achievements', label: 'Achievements', icon: Trophy },
    { id: 'notifications', label: 'Notifications', icon: Bell, notificationCount: unreadNotifications },
    { id: 'resources', label: 'Resources', icon: BookOpen },
    { id: 'ai-chat', label: 'AI Coach', icon: MessageCircle },
  ];

  // Add admin-only items
  if (currentUser?.isAdmin) {
    navItems.push(
      { id: 'post-recovery', label: 'Post Recovery', icon: RefreshCw },
      {
        id: 'admin-dashboard',
        label: 'Admin Dashboard',
        icon: Shield,
        subItems: [
          { id: 'admin-dashboard', label: 'Dashboard', icon: BarChart3 },
          { id: 'users', label: 'User Management', icon: Users },
          { id: 'admin-notifications', label: 'Active Circle', icon: Bell },
          { id: 'all-groups-manager', label: 'All Groups', icon: Users },
          { id: 'admin-tier-manager', label: 'Tier Management', icon: Shield },
          { id: 'member-momentum', label: 'Member Momentum', icon: BarChart3 },
          { id: 'admin-notifications-manager', label: 'Notification Management', icon: Bell }
        ]
      }
    );
  }
  const renderNavItem = (item: { 
    id: string; 
    label: string; 
    icon: React.ComponentType<{ className?: string }>; 
    subItems?: Array<{ id: string; label: string; icon: React.ComponentType<{ className?: string }> }>; 
    notificationCount?: number; 
  }, isSubItem = false) => {
    const Icon = item.icon;
    const isActive = activeTab === item.id || (item.subItems && item.subItems.some(sub => sub.id === activeTab));
    const isAdminItem = item.id === 'admin-notifications' || item.id === 'admin-dashboard' || item.id === 'all-groups-manager' || item.id === 'post-recovery' || item.id === 'admin-tier-manager' || item.id === 'member-momentum' || item.id === 'admin-notifications-manager' || item.id === 'users';
    const isCommunityItem = item.id === 'community';
    const isTrackProgressItem = item.id === 'track-progress';
    const isAdminDropdownItem = item.id === 'admin-dashboard' && item.subItems;
    
    return (
      <div key={item.id}>
        <Button
          variant={isActive ? "secondary" : "ghost"}
          className={`w-full justify-start text-left transition-all duration-300 transform ${
            isActive 
              ? 'bg-brown text-white shadow-lg scale-105' 
              : 'text-white hover:text-white hover:bg-brown/20 hover:shadow-md hover:scale-102'
          } ${isAdminItem ? 'border border-yellow-600/30' : ''} ${
            isSubItem ? 'ml-4 text-sm' : ''
          }`}
          onClick={() => {
            if (isCommunityItem) {
              setIsCommunityDropdownOpen(!isCommunityDropdownOpen);
            } else if (isTrackProgressItem) {
              setIsTrackProgressDropdownOpen(!isTrackProgressDropdownOpen);
            } else if (isAdminDropdownItem) {
              setIsAdminDropdownOpen(!isAdminDropdownOpen);
            } else {
              setActiveTab(item.id);
              setIsMobileMenuOpen(false);
            }
          }}
         >
           <Icon className="mr-3 h-4 w-4" />
           {item.label}
           {item.notificationCount > 0 && item.id === 'notifications' && (
             <Badge className="ml-auto bg-red-500 text-white text-xs min-w-[20px] h-5 flex items-center justify-center">
               {item.notificationCount}
             </Badge>
           )}
           {(isCommunityItem || isTrackProgressItem || isAdminDropdownItem) && (
             <div className="ml-auto">
               {(isCommunityItem && isCommunityDropdownOpen) || 
                (isTrackProgressItem && isTrackProgressDropdownOpen) ||
                (isAdminDropdownItem && isAdminDropdownOpen) ? (
                 <ChevronDown className="h-4 w-4" />
               ) : (
                 <ChevronRight className="h-4 w-4" />
               )}
             </div>
           )}
           {isAdminItem && !isAdminDropdownItem && (
             <Badge className="ml-auto bg-yellow-600 text-white text-xs">
               Admin
             </Badge>
           )}
         </Button>
        {item.subItems && isCommunityDropdownOpen && isCommunityItem && (
          <div className="mt-1 space-y-1">
            {item.subItems.map(subItem => renderNavItem(subItem, true))}
          </div>
        )}

        {item.subItems && isTrackProgressDropdownOpen && isTrackProgressItem && (
          <div className="mt-1 space-y-1">
            {item.subItems.map(subItem => renderNavItem(subItem, true))}
          </div>
        )}
        
        {item.subItems && isAdminDropdownOpen && isAdminDropdownItem && (
          <div className="mt-1 space-y-1">
            {item.subItems.map(subItem => renderNavItem(subItem, true))}
          </div>
        )}
      </div>
    );
  };

  return (
    <>
      <div className="md:hidden fixed top-4 left-4 z-50">
        <Button
          variant="outline"
          size="sm"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          className="bg-acclounge-dark text-white border-olive"
        >
          {isMobileMenuOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
        </Button>
      </div>

      <nav className="hidden md:flex flex-col w-64 bg-acclounge-dark p-6 min-h-screen border-r border-slate/20">
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-white mb-2">ACCLOUNGE</h1>
          <p className="text-gray-300 text-sm">Accountability Lounge</p>
          {currentUser?.isAdmin && (
            <Badge className="mt-2 bg-yellow-600 text-white text-xs">
              Admin
            </Badge>
          )}
        </div>
        <div className="space-y-2 flex-1">
          {navItems.map((item) => renderNavItem(item))}
        </div>
        
        <div className="mt-auto pt-4 border-t border-gray-600">
          <Button
            variant="ghost"
            className="w-full justify-start text-white hover:text-white hover:bg-red-600/20"
            onClick={handleSignOut}
          >
            <LogOut className="mr-3 h-4 w-4" />
            Sign Out
          </Button>
        </div>
      </nav>

      {isMobileMenuOpen && (
        <div className="md:hidden fixed inset-0 z-40 bg-acclounge-dark p-6">
          <div className="mt-16">
            <h1 className="text-2xl font-bold text-white mb-4">ACCLOUNGE</h1>
            {currentUser?.isAdmin && (
              <Badge className="mb-6 bg-yellow-600 text-white text-xs">
                Admin User
              </Badge>
            )}
            <div className="space-y-2 flex-1">
              {navItems.map((item) => renderNavItem(item))}
            </div>
            
            <div className="mt-8 pt-4 border-t border-gray-600">
              <Button
                variant="ghost"
                className="w-full justify-start text-white hover:text-white hover:bg-red-600/20"
                onClick={handleSignOut}
              >
                <LogOut className="mr-3 h-4 w-4" />
                Sign Out
              </Button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default Navigation;