import React, { useState, useEffect } from 'react';
import { useAppContext } from '@/contexts/OptimizedAppContext';
import { useOptimizedUserData } from '@/hooks/useOptimizedUserData';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { User, Bell, CreditCard, Settings, Shield, Trophy, Calendar, Target } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';
import NotificationConfigModal from './NotificationConfigModal';

const EnhancedUserProfile: React.FC = () => {
  const { currentUser } = useAppContext();
  const { userProfile, loading } = useOptimizedUserData();
  const [profile, setProfile] = useState({
    full_name: '',
    name: '',
    bio: ''
  });
  const [saving, setSaving] = useState(false);
  const [userStats, setUserStats] = useState({
    totalHabits: 0,
    activeStreaks: 0,
    longestStreak: 0,
    goalsCompleted: 0,
    totalPoints: 0,
    joinDate: new Date(),
    level: 'Member',
    achievements: [],
    isAdmin: false
  });
  const [notificationModal, setNotificationModal] = useState<{
    isOpen: boolean;
    type: 'email' | 'push';
  }>({
    isOpen: false,
    type: 'email'
  });
  const { toast } = useToast();

  // Load real user stats from database
  // Load real user stats from database
  useEffect(() => {
    const loadUserStats = async () => {
      if (!currentUser?.id) return;

      try {
        // Get basic profile data
        const { data: profileData } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', currentUser.id)
          .single();

        // Get habits count and streaks
        const { data: habitsData } = await supabase
          .from('habits')
          .select('id, current_streak')
          .eq('user_id', currentUser.id);

        // Get goals count and completion
        const { data: goalsData } = await supabase
          .from('goals')
          .select('id, status')
          .eq('user_id', currentUser.id);

        // Check admin status from user_roles table
        const { data: adminData } = await supabase
          .from('user_roles')
          .select('role')
          .eq('user_id', currentUser.id)
          .single();

        // Get momentum metrics for points calculation
        const { data: momentumData } = await supabase
          .from('momentum_metrics')
          .select('community_engagement_score, goals_completion_rate')
          .eq('user_id', currentUser.id)
          .single();

        if (profileData) {
          const habits = habitsData || [];
          const goals = goalsData || [];
          const activeStreaks = habits.filter(h => h.current_streak > 0).length;
          const longestStreak = habits.length > 0 ? Math.max(...habits.map(h => h.current_streak || 0)) : 0;
          const goalsCompleted = goals.filter(g => g.status === 'completed').length;
          
          // Calculate points from engagement score and completion rate
          const engagementScore = momentumData?.community_engagement_score || 0;
          const completionRate = parseFloat(momentumData?.goals_completion_rate || '0');
          const calculatedPoints = Math.round(engagementScore + (completionRate * 10));

          setUserStats({
            totalHabits: habits.length,
            activeStreaks,
            longestStreak,
            goalsCompleted,
            totalPoints: calculatedPoints,
            joinDate: new Date(profileData.created_at),
            level: adminData?.role === 'Admin' ? 'Admin' : profileData.subscription_tier || 'Member',
            achievements: activeStreaks > 0 ? ['Active Streaker'] : [],
            isAdmin: adminData?.role === 'Admin' || profileData.is_admin || false
          });
        }
      } catch (error) {
        console.error('Error loading user stats:', error);
      }
    };

    loadUserStats();
  }, [currentUser?.id]);

  useEffect(() => {
    if (userProfile) {
      setProfile({
        full_name: userProfile.full_name || userProfile.name || '',
        name: userProfile.name || '',
        bio: userProfile.bio || ''
      });
    }
  }, [userProfile]);

  const saveProfile = async () => {
    if (!currentUser?.id) return;

    try {
      setSaving(true);
      
      const { error } = await supabase
        .from('profiles')
        .update({
          name: profile.name,
          full_name: profile.full_name,
          bio: profile.bio
        })
        .eq('id', currentUser.id);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Profile updated successfully"
      });
    } catch (error) {
      console.error('Error saving profile:', error);
      toast({
        title: "Error",
        description: "Failed to save profile",
        variant: "destructive"
      });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-64">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p>Loading profile...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto p-4 space-y-6">
      {/* Profile Header */}
      <Card className="bg-gradient-to-r from-blue-50 to-purple-50">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row items-center gap-6">
            <Avatar className="h-24 w-24">
              <AvatarFallback className="text-2xl">
                {(profile.full_name || profile.name || currentUser?.name || 'U').charAt(0).toUpperCase()}
              </AvatarFallback>
            </Avatar>
            <div className="text-center md:text-left flex-1">
              <h1 className="text-3xl font-bold mb-2">
                {profile.full_name || currentUser?.name || 'User'}
              </h1>
              <p className="text-gray-600 mb-3">{profile.bio || 'Building momentum, one habit at a time.'}</p>
              <div className="flex flex-wrap gap-2 justify-center md:justify-start">
                <Badge className="bg-blue-600">
                  <Trophy className="h-3 w-3 mr-1" />
                  {userStats.level}
                </Badge>
                {userStats.isAdmin && (
                  <Badge className="bg-yellow-600">
                    <Shield className="h-3 w-3 mr-1" />
                    Admin
                  </Badge>
                )}
                <Badge variant="outline">
                  <Calendar className="h-3 w-3 mr-1" />
                  Joined {userStats.joinDate.toLocaleDateString()}
                </Badge>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4 text-center">
              <div>
                <div className="text-2xl font-bold text-blue-600">{userStats.totalPoints}</div>
                <div className="text-sm text-gray-600">Points</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-green-600">{userStats.longestStreak}</div>
                <div className="text-sm text-gray-600">Best Streak</div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Stats Overview */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <Target className="h-8 w-8 text-blue-600 mx-auto mb-2" />
            <div className="text-2xl font-bold">{userStats.totalHabits}</div>
            <div className="text-sm text-gray-600">Total Habits</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <Trophy className="h-8 w-8 text-green-600 mx-auto mb-2" />
            <div className="text-2xl font-bold">{userStats.activeStreaks}</div>
            <div className="text-sm text-gray-600">Active Streaks</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <Target className="h-8 w-8 text-purple-600 mx-auto mb-2" />
            <div className="text-2xl font-bold">{userStats.goalsCompleted}</div>
            <div className="text-sm text-gray-600">Goals Done</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <Trophy className="h-8 w-8 text-orange-600 mx-auto mb-2" />
            <div className="text-2xl font-bold">{userStats.achievements.length}</div>
            <div className="text-sm text-gray-600">Achievements</div>
          </CardContent>
        </Card>
      </div>

      {/* Profile Tabs */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <User className="h-5 w-5" />
            Profile Settings
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="profile" className="space-y-4">
            <TabsList className="grid w-full grid-cols-2 md:grid-cols-3">
              <TabsTrigger value="profile">Profile</TabsTrigger>
              <TabsTrigger value="achievements">Achievements</TabsTrigger>
              <TabsTrigger value="settings">Settings</TabsTrigger>
            </TabsList>

            <TabsContent value="profile" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="full_name">Full Name</Label>
                  <Input
                    id="full_name"
                    value={profile.full_name}
                    onChange={(e) => setProfile(prev => ({ ...prev, full_name: e.target.value }))}
                    placeholder="Enter your full name"
                  />
                </div>
                <div>
                  <Label htmlFor="name">Display Name</Label>
                  <Input
                    id="name"
                    value={profile.name}
                    onChange={(e) => setProfile(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="Enter display name"
                  />
                </div>
                <div className="md:col-span-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    value={currentUser?.email || ''}
                    disabled
                    className="bg-gray-50"
                  />
                </div>
                <div className="md:col-span-2">
                  <Label htmlFor="bio">Bio</Label>
                  <Input
                    id="bio"
                    value={profile.bio}
                    onChange={(e) => setProfile(prev => ({ ...prev, bio: e.target.value }))}
                    placeholder="Tell us about yourself"
                  />
                </div>
              </div>
              <Button onClick={saveProfile} disabled={saving}>
                {saving ? 'Saving...' : 'Save Profile'}
              </Button>
            </TabsContent>

            <TabsContent value="achievements" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {userStats.achievements.map((achievement, index) => (
                  <Card key={index} className="p-4">
                    <div className="flex items-center gap-3">
                      <Trophy className="h-8 w-8 text-yellow-600" />
                      <div>
                        <h3 className="font-semibold">{achievement}</h3>
                        <p className="text-sm text-gray-600">Unlocked</p>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="settings" className="space-y-4">
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Notification Preferences</h3>
                <div className="space-y-2">
                  <div className="flex items-center justify-between p-3 border rounded">
                    <span>Email notifications</span>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => setNotificationModal({ isOpen: true, type: 'email' })}
                    >
                      Configure
                    </Button>
                  </div>
                  <div className="flex items-center justify-between p-3 border rounded">
                    <span>Push notifications</span>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => setNotificationModal({ isOpen: true, type: 'push' })}
                    >
                      Configure
                    </Button>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* Notification Configuration Modal */}
      <NotificationConfigModal
        isOpen={notificationModal.isOpen}
        onClose={() => setNotificationModal({ isOpen: false, type: 'email' })}
        type={notificationModal.type}
      />
    </div>
  );
};

export default EnhancedUserProfile;