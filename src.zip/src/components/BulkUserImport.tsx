import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Upload, FileSpreadsheet, CheckCircle, XCircle, AlertCircle, Mail } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { toast } from '@/components/ui/use-toast';

interface ImportResult {
  email: string;
  status: 'success' | 'failed';
  error?: string;
  userId?: string;
}

interface ImportStats {
  total: number;
  successful: number;
  failed: number;
  results: ImportResult[];
}

const BulkUserImport: React.FC = () => {
  const [file, setFile] = useState<File | null>(null);
  const [csvData, setCsvData] = useState<any[]>([]);
  const [importing, setImporting] = useState(false);
  const [importStats, setImportStats] = useState<ImportStats | null>(null);
  const [progress, setProgress] = useState(0);
  const [sendEmails, setSendEmails] = useState(true);

  const parseCSV = (text: string) => {
    const lines = text.split('\n').filter(line => line.trim());
    if (lines.length < 2) return [];

    const headers = lines[0].split(',').map(h => h.trim().toLowerCase());
    const data = [];

    for (let i = 1; i < lines.length; i++) {
      const values = lines[i].split(',').map(v => v.trim());
      const row: any = {};
      
      headers.forEach((header, index) => {
        if (values[index]) {
          row[header] = values[index].replace(/^["']|["']$/g, '');
        }
      });

      // Map common column names
      if (row.name || row.full_name || row.username) {
        row.full_name = row.name || row.full_name || row.username;
      }
      if (row.email_address) {
        row.email = row.email_address;
      }

      if (row.email && row.full_name) {
        data.push(row);
      }
    }

    return data;
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const uploadedFile = event.target.files?.[0];
    if (!uploadedFile) return;

    setFile(uploadedFile);
    const reader = new FileReader();
    
    reader.onload = (e) => {
      const text = e.target?.result as string;
      const parsed = parseCSV(text);
      setCsvData(parsed);
      
      if (parsed.length === 0) {
        toast({
          title: "Invalid File",
          description: "No valid user data found. Ensure file has email and name columns.",
          variant: "destructive"
        });
      }
    };
    
    reader.readAsText(uploadedFile);
  };

  const startImport = async () => {
    if (csvData.length === 0) return;

    setImporting(true);
    setProgress(0);
    
    try {
      const { data: result, error } = await supabase.functions.invoke('admin-operations', {
        body: { 
          operation: 'bulk_import_users', 
          data: { users: csvData, sendEmails }
        }
      });
      if (error) throw error;
      
      setImportStats(result.data);
      setProgress(100);
      
      toast({
        title: "Import Complete",
        description: `${result.data.successful}/${result.data.total} users imported successfully`
      });
      
    } catch (error) {
      toast({
        title: "Import Failed",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setImporting(false);
    }
  };

  const resetImport = () => {
    setFile(null);
    setCsvData([]);
    setImportStats(null);
    setProgress(0);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Upload className="h-5 w-5" />
          Bulk User Import
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {!importStats ? (
          <>
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                Upload a CSV file with columns: email, name (or full_name), bio (optional), role (optional)
              </AlertDescription>
            </Alert>

            <div>
              <Label htmlFor="csv-file">CSV File</Label>
              <Input
                id="csv-file"
                type="file"
                accept=".csv,.txt"
                onChange={handleFileUpload}
                disabled={importing}
              />
            </div>

            {csvData.length > 0 && (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">
                    {csvData.length} users found
                  </span>
                  <Button onClick={resetImport} variant="outline" size="sm">
                    Clear
                  </Button>
                </div>

                <div className="max-h-40 overflow-y-auto border rounded p-2">
                  {csvData.slice(0, 5).map((user, index) => (
                    <div key={index} className="text-sm py-1">
                      <strong>{user.full_name}</strong> - {user.email}
                      {user.role && <Badge variant="outline" className="ml-2 text-xs">{user.role}</Badge>}
                    </div>
                  ))}
                  {csvData.length > 5 && (
                    <div className="text-xs text-muted-foreground">
                      ... and {csvData.length - 5} more
                    </div>
                  )}
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="send-emails"
                    checked={sendEmails}
                    onCheckedChange={setSendEmails}
                  />
                  <Label htmlFor="send-emails" className="text-sm flex items-center gap-1">
                    <Mail className="h-3 w-3" />
                    Send welcome emails to imported users
                  </Label>
                </div>

                {importing && (
                  <div className="space-y-2">
                    <Progress value={progress} />
                    <p className="text-sm text-center">Importing users...</p>
                  </div>
                )}

                <Button 
                  onClick={startImport} 
                  disabled={importing || csvData.length === 0}
                  className="w-full"
                >
                  <FileSpreadsheet className="h-4 w-4 mr-2" />
                  {importing ? 'Importing...' : `Import ${csvData.length} Users`}
                </Button>
              </div>
            )}
          </>
        ) : (
          <div className="space-y-4">
            <div className="text-center">
              <h3 className="text-lg font-semibold">Import Complete</h3>
              <div className="flex justify-center gap-4 mt-2">
                <div className="flex items-center gap-1 text-green-600">
                  <CheckCircle className="h-4 w-4" />
                  {importStats.successful} successful
                </div>
                <div className="flex items-center gap-1 text-red-600">
                  <XCircle className="h-4 w-4" />
                  {importStats.failed} failed
                </div>
              </div>
            </div>

            {importStats.failed > 0 && (
              <div className="max-h-40 overflow-y-auto border rounded p-2">
                <h4 className="font-medium text-sm mb-2">Failed Imports:</h4>
                {importStats.results
                  .filter(r => r.status === 'failed')
                  .map((result, index) => (
                    <div key={index} className="text-sm py-1 text-red-600">
                      {result.email}: {result.error}
                    </div>
                  ))}
              </div>
            )}

            <Button onClick={resetImport} className="w-full">
              Import More Users
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default BulkUserImport;