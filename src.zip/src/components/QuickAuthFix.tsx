import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { supabase } from '@/lib/supabase';

export default function QuickAuthFix() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState('');
  const [connectionTest, setConnectionTest] = useState('');

  const testConnection = async () => {
    setConnectionTest('Testing...');
    try {
      // Test basic connection
      const { data, error } = await supabase.from('users').select('count').limit(1);
      if (error) {
        setConnectionTest(`Connection Error: ${error.message}`);
      } else {
        setConnectionTest('✅ Database connection successful');
      }
    } catch (err: any) {
      setConnectionTest(`Connection Failed: ${err.message}`);
    }
  };

  const testLogin = async () => {
    if (!email || !password) {
      setResult('Please enter email and password');
      return;
    }
    
    setLoading(true);
    setResult('');
    
    try {
      console.log('Attempting login with:', { email, url: 'https://sxoshewvwyhxlavbtgog.supabase.co' });
      
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });
      
      if (error) {
        setResult(`❌ Login Error: ${error.message}`);
        console.error('Login error details:', error);
      } else {
        setResult('✅ Login successful!');
        console.log('Login success:', data);
      }
    } catch (err: any) {
      setResult(`❌ Unexpected Error: ${err.message}`);
      console.error('Unexpected login error:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle>🔧 Auth Quick Fix</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Button onClick={testConnection} className="w-full" variant="outline">
            Test Database Connection
          </Button>
          {connectionTest && (
            <p className="text-sm p-2 bg-gray-100 rounded">{connectionTest}</p>
          )}
          
          <div className="border-t pt-4">
            <h3 className="font-medium mb-3">Test Login</h3>
            <Input
              type="email"
              placeholder="Your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
            <Input
              type="password"
              placeholder="Your password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="mt-2"
            />
            <Button 
              onClick={testLogin} 
              className="w-full mt-3" 
              disabled={loading}
            >
              {loading ? 'Testing Login...' : 'Test Login'}
            </Button>
          </div>
          
          {result && (
            <p className="text-sm p-2 bg-gray-100 rounded">{result}</p>
          )}
          
          <div className="text-xs text-gray-500 mt-4">
            <p>URL: https://sxoshewvwyhxlavbtgog.supabase.co</p>
            <p>Key: eyJhbGciOiJIUzI1NiIs...</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}