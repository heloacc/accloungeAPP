import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { supabase } from '@/lib/supabase';
import { Plus, CheckCircle, Calendar } from 'lucide-react';
import { format } from 'date-fns';

interface Assignment {
  id: string;
  goal: {
    title: string;
    description: string;
  };
  status: string;
}

interface Task {
  id: string;
  title: string;
  description: string;
  completed: boolean;
  due_date: string;
  points: number;
  assignment_id: string;
}

interface MemberTaskManagerProps {
  groupId: string;
  userId: string;
}

export function MemberTaskManager({ groupId, userId }: MemberTaskManagerProps) {
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [selectedAssignment, setSelectedAssignment] = useState('');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [newTask, setNewTask] = useState({
    title: '',
    description: '',
    due_date: '',
    points: 1
  });

  useEffect(() => {
    fetchAssignments();
    fetchTasks();
  }, [groupId, userId]);

  const fetchAssignments = async () => {
    try {
      const { data, error } = await supabase
        .from('acircle_goal_assignments')
        .select(`
          id,
          status,
          acircle_group_goals(title, description)
        `)
        .eq('group_id', groupId)
        .eq('assigned_to', userId)
        .eq('status', 'active');

      if (error) throw error;
      setAssignments(data?.map(a => ({
        id: a.id,
        goal: a.acircle_group_goals,
        status: a.status
      })) || []);
    } catch (error) {
      console.error('Error fetching assignments:', error);
    }
  };

  const fetchTasks = async () => {
    try {
      const { data, error } = await supabase
        .from('acircle_member_tasks')
        .select('*')
        .eq('member_id', userId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setTasks(data || []);
    } catch (error) {
      console.error('Error fetching tasks:', error);
    }
  };

  const createTask = async () => {
    if (!selectedAssignment || !newTask.title) return;

    try {
      const { error } = await supabase
        .from('acircle_member_tasks')
        .insert({
          assignment_id: selectedAssignment,
          member_id: userId,
          title: newTask.title,
          description: newTask.description,
          due_date: newTask.due_date,
          points: newTask.points
        });

      if (error) throw error;

      setNewTask({ title: '', description: '', due_date: '', points: 1 });
      setSelectedAssignment('');
      setIsDialogOpen(false);
      fetchTasks();
    } catch (error) {
      console.error('Error creating task:', error);
    }
  };

  const toggleTask = async (taskId: string, completed: boolean) => {
    try {
      const { error } = await supabase
        .from('acircle_member_tasks')
        .update({ 
          completed: !completed,
          completed_at: !completed ? new Date().toISOString() : null
        })
        .eq('id', taskId);

      if (error) throw error;

      // Update leaderboard points
      if (!completed) {
        const task = tasks.find(t => t.id === taskId);
        if (task) {
          await supabase.rpc('update_leaderboard_points', {
            group_id_param: groupId,
            user_id_param: userId,
            points_param: task.points
          });
        }
      }

      fetchTasks();
    } catch (error) {
      console.error('Error toggling task:', error);
    }
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <CheckCircle className="h-5 w-5 text-[#596D59]" />
            My Tasks
          </CardTitle>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button size="sm" variant="outline">
                <Plus className="h-4 w-4 mr-2" />
                Add Task
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create New Task</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label>Goal Assignment</Label>
                  <select
                    className="w-full p-2 border rounded"
                    value={selectedAssignment}
                    onChange={(e) => setSelectedAssignment(e.target.value)}
                  >
                    <option value="">Select assignment</option>
                    {assignments.map(assignment => (
                      <option key={assignment.id} value={assignment.id}>
                        {assignment.goal.title}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <Label htmlFor="title">Task Title</Label>
                  <Input
                    id="title"
                    value={newTask.title}
                    onChange={(e) => setNewTask({ ...newTask, title: e.target.value })}
                    placeholder="Enter task title"
                  />
                </div>
                <div>
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={newTask.description}
                    onChange={(e) => setNewTask({ ...newTask, description: e.target.value })}
                    placeholder="Task description"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="due_date">Due Date</Label>
                    <Input
                      id="due_date"
                      type="date"
                      value={newTask.due_date}
                      onChange={(e) => setNewTask({ ...newTask, due_date: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="points">Points</Label>
                    <Input
                      id="points"
                      type="number"
                      min="1"
                      value={newTask.points}
                      onChange={(e) => setNewTask({ ...newTask, points: parseInt(e.target.value) })}
                    />
                  </div>
                </div>
                <Button onClick={createTask} disabled={!selectedAssignment || !newTask.title}>
                  Create Task
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {tasks.map(task => (
            <div key={task.id} className="flex items-start gap-3 p-3 border rounded-lg">
              <Checkbox
                checked={task.completed}
                onCheckedChange={() => toggleTask(task.id, task.completed)}
                className="mt-1"
              />
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <h4 className={`font-medium ${task.completed ? 'line-through text-gray-500' : ''}`}>
                    {task.title}
                  </h4>
                  <Badge variant="secondary">{task.points} pts</Badge>
                </div>
                {task.description && (
                  <p className="text-sm text-gray-600 mb-2">{task.description}</p>
                )}
                {task.due_date && (
                  <div className="flex items-center gap-1 text-xs text-gray-500">
                    <Calendar className="h-3 w-3" />
                    Due {format(new Date(task.due_date), 'MMM d, yyyy')}
                  </div>
                )}
              </div>
            </div>
          ))}
          {tasks.length === 0 && (
            <p className="text-center text-gray-500 py-4">
              No tasks yet. Add tasks for your assigned goals!
            </p>
          )}
        </div>
      </CardContent>
    </Card>
  );
}