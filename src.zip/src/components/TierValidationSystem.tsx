import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, XCircle, AlertTriangle, RefreshCw } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { toast } from '@/components/ui/use-toast';

// Environment configuration
const VITE_STRIPE_PUBLISHABLE_KEY = ''; // Add your Stripe publishable key here
const VITE_SUPABASE_URL = ''; // Add your Supabase URL here
interface ValidationResult {
  category: string;
  status: 'success' | 'warning' | 'error';
  message: string;
  details?: string;
}

export default function TierValidationSystem() {
  const [validationResults, setValidationResults] = useState<ValidationResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [lastValidated, setLastValidated] = useState<Date | null>(null);

  useEffect(() => {
    runValidation();
  }, []);

  const runValidation = async () => {
    setLoading(true);
    const results: ValidationResult[] = [];

    try {
      // Validate subscription tiers
      await validateTiers(results);
      
      // Validate access rules
      await validateAccessRules(results);
      
      // Validate user assignments
      await validateUserAssignments(results);
      
      // Validate Stripe integration
      await validateStripeIntegration(results);

      setValidationResults(results);
      setLastValidated(new Date());
    } catch (error) {
      console.error('Validation error:', error);
      results.push({
        category: 'System',
        status: 'error',
        message: 'Validation system encountered an error',
        details: error instanceof Error ? error.message : 'Unknown error'
      });
      setValidationResults(results);
    } finally {
      setLoading(false);
    }
  };

  const validateTiers = async (results: ValidationResult[]) => {
    try {
      const { data: tiers, error } = await supabase
        .from('subscription_tiers')
        .select('*')
        .eq('is_active', true);

      if (error) throw error;

      const requiredTiers = ['Freemium', 'Accountability Essentials', 'All Access'];
      const foundTiers = tiers?.map(t => t.name) || [];
      
      // Check if all required tiers exist
      const missingTiers = requiredTiers.filter(rt => !foundTiers.includes(rt));
      
      if (missingTiers.length === 0) {
        results.push({
          category: 'Subscription Tiers',
          status: 'success',
          message: 'All required tiers are configured',
          details: `Found: ${foundTiers.join(', ')}`
        });
      } else {
        results.push({
          category: 'Subscription Tiers',
          status: 'error',
          message: 'Missing required tiers',
          details: `Missing: ${missingTiers.join(', ')}`
        });
      }

      // Check Stripe integration
      const tiersWithoutStripe = tiers?.filter(t => !t.stripe_product_id && t.price_monthly > 0) || [];
      
      if (tiersWithoutStripe.length === 0) {
        results.push({
          category: 'Stripe Integration',
          status: 'success',
          message: 'All paid tiers have Stripe product IDs'
        });
      } else {
        results.push({
          category: 'Stripe Integration',
          status: 'warning',
          message: 'Some paid tiers missing Stripe product IDs',
          details: `Tiers: ${tiersWithoutStripe.map(t => t.name).join(', ')}`
        });
      }

    } catch (error) {
      results.push({
        category: 'Subscription Tiers',
        status: 'error',
        message: 'Failed to validate subscription tiers',
        details: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  };

  const validateAccessRules = async (results: ValidationResult[]) => {
    try {
      const { data: rules, error } = await supabase
        .from('page_access_rules')
        .select('*')
        .eq('is_active', true);

      if (error) throw error;

      if (!rules || rules.length === 0) {
        results.push({
          category: 'Access Rules',
          status: 'warning',
          message: 'No access rules configured',
          details: 'Consider setting up route-based access control'
        });
      } else {
        results.push({
          category: 'Access Rules',
          status: 'success',
          message: `${rules.length} access rules configured`,
          details: `Routes protected: ${rules.map(r => r.route_path).join(', ')}`
        });
      }

    } catch (error) {
      results.push({
        category: 'Access Rules',
        status: 'error',
        message: 'Failed to validate access rules',
        details: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  };

  const validateUserAssignments = async (results: ValidationResult[]) => {
    try {
      const { data: profiles, error } = await supabase
        .from('profiles')
        .select('subscription_tier')
        .not('subscription_tier', 'is', null);

      if (error) throw error;

      const tierCounts = profiles?.reduce((acc: any, profile) => {
        acc[profile.subscription_tier] = (acc[profile.subscription_tier] || 0) + 1;
        return acc;
      }, {}) || {};

      if (Object.keys(tierCounts).length > 0) {
        results.push({
          category: 'User Assignments',
          status: 'success',
          message: 'Users have tier assignments',
          details: Object.entries(tierCounts)
            .map(([tier, count]) => `${tier}: ${count}`)
            .join(', ')
        });
      } else {
        results.push({
          category: 'User Assignments',
          status: 'warning',
          message: 'No users have tier assignments',
          details: 'All users will default to freemium'
        });
      }

    } catch (error) {
      results.push({
        category: 'User Assignments',
        status: 'error',
        message: 'Failed to validate user assignments',
        details: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  };

  const validateStripeIntegration = async (results: ValidationResult[]) => {
    try {
      // Check if Stripe environment variables are configured
      const hasStripeKeys = VITE_STRIPE_PUBLISHABLE_KEY && 
                           VITE_SUPABASE_URL;

      if (hasStripeKeys) {
        results.push({
          category: 'Environment',
          status: 'success',
          message: 'Stripe environment variables configured'
        });
      } else {
        results.push({
          category: 'Environment',
          status: 'warning',
          message: 'Stripe environment variables may not be configured',
          details: 'Check VITE_STRIPE_PUBLISHABLE_KEY and related variables'
        });
      }

    } catch (error) {
      results.push({
        category: 'Environment',
        status: 'error',
        message: 'Failed to validate environment configuration',
        details: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'success':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'warning':
        return <AlertTriangle className="h-5 w-5 text-yellow-500" />;
      case 'error':
        return <XCircle className="h-5 w-5 text-red-500" />;
      default:
        return null;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'success':
        return 'border-green-200 bg-green-50';
      case 'warning':
        return 'border-yellow-200 bg-yellow-50';
      case 'error':
        return 'border-red-200 bg-red-50';
      default:
        return 'border-gray-200';
    }
  };

  const successCount = validationResults.filter(r => r.status === 'success').length;
  const warningCount = validationResults.filter(r => r.status === 'warning').length;
  const errorCount = validationResults.filter(r => r.status === 'error').length;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold">Tier System Validation</h3>
          <p className="text-sm text-muted-foreground">
            Comprehensive validation of subscription tier configuration
          </p>
          {lastValidated && (
            <p className="text-xs text-muted-foreground mt-1">
              Last validated: {lastValidated.toLocaleString()}
            </p>
          )}
        </div>
        <Button onClick={runValidation} disabled={loading}>
          <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
          {loading ? 'Validating...' : 'Run Validation'}
        </Button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="border-green-200">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-green-600">{successCount}</div>
            <div className="text-sm text-muted-foreground">Passed</div>
          </CardContent>
        </Card>
        <Card className="border-yellow-200">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-yellow-600">{warningCount}</div>
            <div className="text-sm text-muted-foreground">Warnings</div>
          </CardContent>
        </Card>
        <Card className="border-red-200">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-red-600">{errorCount}</div>
            <div className="text-sm text-muted-foreground">Errors</div>
          </CardContent>
        </Card>
      </div>

      {/* Validation Results */}
      <div className="space-y-3">
        {validationResults.map((result, index) => (
          <Card key={index} className={getStatusColor(result.status)}>
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                {getStatusIcon(result.status)}
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h4 className="font-medium">{result.category}</h4>
                    <Badge variant={result.status === 'success' ? 'default' : 
                                  result.status === 'warning' ? 'secondary' : 'destructive'}>
                      {result.status}
                    </Badge>
                  </div>
                  <p className="text-sm text-gray-700 mb-1">{result.message}</p>
                  {result.details && (
                    <p className="text-xs text-gray-500">{result.details}</p>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}

        {validationResults.length === 0 && !loading && (
          <Card>
            <CardContent className="p-8 text-center">
              <p className="text-muted-foreground">
                Click "Run Validation" to check your tier system configuration
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}