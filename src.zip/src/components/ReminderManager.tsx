import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Button } from '@/components/ui/button';
import { Bell, Calendar, Target, Clock } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface ReminderSettings {
  habit_reminders: boolean;
  goal_reminders: boolean;
  weekly_reviews: boolean;
  monthly_reviews: boolean;
}

export default function ReminderManager() {
  const [settings, setSettings] = useState<ReminderSettings>({
    habit_reminders: true,
    goal_reminders: true,
    weekly_reviews: true,
    monthly_reviews: true
  });
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('profiles')
        .select('reminder_settings')
        .eq('id', user.id)
        .single();

      if (error) throw error;
      
      if (data?.reminder_settings) {
        setSettings({ ...settings, ...data.reminder_settings });
      }
    } catch (error) {
      console.error('Error loading reminder settings:', error);
    }
  };

  const updateSettings = async (key: keyof ReminderSettings, value: boolean) => {
    try {
      setLoading(true);
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const newSettings = { ...settings, [key]: value };
      setSettings(newSettings);

      const { error } = await supabase
        .from('profiles')
        .update({ reminder_settings: newSettings })
        .eq('id', user.id);

      if (error) throw error;

      toast({
        title: "Settings Updated",
        description: "Your reminder preferences have been saved.",
      });
    } catch (error) {
      console.error('Error updating settings:', error);
      toast({
        title: "Error",
        description: "Failed to update reminder settings.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const testReminders = async () => {
    try {
      setLoading(true);
      
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        toast({
          title: "Error",
          description: "You must be logged in to test reminders.",
          variant: "destructive"
        });
        return;
      }

      // Send test habit reminder directly
      const { error: habitError } = await supabase
        .from('notifications')
        .insert({
          type: 'habit_reminder',
          title: 'Test Habit Reminder',
          message: 'This is a test habit reminder. Don\'t forget to complete your habits! 💪',
          user_id: user.id,
          read: false
        });

      if (habitError) {
        console.error('Habit reminder error:', habitError);
        throw new Error('Failed to send habit reminder');
      }

      // Send test goal reminder directly
      const { error: goalError } = await supabase
        .from('notifications')
        .insert({
          type: 'goal_reminder',
          title: 'Test Goal Reminder',
          message: 'This is a test goal reminder. Time to work on your goals! 🎯',
          user_id: user.id,
          read: false
        });

      if (goalError) {
        console.error('Goal reminder error:', goalError);
        throw new Error('Failed to send goal reminder');
      }

      toast({
        title: "Test Complete",
        description: "Test reminders have been sent successfully. Check your notifications tab.",
      });
    } catch (error) {
      console.error('Error testing reminders:', error);
      toast({
        title: "Test Failed",
        description: error instanceof Error ? error.message : "Failed to send test reminders.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bell className="w-5 h-5" />
            Reminder Settings
          </CardTitle>
          <CardDescription>
            Configure when you'd like to receive reminders to stay on track
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Target className="w-4 h-4 text-blue-500" />
              <div>
                <p className="font-medium">Daily Habit Reminders</p>
                <p className="text-sm text-muted-foreground">
                  Get notified daily to maintain your habit streaks
                </p>
              </div>
            </div>
            <Switch
              checked={settings.habit_reminders}
              onCheckedChange={(checked) => updateSettings('habit_reminders', checked)}
              disabled={loading}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Calendar className="w-4 h-4 text-green-500" />
              <div>
                <p className="font-medium">Goal Task Reminders</p>
                <p className="text-sm text-muted-foreground">
                  Get reminded about pending goal tasks based on their frequency
                </p>
              </div>
            </div>
            <Switch
              checked={settings.goal_reminders}
              onCheckedChange={(checked) => updateSettings('goal_reminders', checked)}
              disabled={loading}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Clock className="w-4 h-4 text-purple-500" />
              <div>
                <p className="font-medium">Weekly Reviews</p>
                <p className="text-sm text-muted-foreground">
                  Weekly check-ins on Mondays to review your progress
                </p>
              </div>
            </div>
            <Switch
              checked={settings.weekly_reviews}
              onCheckedChange={(checked) => updateSettings('weekly_reviews', checked)}
              disabled={loading}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Calendar className="w-4 h-4 text-orange-500" />
              <div>
                <p className="font-medium">Monthly Reviews</p>
                <p className="text-sm text-muted-foreground">
                  Monthly goal reviews on the 1st of each month
                </p>
              </div>
            </div>
            <Switch
              checked={settings.monthly_reviews}
              onCheckedChange={(checked) => updateSettings('monthly_reviews', checked)}
              disabled={loading}
            />
          </div>

          <div className="pt-4 border-t">
            <Button 
              onClick={testReminders}
              disabled={loading}
              variant="outline"
              className="w-full"
            >
              {loading ? 'Testing...' : 'Test Reminders Now'}
            </Button>
            <p className="text-xs text-muted-foreground mt-2 text-center">
              This will trigger reminder checks and send notifications if you have incomplete items
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}