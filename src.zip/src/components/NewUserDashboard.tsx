import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useAppContext } from '@/contexts/AppContext';
import UserNotifications from './UserNotifications';
import { 
  Target, 
  Users, 
  Trophy, 
  TrendingUp,
  MessageCircle,
  CheckSquare,
  Sparkles,
  ArrowRight
} from 'lucide-react';

interface NewUserDashboardProps {
  userName: string;
  onNavigate?: (tab: string) => void;
}

const NewUserDashboard = ({ userName, onNavigate }: NewUserDashboardProps) => {
  const { currentUser } = useAppContext();
  const handleQuickAction = (action: string) => {
    if (onNavigate) {
      onNavigate(action);
    }
  };

  const quickActions = [
    {
      title: 'Create Your First Habit',
      description: 'Start building positive routines that stick',
      icon: Target,
      action: 'habits',
      color: 'bg-[#596D59]',
      priority: 1
    },
    {
      title: 'Set Your Goals',
      description: 'Define what you want to achieve',
      icon: CheckSquare,
      action: 'goals',
      color: 'bg-[#2C2C44]',
      priority: 2
    },
    {
      title: 'Find Your Partner',
      description: 'Get matched with an accountability buddy',
      icon: Users,
      action: 'partner-matching',
      color: 'bg-[#7E8E9D]',
      priority: 3
    },
    {
      title: 'Chat with AI Coach',
      description: 'Get personalized guidance and motivation',
      icon: MessageCircle,
      action: 'ai-chat',
      color: 'bg-purple-600',
      priority: 4
    }
  ];

  return (
    <div className="space-y-6 p-6">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-[#001B30] to-[#2C2C44] rounded-lg p-8 text-white text-center">
        <div className="flex justify-center mb-4">
          <div className="p-3 rounded-full bg-white/10">
            <Sparkles className="h-8 w-8 text-yellow-400" />
          </div>
        </div>
        <h2 className="text-3xl font-bold mb-3">Welcome to ACCLOUNGE, {userName}! 🎉</h2>
        <p className="text-[#7E8E9D] text-lg mb-4">
          You're about to start an amazing journey of growth and accountability.
        </p>
        <p className="text-[#7E8E9D]">
          Let's get you set up with your first habit or goal to begin building momentum!
        </p>
      </div>

      {/* Notifications Section - Also visible for new users */}
      {currentUser?.id && <UserNotifications userId={currentUser.id} />}

      {/* Getting Started Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-[#001B30]">
            <TrendingUp className="h-5 w-5 text-[#596D59]" />
            Your Journey Starts Here
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-[#7E8E9D] mb-6">
            Take your first step by choosing one of these actions. Don't worry - you can always add more later!
          </p>
          
          <div className="grid md:grid-cols-2 gap-4">
            {quickActions.map((action) => {
              const Icon = action.icon;
              return (
                <Card key={action.action} className="border-2 border-dashed border-[#7E8E9D]/30 hover:border-[#596D59] transition-colors cursor-pointer group"
                      onClick={() => handleQuickAction(action.action)}>
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <div className={`p-3 rounded-lg ${action.color} group-hover:scale-110 transition-transform`}>
                        <Icon className="h-6 w-6 text-white" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-semibold text-[#001B30] mb-2 group-hover:text-[#596D59] transition-colors">
                          {action.title}
                        </h3>
                        <p className="text-sm text-[#7E8E9D] mb-3">
                          {action.description}
                        </p>
                        <div className="flex items-center text-[#596D59] text-sm font-medium group-hover:gap-2 transition-all">
                          Get Started
                          <ArrowRight className="h-4 w-4 ml-1 group-hover:translate-x-1 transition-transform" />
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Stats Preview */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-[#001B30]">
            <Trophy className="h-5 w-5 text-yellow-500" />
            Your Progress Will Show Here
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { label: 'Active Habits', value: '0', icon: Target },
              { label: 'Current Streak', value: '0', icon: Target },
              { label: 'Goals Completed', value: '0', icon: CheckSquare },
              { label: 'Achievements', value: '1', icon: Trophy }
            ].map((stat, index) => {
              const Icon = stat.icon;
              return (
                <div key={index} className="text-center p-4 rounded-lg bg-gray-50">
                  <Icon className="h-6 w-6 text-[#7E8E9D] mx-auto mb-2" />
                  <p className="text-2xl font-bold text-[#001B30]">{stat.value}</p>
                  <p className="text-sm text-[#7E8E9D]">{stat.label}</p>
                </div>
              );
            })}
          </div>
          <p className="text-center text-[#7E8E9D] mt-4">
            Start tracking habits and goals to see your progress grow!
          </p>
        </CardContent>
      </Card>
    </div>
  );
};

export default NewUserDashboard;