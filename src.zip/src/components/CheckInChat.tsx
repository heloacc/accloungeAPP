import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { MessageSquare, Send, User, UserCheck } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';

interface ChatMessage {
  id: string;
  thread_id: string;
  sender_id: string;
  recipient_id: string;
  message_text: string;
  is_admin_message: boolean;
  created_at: string;
  sender_name?: string;
}

interface CheckInChatProps {
  recipientId: string;
  recipientName: string;
  isAdminView?: boolean;
  threadId?: string;
  onThreadCreated?: (threadId: string) => void;
}

export const CheckInChat: React.FC<CheckInChatProps> = ({
  recipientId,
  recipientName,
  isAdminView = false,
  threadId: initialThreadId,
  onThreadCreated
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [threadId, setThreadId] = useState<string | null>(initialThreadId || null);
  const [currentUserId, setCurrentUserId] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  useEffect(() => {
    getCurrentUser();
  }, []);

  useEffect(() => {
    if (currentUserId && recipientId) {
      loadMessages();
      const cleanup = setupRealtimeSubscription();
      
      return () => {
        if (cleanup) {
          cleanup();
        }
      };
    }
  }, [currentUserId, recipientId, threadId, loadMessages, setupRealtimeSubscription]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const getCurrentUser = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (user) {
      setCurrentUserId(user.id);
    }
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const loadMessages = useCallback(async () => {
    try {
      if (!currentUserId) return;

      let query = supabase
        .from('check_in_messages')
        .select(`
          id, thread_id, sender_id, recipient_id, message_text, 
          is_admin_message, created_at,
          sender_profile:profiles!check_in_messages_sender_id_fkey(name, full_name)
        `)
        .order('created_at', { ascending: true });

      if (threadId) {
        query = query.eq('thread_id', threadId);
      } else {
        // Find existing thread between current user and recipient
        query = query.or(
          `and(sender_id.eq.${currentUserId},recipient_id.eq.${recipientId}),and(sender_id.eq.${recipientId},recipient_id.eq.${currentUserId})`
        );
      }

      const { data, error } = await query;

      if (error) throw error;

      const formattedMessages = data?.map(msg => ({
        ...msg,
        sender_name: msg.sender_profile?.full_name || msg.sender_profile?.name || 'Unknown'
      })) || [];

      setMessages(formattedMessages);

      // Set threadId if we found messages
      if (formattedMessages.length > 0 && !threadId) {
        setThreadId(formattedMessages[0].thread_id);
      }
    } catch (error) {
      console.error('Error loading messages:', error);
    } finally {
      setLoading(false);
    }
  }, [currentUserId, recipientId, threadId]);

  const setupRealtimeSubscription = useCallback(() => {
    if (!currentUserId || !recipientId) return null;

    const subscription = supabase
      .channel('check_in_messages')
      .on('postgres_changes', 
        { 
          event: 'INSERT', 
          schema: 'public', 
          table: 'check_in_messages',
          filter: threadId ? `thread_id=eq.${threadId}` : undefined
        }, 
        (payload) => {
          const newMsg = payload.new as ChatMessage;
          if (
            (newMsg.sender_id === currentUserId || newMsg.recipient_id === currentUserId) &&
            (newMsg.sender_id === recipientId || newMsg.recipient_id === recipientId)
          ) {
            setMessages(prev => [...prev, newMsg]);
          }
        }
      )
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, [currentUserId, recipientId, threadId]);

  const sendMessage = async () => {
    if (!newMessage.trim() || !currentUserId) return;

    try {
      setSending(true);
      
      let messageThreadId = threadId;
      
      // Create new thread if none exists
      if (!messageThreadId) {
        messageThreadId = crypto.randomUUID();
        setThreadId(messageThreadId);
        onThreadCreated?.(messageThreadId);
      }

      const { error } = await supabase
        .from('check_in_messages')
        .insert({
          thread_id: messageThreadId,
          sender_id: currentUserId,
          recipient_id: recipientId,
          message_text: newMessage.trim(),
          is_admin_message: isAdminView
        });

      if (error) throw error;

      setNewMessage('');
      
      toast({
        title: 'Message sent',
        description: `Your message has been sent to ${recipientName}`
      });
    } catch (error) {
      console.error('Error sending message:', error);
      toast({
        title: 'Error',
        description: 'Failed to send message',
        variant: 'destructive'
      });
    } finally {
      setSending(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="p-4">
          <div className="animate-pulse">Loading chat...</div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="flex flex-col h-96">
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2">
          <MessageSquare className="h-4 w-4" />
          Chat with {recipientName}
          {isAdminView && <Badge variant="outline" className="text-xs">Admin</Badge>}
        </CardTitle>
      </CardHeader>
      
      <CardContent className="flex-1 flex flex-col p-0">
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {messages.length > 0 ? (
            messages.map((message) => (
              <div 
                key={message.id}
                className={`flex ${message.sender_id === currentUserId ? 'justify-end' : 'justify-start'}`}
              >
                <div className={`max-w-[80%] px-3 py-2 rounded-lg ${
                  message.sender_id === currentUserId
                    ? 'bg-blue-500 text-white'
                    : message.is_admin_message
                    ? 'bg-green-100 text-green-800 border border-green-200'
                    : 'bg-gray-100 text-gray-800'
                }`}>
                  <div className="flex items-center gap-2 mb-1">
                    {message.sender_id === currentUserId ? (
                      <User className="h-3 w-3" />
                    ) : (
                      <UserCheck className="h-3 w-3" />
                    )}
                    <span className="text-xs font-medium">
                      {message.sender_id === currentUserId ? 'You' : 
                       message.is_admin_message ? 'Coach' : message.sender_name}
                    </span>
                    <span className="text-xs opacity-70">
                      {new Date(message.created_at).toLocaleTimeString([], { 
                        hour: '2-digit', 
                        minute: '2-digit' 
                      })}
                    </span>
                  </div>
                  <p className="text-sm leading-relaxed">{message.message_text}</p>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center text-gray-500 text-sm">
              No messages yet. Start the conversation!
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>
        
        <div className="border-t p-4">
          <div className="flex gap-2">
            <Textarea
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder={isAdminView ? "Send a check-in message..." : "Type your message..."}
              className="min-h-[60px] resize-none"
              disabled={sending}
            />
            <Button 
              onClick={sendMessage}
              disabled={!newMessage.trim() || sending}
              size="sm"
              className="self-end"
            >
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};