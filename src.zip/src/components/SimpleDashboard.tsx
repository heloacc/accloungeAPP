import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useAppContext } from '@/contexts/AppContext';
import { supabase } from '@/lib/supabase';
import UserNotifications from './UserNotifications';
import { 
  Target, 
  Users, 
  Trophy, 
  TrendingUp,
  MessageCircle,
  CheckSquare,
  Flame
} from 'lucide-react';

interface UserStats {
  habits_count: number;
  goals_count: number;
  current_streak: number;
  achievements_count: number;
}

const SimpleDashboard = () => {
  const { currentUser, setActiveTab, achievements } = useAppContext();
  const [userStats, setUserStats] = useState<UserStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let isMounted = true;
    
    const loadStats = async () => {
      if (currentUser?.id && isMounted) {
        await fetchUserStats();
      }
    };
    
    if (currentUser?.id) {
      loadStats();
    } else {
      setLoading(false);
    }
    
    return () => {
      isMounted = false;
    };
  }, [currentUser?.id]);
  const calculateCurrentStreak = (completedDates: string[]): number => {
    if (!completedDates || completedDates.length === 0) return 0;
    
    const sortedDates = completedDates.sort((a, b) => new Date(b).getTime() - new Date(a).getTime());
    const today = new Date().toISOString().split('T')[0];
    const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
    
    // Check if streak should start from today or yesterday
    let currentDate = sortedDates.includes(today) ? today : 
                     sortedDates.includes(yesterday) ? yesterday : null;
    
    if (!currentDate) return 0;
    
    let streak = 0;
    const currentDateObj = new Date(currentDate);
    
    // Count backwards from current date
    for (let i = 0; i < sortedDates.length; i++) {
      const expectedDate = new Date(currentDateObj.getTime() - (streak * 86400000)).toISOString().split('T')[0];
      if (sortedDates.includes(expectedDate)) {
        streak++;
      } else {
        break;
      }
    }
    
    return streak;
  };

  const fetchUserStats = async () => {
    try {
      setLoading(true);
      
      // Get habits count and calculate max streak
      const { data: habits } = await supabase
        .from('habits')
        .select('completed_dates')
        .eq('user_id', currentUser.id);

      // Get goals count
      const { data: goals } = await supabase
        .from('goals')
        .select('id')
        .eq('user_id', currentUser.id);

      const habitsCount = habits?.length || 0;
      const goalsCount = goals?.length || 0;
      
      // Calculate the highest current streak across all habits
      let maxStreak = 0;
      if (habits && habits.length > 0) {
        maxStreak = habits.reduce((max, habit) => {
          const streak = calculateCurrentStreak(habit.completed_dates || []);
          return Math.max(max, streak);
        }, 0);
      }

      const achievementsCount = achievements.filter(a => a.unlocked).length;

      setUserStats({
        habits_count: habitsCount,
        goals_count: goalsCount,
        current_streak: maxStreak,
        achievements_count: achievementsCount
      });
    } catch (error) {
      console.error('Error fetching user stats:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleQuickAction = (action: string) => {
    setActiveTab(action);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-[#7E8E9D]">Loading your dashboard...</div>
      </div>
    );
  }

  const stats = [
    { label: 'Active Habits', value: userStats?.habits_count?.toString() || '0', icon: Target, color: 'bg-[#596D59]' },
    { label: 'Active Goals', value: userStats?.goals_count?.toString() || '0', icon: TrendingUp, color: 'bg-[#2C2C44]' },
    { label: 'Achievements', value: userStats?.achievements_count?.toString() || '0', icon: Trophy, color: 'bg-[#7E8E9D]' },
    { label: 'Current Streak', value: userStats?.current_streak?.toString() || '0', icon: Flame, color: 'bg-orange-500' },
  ];

  return (
    <div className="space-y-6 p-6">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-[#001B30] to-[#2C2C44] rounded-lg p-6 text-white">
        <h2 className="text-2xl font-bold mb-2">
          Welcome back, {currentUser?.name?.split(' ')[0] || currentUser?.full_name?.split(' ')[0] || 'User'}! 👋
        </h2>
        <p className="text-[#7E8E9D]">
          {userStats?.current_streak && userStats.current_streak > 0 
            ? `You're on a ${userStats.current_streak}-day streak! Keep it up!`
            : "Ready to continue building great habits?"
          }
        </p>
      </div>

      {/* Notifications Section - Prominently displayed */}
      {currentUser?.id && <UserNotifications userId={currentUser.id} />}

      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <Card key={index} className="border-gray-200">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600 font-medium">{stat.label}</p>
                    <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                  </div>
                  <div className={`p-3 rounded-lg ${stat.color} shadow-sm`}>
                    <Icon className="h-5 w-5 text-white" />
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Quick Actions */}
      <Card className="border-gray-200">
        <CardHeader>
          <CardTitle className="text-gray-900">Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-3">
            <Button 
              className="bg-black text-white hover:bg-gray-800"
              onClick={() => handleQuickAction('habits')}
            >
              <Target className="h-4 w-4 mr-2" />
              Add New Habit
            </Button>
            <Button 
              className="bg-black text-white hover:bg-gray-800"
              onClick={() => handleQuickAction('goals')}
            >
              <CheckSquare className="h-4 w-4 mr-2" />
              Create Goal
            </Button>
            <Button 
              variant="outline" 
              className="border-gray-300 text-gray-700 hover:bg-gray-50"
              onClick={() => handleQuickAction('achievements')}
            >
              <Trophy className="h-4 w-4 mr-2" />
              View Achievements
            </Button>
            <Button 
              variant="outline" 
              className="border-gray-300 text-gray-700 hover:bg-gray-50"
              onClick={() => handleQuickAction('ai-chat')}
            >
              <MessageCircle className="h-4 w-4 mr-2" />
              Chat with AI Coach
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default SimpleDashboard;