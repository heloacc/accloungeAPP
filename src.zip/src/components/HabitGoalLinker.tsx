import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Link, Unlink, Target, TrendingUp } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabase';

interface Goal {
  id: string;
  title: string;
  description?: string;
}

interface Habit {
  id: string;
  title: string;
  linked_goal_id?: string;
  current_streak: number;
  completed_dates: string[];
}

interface HabitGoalLinkerProps {
  habits: Habit[];
  onUpdate: () => void;
}

const HabitGoalLinker: React.FC<HabitGoalLinkerProps> = ({ habits, onUpdate }) => {
  const [goals, setGoals] = useState<Goal[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchGoals();
  }, []);

  const fetchGoals = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('goals')
        .select('id, title, description')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setGoals(data || []);
    } catch (error) {
      console.error('Error fetching goals:', error);
    }
  };

  const linkHabitToGoal = async (habitId: string, goalId: string) => {
    setLoading(true);
    try {
      const { error } = await supabase
        .from('habits')
        .update({
          linked_goal_id: goalId === 'none' ? null : goalId,
          updated_at: new Date().toISOString()
        })
        .eq('id', habitId);

      if (error) throw error;

      // Update goal progress when habit is linked
      if (goalId !== 'none') {
        await supabase.functions.invoke('update-goal-progress', {
          body: { habitId, goalId }
        });
      }

      toast({
        title: "Success",
        description: goalId === 'none' ? "Habit unlinked from goal" : "Habit linked to goal successfully!",
      });

      onUpdate();
    } catch (error) {
      console.error('Error linking habit to goal:', error);
      toast({
        title: "Error",
        description: "Failed to link habit to goal. Please try again.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const getGoalProgress = (goalId: string) => {
    const linkedHabits = habits.filter(h => h.linked_goal_id === goalId);
    if (linkedHabits.length === 0) return 0;
    
    const totalCompletions = linkedHabits.reduce((sum, habit) => 
      sum + (habit.completed_dates?.length || 0), 0);
    const avgCompletions = totalCompletions / linkedHabits.length;
    
    return Math.min(Math.round(avgCompletions), 100);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 mb-4">
        <Link className="h-5 w-5" />
        <h3 className="text-lg font-semibold">Link Habits to Goals</h3>
      </div>

      {habits.map((habit) => {
        const linkedGoal = goals.find(g => g.id === habit.linked_goal_id);
        
        return (
          <Card key={habit.id} className="border-l-4 border-l-purple-500">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">{habit.title}</CardTitle>
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="flex items-center gap-1">
                    <TrendingUp className="h-3 w-3" />
                    {habit.current_streak} day streak
                  </Badge>
                  {linkedGoal && (
                    <Badge variant="secondary" className="bg-purple-100 text-purple-800">
                      Linked
                    </Badge>
                  )}
                </div>
              </div>
            </CardHeader>
            
            <CardContent className="space-y-4">
              <div className="flex items-center gap-3">
                <Target className="h-4 w-4 text-purple-500" />
                <div className="flex-1">
                  <Select
                    value={habit.linked_goal_id || 'none'}
                    onValueChange={(value) => linkHabitToGoal(habit.id, value)}
                    disabled={loading}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select a goal to link" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">
                        <div className="flex items-center gap-2">
                          <Unlink className="h-4 w-4" />
                          No goal linked
                        </div>
                      </SelectItem>
                      {goals.map((goal) => (
                        <SelectItem key={goal.id} value={goal.id}>
                          <div className="flex items-center gap-2">
                            <Link className="h-4 w-4" />
                            {goal.title}
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {linkedGoal && (
                <div className="bg-purple-50 p-3 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium text-purple-800">
                      Linked Goal: {linkedGoal.title}
                    </span>
                    <Badge variant="outline" className="text-purple-600">
                      {getGoalProgress(linkedGoal.id)}% progress
                    </Badge>
                  </div>
                  <p className="text-xs text-purple-600">
                    Your habit completions contribute to this goal's progress
                  </p>
                </div>
              )}

              <div className="text-sm text-muted-foreground">
                <span className="font-medium">{habit.completed_dates?.length || 0}</span> total completions
              </div>
            </CardContent>
          </Card>
        );
      })}

      {goals.length === 0 && (
        <Card className="border-dashed">
          <CardContent className="text-center py-8">
            <Target className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">No Goals Available</h3>
            <p className="text-muted-foreground mb-4">
              Create some goals first to link your habits to them.
            </p>
            <Button variant="outline" onClick={() => window.location.href = '/goals'}>
              Create Goals
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default HabitGoalLinker;