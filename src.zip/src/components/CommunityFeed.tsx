import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Users, MessageCircle, Star } from 'lucide-react';

interface FeedItem {
  id: string;
  userName: string;
  achievement: string;
  timeAgo: string;
  emoji: string;
}

interface GroupSprint {
  id: string;
  name: string;
  members: number;
  category: string;
  startDate: string;
}

interface CommunityFeedProps {
  feedItems: FeedItem[];
  groupSprints: GroupSprint[];
  onNavigate?: (tab: string) => void;
}

export const CommunityFeed: React.FC<CommunityFeedProps> = ({ feedItems, groupSprints, onNavigate }) => {
  return (
    <Card className="mb-6">
      <CardHeader>
        <CardTitle className="text-xl font-semibold flex items-center gap-2">
          <Users className="h-5 w-5" />
          Check-In With Others
        </CardTitle>
        <p className="text-sm text-muted-foreground">Optional inspiration from your community</p>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-3">
          <h4 className="font-medium text-sm text-muted-foreground cursor-pointer hover:text-primary" onClick={() => onNavigate?.('wins-wall')}>Recent Wins</h4>
          {feedItems.slice(0, 3).map((item) => (
            <div key={item.id} className="flex items-center gap-3 p-3 rounded-lg bg-muted/50 cursor-pointer hover:bg-muted/70" onClick={() => {
              if (item.userName === 'Community' && item.achievement.includes('Welcome')) {
                onNavigate?.('gather');
              }
            }}>
              <span className="text-2xl">{item.emoji}</span>
              <div className="flex-1">
                <p className="text-sm">
                  <span className="font-medium">{item.userName}</span> {item.achievement}
                </p>
                <p className="text-xs text-muted-foreground">{item.timeAgo}</p>
              </div>
              <MessageCircle className="h-4 w-4 text-muted-foreground" />
            </div>
          ))}
        </div>
        
        <div className="space-y-3">
          <h4 className="font-medium text-sm text-muted-foreground cursor-pointer hover:text-primary" onClick={() => onNavigate?.('groups')}>Join a Group Sprint</h4>
          {groupSprints.slice(0, 2).map((sprint) => (
            <div key={sprint.id} className="p-3 rounded-lg border bg-card">
              <div className="flex justify-between items-start mb-2">
                <h5 className="font-medium">{sprint.name}</h5>
                <Badge variant="secondary">{sprint.members} members</Badge>
              </div>
              <div className="flex justify-between items-center">
                <div className="text-sm text-muted-foreground">
                  <span>{sprint.category}</span> • <span>Starts {sprint.startDate}</span>
                </div>
                <Button size="sm" variant="outline">
                  <Star className="h-3 w-3 mr-1" />
                  Join
                </Button>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default CommunityFeed;