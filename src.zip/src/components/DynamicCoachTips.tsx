import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Lightbulb, Target, Flame, TrendingUp } from 'lucide-react';

interface DynamicCoachTipsProps {
  habits: Array<{
    id: string;
    name: string;
    completed: boolean;
    streak: number;
  }>;
  goals: Array<{
    id: string;
    title: string;
    progress: number;
  }>;
  streakDays: number;
  consistencyScore: number;
}

export const DynamicCoachTips: React.FC<DynamicCoachTipsProps> = ({
  habits,
  goals,
  streakDays,
  consistencyScore
}) => {
  const getCoachMessage = () => {
    if (habits.length === 0) {
      return {
        message: 'Start by adding your first habit to begin tracking your progress.',
        icon: Target,
        type: 'Getting Started'
      };
    }
    
    const completedToday = habits.filter(h => h.completed).length;
    const hasActiveStreak = streakDays > 0;
    
    if (completedToday === habits.length && hasActiveStreak) {
      return {
        message: `Amazing! You've completed all habits today and have a ${streakDays}-day streak going!`,
        icon: Flame,
        type: 'Streak Master'
      };
    } else if (completedToday > 0) {
      return {
        message: `Great progress! You've completed ${completedToday}/${habits.length} habits today.`,
        icon: TrendingUp,
        type: 'Making Progress'
      };
    } else if (hasActiveStreak) {
      return {
        message: `Don't break your ${streakDays}-day streak! Complete your habits today.`,
        icon: Flame,
        type: 'Streak Alert'
      };
    } else {
      return {
        message: 'Ready to build some momentum? Complete your first habit today!',
        icon: Lightbulb,
        type: 'Motivation'
      };
    }
  };

  const coachTip = getCoachMessage();
  const IconComponent = coachTip.icon;

  return (
    <Card className="mb-4 sm:mb-6">
      <CardHeader className="pb-3 sm:pb-4">
        <CardTitle className="text-base sm:text-lg font-semibold flex items-center gap-2 flex-wrap">
          <IconComponent className="h-4 w-4 sm:h-5 sm:w-5 text-blue-600 flex-shrink-0" />
          <span className="min-w-0">Lounger Tip of The Day</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="flex items-start gap-2 sm:gap-3">
          <div className="w-6 h-6 sm:w-8 sm:h-8 bg-yellow-100 rounded-full flex items-center justify-center flex-shrink-0">
            <span className="text-sm sm:text-lg">💡</span>
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1 flex-wrap">
              <span className="font-medium text-xs sm:text-sm">Lounger</span>
              <Badge variant="secondary" className="text-xs px-1.5 py-0.5">{coachTip.type}</Badge>
              <span className="text-xs text-muted-foreground whitespace-nowrap">
                {new Date().toLocaleDateString()}
              </span>
            </div>
            <p className="text-xs sm:text-sm leading-relaxed">{coachTip.message}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
