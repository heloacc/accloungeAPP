import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { Lock, Unlock, AlertTriangle } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { toast } from '@/hooks/use-toast';

interface GroupPrivacyToggleProps {
  groupId: string;
  groupName: string;
  isPrivate: boolean;
  isAdmin: boolean;
  onPrivacyChange?: (newPrivacy: boolean) => void;
}

const GroupPrivacyToggle: React.FC<GroupPrivacyToggleProps> = ({
  groupId,
  groupName,
  isPrivate,
  isAdmin,
  onPrivacyChange
}) => {
  const [loading, setLoading] = useState(false);
  const [currentPrivacy, setCurrentPrivacy] = useState(isPrivate);

  const togglePrivacy = async () => {
    if (!isAdmin) {
      toast({
        title: "Access Denied",
        description: "Only administrators can change group privacy settings.",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    try {
      const newPrivacy = !currentPrivacy;
      
      const { error } = await supabase
        .from('acircle_groups')
        .update({ is_private: newPrivacy })
        .eq('id', groupId);

      if (error) throw error;

      setCurrentPrivacy(newPrivacy);
      onPrivacyChange?.(newPrivacy);

      toast({
        title: "Privacy Updated",
        description: `Group "${groupName}" is now ${newPrivacy ? 'private' : 'public'}.`,
      });
    } catch (error) {
      console.error('Error updating privacy:', error);
      toast({
        title: "Error",
        description: "Failed to update group privacy settings.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  if (!isAdmin) {
    return (
      <div className="flex items-center gap-2">
        <Badge variant={currentPrivacy ? "secondary" : "outline"} className="text-xs">
          {currentPrivacy ? (
            <>
              <Lock className="h-3 w-3 mr-1" />
              Private
            </>
          ) : (
            <>
              <Unlock className="h-3 w-3 mr-1" />
              Public
            </>
          )}
        </Badge>
      </div>
    );
  }

  return (
    <Card className="border-dashed">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm flex items-center gap-2">
          {currentPrivacy ? (
            <Lock className="h-4 w-4 text-orange-600" />
          ) : (
            <Unlock className="h-4 w-4 text-green-600" />
          )}
          Group Privacy Settings
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <p className="text-sm font-medium">
              Currently: {currentPrivacy ? 'Private' : 'Public'}
            </p>
            <p className="text-xs text-muted-foreground">
              {currentPrivacy 
                ? 'Only members can see group content. New members need approval.'
                : 'Anyone can see and request to join this group.'
              }
            </p>
          </div>
          
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <div className="flex items-center gap-2">
                <Switch
                  checked={currentPrivacy}
                  disabled={loading}
                />
                <Button variant="outline" size="sm" disabled={loading}>
                  {loading ? 'Updating...' : 'Change'}
                </Button>
              </div>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-amber-600" />
                  Change Group Privacy
                </AlertDialogTitle>
                <AlertDialogDescription>
                  Are you sure you want to make "{groupName}" {currentPrivacy ? 'public' : 'private'}?
                  
                  {currentPrivacy ? (
                    <div className="mt-2 p-3 bg-green-50 rounded-md">
                      <p className="text-sm text-green-800">
                        <strong>Making Public:</strong> Anyone will be able to see and request to join this group.
                      </p>
                    </div>
                  ) : (
                    <div className="mt-2 p-3 bg-orange-50 rounded-md">
                      <p className="text-sm text-orange-800">
                        <strong>Making Private:</strong> Only current members will see group content. New members will need approval.
                      </p>
                    </div>
                  )}
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={togglePrivacy}>
                  {currentPrivacy ? 'Make Public' : 'Make Private'}
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </CardContent>
    </Card>
  );
};

export default GroupPrivacyToggle;