import React, { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';

const ConnectionTest: React.FC = () => {
  const [status, setStatus] = useState<'testing' | 'success' | 'error'>('testing');
  const [details, setDetails] = useState<any>({});

  useEffect(() => {
    const testConnection = async () => {
      try {
        console.log('Testing Supabase connection...');
        
        // Test basic connection
        const { data, error } = await supabase
          .from('profiles')
          .select('count')
          .limit(1);
        
        console.log('Connection test result:', { data, error });
        
        if (error) {
          setStatus('error');
          setDetails({ error: error.message, code: error.code });
        } else {
          setStatus('success');
          setDetails({ message: 'Connection successful' });
        }
      } catch (err) {
        console.error('Connection test failed:', err);
        setStatus('error');
        setDetails({ error: 'Network error or invalid configuration' });
      }
    };

    testConnection();
  }, []);

  if (status === 'testing') {
    return (
      <div className="p-4 bg-yellow-50 border border-yellow-200 rounded">
        <p>Testing database connection...</p>
      </div>
    );
  }

  if (status === 'error') {
    return (
      <div className="p-4 bg-red-50 border border-red-200 rounded">
        <h3 className="font-semibold text-red-800">Connection Failed</h3>
        <p className="text-red-600">{details.error}</p>
        {details.code && <p className="text-sm text-red-500">Code: {details.code}</p>}
      </div>
    );
  }

  return (
    <div className="p-4 bg-green-50 border border-green-200 rounded">
      <h3 className="font-semibold text-green-800">Connection Successful</h3>
      <p className="text-green-600">{details.message}</p>
    </div>
  );
};

export default ConnectionTest;