import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { HabitChallenges } from './HabitChallenges';
import { ChallengeHabitTracker } from './ChallengeHabitTracker';
import { StreakCompetitions } from './StreakCompetitions';
import { HabitEncouragement } from './HabitEncouragement';
import { BuddyMatchingSystem } from './BuddyMatchingSystem';
import { AccountabilityCheckIns } from './AccountabilityCheckIns';
import { SocialProgressSharing } from './SocialProgressSharing';
import { SocialEncouragementSystem } from './SocialEncouragementSystem';
import { Trophy, Flame, Heart, Users, Target, MessageCircle, UserPlus, Share2 } from 'lucide-react';

export const HabitSocialHub = () => {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center">
        <h1 className="text-3xl font-bold text-[#001B30] mb-2">Social Habits</h1>
        <p className="text-[#7E8E9D] text-lg">
          Connect, compete, and encourage each other on your habit journey
        </p>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-gradient-to-r from-blue-50 to-blue-100">
          <CardContent className="p-4 text-center">
            <Trophy className="w-8 h-8 text-blue-600 mx-auto mb-2" />
            <p className="text-2xl font-bold text-blue-800">12</p>
            <p className="text-sm text-blue-600">Active Challenges</p>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-r from-orange-50 to-orange-100">
          <CardContent className="p-4 text-center">
            <Flame className="w-8 h-8 text-orange-600 mx-auto mb-2" />
            <p className="text-2xl font-bold text-orange-800">8</p>
            <p className="text-sm text-orange-600">Streak Competitions</p>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-r from-red-50 to-red-100">
          <CardContent className="p-4 text-center">
            <Heart className="w-8 h-8 text-red-600 mx-auto mb-2" />
            <p className="text-2xl font-bold text-red-800">156</p>
            <p className="text-sm text-red-600">Encouragements Shared</p>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Tabs */}
      <Tabs defaultValue="buddy-matching" className="w-full">
        <TabsList className="grid w-full grid-cols-3 lg:grid-cols-6 gap-1">
          <TabsTrigger value="buddy-matching" className="flex items-center justify-center gap-1 text-xs px-1 py-2">
            <UserPlus className="w-3 h-3 md:w-4 md:h-4" />
            <span className="hidden sm:inline">Find Buddies</span>
            <span className="sm:hidden">Buddies</span>
          </TabsTrigger>
          <TabsTrigger value="check-ins" className="flex items-center justify-center gap-1 text-xs px-1 py-2">
            <MessageCircle className="w-3 h-3 md:w-4 md:h-4" />
            <span className="hidden sm:inline">Check-Ins</span>
            <span className="sm:hidden">Check-In</span>
          </TabsTrigger>
          <TabsTrigger value="progress-sharing" className="flex items-center justify-center gap-1 text-xs px-1 py-2">
            <Share2 className="w-3 h-3 md:w-4 md:h-4" />
            <span className="hidden sm:inline">Share Progress</span>
            <span className="sm:hidden">Share</span>
          </TabsTrigger>
          <TabsTrigger value="encouragement" className="flex items-center justify-center gap-1 text-xs px-1 py-2">
            <Heart className="w-3 h-3 md:w-4 md:h-4" />
            <span className="hidden sm:inline">Encouragement</span>
            <span className="sm:hidden">Support</span>
          </TabsTrigger>
          <TabsTrigger value="challenges" className="flex items-center justify-center gap-1 text-xs px-1 py-2">
            <Trophy className="w-3 h-3 md:w-4 md:h-4" />
            <span className="hidden sm:inline">Challenges</span>
            <span className="sm:hidden">Challenges</span>
          </TabsTrigger>
          <TabsTrigger value="competitions" className="flex items-center justify-center gap-1 text-xs px-1 py-2">
            <Flame className="w-3 h-3 md:w-4 md:h-4" />
            <span className="hidden sm:inline">Competitions</span>
            <span className="sm:hidden">Compete</span>
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="buddy-matching" className="mt-6">
          <BuddyMatchingSystem />
        </TabsContent>
        
        <TabsContent value="check-ins" className="mt-6">
          <AccountabilityCheckIns />
        </TabsContent>
        
        <TabsContent value="progress-sharing" className="mt-6">
          <SocialProgressSharing />
        </TabsContent>
        
        <TabsContent value="encouragement" className="mt-6">
          <SocialEncouragementSystem />
        </TabsContent>
        
        <TabsContent value="challenges" className="mt-6">
          <HabitChallenges />
        </TabsContent>

        <TabsContent value="competitions" className="mt-6">
          <StreakCompetitions />
        </TabsContent>
      </Tabs>

      {/* Community Features */}
      <Card className="bg-gradient-to-r from-green-50 to-green-100">
        <CardContent className="p-6">
          <div className="flex items-center gap-4 mb-4">
            <Users className="w-8 h-8 text-green-600" />
            <div>
              <h3 className="text-lg font-semibold text-green-800">Join the Community</h3>
              <p className="text-green-600">Connect with accountability partners and join groups</p>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="flex items-center gap-3 p-3 bg-white rounded-lg">
              <Target className="w-5 h-5 text-[#596D59]" />
              <div>
                <p className="font-medium text-[#001B30]">Find Partners</p>
                <p className="text-sm text-[#7E8E9D]">Get matched with accountability buddies</p>
              </div>
            </div>
            <div className="flex items-center gap-3 p-3 bg-white rounded-lg">
              <MessageCircle className="w-5 h-5 text-[#596D59]" />
              <div>
                <p className="font-medium text-[#001B30]">Join Groups</p>
                <p className="text-sm text-[#7E8E9D]">Participate in accountability groups</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};