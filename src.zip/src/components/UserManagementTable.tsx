import React from 'react';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
interface User {
  id: string;
  name: string;
  email: string;
  role: string;
  is_admin: boolean;
  created_at: string;
  what_brings_you?: string;
  habit_excited?: string;
}

interface UserManagementTableProps {
  users: User[];
  onUpdateRole: (userId: string, role: string) => void;
}

const UserManagementTable: React.FC<UserManagementTableProps> = ({ users, onUpdateRole }) => {
  return (
    <div className="overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Name</TableHead>
            <TableHead>Email</TableHead>
            <TableHead>Role</TableHead>
            <TableHead>What brings you to AccLounge?</TableHead>
            <TableHead>Habit you're excited to build</TableHead>
            <TableHead>Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {users.map((user) => (
            <TableRow key={user.id}>
               <TableCell className="font-medium">{user.name}</TableCell>
               <TableCell>{user.email}</TableCell>
               <TableCell>
                 <Badge variant={
                   user.role === 'Admin' ? "default" : 
                   user.role === 'Moderator' ? "outline" : 
                   "secondary"
                 }>
                   {user.role}
                 </Badge>
               </TableCell>
              <TableCell className="max-w-xs truncate">
                {user.what_brings_you || 'No response'}
              </TableCell>
              <TableCell className="max-w-xs truncate">
                {user.habit_excited || 'No response'}
              </TableCell>
               <TableCell>
                 <Select onValueChange={(value) => onUpdateRole(user.id, value)} defaultValue="">
                   <SelectTrigger className="w-32">
                     <SelectValue placeholder="Change role" />
                   </SelectTrigger>
                   <SelectContent>
                     <SelectItem value="Member">Member</SelectItem>
                     <SelectItem value="Moderator">Moderator</SelectItem>
                     <SelectItem value="Admin">Admin</SelectItem>
                   </SelectContent>
                 </Select>
               </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
};

export default UserManagementTable;