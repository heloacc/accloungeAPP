import React from 'react';
import { useUserTier } from '@/hooks/useUserTier';
import { Badge } from '@/components/ui/badge';
import { Crown, Zap, User } from 'lucide-react';

interface TierBadgeProps {
  showIcon?: boolean;
  size?: 'sm' | 'default' | 'lg';
}

const TierBadge: React.FC<TierBadgeProps> = ({ 
  showIcon = true, 
  size = 'default' 
}) => {
  const { tier, loading } = useUserTier();

  if (loading) {
    return <Badge variant="outline">Loading...</Badge>;
  }

  const getIcon = () => {
    if (!showIcon) return null;
    
    switch (tier) {
      case 'premium':
        return <Crown className="h-3 w-3 mr-1" />;
      case 'enterprise':
        return <Zap className="h-3 w-3 mr-1" />;
      default:
        return <User className="h-3 w-3 mr-1" />;
    }
  };

  const getVariant = () => {
    switch (tier) {
      case 'premium':
        return 'default' as const;
      case 'enterprise':
        return 'secondary' as const;
      default:
        return 'outline' as const;
    }
  };

  const getClassName = () => {
    const base = 'capitalize';
    switch (tier) {
      case 'premium':
        return `${base} bg-yellow-100 text-yellow-800 hover:bg-yellow-200`;
      case 'enterprise':
        return `${base} bg-purple-100 text-purple-800 hover:bg-purple-200`;
      default:
        return `${base} bg-gray-100 text-gray-800`;
    }
  };

  return (
    <Badge 
      variant={getVariant()} 
      className={getClassName()}
    >
      {getIcon()}
      {tier}
    </Badge>
  );
};

export default TierBadge;