import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Search, UserCheck, Crown, AlertCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';
import { Alert, AlertDescription } from '@/components/ui/alert';

interface User {
  id: string;
  email: string;
  display_name?: string;
  current_tier?: string;
}

interface Tier {
  id: string;
  name: string;
}

export default function SimpleTierAssigner() {
  const [users, setUsers] = useState<User[]>([]);
  const [tiers, setTiers] = useState<Tier[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(false);
  const [assigning, setAssigning] = useState<string | null>(null);
  const [debugInfo, setDebugInfo] = useState<string>('');
  const { toast } = useToast();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    setDebugInfo('Loading data...');
    
    try {
      // Load tiers
      const { data: tiersData, error: tiersError } = await supabase
        .from('subscription_tiers')
        .select('id, name')
        .eq('is_active', true)
        .order('name');

      if (tiersError) {
        setDebugInfo(`Tiers error: ${tiersError.message}`);
        throw tiersError;
      }

      setTiers(tiersData || []);
      setDebugInfo(`Loaded ${tiersData?.length || 0} tiers`);

      // Load users from profiles table only
      const { data: usersData, error: usersError } = await supabase
        .from('profiles')
        .select('id, email, name, full_name, subscription_tier')
        .order('email');

      if (usersError) {
        setDebugInfo(`Users error: ${usersError.message}`);
        throw usersError;
      }

      // Map tier IDs to names
      const tierMap = new Map();
      tiersData?.forEach(tier => tierMap.set(tier.id, tier.name));

      const mappedUsers = (usersData || []).map(user => ({
        id: user.id,
        email: user.email || 'No email',
        display_name: user.name || user.full_name || user.email?.split('@')[0] || 'Unknown',
        current_tier: user.subscription_tier ? 
          (tierMap.get(user.subscription_tier) || 'Unknown Tier') : 
          'Freemium'
      }));

      setUsers(mappedUsers);
      setDebugInfo(`Loaded ${mappedUsers.length} users successfully`);
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : 'Unknown error';
      setDebugInfo(`Load error: ${errorMsg}`);
      toast({
        title: "Error loading data",
        description: errorMsg,
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const assignTier = async (userId: string, tierId: string) => {
    setAssigning(userId);
    const user = users.find(u => u.id === userId);
    setDebugInfo(`Starting tier assignment for ${user?.email}...`);
    
    try {
      const tierValue = tierId === 'freemium' ? null : tierId;
      
      // Simple approach: only update profiles table
      const { error: updateError } = await supabase
        .from('profiles')
        .update({ subscription_tier: tierValue })
        .eq('id', userId);

      if (updateError) {
        setDebugInfo(`Profile update failed: ${updateError.message}`);
        throw new Error(`Failed to update user tier: ${updateError.message}`);
      }

      setDebugInfo(`Successfully updated tier for ${user?.email}`);
      
      toast({
        title: "Tier assigned successfully",
        description: `${user?.email} has been assigned to ${tierId === 'freemium' ? 'Freemium' : tiers.find(t => t.id === tierId)?.name || 'Unknown'}`
      });

      // Reload data to reflect changes
      loadData();
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : 'Unknown error';
      setDebugInfo(`Assignment failed: ${errorMsg}`);
      toast({
        title: "Error assigning tier",
        description: errorMsg,
        variant: "destructive"
      });
    } finally {
      setAssigning(null);
    }
  };

  const filteredUsers = users.filter(user =>
    user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (user.display_name && user.display_name.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold flex items-center gap-2">
          <UserCheck className="h-6 w-6" />
          Simple Tier Assigner
        </h2>
      </div>

      {debugInfo && (
        <Alert>
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{debugInfo}</AlertDescription>
        </Alert>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Search Users</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search by email or name..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-4">
        {loading ? (
          <Card>
            <CardContent className="p-6 text-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
              <p className="mt-2 text-muted-foreground">Loading...</p>
            </CardContent>
          </Card>
        ) : filteredUsers.length === 0 ? (
          <Card>
            <CardContent className="p-6 text-center text-muted-foreground">
              No users found.
            </CardContent>
          </Card>
        ) : (
          filteredUsers.map((user) => (
            <Card key={user.id}>
              <CardContent className="p-4">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-semibold">{user.display_name}</h3>
                      {user.current_tier !== 'Freemium' && (
                        <Crown className="h-4 w-4 text-yellow-500" />
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground">{user.email}</p>
                    <Badge variant={user.current_tier === 'Freemium' ? 'secondary' : 'default'} className="mt-1">
                      {user.current_tier}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-2">
                    <Select onValueChange={(tierId) => assignTier(user.id, tierId)}>
                      <SelectTrigger className="w-48">
                        <SelectValue placeholder="Assign tier..." />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="freemium">Freemium</SelectItem>
                        {tiers.map((tier) => (
                          <SelectItem key={tier.id} value={tier.id}>
                            {tier.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {assigning === user.id && (
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-primary"></div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}