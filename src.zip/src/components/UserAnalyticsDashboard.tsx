import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { TrendingUp, Target, Flame, Calendar, BarChart3, Award } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useSession } from '@/hooks/useSession';
import HabitCompletionChart from './HabitCompletionChart';
import StreakAnalysisChart from './StreakAnalysisChart';
import GoalProgressChart from './GoalProgressChart';
import PersonalizedRecommendations from './PersonalizedRecommendations';
import ComparisonMetrics from './ComparisonMetrics';

interface UserAnalytics {
  totalHabits: number;
  completedHabits: number;
  currentStreak: number;
  longestStreak: number;
  weeklyCompletionRate: number;
  monthlyCompletionRate: number;
  totalGoals: number;
  completedGoals: number;
  averageGoalProgress: number;
  consistencyScore: number;
}

const UserAnalyticsDashboard: React.FC = () => {
  const { session } = useSession();
  const [analytics, setAnalytics] = useState<UserAnalytics>({
    totalHabits: 0, completedHabits: 0, currentStreak: 0, longestStreak: 0,
    weeklyCompletionRate: 0, monthlyCompletionRate: 0, totalGoals: 0,
    completedGoals: 0, averageGoalProgress: 0, consistencyScore: 0
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (session?.user?.id) {
      loadUserAnalytics();
    }
  }, [session?.user?.id]);

  const loadUserAnalytics = async () => {
    try {
      setLoading(true);
      const userId = session?.user?.id;
      
      // Use the same approach as RealDataDashboard - separate queries
      const [habitsRes, goalsRes] = await Promise.all([
        supabase
          .from('habits')
          .select('id, title, current_streak, longest_streak, is_active')
          .eq('user_id', userId)
          .eq('is_active', true),
        supabase
          .from('goals')
          .select('id, title, status, target_date, updated_at')
          .eq('user_id', userId)
      ]);

      const habitsData = habitsRes.data || [];
      const goalsData = goalsRes.data || [];

      
      // Calculate analytics from the fetched data
      const totalHabits = habitsData.length;
      const currentStreak = Math.max(...habitsData.map(h => h.current_streak || 0), 0);
      const longestStreak = Math.max(...habitsData.map(h => h.longest_streak || 0), 0);
      
      // Calculate goal metrics
      const completedGoals = goalsData.filter(g => g.status === 'completed').length;
      const activeGoals = goalsData.filter(g => g.status === 'active').length;
      
      // Simple completion rates based on available data
      const weeklyCompletionRate = totalHabits > 0 ? Math.round((currentStreak / 7) * 100) : 0;
      const monthlyCompletionRate = totalHabits > 0 ? Math.round((currentStreak / 30) * 100) : 0;
      
      setAnalytics({
        totalHabits,
        completedHabits: activeGoals, // Use active goals as proxy
        currentStreak,
        longestStreak,
        weeklyCompletionRate: Math.min(weeklyCompletionRate, 100),
        monthlyCompletionRate: Math.min(monthlyCompletionRate, 100),
        totalGoals: goalsData.length,
        completedGoals,
        averageGoalProgress: goalsData.length > 0 ? Math.round((completedGoals / goalsData.length) * 100) : 0,
        consistencyScore: longestStreak > 0 ? Math.round((currentStreak / longestStreak) * 100) : 0
      });
    } catch (error) {
      console.error('Error loading analytics:', error);
      // Set fallback data on error
      setAnalytics({
        totalHabits: 0, completedHabits: 0, currentStreak: 0, longestStreak: 0,
        weeklyCompletionRate: 0, monthlyCompletionRate: 0, totalGoals: 0,
        completedGoals: 0, averageGoalProgress: 0, consistencyScore: 0
      });
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div className="flex justify-center p-8"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div></div>;
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Target className="h-4 w-4" />
              Habits
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{analytics.totalHabits}</div>
            <p className="text-xs text-muted-foreground">{analytics.completedHabits} completed today</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Flame className="h-4 w-4" />
              Current Streak
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-500">{analytics.currentStreak}</div>
            <p className="text-xs text-muted-foreground">days</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Award className="h-4 w-4" />
              Best Streak
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-500">{analytics.longestStreak}</div>
            <p className="text-xs text-muted-foreground">days</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              Weekly Rate
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{analytics.weeklyCompletionRate}%</div>
            <p className="text-xs text-muted-foreground">completion</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              Monthly Rate
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{analytics.monthlyCompletionRate}%</div>
            <p className="text-xs text-muted-foreground">completion</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              Consistency
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{analytics.consistencyScore}%</div>
            <p className="text-xs text-muted-foreground">score</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="habits" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="habits">Habit Patterns</TabsTrigger>
          <TabsTrigger value="streaks">Streak Analysis</TabsTrigger>
          <TabsTrigger value="goals">Goal Progress</TabsTrigger>
          <TabsTrigger value="insights">Insights</TabsTrigger>
        </TabsList>

        <TabsContent value="habits" className="space-y-4">
          <HabitCompletionChart />
        </TabsContent>

        <TabsContent value="streaks" className="space-y-4">
          <StreakAnalysisChart />
        </TabsContent>

        <TabsContent value="goals" className="space-y-4">
          <GoalProgressChart />
        </TabsContent>

        <TabsContent value="insights" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <PersonalizedRecommendations analytics={analytics} />
            <ComparisonMetrics analytics={analytics} />
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default UserAnalyticsDashboard;