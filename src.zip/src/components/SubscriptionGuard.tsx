import React from 'react';
import { useSubscriptionAccess } from '@/hooks/useSubscriptionAccess';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Lock, CreditCard } from 'lucide-react';

interface SubscriptionGuardProps {
  children: React.ReactNode;
  pagePath: string;
  fallback?: React.ReactNode;
}

const SubscriptionGuard: React.FC<SubscriptionGuardProps> = ({ 
  children, 
  pagePath, 
  fallback 
}) => {
  const { hasAccessToPage, getAccessMessage, loading } = useSubscriptionAccess();

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#623822]"></div>
      </div>
    );
  }

  if (!hasAccessToPage(pagePath)) {
    if (fallback) {
      return <>{fallback}</>;
    }

    return (
      <div className="flex items-center justify-center min-h-[60vh] p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <div className="mx-auto mb-4 p-3 bg-orange-100 rounded-full w-fit">
              <Lock className="h-6 w-6 text-orange-600" />
            </div>
            <CardTitle className="text-xl">Premium Feature</CardTitle>
          </CardHeader>
          <CardContent className="text-center space-y-4">
            <p className="text-muted-foreground">
              {getAccessMessage(pagePath) || 'This feature requires a premium subscription.'}
            </p>
            <Button 
              className="w-full bg-[#623822] hover:bg-[#4a2a1a]"
              onClick={() => window.dispatchEvent(new CustomEvent('navigate-to-tab', { 
                detail: { tab: 'billing' }
              }))}
            >
              <CreditCard className="h-4 w-4 mr-2" />
              Upgrade Now
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return <>{children}</>;
};

export default SubscriptionGuard;