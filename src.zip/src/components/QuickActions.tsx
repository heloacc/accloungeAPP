import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Plus, Target, Users, UserPlus, CheckSquare } from 'lucide-react';

interface QuickActionsProps {
  onLogHabits: () => void;
  onAddGoal: () => void;
  onJoinGroup: () => void;
  onInvitePartner: () => void;
}

export const QuickActions: React.FC<QuickActionsProps> = ({
  onLogHabits,
  onAddGoal,
  onJoinGroup,
  onInvitePartner
}) => {
  return (
    <Card>
      <CardHeader className="pb-3 sm:pb-4">
        <CardTitle className="text-lg sm:text-xl font-semibold">Quick Actions</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <Button 
          onClick={onLogHabits}
          className="w-full bg-green-600 hover:bg-green-700 text-white h-10 sm:h-11"
          size="lg"
        >
          <CheckSquare className="h-4 w-4 sm:h-5 sm:w-5 mr-2" />
          <span className="text-sm sm:text-base">Log Today's Habits</span>
        </Button>
        
        <div className="grid grid-cols-1 gap-2 sm:gap-3">
          <Button 
            onClick={onAddGoal}
            variant="outline"
            className="flex items-center justify-center gap-2 h-9 sm:h-10"
          >
            <Target className="h-3 w-3 sm:h-4 sm:w-4" />
            <span className="text-sm sm:text-base">Add New Goal</span>
          </Button>
          
          <Button 
            onClick={onJoinGroup}
            variant="outline"
            className="flex items-center justify-center gap-2 h-9 sm:h-10"
          >
            <Users className="h-3 w-3 sm:h-4 sm:w-4" />
            <span className="text-sm sm:text-base">Join a Group Sprint</span>
          </Button>
          
          <Button 
            onClick={onInvitePartner}
            variant="outline"
            className="flex items-center justify-center gap-2 h-9 sm:h-10"
          >
            <UserPlus className="h-3 w-3 sm:h-4 sm:w-4" />
            <span className="text-sm sm:text-base">Invite Partner</span>
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};