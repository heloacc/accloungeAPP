import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Trash2, Edit, Plus, Save, X } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/components/ui/use-toast';

interface SubscriptionTier {
  id: string;
  name: string;
  description?: string;
  price_monthly?: number;
  price_yearly?: number;
  stripe_product_id?: string;
  stripe_price_id?: string;
  is_active: boolean;
  features?: string[];
  max_groups?: number;
  max_partnerships?: number;
  priority_support?: boolean;
  analytics_access?: boolean;
  custom_branding?: boolean;
}

const FinalTierManager = () => {
  const [tiers, setTiers] = useState<SubscriptionTier[]>([]);
  const [loading, setLoading] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [showForm, setShowForm] = useState(false);
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    name: '',
    description: '',
    price_monthly: '',
    price_yearly: '',
    stripe_product_id: '',
    stripe_price_id: '',
    is_active: true,
    features: '',
    max_groups: '1',
    max_partnerships: '1',
    priority_support: false,
    analytics_access: false,
    custom_branding: false
  });

  const loadTiers = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('subscription_tiers')
        .select('*')
        .order('price_monthly', { ascending: true });

      if (error) throw error;
      setTiers(data || []);
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      price_monthly: '',
      price_yearly: '',
      stripe_product_id: '',
      stripe_price_id: '',
      is_active: true,
      features: '',
      max_groups: '1',
      max_partnerships: '1',
      priority_support: false,
      analytics_access: false,
      custom_branding: false
    });
    setEditingId(null);
    setShowForm(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const tierData = {
        name: formData.name,
        description: formData.description || null,
        price_monthly: formData.price_monthly ? parseFloat(formData.price_monthly) : null,
        price_yearly: formData.price_yearly ? parseFloat(formData.price_yearly) : null,
        stripe_product_id: formData.stripe_product_id || null,
        stripe_price_id: formData.stripe_price_id || null,
        is_active: formData.is_active,
        features: formData.features ? formData.features.split(',').map(f => f.trim()) : null,
        max_groups: parseInt(formData.max_groups) || 1,
        max_partnerships: parseInt(formData.max_partnerships) || 1,
        priority_support: formData.priority_support,
        analytics_access: formData.analytics_access,
        custom_branding: formData.custom_branding
      };

      if (editingId) {
        const { error } = await supabase
          .from('subscription_tiers')
          .update(tierData)
          .eq('id', editingId);
        
        if (error) throw error;
        toast({ title: "Success", description: "Tier updated successfully" });
      } else {
        const { error } = await supabase
          .from('subscription_tiers')
          .insert([tierData]);
        
        if (error) throw error;
        toast({ title: "Success", description: "Tier created successfully" });
      }

      resetForm();
      loadTiers();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (tier: SubscriptionTier) => {
    setFormData({
      name: tier.name,
      description: tier.description || '',
      price_monthly: tier.price_monthly?.toString() || '',
      price_yearly: tier.price_yearly?.toString() || '',
      stripe_product_id: tier.stripe_product_id || '',
      stripe_price_id: tier.stripe_price_id || '',
      is_active: tier.is_active,
      features: tier.features?.join(', ') || '',
      max_groups: tier.max_groups?.toString() || '1',
      max_partnerships: tier.max_partnerships?.toString() || '1',
      priority_support: tier.priority_support || false,
      analytics_access: tier.analytics_access || false,
      custom_branding: tier.custom_branding || false
    });
    setEditingId(tier.id);
    setShowForm(true);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this tier?')) return;

    setLoading(true);
    try {
      const { error } = await supabase
        .from('subscription_tiers')
        .delete()
        .eq('id', id);

      if (error) throw error;
      toast({ title: "Success", description: "Tier deleted successfully" });
      loadTiers();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const toggleActive = async (id: string, currentStatus: boolean) => {
    try {
      const { error } = await supabase
        .from('subscription_tiers')
        .update({ is_active: !currentStatus })
        .eq('id', id);

      if (error) throw error;
      toast({ 
        title: "Success", 
        description: `Tier ${!currentStatus ? 'activated' : 'deactivated'}` 
      });
      loadTiers();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    }
  };

  useEffect(() => {
    loadTiers();
  }, []);

  if (loading && tiers.length === 0) {
    return <div className="p-4 text-center">Loading subscription tiers...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Subscription Tiers</h2>
        <Button onClick={() => setShowForm(true)} disabled={loading}>
          <Plus className="h-4 w-4 mr-2" />
          Add Tier
        </Button>
      </div>

      {showForm && (
        <Card>
          <CardHeader>
            <CardTitle>{editingId ? 'Edit' : 'Create'} Subscription Tier</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name">Name *</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="price_monthly">Monthly Price</Label>
                  <Input
                    id="price_monthly"
                    type="number"
                    step="0.01"
                    value={formData.price_monthly}
                    onChange={(e) => setFormData({ ...formData, price_monthly: e.target.value })}
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="stripe_product_id">Stripe Product ID</Label>
                  <Input
                    id="stripe_product_id"
                    value={formData.stripe_product_id}
                    onChange={(e) => setFormData({ ...formData, stripe_product_id: e.target.value })}
                    placeholder="prod_..."
                  />
                </div>
                <div>
                  <Label htmlFor="stripe_price_id">Stripe Price ID</Label>
                  <Input
                    id="stripe_price_id"
                    value={formData.stripe_price_id}
                    onChange={(e) => setFormData({ ...formData, stripe_price_id: e.target.value })}
                    placeholder="price_..."
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div className="flex items-center space-x-2">
                  <Switch
                    id="priority_support"
                    checked={formData.priority_support}
                    onCheckedChange={(checked) => setFormData({ ...formData, priority_support: checked })}
                  />
                  <Label htmlFor="priority_support">Priority Support</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch
                    id="analytics_access"
                    checked={formData.analytics_access}
                    onCheckedChange={(checked) => setFormData({ ...formData, analytics_access: checked })}
                  />
                  <Label htmlFor="analytics_access">Analytics Access</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch
                    id="is_active"
                    checked={formData.is_active}
                    onCheckedChange={(checked) => setFormData({ ...formData, is_active: checked })}
                  />
                  <Label htmlFor="is_active">Active</Label>
                </div>
              </div>

              <div className="flex gap-2">
                <Button type="submit" disabled={loading}>
                  <Save className="h-4 w-4 mr-2" />
                  {editingId ? 'Update' : 'Create'}
                </Button>
                <Button type="button" variant="outline" onClick={resetForm}>
                  <X className="h-4 w-4 mr-2" />
                  Cancel
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      <div className="grid gap-4">
        {tiers.map((tier) => (
          <Card key={tier.id}>
            <CardContent className="p-4">
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <h3 className="text-lg font-semibold">{tier.name}</h3>
                    <Badge variant={tier.is_active ? "default" : "secondary"}>
                      {tier.is_active ? "Active" : "Inactive"}
                    </Badge>
                    {tier.stripe_product_id && (
                      <Badge variant="outline">Stripe Connected</Badge>
                    )}
                  </div>
                  {tier.description && (
                    <p className="text-sm text-muted-foreground mb-2">{tier.description}</p>
                  )}
                  <div className="flex gap-4 text-sm">
                    {tier.price_monthly && (
                      <span>Monthly: ${tier.price_monthly}</span>
                    )}
                    {tier.stripe_product_id && (
                      <span>Product: {tier.stripe_product_id}</span>
                    )}
                    {tier.stripe_price_id && (
                      <span>Price: {tier.stripe_price_id}</span>
                    )}
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => toggleActive(tier.id, tier.is_active)}
                    disabled={loading}
                  >
                    {tier.is_active ? 'Deactivate' : 'Activate'}
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleEdit(tier)}
                    disabled={loading}
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button
                    size="sm"
                    variant="destructive"
                    onClick={() => handleDelete(tier.id)}
                    disabled={loading}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {tiers.length === 0 && !loading && (
        <Card>
          <CardContent className="p-8 text-center text-muted-foreground">
            <p>No subscription tiers found. Create your first tier to get started.</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default FinalTierManager;