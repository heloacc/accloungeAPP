import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, Clock, AlertTriangle, Users, Link } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { toast } from '@/hooks/use-toast';
import { useAppContext } from '@/contexts/AppContext';

interface InviteLinkHandlerProps {
  inviteToken?: string;
  groupId?: string;
}

interface GroupInfo {
  id: string;
  name: string;
  description: string;
  is_private: boolean;
  member_count: number;
}

const InviteLinkHandler: React.FC<InviteLinkHandlerProps> = ({ inviteToken, groupId }) => {
  const { currentUser } = useAppContext();
  const [groupInfo, setGroupInfo] = useState<GroupInfo | null>(null);
  const [loading, setLoading] = useState(true);
  const [joining, setJoining] = useState(false);
  const [inviteValid, setInviteValid] = useState(false);
  const [alreadyMember, setAlreadyMember] = useState(false);

  useEffect(() => {
    if (inviteToken && groupId && currentUser) {
      validateInviteAndLoadGroup();
    }
  }, [inviteToken, groupId, currentUser]);

  const validateInviteAndLoadGroup = async () => {
    if (!inviteToken || !groupId || !currentUser) return;

    try {
      // Validate invite token
      const { data: invite, error: inviteError } = await supabase
        .from('group_invites')
        .select('*')
        .eq('invite_token', inviteToken)
        .eq('group_id', groupId)
        .gt('expires_at', new Date().toISOString())
        .is('used_at', null)
        .single();

      if (inviteError || !invite) {
        setInviteValid(false);
        setLoading(false);
        return;
      }

      setInviteValid(true);

      // Load group info
      const { data: group } = await supabase
        .from('acircle_groups')
        .select('id, name, description, is_private')
        .eq('id', groupId)
        .single();

      if (group) {
        // Get member count
        const { count } = await supabase
          .from('acircle_members')
          .select('*', { count: 'exact', head: true })
          .eq('group_id', groupId);

        setGroupInfo({
          ...group,
          member_count: count || 0
        });

        // Check if user is already a member
        const { data: membership } = await supabase
          .from('acircle_members')
          .select('id')
          .eq('user_id', currentUser.id)
          .eq('group_id', groupId)
          .single();

        setAlreadyMember(!!membership);
      }
    } catch (error) {
      console.error('Error validating invite:', error);
      setInviteValid(false);
    } finally {
      setLoading(false);
    }
  };

  const joinGroup = async () => {
    if (!inviteToken || !groupId || !currentUser || !groupInfo) return;

    setJoining(true);
    try {
      // Add user to group
      const { error: memberError } = await supabase
        .from('acircle_members')
        .insert([{
          group_id: groupId,
          user_id: currentUser.id,
          role: 'member'
        }]);

      if (memberError) throw memberError;

      // Mark invite as used
      await supabase
        .from('group_invites')
        .update({
          used_at: new Date().toISOString(),
          used_by: currentUser.id
        })
        .eq('invite_token', inviteToken);

      toast({
        title: "Welcome!",
        description: `You've successfully joined ${groupInfo.name}!`,
      });

      setAlreadyMember(true);
    } catch (error) {
      console.error('Error joining group:', error);
      toast({
        title: "Error",
        description: "Failed to join the group. Please try again.",
        variant: "destructive",
      });
    } finally {
      setJoining(false);
    }
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="p-6 text-center">
          <Clock className="h-12 w-12 mx-auto mb-4 text-muted-foreground animate-spin" />
          <p>Validating invitation...</p>
        </CardContent>
      </Card>
    );
  }

  if (!inviteValid) {
    return (
      <Card>
        <CardContent className="p-6 text-center">
          <AlertTriangle className="h-12 w-12 mx-auto mb-4 text-red-500" />
          <h3 className="text-lg font-semibold mb-2">Invalid Invitation</h3>
          <p className="text-muted-foreground">
            This invitation link is either expired, invalid, or has already been used.
          </p>
        </CardContent>
      </Card>
    );
  }

  if (!groupInfo) {
    return (
      <Card>
        <CardContent className="p-6 text-center">
          <AlertTriangle className="h-12 w-12 mx-auto mb-4 text-red-500" />
          <h3 className="text-lg font-semibold mb-2">Group Not Found</h3>
          <p className="text-muted-foreground">
            The group associated with this invitation could not be found.
          </p>
        </CardContent>
      </Card>
    );
  }

  if (alreadyMember) {
    return (
      <Card>
        <CardContent className="p-6 text-center">
          <CheckCircle className="h-12 w-12 mx-auto mb-4 text-green-500" />
          <h3 className="text-lg font-semibold mb-2">Already a Member</h3>
          <p className="text-muted-foreground">
            You're already a member of <strong>{groupInfo.name}</strong>!
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Link className="h-5 w-5" />
          Group Invitation
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="text-center space-y-2">
          <h3 className="text-xl font-semibold flex items-center justify-center gap-2">
            <Users className="h-5 w-5" />
            {groupInfo.name}
            {groupInfo.is_private && (
              <Badge variant="secondary" className="text-xs">Private</Badge>
            )}
          </h3>
          <p className="text-muted-foreground">{groupInfo.description}</p>
          <p className="text-sm text-muted-foreground">
            {groupInfo.member_count} members
          </p>
        </div>

        <div className="bg-blue-50 p-4 rounded-lg">
          <p className="text-sm text-blue-800">
            You've been invited to join this group! Click below to accept the invitation.
          </p>
        </div>

        <Button 
          onClick={joinGroup} 
          disabled={joining}
          className="w-full"
          size="lg"
        >
          {joining ? (
            <>
              <Clock className="h-4 w-4 mr-2 animate-spin" />
              Joining...
            </>
          ) : (
            <>
              <CheckCircle className="h-4 w-4 mr-2" />
              Join {groupInfo.name}
            </>
          )}
        </Button>
      </CardContent>
    </Card>
  );
};

export default InviteLinkHandler;