import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { UserPlus, Send, Copy, Link, Users } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { toast } from '@/hooks/use-toast';
import { useAppContext } from '@/contexts/AppContext';

interface Group {
  id: string;
  name: string;
  is_private: boolean;
}

const GroupInvitationManager: React.FC = () => {
  const { currentUser } = useAppContext();
  const [groups, setGroups] = useState<Group[]>([]);
  const [selectedGroup, setSelectedGroup] = useState<string>('');
  const [inviteEmail, setInviteEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [inviteLink, setInviteLink] = useState('');

  useEffect(() => {
    if (currentUser?.isAdmin) {
      fetchGroups();
    }
  }, [currentUser?.isAdmin]);

  const fetchGroups = async () => {
    try {
      const { data } = await supabase
        .from('acircle_groups')
        .select('id, name, is_private')
        .eq('is_archived', false)
        .order('name');
      
      setGroups(data || []);
    } catch (error) {
      console.error('Error fetching groups:', error);
    }
  };

  const sendDirectInvite = async () => {
    if (!selectedGroup || !inviteEmail.trim()) {
      toast({
        title: "Error",
        description: "Please select a group and enter an email address.",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    try {
      // Check if user exists
      const { data: profile } = await supabase
        .from('profiles')
        .select('id')
        .eq('email', inviteEmail.trim())
        .single();

      if (!profile) {
        toast({
          title: "User Not Found",
          description: "No user found with that email address.",
          variant: "destructive",
        });
        return;
      }

      // Check if already a member
      const { data: existing } = await supabase
        .from('acircle_members')
        .select('id')
        .eq('user_id', profile.id)
        .eq('group_id', selectedGroup)
        .single();

      if (existing) {
        toast({
          title: "Already a Member",
          description: "This user is already a member of the selected group.",
          variant: "destructive",
        });
        return;
      }

      // Add directly to group
      const { error } = await supabase
        .from('acircle_members')
        .insert([{
          group_id: selectedGroup,
          user_id: profile.id,
          role: 'member'
        }]);

      if (error) throw error;

      toast({
        title: "Success",
        description: "User has been added to the group directly.",
      });

      setInviteEmail('');
      setSelectedGroup('');
    } catch (error) {
      console.error('Error sending invite:', error);
      toast({
        title: "Error",
        description: "Failed to add user to group.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const generateInviteLink = async () => {
    if (!selectedGroup) {
      toast({
        title: "Error",
        description: "Please select a group first.",
        variant: "destructive",
      });
      return;
    }

    // Generate a simple invite token (in production, use crypto.randomUUID())
    const token = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
    const link = `${window.location.origin}/?invite=${selectedGroup}&token=${token}`;
    
    setInviteLink(link);
    
    // Store the invite token in database for validation
    try {
      await supabase
        .from('group_invites')
        .insert([{
          group_id: selectedGroup,
          invite_token: token,
          created_by: currentUser?.id,
          expires_at: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString() // 7 days
        }]);
    } catch (error) {
      console.warn('Could not store invite token:', error);
    }

    toast({
      title: "Invite Link Generated",
      description: "Share this link to allow direct access to the group.",
    });
  };

  const copyInviteLink = () => {
    navigator.clipboard.writeText(inviteLink);
    toast({
      title: "Copied",
      description: "Invite link copied to clipboard.",
    });
  };

  if (!currentUser?.isAdmin) {
    return (
      <Card>
        <CardContent className="p-6 text-center">
          <UserPlus className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
          <p className="text-muted-foreground">Admin access required for group invitations.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <UserPlus className="h-5 w-5" />
          Group Invitation Manager
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-4">
          <div>
            <label className="text-sm font-medium mb-2 block">Select Group</label>
            <Select value={selectedGroup} onValueChange={setSelectedGroup}>
              <SelectTrigger>
                <SelectValue placeholder="Choose a group..." />
              </SelectTrigger>
              <SelectContent>
                {groups.map((group) => (
                  <SelectItem key={group.id} value={group.id}>
                    <div className="flex items-center gap-2">
                      <Users className="h-4 w-4" />
                      {group.name}
                      {group.is_private && <Badge variant="outline" className="text-xs">Private</Badge>}
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Direct Invitation by Email</label>
              <div className="flex gap-2">
                <Input
                  type="email"
                  placeholder="user@example.com"
                  value={inviteEmail}
                  onChange={(e) => setInviteEmail(e.target.value)}
                />
                <Button onClick={sendDirectInvite} disabled={loading}>
                  <Send className="h-4 w-4 mr-2" />
                  Invite
                </Button>
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                User will be added directly to the group (bypasses approval)
              </p>
            </div>

            <div className="border-t pt-4">
              <div className="flex items-center justify-between mb-2">
                <label className="text-sm font-medium">Generate Invite Link</label>
                <Button variant="outline" size="sm" onClick={generateInviteLink}>
                  <Link className="h-4 w-4 mr-2" />
                  Generate
                </Button>
              </div>
              
              {inviteLink && (
                <div className="space-y-2">
                  <div className="flex gap-2">
                    <Input value={inviteLink} readOnly className="text-xs" />
                    <Button variant="outline" size="sm" onClick={copyInviteLink}>
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Link expires in 7 days. Anyone with this link can join the group directly.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default GroupInvitationManager;