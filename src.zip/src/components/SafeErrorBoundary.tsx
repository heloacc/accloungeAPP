import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertTriangle, RefreshCw, Home } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface Props {
  children: ReactNode;
  fallback?: ReactNode;
  onError?: (error: Error, errorInfo: ErrorInfo) => void;
  context?: string;
}

interface State {
  hasError: boolean;
  error?: Error;
  retryCount: number;
}

export class SafeErrorBoundary extends Component<Props, State> {
  private retryTimeout?: NodeJS.Timeout;

  constructor(props: Props) {
    super(props);
    this.state = { hasError: false, retryCount: 0 };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error, retryCount: 0 };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    // Log error with context
    console.error(`[Error Boundary] ${this.props.context || 'Unknown'}:`, {
      error: error.message,
      stack: error.stack,
      componentStack: errorInfo.componentStack,
      timestamp: new Date().toISOString()
    });

    // Call custom error handler
    this.props.onError?.(error, errorInfo);

    // Send telemetry
    this.sendErrorTelemetry(error, errorInfo);
  }

  private sendErrorTelemetry = (error: Error, errorInfo: ErrorInfo) => {
    try {
      // Basic error telemetry
      const telemetry = {
        type: 'error_boundary',
        context: this.props.context || 'unknown',
        message: error.message,
        stack: error.stack?.substring(0, 500), // Truncate stack
        timestamp: Date.now(),
        retryCount: this.state.retryCount,
        userAgent: navigator.userAgent
      };
      
      // Store in localStorage for later transmission
      const errors = JSON.parse(localStorage.getItem('error_telemetry') || '[]');
      errors.push(telemetry);
      localStorage.setItem('error_telemetry', JSON.stringify(errors.slice(-10))); // Keep last 10
    } catch (e) {
      console.warn('Failed to record error telemetry:', e);
    }
  };

  private handleRetry = () => {
    if (this.state.retryCount < 3) {
      this.setState(prev => ({ 
        hasError: false, 
        error: undefined,
        retryCount: prev.retryCount + 1 
      }));
    }
  };

  private handleGoHome = () => {
    window.location.href = '/';
  };

  render() {
    if (this.state.hasError) {
      if (this.props.fallback) {
        return this.props.fallback;
      }

      return (
        <Card className="max-w-md mx-auto mt-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-red-600">
              <AlertTriangle className="h-5 w-5" />
              Something went wrong
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-gray-600">
              {this.props.context ? `Error in ${this.props.context}` : 'An unexpected error occurred'}
            </p>
            
            {this.state.error && (
              <details className="text-xs bg-gray-50 p-2 rounded">
                <summary className="cursor-pointer">Error details</summary>
                <pre className="mt-2 whitespace-pre-wrap">{this.state.error.message}</pre>
              </details>
            )}

            <div className="flex gap-2">
              {this.state.retryCount < 3 && (
                <Button onClick={this.handleRetry} size="sm" className="flex-1">
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Try Again ({3 - this.state.retryCount} left)
                </Button>
              )}
              <Button onClick={this.handleGoHome} variant="outline" size="sm">
                <Home className="h-4 w-4 mr-2" />
                Go Home
              </Button>
            </div>
          </CardContent>
        </Card>
      );
    }

    return this.props.children;
  }
}

export default SafeErrorBoundary;