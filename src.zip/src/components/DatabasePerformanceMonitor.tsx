import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { useQueryPerformance } from '../hooks/useOptimizedQueries';
import { supabase } from '../lib/supabase';
import { AlertTriangle, Database, TrendingUp, Clock } from 'lucide-react';

export function DatabasePerformanceMonitor() {
  const { metrics, slowQueries, refreshMetrics } = useQueryPerformance();
  const [optimizationSuggestions, setOptimizationSuggestions] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchOptimizationSuggestions = async () => {
    setLoading(true);
    try {
      const { data } = await supabase.functions.invoke('database-performance-monitor', {
        body: { action: 'optimize_indexes' }
      });
      
      if (data?.suggestions) {
        setOptimizationSuggestions(data.suggestions);
      }
    } catch (error) {
      console.error('Failed to fetch optimization suggestions:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchOptimizationSuggestions();
  }, []);

  const averageQueryTime = metrics.length > 0 
    ? metrics.reduce((sum, m) => sum + m.avgDuration, 0) / metrics.length 
    : 0;

  const totalQueries = metrics.reduce((sum, m) => sum + m.count, 0);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Database className="h-4 w-4 text-blue-500" />
              <div>
                <p className="text-sm text-gray-600">Total Queries</p>
                <p className="text-2xl font-bold">{totalQueries}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Clock className="h-4 w-4 text-green-500" />
              <div>
                <p className="text-sm text-gray-600">Avg Response</p>
                <p className="text-2xl font-bold">{averageQueryTime.toFixed(0)}ms</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <AlertTriangle className="h-4 w-4 text-yellow-500" />
              <div>
                <p className="text-sm text-gray-600">Slow Queries</p>
                <p className="text-2xl font-bold">{slowQueries.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <TrendingUp className="h-4 w-4 text-purple-500" />
              <div>
                <p className="text-sm text-gray-600">Cache Hit Rate</p>
                <p className="text-2xl font-bold">85%</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              Query Performance
              <Button onClick={refreshMetrics} size="sm" variant="outline">
                Refresh
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {metrics.slice(0, 10).map((metric, index) => (
                <div key={index} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                  <div>
                    <p className="font-medium text-sm">{metric.query}</p>
                    <p className="text-xs text-gray-600">{metric.count} calls</p>
                  </div>
                  <Badge variant={metric.avgDuration > 500 ? "destructive" : "secondary"}>
                    {metric.avgDuration.toFixed(0)}ms
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Optimization Suggestions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {optimizationSuggestions.map((suggestion, index) => (
                <div key={index} className="p-3 bg-blue-50 rounded border-l-4 border-blue-500">
                  <code className="text-xs text-blue-800 break-all">
                    {suggestion}
                  </code>
                </div>
              ))}
              {loading && <p className="text-sm text-gray-600">Loading suggestions...</p>}
            </div>
          </CardContent>
        </Card>
      </div>

      {slowQueries.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-red-600">Slow Queries Alert</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {slowQueries.slice(0, 5).map((query, index) => (
                <div key={index} className="p-2 bg-red-50 rounded border border-red-200">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">{query.table}.{query.operation}</span>
                    <Badge variant="destructive">{query.duration}ms</Badge>
                  </div>
                  <p className="text-xs text-gray-600 mt-1">{query.query}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}