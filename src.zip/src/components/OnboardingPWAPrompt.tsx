import { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Download, Bell, CheckCircle } from 'lucide-react';
import { showInstallPrompt, getInstallPrompt } from '../utils/pwaUtils';

interface OnboardingPWAPromptProps {
  onComplete: () => void;
}

export function OnboardingPWAPrompt({ onComplete }: OnboardingPWAPromptProps) {
  const [step, setStep] = useState<'install' | 'notifications' | 'complete'>('install');
  const [isInstalled, setIsInstalled] = useState(false);
  const [notificationsEnabled, setNotificationsEnabled] = useState(false);

  useEffect(() => {
    // Check if already installed
    const isStandalone = window.matchMedia('(display-mode: standalone)').matches;
    const isInWebAppiOS = (window.navigator as any).standalone === true;
    setIsInstalled(isStandalone || isInWebAppiOS);
    
    if (isStandalone || isInWebAppiOS) {
      setStep('notifications');
    }
  }, []);

  const handleInstall = async () => {
    const installed = await showInstallPrompt();
    if (installed) {
      setIsInstalled(true);
      setStep('notifications');
    } else {
      // If install failed or was cancelled, skip to notifications
      setStep('notifications');
    }
  };

  const handleSkipInstall = () => {
    setStep('notifications');
  };

  const handleEnableNotifications = async () => {
    try {
      const permission = await Notification.requestPermission();
      setNotificationsEnabled(permission === 'granted');
      setStep('complete');
    } catch (error) {
      console.error('Error requesting notification permission:', error);
      setStep('complete');
    }
  };

  const handleSkipNotifications = () => {
    setStep('complete');
  };

  const handleComplete = () => {
    onComplete();
  };

  if (step === 'install' && !isInstalled) {
    const canInstall = getInstallPrompt() !== null;
    
    return (
      <Card className="w-full max-w-md mx-auto">
        <CardHeader className="text-center">
          <Download className="h-12 w-12 text-primary mx-auto mb-4" />
          <CardTitle>Install AccLounge App</CardTitle>
          <p className="text-muted-foreground">
            Get the full app experience with offline access and faster loading
          </p>
        </CardHeader>
        <CardContent className="space-y-4">
          {canInstall ? (
            <Button onClick={handleInstall} className="w-full">
              <Download className="h-4 w-4 mr-2" />
              Install App
            </Button>
          ) : (
            <div className="text-center space-y-2">
              <p className="text-sm text-muted-foreground">
                App installation not available on this browser
              </p>
            </div>
          )}
          <Button onClick={handleSkipInstall} variant="outline" className="w-full">
            Continue in Browser
          </Button>
        </CardContent>
      </Card>
    );
  }

  if (step === 'notifications') {
    return (
      <Card className="w-full max-w-md mx-auto">
        <CardHeader className="text-center">
          <Bell className="h-12 w-12 text-primary mx-auto mb-4" />
          <CardTitle>Stay Connected</CardTitle>
          <p className="text-muted-foreground">
            Enable notifications to get updates on your goals, group activities, and accountability check-ins
          </p>
        </CardHeader>
        <CardContent className="space-y-4">
          <Button onClick={handleEnableNotifications} className="w-full">
            <Bell className="h-4 w-4 mr-2" />
            Enable Notifications
          </Button>
          <Button onClick={handleSkipNotifications} variant="outline" className="w-full">
            Maybe Later
          </Button>
          <p className="text-xs text-center text-muted-foreground">
            You can change this setting anytime in your browser
          </p>
        </CardContent>
      </Card>
    );
  }

  if (step === 'complete') {
    return (
      <Card className="w-full max-w-md mx-auto">
        <CardHeader className="text-center">
          <CheckCircle className="h-12 w-12 text-green-500 mx-auto mb-4" />
          <CardTitle>You're All Set!</CardTitle>
          <p className="text-muted-foreground">
            {isInstalled && notificationsEnabled 
              ? "App installed and notifications enabled. Welcome to AccLounge!"
              : isInstalled 
              ? "App installed! You can enable notifications later in settings."
              : notificationsEnabled
              ? "Notifications enabled! Consider installing the app for the best experience."
              : "You're ready to start your accountability journey!"
            }
          </p>
        </CardHeader>
        <CardContent>
          <Button onClick={handleComplete} className="w-full">
            Enter AccLounge
          </Button>
        </CardContent>
      </Card>
    );
  }

  return null;
}