import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Lightbulb, TrendingUp, Target, Clock, Flame, AlertTriangle } from 'lucide-react';

interface UserAnalytics {
  totalHabits: number;
  completedHabits: number;
  currentStreak: number;
  longestStreak: number;
  weeklyCompletionRate: number;
  monthlyCompletionRate: number;
  totalGoals: number;
  completedGoals: number;
  averageGoalProgress: number;
  consistencyScore: number;
}

interface Recommendation {
  id: string;
  title: string;
  description: string;
  type: 'habit' | 'goal' | 'streak' | 'consistency' | 'time';
  priority: 'high' | 'medium' | 'low';
  icon: React.ComponentType<any>;
  actionText: string;
}

interface PersonalizedRecommendationsProps {
  analytics: UserAnalytics;
}

const PersonalizedRecommendations: React.FC<PersonalizedRecommendationsProps> = ({ analytics }) => {
  const generateRecommendations = (): Recommendation[] => {
    const recommendations: Recommendation[] = [];

    // Streak-based recommendations
    if (analytics.currentStreak === 0 && analytics.longestStreak > 0) {
      recommendations.push({
        id: 'restart-streak',
        title: 'Restart Your Streak',
        description: `You had a ${analytics.longestStreak}-day streak before. Start small and build it back up!`,
        type: 'streak',
        priority: 'high',
        icon: Flame,
        actionText: 'Start Today'
      });
    }

    if (analytics.currentStreak > 0 && analytics.currentStreak < 7) {
      recommendations.push({
        id: 'build-streak',
        title: 'Build Your Streak',
        description: 'You\'re on a good path! Focus on consistency to reach a 7-day streak.',
        type: 'streak',
        priority: 'medium',
        icon: TrendingUp,
        actionText: 'Stay Consistent'
      });
    }

    // Completion rate recommendations
    if (analytics.weeklyCompletionRate < 60) {
      recommendations.push({
        id: 'improve-completion',
        title: 'Boost Completion Rate',
        description: 'Your weekly completion rate is below 60%. Consider reducing habit difficulty or quantity.',
        type: 'habit',
        priority: 'high',
        icon: Target,
        actionText: 'Adjust Habits'
      });
    }

    if (analytics.weeklyCompletionRate > analytics.monthlyCompletionRate + 10) {
      recommendations.push({
        id: 'maintain-momentum',
        title: 'Maintain Recent Progress',
        description: 'You\'ve improved lately! Keep up the good work to maintain this momentum.',
        type: 'consistency',
        priority: 'medium',
        icon: TrendingUp,
        actionText: 'Keep Going'
      });
    }

    // Goal-based recommendations
    if (analytics.totalGoals === 0) {
      recommendations.push({
        id: 'set-goals',
        title: 'Set Your First Goal',
        description: 'Goals provide direction and motivation. Start with one achievable goal.',
        type: 'goal',
        priority: 'high',
        icon: Target,
        actionText: 'Create Goal'
      });
    }

    if (analytics.averageGoalProgress < 30 && analytics.totalGoals > 0) {
      recommendations.push({
        id: 'focus-goals',
        title: 'Focus on Goal Progress',
        description: 'Your goals need more attention. Break them into smaller, daily actions.',
        type: 'goal',
        priority: 'medium',
        icon: AlertTriangle,
        actionText: 'Review Goals'
      });
    }

    // Habit quantity recommendations
    if (analytics.totalHabits > 5 && analytics.weeklyCompletionRate < 70) {
      recommendations.push({
        id: 'reduce-habits',
        title: 'Simplify Your Habits',
        description: 'You might have too many habits. Focus on 3-5 core habits for better success.',
        type: 'habit',
        priority: 'high',
        icon: Target,
        actionText: 'Prioritize'
      });
    }

    if (analytics.totalHabits < 3 && analytics.weeklyCompletionRate > 80) {
      recommendations.push({
        id: 'add-habits',
        title: 'Add New Challenges',
        description: 'You\'re doing great! Consider adding 1-2 more habits to grow further.',
        type: 'habit',
        priority: 'low',
        icon: TrendingUp,
        actionText: 'Expand'
      });
    }

    // Time-based recommendations
    const now = new Date();
    const hour = now.getHours();
    if (hour < 10 && analytics.completedHabits === 0) {
      recommendations.push({
        id: 'morning-start',
        title: 'Start Your Morning Right',
        description: 'Morning is a great time to complete habits. Start with your easiest one!',
        type: 'time',
        priority: 'medium',
        icon: Clock,
        actionText: 'Do One Now'
      });
    }

    // Consistency recommendations
    if (analytics.consistencyScore < 50) {
      recommendations.push({
        id: 'improve-consistency',
        title: 'Work on Consistency',
        description: 'Small, consistent actions beat sporadic big efforts. Focus on daily completion.',
        type: 'consistency',
        priority: 'high',
        icon: Target,
        actionText: 'Plan Daily'
      });
    }

    return recommendations.slice(0, 5); // Return top 5 recommendations
  };

  const recommendations = generateRecommendations();

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-800 border-red-200';
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'low': return 'bg-green-100 text-green-800 border-green-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Lightbulb className="h-5 w-5" />
          Personalized Recommendations
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {recommendations.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <Lightbulb className="h-12 w-12 mx-auto mb-4 text-gray-300" />
              <p>You're doing great! Keep up the excellent work.</p>
            </div>
          ) : (
            recommendations.map((rec) => {
              const IconComponent = rec.icon;
              return (
                <div key={rec.id} className="border rounded-lg p-4">
                  <div className="flex items-start gap-3">
                    <div className="p-2 bg-blue-100 rounded-lg">
                      <IconComponent className="h-4 w-4 text-blue-600" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <h4 className="font-medium">{rec.title}</h4>
                        <Badge className={getPriorityColor(rec.priority)}>
                          {rec.priority}
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-600 mb-3">{rec.description}</p>
                      <Button size="sm" variant="outline">
                        {rec.actionText}
                      </Button>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default PersonalizedRecommendations;