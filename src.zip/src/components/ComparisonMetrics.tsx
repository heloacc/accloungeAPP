import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { TrendingUp, Users, Award, Target } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface UserAnalytics {
  totalHabits: number;
  completedHabits: number;
  currentStreak: number;
  longestStreak: number;
  weeklyCompletionRate: number;
  monthlyCompletionRate: number;
  totalGoals: number;
  completedGoals: number;
  averageGoalProgress: number;
  consistencyScore: number;
}

interface ComparisonData {
  userPercentile: number;
  averageStreak: number;
  averageCompletionRate: number;
  averageGoals: number;
  topPerformers: {
    streak: number;
    completionRate: number;
    goals: number;
  };
}

interface ComparisonMetricsProps {
  analytics: UserAnalytics;
}

const ComparisonMetrics: React.FC<ComparisonMetricsProps> = ({ analytics }) => {
  const [comparison, setComparison] = useState<ComparisonData>({
    userPercentile: 0,
    averageStreak: 0,
    averageCompletionRate: 0,
    averageGoals: 0,
    topPerformers: { streak: 0, completionRate: 0, goals: 0 }
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadComparisonData();
  }, [analytics.currentStreak, analytics.weeklyCompletionRate, analytics.totalGoals, analytics.consistencyScore]); // Only depend on specific properties that affect comparison

  const loadComparisonData = async () => {
    try {
      setLoading(true);
      
      // Get aggregated user statistics (simplified for demo)
      const { data: users } = await supabase
        .from('user_profiles')
        .select('id')
        .limit(100);

      // Simulate comparison data based on typical user behavior patterns
      const totalUsers = users?.length || 50;
      const avgStreak = 8.5;
      const avgCompletionRate = 65;
      const avgGoals = 3.2;

      // Calculate user percentile based on multiple factors
      let score = 0;
      if (analytics.currentStreak > avgStreak) score += 25;
      if (analytics.weeklyCompletionRate > avgCompletionRate) score += 25;
      if (analytics.totalGoals > avgGoals) score += 25;
      if (analytics.consistencyScore > 70) score += 25;

      setComparison({
        userPercentile: Math.min(95, Math.max(5, score + Math.random() * 20)),
        averageStreak: avgStreak,
        averageCompletionRate: avgCompletionRate,
        averageGoals: avgGoals,
        topPerformers: {
          streak: 45,
          completionRate: 92,
          goals: 8
        }
      });
    } catch (error) {
      console.error('Error loading comparison data:', error);
    } finally {
      setLoading(false);
    }
  };

  const getPerformanceLevel = (percentile: number) => {
    if (percentile >= 90) return { label: 'Elite', color: 'bg-purple-500 text-white' };
    if (percentile >= 75) return { label: 'Excellent', color: 'bg-green-500 text-white' };
    if (percentile >= 50) return { label: 'Good', color: 'bg-blue-500 text-white' };
    if (percentile >= 25) return { label: 'Average', color: 'bg-yellow-500 text-black' };
    return { label: 'Developing', color: 'bg-gray-500 text-white' };
  };

  const compareMetric = (userValue: number, avgValue: number) => {
    const difference = ((userValue - avgValue) / avgValue) * 100;
    return {
      difference: Math.round(difference),
      isAbove: difference > 0,
      significantly: Math.abs(difference) > 20
    };
  };

  const performanceLevel = getPerformanceLevel(comparison.userPercentile);
  const streakComparison = compareMetric(analytics.currentStreak, comparison.averageStreak);
  const completionComparison = compareMetric(analytics.weeklyCompletionRate, comparison.averageCompletionRate);
  const goalsComparison = compareMetric(analytics.totalGoals, comparison.averageGoals);

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Performance Comparison
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex justify-center p-8">
            <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Users className="h-5 w-5" />
          Performance Comparison
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Overall Performance */}
        <div className="text-center">
          <div className="mb-3">
            <Badge className={performanceLevel.color}>
              <Award className="h-4 w-4 mr-1" />
              {performanceLevel.label}
            </Badge>
          </div>
          <div className="text-2xl font-bold mb-2">{Math.round(comparison.userPercentile)}th</div>
          <p className="text-sm text-gray-600">
            You're performing better than {Math.round(comparison.userPercentile)}% of users
          </p>
          <Progress value={comparison.userPercentile} className="mt-3" />
        </div>

        {/* Metric Comparisons */}
        <div className="space-y-4">
          <div className="border rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <Target className="h-4 w-4" />
                <span className="font-medium">Current Streak</span>
              </div>
              <div className="text-right">
                <div className="font-bold">{analytics.currentStreak} days</div>
                <div className="text-sm text-gray-500">vs {comparison.averageStreak} avg</div>
              </div>
            </div>
            <div className={`text-sm ${streakComparison.isAbove ? 'text-green-600' : 'text-red-600'}`}>
              {streakComparison.isAbove ? '↗' : '↘'} {Math.abs(streakComparison.difference)}% 
              {streakComparison.isAbove ? ' above' : ' below'} average
              {streakComparison.significantly && (
                <span className="ml-1 font-medium">
                  ({streakComparison.isAbove ? 'Excellent!' : 'Room for improvement'})
                </span>
              )}
            </div>
          </div>

          <div className="border rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <TrendingUp className="h-4 w-4" />
                <span className="font-medium">Completion Rate</span>
              </div>
              <div className="text-right">
                <div className="font-bold">{analytics.weeklyCompletionRate}%</div>
                <div className="text-sm text-gray-500">vs {comparison.averageCompletionRate}% avg</div>
              </div>
            </div>
            <div className={`text-sm ${completionComparison.isAbove ? 'text-green-600' : 'text-red-600'}`}>
              {completionComparison.isAbove ? '↗' : '↘'} {Math.abs(completionComparison.difference)}% 
              {completionComparison.isAbove ? ' above' : ' below'} average
            </div>
          </div>

          <div className="border rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <Target className="h-4 w-4" />
                <span className="font-medium">Active Goals</span>
              </div>
              <div className="text-right">
                <div className="font-bold">{analytics.totalGoals}</div>
                <div className="text-sm text-gray-500">vs {comparison.averageGoals} avg</div>
              </div>
            </div>
            <div className={`text-sm ${goalsComparison.isAbove ? 'text-green-600' : 'text-red-600'}`}>
              {goalsComparison.isAbove ? '↗' : '↘'} {Math.abs(goalsComparison.difference)}% 
              {goalsComparison.isAbove ? ' above' : ' below'} average
            </div>
          </div>
        </div>

        {/* Top Performers */}
        <div className="border-t pt-4">
          <h4 className="font-medium mb-3">Community Leaders</h4>
          <div className="grid grid-cols-3 gap-3 text-center">
            <div>
              <div className="text-lg font-bold text-orange-500">{comparison.topPerformers.streak}</div>
              <div className="text-xs text-gray-600">Best Streak</div>
            </div>
            <div>
              <div className="text-lg font-bold text-green-500">{comparison.topPerformers.completionRate}%</div>
              <div className="text-xs text-gray-600">Top Completion</div>
            </div>
            <div>
              <div className="text-lg font-bold text-blue-500">{comparison.topPerformers.goals}</div>
              <div className="text-xs text-gray-600">Most Goals</div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default ComparisonMetrics;