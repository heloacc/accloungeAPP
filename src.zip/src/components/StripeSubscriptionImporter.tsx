import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Download, Upload, AlertCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { toast } from '@/components/ui/use-toast';

interface StripeCustomer {
  id: string;
  email: string;
  name?: string;
  subscription?: {
    id: string;
    status: string;
    price_id: string;
    current_period_end: number;
  };
}

const StripeSubscriptionImporter: React.FC = () => {
  const [customers, setCustomers] = useState<StripeCustomer[]>([]);
  const [loading, setLoading] = useState(false);
  const [importing, setImporting] = useState(false);
  const [csvData, setCsvData] = useState('');

  const fetchStripeCustomers = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('subscription-management', {
        body: { action: 'fetch_customers' }
      });

      if (error) throw error;
      setCustomers(data.customers || []);
      toast({ title: "Success", description: `Fetched ${data.customers?.length || 0} customers` });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || 'Failed to fetch customers',
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const importCustomers = async () => {
    if (!csvData.trim()) {
      toast({
        title: "Error",
        description: "Please provide customer data",
        variant: "destructive"
      });
      return;
    }

    setImporting(true);
    try {
      const lines = csvData.trim().split('\n');
      const headers = lines[0].split(',');
      const customerData = lines.slice(1).map(line => {
        const values = line.split(',');
        return headers.reduce((obj, header, index) => {
          obj[header.trim()] = values[index]?.trim();
          return obj;
        }, {} as any);
      });

      const { data, error } = await supabase.functions.invoke('subscription-management', {
        body: { 
          action: 'import_customers',
          customers: customerData
        }
      });

      if (error) throw error;
      
      toast({ 
        title: "Success", 
        description: `Imported ${data.imported} customers, updated ${data.updated} existing` 
      });
      
      setCsvData('');
      fetchStripeCustomers();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || 'Failed to import customers',
        variant: "destructive"
      });
    } finally {
      setImporting(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Download className="h-5 w-5" />
            Stripe Subscription Importer
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <Button onClick={fetchStripeCustomers} disabled={loading}>
              {loading ? 'Fetching...' : 'Fetch from Stripe'}
            </Button>
            <Badge variant="secondary">
              {customers.length} customers loaded
            </Badge>
          </div>

          <div>
            <Label htmlFor="csv-data">Import CSV Data</Label>
            <Textarea
              id="csv-data"
              placeholder="customer_id,email,name,subscription_status,price_id&#10;cus_123,user@example.com,John Doe,active,price_456"
              value={csvData}
              onChange={(e) => setCsvData(e.target.value)}
              rows={6}
            />
            <p className="text-xs text-muted-foreground mt-1">
              Format: customer_id,email,name,subscription_status,price_id
            </p>
          </div>

          <Button onClick={importCustomers} disabled={importing || !csvData.trim()}>
            <Upload className="h-4 w-4 mr-2" />
            {importing ? 'Importing...' : 'Import Customers'}
          </Button>
        </CardContent>
      </Card>

      {customers.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Existing Stripe Customers</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {customers.map((customer) => (
                <div key={customer.id} className="flex items-center justify-between p-3 border rounded">
                  <div>
                    <p className="font-medium">{customer.name || customer.email}</p>
                    <p className="text-sm text-muted-foreground">{customer.email}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    {customer.subscription && (
                      <Badge variant={customer.subscription.status === 'active' ? 'default' : 'secondary'}>
                        {customer.subscription.status}
                      </Badge>
                    )}
                    <Badge variant="outline">{customer.id}</Badge>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default StripeSubscriptionImporter;