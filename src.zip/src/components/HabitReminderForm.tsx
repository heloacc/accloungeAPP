import React from 'react';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

interface ReminderData {
  enabled: boolean;
  time?: string;
  type: 'notification' | 'email' | 'both';
  message?: string;
}

interface HabitReminderFormProps {
  reminder: ReminderData;
  onChange: (reminder: ReminderData) => void;
}

export default function HabitReminderForm({ reminder, onChange }: HabitReminderFormProps) {
  const handleEnabledChange = (enabled: boolean) => {
    onChange({
      ...reminder,
      enabled,
      time: enabled ? (reminder.time || '09:00') : reminder.time,
      type: enabled ? (reminder.type || 'notification') : reminder.type
    });
  };

  const handleTimeChange = (time: string) => {
    onChange({
      ...reminder,
      time
    });
  };

  const handleTypeChange = (type: string) => {
    onChange({
      ...reminder,
      type: type as 'notification' | 'email' | 'both'
    });
  };

  const handleMessageChange = (message: string) => {
    onChange({
      ...reminder,
      message
    });
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center space-x-2">
        <Switch
          id="reminderEnabled"
          checked={reminder.enabled}
          onCheckedChange={handleEnabledChange}
        />
        <Label htmlFor="reminderEnabled">Enable Reminders</Label>
      </div>

      {reminder.enabled && (
        <>
          <div>
            <Label htmlFor="reminderTime">Reminder Time</Label>
            <Input
              id="reminderTime"
              type="time"
              value={reminder.time || '09:00'}
              onChange={(e) => handleTimeChange(e.target.value)}
              className="w-32"
            />
          </div>

          <div>
            <Label>Reminder Type</Label>
            <Select value={reminder.type} onValueChange={handleTypeChange}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="notification">Push Notification</SelectItem>
                <SelectItem value="email">Email</SelectItem>
                <SelectItem value="both">Both</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="reminderMessage">Custom Message (Optional)</Label>
            <Input
              id="reminderMessage"
              value={reminder.message || ''}
              onChange={(e) => handleMessageChange(e.target.value)}
              placeholder="Time to work on your habit!"
            />
          </div>
        </>
      )}
    </div>
  );
}