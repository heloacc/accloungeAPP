import { useState } from 'react';
import { supabase } from '@/lib/supabase';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { Badge } from '@/components/ui/badge';
import { Trash2, Users, Shield, AlertTriangle } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';

interface Group {
  id: string;
  name: string;
  description: string;
  is_private: boolean;
  member_count: number;
}

interface AdminGroupDeleteManagerProps {
  groups: Group[];
  onGroupDeleted: () => void;
}

const AdminGroupDeleteManager = ({ groups, onGroupDeleted }: AdminGroupDeleteManagerProps) => {
  const [deletingGroup, setDeletingGroup] = useState<string | null>(null);

  const handleDeleteGroup = async (groupId: string, groupName: string) => {
    setDeletingGroup(groupId);
    
    try {
      // Delete in order: join requests, members, then group
      const { error: requestsError } = await supabase
        .from('acircle_join_requests')
        .delete()
        .eq('group_id', groupId);

      if (requestsError) throw requestsError;

      const { error: membersError } = await supabase
        .from('acircle_members')
        .delete()
        .eq('group_id', groupId);

      if (membersError) throw membersError;

      const { error: groupError } = await supabase
        .from('acircle_groups')
        .delete()
        .eq('id', groupId);

      if (groupError) throw groupError;

      toast({
        title: "Group Deleted",
        description: `${groupName} has been permanently deleted.`,
      });

      onGroupDeleted();
    } catch (error: any) {
      console.error('Error deleting group:', error);
      toast({
        title: "Error",
        description: `Failed to delete group: ${error.message}`,
        variant: "destructive"
      });
    } finally {
      setDeletingGroup(null);
    }
  };

  return (
    <Card className="bg-red-50 border-red-200">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-red-800">
          <AlertTriangle className="h-5 w-5" />
          Danger Zone - Delete Groups
          <Badge className="bg-red-600 text-white text-xs">Admin Only</Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="bg-red-100 border border-red-300 rounded-lg p-4">
          <div className="flex items-center gap-2 text-red-800 mb-2">
            <Shield className="h-4 w-4" />
            <span className="font-medium text-sm">Warning</span>
          </div>
          <p className="text-sm text-red-700">
            Deleting a group will permanently remove all members, join requests, and group data. This action cannot be undone.
          </p>
        </div>
        
        <div className="space-y-3">
          {groups.map((group) => (
            <div key={group.id} className="flex items-center justify-between p-3 border border-red-200 rounded-lg bg-white">
              <div className="flex items-center gap-3">
                <Users className="h-4 w-4 text-gray-600" />
                <div>
                  <p className="font-medium text-gray-900">{group.name}</p>
                  <p className="text-sm text-gray-600">
                    {group.member_count} members • {group.is_private ? 'Private' : 'Public'}
                  </p>
                </div>
              </div>
              
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button
                    variant="destructive"
                    size="sm"
                    disabled={deletingGroup === group.id}
                  >
                    <Trash2 className="h-4 w-4 mr-1" />
                    Delete
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Delete Group: {group.name}</AlertDialogTitle>
                    <AlertDialogDescription>
                      This will permanently delete the group "{group.name}" and all associated data including:
                      <ul className="list-disc list-inside mt-2 space-y-1">
                        <li>{group.member_count || 0} group members</li>
                        <li>All join requests</li>
                        <li>Group posts and activity</li>
                        <li>All group settings and data</li>
                      </ul>
                      <strong className="block mt-3 text-red-600">This action cannot be undone.</strong>
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction
                      onClick={() => handleDeleteGroup(group.id, group.name)}
                      className="bg-red-600 hover:bg-red-700"
                    >
                      Delete Permanently
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </div>
          ))}
          
          {groups.length === 0 && (
            <p className="text-center text-gray-500 py-4">No groups available to delete</p>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default AdminGroupDeleteManager;