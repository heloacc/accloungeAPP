import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useAppContext } from '@/contexts/OptimizedAppContext';
import { useUserRole } from '@/hooks/useUserRole';
import { supabase } from '@/lib/supabase';
import { Users, Plus, Shield, Lock, AlertCircle } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';

interface Group {
  id: string;
  name: string;
  description: string;
  is_private: boolean;
  max_members: number;
  isMember?: boolean;
  canAccess?: boolean;
}

const RoleBasedGroupsView = ({ onNavigate }: { onNavigate?: (tab: string, data?: any) => void }) => {
  const { currentUser } = useAppContext();
  const { role, isAdmin, canCreateGroups } = useUserRole();
  const [myGroups, setMyGroups] = useState<Group[]>([]);
  const [discoverGroups, setDiscoverGroups] = useState<Group[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (currentUser?.id) {
      fetchGroups();
    }
  }, [currentUser?.id, role]);

  const fetchGroups = async () => {
    if (!currentUser?.id) return;
    
    setLoading(true);
    
    try {
      if (isAdmin) {
        // Admins see all groups
        const { data: allGroups } = await supabase
          .from('acircle_groups')
          .select('*')
          .eq('is_archived', false)
          .order('created_at', { ascending: false });
        
        setMyGroups(allGroups || []);
        setDiscoverGroups([]);
      } else {
        // Get user's group memberships
        const { data: memberships } = await supabase
          .from('acircle_members')
          .select('group_id')
          .eq('user_id', currentUser.id)
          .eq('status', 'active');

        const memberGroupIds = memberships?.map(m => m.group_id) || [];

        // Get user's groups
        if (memberGroupIds.length > 0) {
          const { data: userGroups } = await supabase
            .from('acircle_groups')
            .select('*')
            .in('id', memberGroupIds)
            .eq('is_archived', false);
          
          setMyGroups(userGroups || []);
        } else {
          setMyGroups([]);
        }

        // Get discoverable groups (public groups user isn't in)
        let discoverQuery = supabase
          .from('acircle_groups')
          .select('*')
          .eq('is_private', false)
          .eq('is_archived', false);

        if (memberGroupIds.length > 0) {
          discoverQuery = discoverQuery.not('id', 'in', `(${memberGroupIds.join(',')})`);
        }

        const { data: publicGroups } = await discoverQuery;

        setDiscoverGroups(publicGroups || []);
      }
    } catch (err: any) {
      toast({
        title: "Error Loading Groups",
        description: err.message || 'Failed to load groups.',
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleGroupAccess = async (groupId: string, group: Group) => {
    if (!currentUser?.id) return;

    // Admins and members can access directly
    if (isAdmin || group.isMember) {
      sessionStorage.setItem('selectedGroupId', groupId);
      
      if (onNavigate) {
        onNavigate('active-circle', { groupId });
      } else {
        window.dispatchEvent(new CustomEvent('navigate-to-tab', { 
          detail: { tab: 'active-circle', data: { groupId } }
        }));
      }
      return;
    }

    // Non-members need to request access
    toast({
      title: "Access Denied",
      description: "You must be a member to access this group.",
      variant: "destructive"
    });
  };

  if (loading) {
    return (
      <div className="space-y-6 p-6">
        <h2 className="text-2xl font-bold text-[#001B30]">Groups</h2>
        <div className="text-center py-8">
          <p className="text-[#7E8E9D]">Loading groups...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 p-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-[#001B30]">Groups</h2>
          <p className="text-[#7E8E9D]">
            {isAdmin ? 'Manage all groups' : 'Connect with like-minded people'}
          </p>
        </div>
        {canCreateGroups && (
          <Button 
            onClick={() => onNavigate?.('create-group')}
            className="bg-[#596D59] hover:bg-[#4A5A4A] text-white"
          >
            <Plus className="h-4 w-4 mr-2" />
            Create Group
          </Button>
        )}
      </div>

      {isAdmin && (
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
          <div className="flex items-center gap-2 text-yellow-800">
            <Shield className="h-5 w-5" />
            <span className="font-medium">Admin Access</span>
          </div>
          <p className="text-sm text-yellow-700 mt-1">
            You have administrative access to all groups.
          </p>
        </div>
      )}

      <Tabs defaultValue={isAdmin ? "all-groups" : "my-groups"} className="w-full">
        <TabsList>
          {isAdmin ? (
            <TabsTrigger value="all-groups">All Groups ({myGroups.length})</TabsTrigger>
          ) : (
            <>
              <TabsTrigger value="my-groups">My Groups ({myGroups.length})</TabsTrigger>
              <TabsTrigger value="discover">Discover ({discoverGroups.length})</TabsTrigger>
            </>
          )}
        </TabsList>

        {isAdmin ? (
          <TabsContent value="all-groups" className="space-y-6">
            {myGroups.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-[#7E8E9D] mb-4">No groups found.</p>
                <Button onClick={fetchGroups} className="bg-blue-600 hover:bg-blue-700 text-white">
                  Refresh
                </Button>
              </div>
            ) : (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {myGroups.map((group) => (
                  <Card key={group.id} className="border-[#596D59]/20 hover:shadow-md transition-shadow">
                    <CardHeader>
                      <div className="flex justify-between items-start">
                        <CardTitle className="flex items-center gap-2 text-[#001B30]">
                          <Users className="h-5 w-5 text-[#596D59]" />
                          {group.name}
                        </CardTitle>
                        {group.is_private && (
                          <Badge variant="outline" className="text-xs">
                            <Lock className="h-3 w-3 mr-1" />
                            Private
                          </Badge>
                        )}
                      </div>
                      <p className="text-sm text-[#7E8E9D]">{group.description}</p>
                    </CardHeader>
                    <CardContent>
                      <Button 
                        className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                        onClick={() => handleGroupAccess(group.id, group)}
                      >
                        <Users className="h-4 w-4 mr-2" />
                        Enter Group
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
        ) : (
          <>
            <TabsContent value="my-groups" className="space-y-6">
              {myGroups.length === 0 ? (
                <div className="text-center py-8">
                  <p className="text-[#7E8E9D] mb-4">You haven't joined any groups yet.</p>
                  <Button onClick={() => {
                    const tabsElement = document.querySelector('[data-state="inactive"][value="discover"]') as HTMLElement;
                    tabsElement?.click();
                  }} className="bg-blue-600 hover:bg-blue-700 text-white">
                    Discover Groups
                  </Button>
                </div>
              ) : (
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {myGroups.map((group) => (
                    <Card key={group.id} className="border-[#596D59]/20 hover:shadow-md transition-shadow">
                      <CardHeader>
                        <div className="flex justify-between items-start">
                          <CardTitle className="flex items-center gap-2 text-[#001B30]">
                            <Users className="h-5 w-5 text-[#596D59]" />
                            {group.name}
                          </CardTitle>
                          <Badge variant="secondary" className="text-xs">Member</Badge>
                        </div>
                        <p className="text-sm text-[#7E8E9D]">{group.description}</p>
                      </CardHeader>
                      <CardContent>
                        <Button 
                          className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                          onClick={() => handleGroupAccess(group.id, { ...group, isMember: true })}
                        >
                          <Users className="h-4 w-4 mr-2" />
                          Enter Group
                        </Button>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </TabsContent>

            <TabsContent value="discover" className="space-y-6">
              {discoverGroups.length === 0 ? (
                <div className="text-center py-8">
                  <p className="text-[#7E8E9D] mb-4">No public groups available to join.</p>
                </div>
              ) : (
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {discoverGroups.map((group) => (
                    <Card key={group.id} className="border-[#596D59]/20 hover:shadow-md transition-shadow">
                      <CardHeader>
                        <div className="flex justify-between items-start">
                          <CardTitle className="flex items-center gap-2 text-[#001B30]">
                            <Users className="h-5 w-5 text-[#596D59]" />
                            {group.name}
                          </CardTitle>
                          <Badge variant="outline" className="text-xs">Public</Badge>
                        </div>
                        <p className="text-sm text-[#7E8E9D]">{group.description}</p>
                      </CardHeader>
                       <CardContent>
                         <Button
                          className="w-full bg-green-600 hover:bg-green-700 text-white"
                          onClick={async () => {
                            try {
                              // Simplified join request - directly insert into join requests table
                              const { error } = await supabase
                                .from('acircle_join_requests')
                                .insert([{
                                  user_id: currentUser.id,
                                  group_id: group.id,
                                  message: `I would like to join ${group.name}`,
                                  status: 'pending'
                                }]);

                              if (error) {
                                // If error is duplicate, show appropriate message
                                if (error.code === '23505') {
                                  toast({
                                    title: "Request Already Sent",
                                    description: "You have already requested to join this group.",
                                    variant: "default"
                                  });
                                  return;
                                }
                                throw error;
                              }

                              toast({
                                title: "Request Sent",
                                description: "Your join request has been submitted for review.",
                                variant: "default"
                              });
                              
                              // Refresh groups to update UI
                              fetchGroups();
                            } catch (err: any) {
                              toast({
                                title: "Request Failed",
                                description: err.message || "Failed to send join request.",
                                variant: "destructive"
                              });
                            }
                          }}
                         >
                           <Plus className="h-4 w-4 mr-2" />
                           Request to Join
                         </Button>
                        </CardContent>
                     </Card>
                   ))}
                 </div>
               )}
             </TabsContent>
           </>
         )}
      </Tabs>
    </div>
  );
};

export default RoleBasedGroupsView;