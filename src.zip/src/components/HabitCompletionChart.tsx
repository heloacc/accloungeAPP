import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { BarChart3, Calendar, TrendingUp } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useSession } from '@/hooks/useSession';

interface HabitData {
  date: string;
  completed: number;
  total: number;
  rate: number;
}

const HabitCompletionChart: React.FC = () => {
  const { session } = useSession();
  const [data, setData] = useState<HabitData[]>([]);
  const [timeframe, setTimeframe] = useState<'week' | 'month' | '3months'>('month');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (session?.user?.id) {
      loadHabitData();
    }
  }, [session?.user?.id, timeframe]);

  const loadHabitData = async () => {
    try {
      setLoading(true);
      const userId = session?.user?.id;
      const days = timeframe === 'week' ? 7 : timeframe === 'month' ? 30 : 90;

      // Use separate queries to avoid relationship issues
      const [habitsRes, habitLogsRes] = await Promise.all([
        supabase
          .from('habits')
          .select('id, title, is_active')
          .eq('user_id', userId)
          .eq('is_active', true),
        supabase
          .from('habit_logs')
          .select('habit_id, date, status')
          .eq('user_id', userId)
          .gte('date', new Date(Date.now() - days * 24 * 60 * 60 * 1000).toISOString().split('T')[0])
          .order('date', { ascending: true })
      ]);

      const habitsData = habitsRes.data || [];
      const habitLogsData = habitLogsRes.data || [];

      // Process data by date
      const dateMap = new Map<string, { completed: number; total: number }>();
      const totalHabits = habitsData.length;

      // Initialize dates
      for (let i = 0; i < days; i++) {
        const date = new Date();
        date.setDate(date.getDate() - i);
        const dateStr = date.toISOString().split('T')[0];
        dateMap.set(dateStr, { completed: 0, total: totalHabits });
      }

      // Count completions
      habitLogsData.forEach(log => {
        if (log.status === 'done' && dateMap.has(log.date)) {
          const current = dateMap.get(log.date)!;
          dateMap.set(log.date, { ...current, completed: current.completed + 1 });
        }
      });

      const chartData: HabitData[] = Array.from(dateMap.entries())
        .map(([date, stats]) => ({
          date,
          completed: stats.completed,
          total: stats.total,
          rate: stats.total > 0 ? Math.round((stats.completed / stats.total) * 100) : 0
        }))
        .sort((a, b) => a.date.localeCompare(b.date));

      setData(chartData);
    } catch (error) {
      console.error('Error loading habit data:', error);
      setData([]);
    } finally {
      setLoading(false);
    }
  };

  const avgRate = data.length > 0 ? Math.round(data.reduce((sum, d) => sum + d.rate, 0) / data.length) : 0;

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold">Habit Completion Patterns</h3>
        <Select value={timeframe} onValueChange={(value: any) => setTimeframe(value)}>
          <SelectTrigger className="w-32">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="week">Week</SelectItem>
            <SelectItem value="month">Month</SelectItem>
            <SelectItem value="3months">3 Months</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <BarChart3 className="h-8 w-8 text-blue-600 mx-auto mb-2" />
            <div className="text-2xl font-bold">{avgRate}%</div>
            <div className="text-sm text-gray-600">Average Rate</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <TrendingUp className="h-8 w-8 text-green-600 mx-auto mb-2" />
            <div className="text-2xl font-bold">{data[data.length - 1]?.rate || 0}%</div>
            <div className="text-sm text-gray-600">Latest Rate</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <Calendar className="h-8 w-8 text-purple-600 mx-auto mb-2" />
            <div className="text-2xl font-bold">{data.filter(d => d.rate === 100).length}</div>
            <div className="text-sm text-gray-600">Perfect Days</div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Daily Completion Rates</CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex justify-center p-8">
              <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary"></div>
            </div>
          ) : (
            <div className="space-y-2">
              {data.slice(-14).map((item) => (
                <div key={item.date} className="flex items-center gap-3">
                  <div className="w-20 text-sm text-gray-600">
                    {new Date(item.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <div className="flex-1 bg-gray-200 rounded-full h-2">
                        <div 
                          className={`h-2 rounded-full transition-all duration-300 ${
                            item.rate === 100 ? 'bg-green-500' : 
                            item.rate >= 75 ? 'bg-blue-500' : 
                            item.rate >= 50 ? 'bg-yellow-500' : 'bg-red-500'
                          }`}
                          style={{ width: `${item.rate}%` }}
                        />
                      </div>
                      <div className="w-12 text-sm font-medium text-right">
                        {item.rate}%
                      </div>
                    </div>
                  </div>
                  <div className="w-16 text-sm text-gray-500 text-right">
                    {item.completed}/{item.total}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default HabitCompletionChart;