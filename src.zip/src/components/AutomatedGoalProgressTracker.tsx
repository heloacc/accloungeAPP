import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Target, Trophy, Bell, TrendingUp, CheckCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';
import { calculateAndUpdateGoalProgress, updateAutoTaskProgress } from '@/utils/goalProgressCalculator';
interface Goal {
  id: string;
  title: string;
  completion_percent: number;
  status: string;
  target_date?: string;
  goal_tasks?: Task[];
}

interface Task {
  id: string;
  title: string;
  type: string;
  status: string;
  auto_config?: {
    habit_id: string;
    rule: string;
    target_number: number;
    current_count?: number;
  };
}

interface Milestone {
  id: string;
  goal_id: string;
  percentage: number;
  title: string;
  achieved: boolean;
  achieved_at?: string;
}

export default function AutomatedGoalProgressTracker() {
  const [goals, setGoals] = useState<Goal[]>([]);
  const [milestones, setMilestones] = useState<Milestone[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    loadGoalsAndMilestones();
    setupHabitCompletionListener();
    
    return () => {
      window.removeEventListener('habitCompleted', handleHabitCompletion);
    };
  }, []);

  const loadGoalsAndMilestones = async () => {
    try {
      const { data: user } = await supabase.auth.getUser();
      if (!user.user) return;

      const [goalsRes, milestonesRes] = await Promise.all([
        supabase.from('goals').select(`
          *,
          goal_tasks(*)
        `).eq('user_id', user.user.id).eq('status', 'active'),
        supabase.from('goal_milestones').select('*').eq('user_id', user.user.id)
      ]);

      setGoals(goalsRes.data || []);
      setMilestones(milestonesRes.data || []);
    } catch (error) {
      console.error('Error loading goals:', error);
    } finally {
      setLoading(false);
    }
  };

  const setupHabitCompletionListener = () => {
    window.addEventListener('habitCompleted', handleHabitCompletion);
  };

  const handleHabitCompletion = async (event: any) => {
    const { habitId } = event.detail;
    await updateLinkedGoalProgress(habitId);
  };

  const updateLinkedGoalProgress = async (habitId: string) => {
    try {
      const { data: user } = await supabase.auth.getUser();
      if (!user.user) return;

      // Use centralized function to update auto task progress
      await updateAutoTaskProgress(habitId, user.user.id);
      
      // Refresh data to show updated progress
      await loadGoalsAndMilestones();
    } catch (error) {
      console.error('Error updating goal progress:', error);
    }
  };

  const recalculateGoalCompletion = async (goalId: string) => {
    try {
      // Get updated tasks
      const { data: tasks } = await supabase
        .from('goal_tasks')
        .select('*')
        .eq('goal_id', goalId);

      if (!tasks || tasks.length === 0) return;

      const completedTasks = tasks.filter(t => t.status === 'done').length;
      const newCompletionPercent = Math.round((completedTasks / tasks.length) * 100);

      // Update goal completion percentage
      await supabase
        .from('goals')
        .update({ completion_percent: newCompletionPercent })
        .eq('id', goalId);

      // Check for milestone achievements
      await checkMilestoneAchievements(goalId, newCompletionPercent);

      // Check for goal completion
      if (newCompletionPercent === 100) {
        await handleGoalCompletion(goalId);
      }

      // Refresh data
      loadGoalsAndMilestones();
    } catch (error) {
      console.error('Error recalculating goal completion:', error);
    }
  };

  const checkMilestoneAchievements = async (goalId: string, completionPercent: number) => {
    const goalMilestones = milestones.filter(m => 
      m.goal_id === goalId && 
      !m.achieved && 
      completionPercent >= m.percentage
    );

    for (const milestone of goalMilestones) {
      await achieveMilestone(milestone);
    }
  };

  const achieveMilestone = async (milestone: Milestone) => {
    try {
      const { data: user } = await supabase.auth.getUser();
      if (!user.user) return;

      // Mark milestone as achieved
      await supabase
        .from('goal_milestones')
        .update({ 
          achieved: true, 
          achieved_at: new Date().toISOString() 
        })
        .eq('id', milestone.id);

      // Create notification
      await supabase.from('notifications').insert({
        user_id: user.user.id,
        type: 'milestone_achieved',
        title: 'Milestone Achieved! 🎉',
        message: `You've reached ${milestone.percentage}% progress on "${milestone.title}"`,
        data: { milestone_id: milestone.id, goal_id: milestone.goal_id }
      });

      toast({
        title: 'Milestone Achieved! 🎉',
        description: `${milestone.percentage}% progress reached!`
      });
    } catch (error) {
      console.error('Error achieving milestone:', error);
    }
  };

  const handleGoalCompletion = async (goalId: string) => {
    try {
      const { data: user } = await supabase.auth.getUser();
      if (!user.user) return;

      const goal = goals.find(g => g.id === goalId);
      if (!goal) return;

      // Update goal status to completed
      await supabase
        .from('goals')
        .update({ status: 'completed' })
        .eq('id', goalId);

      // Create notification
      await supabase.from('notifications').insert({
        user_id: user.user.id,
        type: 'goal_completed',
        title: 'Goal Completed! 🏆',
        message: `Congratulations! You've completed "${goal.title}"`,
        data: { goal_id: goalId }
      });

      toast({
        title: 'Goal Completed! 🏆',
        description: `Congratulations on completing "${goal.title}"!`
      });
    } catch (error) {
      console.error('Error handling goal completion:', error);
    }
  };

  if (loading) {
    return <div className="text-center py-8">Loading goal progress tracker...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3 mb-6">
        <Target className="h-8 w-8 text-primary" />
        <div>
          <h2 className="text-2xl font-bold">Automated Goal Progress</h2>
          <p className="text-muted-foreground">Real-time tracking of your goal achievements</p>
        </div>
      </div>

      {goals.length === 0 ? (
        <Card>
          <CardContent className="text-center py-8">
            <Target className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
            <h3 className="text-lg font-semibold mb-2">No Active Goals</h3>
            <p className="text-muted-foreground">Create some goals to start tracking progress automatically.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-6">
          {goals.map((goal) => {
            const goalMilestones = milestones.filter(m => m.goal_id === goal.id);
            const nextMilestone = goalMilestones.find(m => !m.achieved && m.percentage > goal.completion_percent);
            
            return (
              <Card key={goal.id} className="border-l-4 border-l-primary">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-xl">{goal.title}</CardTitle>
                    <div className="flex items-center gap-2">
                      <Badge variant={goal.completion_percent === 100 ? 'default' : 'secondary'}>
                        {goal.completion_percent}% Complete
                      </Badge>
                      {goal.completion_percent === 100 && (
                        <Trophy className="h-5 w-5 text-yellow-500" />
                      )}
                    </div>
                  </div>
                  <Progress value={goal.completion_percent} className="mt-2" />
                </CardHeader>
                
                <CardContent className="space-y-4">
                  {nextMilestone && (
                    <div className="bg-blue-50 p-3 rounded-lg">
                      <div className="flex items-center gap-2">
                        <TrendingUp className="h-4 w-4 text-blue-600" />
                        <span className="text-sm font-medium text-blue-800">
                          Next Milestone: {nextMilestone.percentage}%
                        </span>
                      </div>
                      <p className="text-xs text-blue-600 mt-1">{nextMilestone.title}</p>
                    </div>
                  )}

                  {goal.goal_tasks && goal.goal_tasks.length > 0 && (
                    <div className="space-y-2">
                      <h4 className="font-medium">Automated Tasks:</h4>
                      {goal.goal_tasks
                        .filter(task => task.type === 'auto')
                        .map((task) => (
                          <div key={task.id} className="flex items-center justify-between p-2 border rounded">
                            <div className="flex items-center gap-2">
                              {task.status === 'done' ? (
                                <CheckCircle className="h-4 w-4 text-green-600" />
                              ) : (
                                <div className="h-4 w-4 border rounded-full" />
                              )}
                              <span className={task.status === 'done' ? 'line-through text-muted-foreground' : ''}>
                                {task.title}
                              </span>
                            </div>
                            {task.auto_config && (
                              <Badge variant="outline" className="text-xs">
                                {task.auto_config.current_count || 0}/{task.auto_config.target_number}
                              </Badge>
                            )}
                          </div>
                        ))}
                    </div>
                  )}

                  {goalMilestones.filter(m => m.achieved).length > 0 && (
                    <div className="space-y-2">
                      <h4 className="font-medium">Achieved Milestones:</h4>
                      <div className="flex flex-wrap gap-2">
                        {goalMilestones
                          .filter(m => m.achieved)
                          .map((milestone) => (
                            <Badge key={milestone.id} variant="secondary" className="bg-green-100 text-green-800">
                              {milestone.percentage}% ✓
                            </Badge>
                          ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}