import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAppContext } from '@/contexts/OptimizedAppContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Textarea } from '@/components/ui/textarea';
import { Heart, MessageCircle, Send, Sparkles, ThumbsUp, Star, Loader2 } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';

interface EncouragementMessage {
  id: string;
  sender_id: string;
  sender_name: string;
  recipient_name: string;
  message: string;
  type: 'motivation' | 'congratulations' | 'support';
  timestamp: Date;
  likes: number;
}

export const SocialEncouragementSystem = () => {
  const { currentUser } = useAppContext();
  const [newMessage, setNewMessage] = useState('');
  const [selectedType, setSelectedType] = useState<'motivation' | 'congratulations' | 'support'>('motivation');
  const [messages, setMessages] = useState<EncouragementMessage[]>([]);
  const [loading, setLoading] = useState(true);
  const [posting, setPosting] = useState(false);

  useEffect(() => {
    fetchMessages();
  }, []);

  const fetchMessages = async () => {
    try {
      const { data: posts, error } = await supabase
        .from('acircle_posts')
        .select(`
          id,
          content,
          created_at,
          user_id,
          post_type,
          profiles!fk_acircle_posts_user_id (
            name,
            full_name,
            avatar_url
          )
        `)
        .eq('post_type', 'encouragement')
        .order('created_at', { ascending: false })
        .limit(20);
      
      if (error) throw error;

      const formattedMessages: EncouragementMessage[] = (posts || []).map(post => ({
        id: post.id,
        sender_id: post.user_id,
        sender_name: post.profiles?.name || post.profiles?.full_name || 'Community Member',
        recipient_name: 'Community',
        message: post.content,
        type: 'motivation',
        timestamp: new Date(post.created_at),
        likes: 0
      }));

      setMessages(formattedMessages);
    } catch (error) {
      console.error('Error fetching messages:', error);
      // Fallback to mock data with initial posts from Caris
      setMessages([
        {
          id: '1',
          sender_id: 'caris-founder',
          sender_name: 'Caris (Founder)',
          recipient_name: 'Community',
          message: 'Welcome to AccLounge! Remember, every small step counts. Your journey to better habits starts with just one day at a time. We\'re here to support each other! 🌟',
          type: 'motivation',
          timestamp: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000), // 2 days ago
          likes: 12
        },
        {
          id: '2',
          sender_id: 'caris-founder',
          sender_name: 'Caris (Founder)',
          recipient_name: 'Community',
          message: 'Consistency beats perfection every time. Don\'t worry if you miss a day - just get back on track tomorrow. Your accountability partners are here to help! 💪',
          type: 'support',
          timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000), // 1 day ago
          likes: 8
        },
        {
          id: '3',
          sender_id: 'community-member-1',
          sender_name: 'Emma L.',
          recipient_name: 'Community',
          message: 'Just completed my 7-day meditation streak! The morning mindfulness sessions have been game-changing. Thank you all for the encouragement!',
          type: 'congratulations',
          timestamp: new Date(Date.now() - 4 * 60 * 60 * 1000), // 4 hours ago
          likes: 15
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  const encouragementTypes = [
    { type: 'motivation' as const, label: 'Motivation', icon: Sparkles, color: 'bg-purple-100 text-purple-800' },
    { type: 'congratulations' as const, label: 'Congratulations', icon: Star, color: 'bg-yellow-100 text-yellow-800' },
    { type: 'support' as const, label: 'Support', icon: Heart, color: 'bg-red-100 text-red-800' }
  ];

  const sendEncouragement = async () => {
    if (!newMessage.trim() || !currentUser) return;
    
    setPosting(true);
    try {
      const { error } = await supabase
        .from('acircle_posts')
        .insert({
          user_id: currentUser.id,
          content: newMessage,
          post_type: 'encouragement',
          group_id: null
        });

      if (error) throw error;

      toast({
        title: "Encouragement Sent!",
        description: "Your message has been shared with the community.",
      });

      setNewMessage('');
      fetchMessages();
    } catch (error) {
      console.error('Error sending encouragement:', error);
      toast({
        title: "Error",
        description: "Failed to send encouragement. Please try again.",
        variant: "destructive"
      });
    } finally {
      setPosting(false);
    }
  };

  const getTypeIcon = (type: string) => {
    const typeConfig = encouragementTypes.find(t => t.type === type);
    if (!typeConfig) return Heart;
    return typeConfig.icon;
  };

  const getTypeColor = (type: string) => {
    const typeConfig = encouragementTypes.find(t => t.type === type);
    return typeConfig?.color || 'bg-gray-100 text-gray-800';
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="p-6 text-center">
          <Loader2 className="w-6 h-6 animate-spin mx-auto mb-2" />
          <p className="text-muted-foreground">Loading encouragement messages...</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Send Encouragement */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Heart className="w-5 h-5 text-[#596D59]" />
            Send Encouragement
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            {encouragementTypes.map(({ type, label, icon: Icon, color }) => (
              <Button
                key={type}
                size="sm"
                variant={selectedType === type ? "default" : "outline"}
                onClick={() => setSelectedType(type)}
                className={selectedType === type ? "bg-[#596D59] hover:bg-[#596D59]/90" : ""}
              >
                <Icon className="w-4 h-4 mr-1" />
                {label}
              </Button>
            ))}
          </div>
          
          <Textarea
            placeholder="Write an encouraging message to lift someone up..."
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            className="min-h-[100px]"
          />
          
          <Button 
            onClick={sendEncouragement}
            disabled={!newMessage.trim() || posting}
            className="bg-[#596D59] hover:bg-[#596D59]/90"
          >
            {posting ? (
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            ) : (
              <Send className="w-4 h-4 mr-2" />
            )}
            {posting ? 'Sending...' : `Send ${encouragementTypes.find(t => t.type === selectedType)?.label}`}
          </Button>
        </CardContent>
      </Card>

      {/* Encouragement Feed */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MessageCircle className="w-5 h-5 text-[#596D59]" />
            Community Encouragement
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {messages.length === 0 ? (
            <div className="text-center py-8">
              <Heart className="w-12 h-12 text-[#7E8E9D] mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-[#001B30] mb-2">No Messages Yet</h3>
              <p className="text-[#7E8E9D]">Be the first to send some encouragement!</p>
            </div>
          ) : (
            messages.map((message) => {
              const TypeIcon = getTypeIcon(message.type);
              return (
                <Card key={message.id} className="border-[#596D59]/20 bg-gradient-to-r from-white to-gray-50">
                  <CardContent className="p-4">
                    <div className="flex items-start gap-3">
                      <Avatar className="w-8 h-8">
                        <AvatarFallback className="bg-[#596D59] text-white text-sm">
                          {message.sender_name.split(' ').map(n => n[0]).join('')}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <span className="font-medium text-[#001B30]">{message.sender_name}</span>
                          <span className="text-[#7E8E9D]">→</span>
                          <span className="font-medium text-[#001B30]">{message.recipient_name}</span>
                          <Badge className={getTypeColor(message.type)}>
                            <TypeIcon className="w-3 h-3 mr-1" />
                            {message.type}
                          </Badge>
                        </div>
                        
                        <p className="text-[#2C2C44] mb-3 italic">"{message.message}"</p>
                        
                        <div className="flex items-center justify-between">
                          <span className="text-xs text-[#7E8E9D]">
                            {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </span>
                          <Button
                            size="sm"
                            variant="ghost"
                            className="text-[#7E8E9D] hover:text-red-600"
                          >
                            <ThumbsUp className="w-4 h-4 mr-1" />
                            {message.likes}
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })
          )}
        </CardContent>
      </Card>
    </div>
  );
};