import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { VisuallyHidden } from '@/components/ui/visually-hidden';
import { Badge } from '@/components/ui/badge';
import { Menu, X, User, Settings, Shield, Users, Target, Calendar, MessageSquare, Trophy, Bell, CreditCard, Home, CheckCircle, BookOpen, Crown, Database, Activity, Heart } from 'lucide-react';
import { useAppContext } from '@/contexts/OptimizedAppContext';
import { useStableUserRole } from '@/hooks/useStableUserRole';

interface ResponsiveNavigationProps {
   activeTab: string;
  setActiveTab: (tab: string) => void;
}

const ResponsiveNavigation: React.FC<ResponsiveNavigationProps> = ({ activeTab, setActiveTab }) => {
  const [isOpen, setIsOpen] = useState(false);
  const { currentUser } = useAppContext();
  const { isAdmin, role } = useStableUserRole();
  
  // Special admin detection for hello@acclounge.org
  const isSpecialAdmin = currentUser?.email === 'hello@acclounge.org';
  
  // Debug logging

  const navigationItems = [
    { id: 'dashboard', label: 'Dashboard', icon: Home },
    { id: 'habits-goals', label: 'Habits & Goals', icon: CheckCircle },
    { id: 'user-analytics', label: 'My Analytics', icon: Activity },
    { id: 'groups', label: 'Spaces', icon: Users },
    { id: 'find-partners', label: 'Find Partners', icon: Target },
    { id: 'social-habits', label: 'Social Habits', icon: Heart },
    { id: 'community-feed', label: 'Community Feed', icon: MessageSquare },
    { id: 'achievements', label: 'Achievements', icon: Trophy },
    { id: 'notifications', label: 'Notifications', icon: Bell },
    { id: 'resources', label: 'Resources', icon: BookOpen },
    { id: 'billing', label: 'Billing', icon: CreditCard },
    { id: 'admin-tier-manager', label: 'Tier Management', icon: Crown, adminOnly: true },
    { id: 'admin-dashboard', label: 'Admin Management', icon: Database, adminOnly: true },
    { id: 'admin-notifications', label: 'Notification Management', icon: Bell, adminOnly: true },
    { id: 'member-momentum', label: 'Member Momentum', icon: Activity, adminOnly: true },
  ];

  // Use multiple sources for admin detection with special case for hello@acclounge.org
  const finalIsAdmin = isAdmin || currentUser?.isAdmin || isSpecialAdmin || false;

  // Filter navigation items based on admin status
  const filteredNavigationItems = navigationItems.filter(item => 
    !item.adminOnly || finalIsAdmin
  );
  const handleNavigation = (tabId: string) => {
    setActiveTab(tabId);
    setIsOpen(false);
  };

  const NavItem = ({ item }: { item: typeof navigationItems[0] }) => {
    const Icon = item.icon;
    const isActive = activeTab === item.id;
    
    return (
      <Button
        variant={isActive ? "default" : "ghost"}
        className={`w-full justify-start gap-2 h-10 text-sm ${
          isActive 
            ? 'bg-acclounge-brown text-white hover:bg-acclounge-brown/90' 
            : 'hover:bg-acclounge-sage/10 hover:text-acclounge-brown text-acclounge-slate'
        }`}
        onClick={() => handleNavigation(item.id)}
      >
        <Icon className="h-4 w-4" />
        <span className="font-medium">{item.label}</span>
        {item.id === 'notifications' && (
          <Badge variant="secondary" className="ml-auto text-xs">3</Badge>
        )}
      </Button>
    );
  };

  return (
    <>
      {/* Mobile Navigation */}
      <div className="lg:hidden fixed top-0 left-0 right-0 z-50 bg-white border-b border-acclounge-sage/20 shadow-sm">
        <div className="flex items-center justify-between p-3">
          <h1 className="text-lg font-bold text-acclounge-brown">ACCLOUNGE</h1>
          <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="sm" className="p-2">
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-80 p-0 max-w-[90vw]">
              <SheetHeader>
                <VisuallyHidden>
                  <SheetTitle>Navigation Menu</SheetTitle>
                </VisuallyHidden>
              </SheetHeader>
              <div className="flex flex-col h-full">
                <div className="flex items-center justify-between p-4 border-b bg-acclounge-brown/5">
                  <h2 className="font-semibold text-acclounge-brown">Navigation</h2>
                  <Button variant="ghost" size="sm" onClick={() => setIsOpen(false)} className="p-1">
                    <X className="h-4 w-4" />
                  </Button>
                </div>
                <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
                  {filteredNavigationItems.map((item) => (
                    <NavItem key={item.id} item={item} />
                  ))}
                </nav>
                <div className="p-3 border-t bg-gray-50">
                  <Button
                    variant={activeTab === 'profile' ? "default" : "ghost"}
                    className={`w-full justify-start gap-2 h-10 text-sm ${
                      activeTab === 'profile' 
                        ? 'bg-acclounge-brown text-white hover:bg-acclounge-brown/90' 
                        : 'hover:bg-acclounge-sage/10 hover:text-acclounge-brown text-acclounge-slate'
                    }`}
                    onClick={() => handleNavigation('profile')}
                  >
                    <User className="h-4 w-4" />
                    <span className="font-medium">Profile</span>
                  </Button>
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>

      {/* Desktop Sidebar */}
      <div className="hidden lg:flex lg:flex-col lg:w-56 lg:fixed lg:inset-y-0 bg-white border-r border-acclounge-sage/20">
        <div className="flex flex-col h-full">
          <div className="p-4 border-b border-acclounge-sage/20 bg-acclounge-brown/5">
            <h1 className="text-lg font-bold text-acclounge-brown">ACCLOUNGE</h1>
          </div>
          <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
            {filteredNavigationItems.map((item) => (
              <NavItem key={item.id} item={item} />
            ))}
          </nav>
          <div className="p-3 border-t border-acclounge-sage/20">
            <Button
              variant={activeTab === 'profile' ? "default" : "ghost"}
              className={`w-full justify-start gap-2 h-10 text-sm ${
                activeTab === 'profile' 
                  ? 'bg-acclounge-brown text-white hover:bg-acclounge-brown/90' 
                  : 'hover:bg-acclounge-sage/10 hover:text-acclounge-brown text-acclounge-slate'
              }`}
              onClick={() => handleNavigation('profile')}
            >
              <User className="h-4 w-4" />
              <span className="font-medium">Profile</span>
            </Button>
          </div>
        </div>
      </div>
    </>
  );
};

export default ResponsiveNavigation;