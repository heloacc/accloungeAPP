import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Trophy, Star, Users, Target } from 'lucide-react';

interface Achievement {
  id: string;
  name: string;
  icon: string;
  unlocked: boolean;
  progress?: number;
  requirement?: string;
  imageUrl?: string;
}

interface AchievementsBadgesProps {
  achievements: Achievement[];
  badgeImages: string[];
}

export const AchievementsBadges: React.FC<AchievementsBadgesProps> = ({ 
  achievements, 
  badgeImages 
}) => {
  const [highlightedBadge, setHighlightedBadge] = useState(0);
  const unlockedAchievements = achievements.filter(a => a.unlocked);
  const nearlyUnlocked = achievements.filter(a => !a.unlocked && a.progress && a.progress > 50);

  useEffect(() => {
    if (unlockedAchievements.length > 0) {
      const interval = setInterval(() => {
        setHighlightedBadge((prev) => (prev + 1) % unlockedAchievements.length);
      }, 3000);
      return () => clearInterval(interval);
    }
  }, [unlockedAchievements.length]);

  const getIconComponent = (iconName: string) => {
    switch (iconName) {
      case 'trophy': return <Trophy className="h-4 w-4" />;
      case 'star': return <Star className="h-4 w-4" />;
      case 'users': return <Users className="h-4 w-4" />;
      case 'target': return <Target className="h-4 w-4" />;
      default: return <Trophy className="h-4 w-4" />;
    }
  };

  return (
    <Card className="mb-6">
      <CardHeader>
        <CardTitle className="text-xl font-semibold flex items-center gap-2">
          <Trophy className="h-5 w-5" />
          Your Wins
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Unlocked Badges */}
        <div>
          <h4 className="font-medium text-sm text-muted-foreground mb-3">Earned Badges</h4>
          <div className="flex flex-wrap gap-2">
            {unlockedAchievements.map((achievement, index) => (
              <div 
                key={achievement.id}
                className={`flex items-center gap-2 px-3 py-2 rounded-full border transition-all duration-300 ${
                  index === highlightedBadge 
                    ? 'bg-yellow-100 border-yellow-300 animate-pulse' 
                    : 'bg-card border-border'
                }`}
              >
                {achievement.imageUrl ? (
                  <img 
                    src={badgeImages[index % badgeImages.length]} 
                    alt={achievement.name}
                    className="w-6 h-6 rounded-full"
                  />
                ) : (
                  getIconComponent(achievement.icon)
                )}
                <span className="text-sm font-medium">{achievement.name}</span>
                <span className="text-lg">{achievement.icon === 'trophy' ? '🏅' : achievement.icon === 'star' ? '✅' : '🤝'}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Progress Towards New Badges */}
        {nearlyUnlocked.length > 0 && (
          <div>
            <h4 className="font-medium text-sm text-muted-foreground mb-3">
              {nearlyUnlocked.length} badges close to unlocking
            </h4>
            <div className="space-y-2">
              {nearlyUnlocked.map((achievement) => (
                <div key={achievement.id} className="p-3 rounded-lg border bg-muted/50">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      {getIconComponent(achievement.icon)}
                      <span className="font-medium text-sm">{achievement.name}</span>
                    </div>
                    <Badge variant="secondary">{achievement.progress}%</Badge>
                  </div>
                  <p className="text-xs text-muted-foreground">{achievement.requirement}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Motivational Message */}
        <div className="p-4 rounded-lg bg-gradient-to-r from-purple-50 to-blue-50 border border-purple-200">
          <p className="text-sm font-medium text-purple-800">
            🎯 Keep going! You're building an impressive collection of achievements.
          </p>
        </div>
      </CardContent>
    </Card>
  );
};