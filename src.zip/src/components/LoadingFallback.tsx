import React, { useState, useEffect } from 'react';
import { Skeleton } from '@/components/ui/skeleton';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { AlertCircle, RefreshCw, X } from 'lucide-react';

interface LoadingFallbackProps {
  isLoading: boolean;
  error?: Error | null;
  onRetry?: () => void;
  onCancel?: () => void;
  timeout?: number;
  context?: string;
  skeleton?: 'card' | 'list' | 'table' | 'custom';
  children?: React.ReactNode;
}

export const LoadingFallback: React.FC<LoadingFallbackProps> = ({
  isLoading,
  error,
  onRetry,
  onCancel,
  timeout = 10000,
  context = 'Operation',
  skeleton = 'card',
  children
}) => {
  const [showTimeout, setShowTimeout] = useState(false);
  const [timeoutId, setTimeoutId] = useState<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (isLoading && timeout > 0) {
      const id = setTimeout(() => {
        setShowTimeout(true);
        console.warn(`[Loading Timeout] ${context}: Loading exceeded ${timeout}ms`);
        
        // Send telemetry for stuck loader
        try {
          const telemetry = JSON.parse(localStorage.getItem('loading_telemetry') || '[]');
          telemetry.push({
            type: 'stuck_loader',
            context,
            timeout,
            timestamp: Date.now()
          });
          localStorage.setItem('loading_telemetry', JSON.stringify(telemetry.slice(-20)));
        } catch (e) {
          console.warn('Failed to record loading telemetry:', e);
        }
      }, timeout);
      
      setTimeoutId(id);
      return () => clearTimeout(id);
    } else {
      setShowTimeout(false);
      if (timeoutId) {
        clearTimeout(timeoutId);
        setTimeoutId(null);
      }
    }
  }, [isLoading, timeout, context]);

  // Error state
  if (error) {
    return (
      <Card className="max-w-md mx-auto">
        <CardHeader>
          <div className="flex items-center gap-2 text-red-600">
            <AlertCircle className="h-5 w-5" />
            <span className="font-medium">Failed to load {context}</span>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-gray-600">{error.message}</p>
          <div className="flex gap-2">
            {onRetry && (
              <Button onClick={onRetry} size="sm" className="flex-1">
                <RefreshCw className="h-4 w-4 mr-2" />
                Try Again
              </Button>
            )}
            {onCancel && (
              <Button onClick={onCancel} variant="outline" size="sm">
                <X className="h-4 w-4 mr-2" />
                Cancel
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    );
  }

  // Loading state with timeout warning
  if (isLoading) {
    return (
      <div className="space-y-4">
        {showTimeout && (
          <Card className="border-orange-200 bg-orange-50">
            <CardContent className="pt-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-orange-700">
                  <AlertCircle className="h-4 w-4" />
                  <span className="text-sm">Taking longer than expected...</span>
                </div>
                <div className="flex gap-2">
                  {onRetry && (
                    <Button onClick={onRetry} size="sm" variant="outline">
                      Retry
                    </Button>
                  )}
                  {onCancel && (
                    <Button onClick={onCancel} size="sm" variant="outline">
                      Cancel
                    </Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        )}
        
        {children || <SkeletonLoader type={skeleton} />}
      </div>
    );
  }

  return null;
};

const SkeletonLoader: React.FC<{ type: 'card' | 'list' | 'table' | 'custom' }> = ({ type }) => {
  switch (type) {
    case 'card':
      return (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <Card key={i}>
              <CardHeader>
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-3 w-1/2" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-20 w-full mb-4" />
                <Skeleton className="h-3 w-full mb-2" />
                <Skeleton className="h-3 w-2/3" />
              </CardContent>
            </Card>
          ))}
        </div>
      );
    
    case 'list':
      return (
        <div className="space-y-3">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="flex items-center gap-3 p-3 border rounded">
              <Skeleton className="h-10 w-10 rounded-full" />
              <div className="flex-1">
                <Skeleton className="h-4 w-1/3 mb-2" />
                <Skeleton className="h-3 w-2/3" />
              </div>
            </div>
          ))}
        </div>
      );
    
    case 'table':
      return (
        <div className="space-y-3">
          <Skeleton className="h-8 w-full" />
          {Array.from({ length: 5 }).map((_, i) => (
            <div key={i} className="grid grid-cols-4 gap-4">
              <Skeleton className="h-6 w-full" />
              <Skeleton className="h-6 w-full" />
              <Skeleton className="h-6 w-full" />
              <Skeleton className="h-6 w-full" />
            </div>
          ))}
        </div>
      );
    
    default:
      return <Skeleton className="h-40 w-full" />;
  }
};

export default LoadingFallback;