import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Settings, Shield, CheckCircle, Users } from 'lucide-react';
import ProductionTierManager from './ProductionTierManager';
import TierEnforcementSystem from './TierEnforcementSystem';
import TierValidationSystem from './TierValidationSystem';

export default function ComprehensiveSubscriptionManager() {
  const [activeTab, setActiveTab] = useState('tiers');

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold">Subscription Management System</h1>
        <p className="text-muted-foreground">
          Complete production-ready subscription tier management and enforcement
        </p>
        <div className="flex justify-center gap-2">
          <Badge variant="outline" className="text-green-600">
            <CheckCircle className="h-3 w-3 mr-1" />
            Production Ready
          </Badge>
          <Badge variant="outline">
            <Shield className="h-3 w-3 mr-1" />
            Secure
          </Badge>
          <Badge variant="outline">
            <Settings className="h-3 w-3 mr-1" />
            Configurable
          </Badge>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="tiers" className="flex items-center gap-2">
            <Users className="h-4 w-4" />
            Tier Management
          </TabsTrigger>
          <TabsTrigger value="enforcement" className="flex items-center gap-2">
            <Shield className="h-4 w-4" />
            Access Control
          </TabsTrigger>
          <TabsTrigger value="validation" className="flex items-center gap-2">
            <CheckCircle className="h-4 w-4" />
            Validation
          </TabsTrigger>
        </TabsList>

        <TabsContent value="tiers" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                Production Tier Configuration
              </CardTitle>
              <p className="text-sm text-muted-foreground">
                Manage the three core subscription tiers: Freemium, Accountability Essentials, and All Access
              </p>
            </CardHeader>
            <CardContent>
              <ProductionTierManager />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="enforcement" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5" />
                Access Control & Enforcement
              </CardTitle>
              <p className="text-sm text-muted-foreground">
                Configure route-based access control and subscription enforcement rules
              </p>
            </CardHeader>
            <CardContent>
              <TierEnforcementSystem />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="validation" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CheckCircle className="h-5 w-5" />
                System Validation
              </CardTitle>
              <p className="text-sm text-muted-foreground">
                Comprehensive validation of subscription system configuration and health
              </p>
            </CardHeader>
            <CardContent>
              <TierValidationSystem />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Quick Status Overview */}
      <Card className="bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200">
        <CardContent className="p-6">
          <div className="text-center space-y-2">
            <h3 className="text-lg font-semibold text-blue-900">System Status</h3>
            <p className="text-sm text-blue-700">
              Your subscription system is configured with three production tiers and comprehensive access control
            </p>
            <div className="flex justify-center gap-4 mt-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-600">3</div>
                <div className="text-xs text-blue-600">Active Tiers</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600">✓</div>
                <div className="text-xs text-green-600">Stripe Ready</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-purple-600">∞</div>
                <div className="text-xs text-purple-600">Scalable</div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}