import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, Target, Flame, Trash2, Calendar } from 'lucide-react';
import HabitCalendarView from './HabitCalendarView';

interface Habit {
  id: string;
  title: string;
  description?: string;
  frequency: string;
  target_count: number;
  current_streak: number;
  longest_streak: number;
  completed_dates?: string[];
}

interface AnimatedHabitCardProps {
  habit: Habit;
  onToggle: (habitId: string) => void;
  onDelete: (habitId: string) => void;
  isCompletedToday: boolean;
}

const AnimatedHabitCard: React.FC<AnimatedHabitCardProps> = ({
  habit,
  onToggle,
  onDelete,
  isCompletedToday
}) => {
  const [showAnimation, setShowAnimation] = useState(false);
  const [showCalendar, setShowCalendar] = useState(false);
  const [justCompleted, setJustCompleted] = useState(false);

  const handleToggle = () => {
    if (!isCompletedToday) {
      setShowAnimation(true);
      setJustCompleted(true);
      setTimeout(() => {
        setShowAnimation(false);
      }, 1000);
    }
    onToggle(habit.id);
  };

  useEffect(() => {
    if (justCompleted && !isCompletedToday) {
      setJustCompleted(false);
    }
  }, [isCompletedToday, justCompleted]);

  return (
    <div className="space-y-4">
      <Card className={`hover:shadow-lg transition-all duration-300 ${
        showAnimation ? 'scale-105 shadow-xl' : ''
      }`}>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div className="flex-1">
              <CardTitle className={`text-lg transition-all duration-300 ${
                isCompletedToday ? 'line-through text-gray-500' : ''
              }`}>
                {habit.title}
                {showAnimation && (
                  <span className="ml-2 inline-block animate-bounce">
                    ✨
                  </span>
                )}
              </CardTitle>
              {habit.description && (
                <p className={`text-sm text-muted-foreground mt-1 transition-all duration-300 ${
                  isCompletedToday ? 'line-through opacity-60' : ''
                }`}>
                  {habit.description}
                </p>
              )}
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowCalendar(!showCalendar)}
                className="text-blue-500 hover:text-blue-700 hover:bg-blue-50"
              >
                <Calendar className="h-4 w-4" />
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => onDelete(habit.id)}
                className="text-red-500 hover:text-red-700 hover:bg-red-50"
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardHeader>
        
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Progress</span>
              <span>{habit.current_streak || 0}/{habit.target_count} days</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2 overflow-hidden">
              <div 
                className={`h-2 rounded-full transition-all duration-500 ${
                  isCompletedToday ? 'bg-green-500' : 'bg-black'
                }`}
                style={{ 
                  width: `${Math.min(((habit.current_streak || 0) / habit.target_count) * 100, 100)}%` 
                }}
              ></div>
            </div>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Flame className={`h-4 w-4 transition-colors duration-300 ${
                (habit.current_streak || 0) > 0 ? 'text-orange-500' : 'text-gray-400'
              }`} />
              <span className={`text-sm font-medium transition-colors duration-300 ${
                (habit.current_streak || 0) > 0 ? 'text-gray-900' : 'text-gray-500'
              }`}>
                {(habit.current_streak || 0) > 0 ? `${habit.current_streak} day streak` : 'No streak yet'}
              </span>
              {showAnimation && (
                <span className="text-sm font-bold text-green-600 animate-pulse">
                  +1 🔥
                </span>
              )}
            </div>
            <Badge variant="outline" className="text-xs">
              {habit.frequency}
            </Badge>
          </div>

          <Button
            onClick={handleToggle}
            className={`w-full transition-all duration-300 transform ${
              isCompletedToday 
                ? 'bg-green-500 text-white hover:bg-green-600 scale-95' 
                : 'hover:scale-105'
            } ${showAnimation ? 'animate-pulse' : ''}`}
            variant={isCompletedToday ? "default" : "outline"}
          >
            {isCompletedToday ? (
              <>
                <CheckCircle className="h-4 w-4 mr-2" />
                Completed Today!
              </>
            ) : (
              <>
                <Target className="h-4 w-4 mr-2" />
                Mark Complete
              </>
            )}
          </Button>

          {showAnimation && (
            <div className="text-center">
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-green-100 rounded-full text-green-800 text-sm font-medium animate-fade-in">
                🎉 Great job! Streak continued!
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {showCalendar && (
        <div className="animate-slide-down">
          <HabitCalendarView
            habitId={habit.id}
            completedDates={habit.completed_dates || []}
            habitTitle={habit.title}
          />
        </div>
      )}
    </div>
  );
};

export default AnimatedHabitCard;