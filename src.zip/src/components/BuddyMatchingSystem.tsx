import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { useAppContext } from '@/contexts/OptimizedAppContext';
import { supabase } from '@/lib/supabase';
import { Users, Heart, Target, MessageCircle, Loader2, UserPlus, CheckCircle } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';

interface PotentialBuddy {
  id: string;
  display_name: string;
  shared_habits: string[];
  compatibility_score: number;
  current_streak: number;
  avatar_url?: string;
}

interface BuddyConnection {
  id: string;
  buddy_name: string;
  shared_habits: string[];
  status: 'pending' | 'accepted' | 'active';
  created_at: Date;
  user1_id?: string;
  user2_id?: string;
  isReceiver?: boolean;
}

export const BuddyMatchingSystem = () => {
  const { currentUser } = useAppContext();
  const [potentialBuddies, setPotentialBuddies] = useState<PotentialBuddy[]>([]);
  const [connections, setConnections] = useState<BuddyConnection[]>([]);
  const [loading, setLoading] = useState(false);
  const [sendingRequest, setSendingRequest] = useState<string | null>(null);

  useEffect(() => {
    fetchConnections();
  }, []);

  const fetchConnections = async () => {
    try {
      // First get partnerships
      const { data: partnerships, error } = await supabase
        .from('partnerships')
        .select('*')
        .or(`user1_id.eq.${currentUser?.id},user2_id.eq.${currentUser?.id}`)
        .order('created_at', { ascending: false });

      if (error) throw error;

      // Then get profile data for each partner
      const formattedConnections: BuddyConnection[] = await Promise.all(
        (partnerships || []).map(async (p) => {
          const isUserOne = p.user1_id === currentUser?.id;
          const partnerId = isUserOne ? p.user2_id : p.user1_id;
          
          // Get partner's profile with better error handling
          const { data: profile, error: profileError } = await supabase
            .from('profiles')
            .select('id, name, full_name, email')
            .eq('id', partnerId)
            .maybeSingle();

          if (profileError) {
            console.error('Error fetching partner profile:', profileError);
          }
          
          // Improved name resolution logic
          let buddyName = 'Unknown User';
          
          if (profile) {
            if (profile.full_name && profile.full_name.trim()) {
              buddyName = profile.full_name;
            } else if (profile.name && profile.name.trim()) {
              buddyName = profile.name;
            } else if (profile.email) {
              // Use email prefix as fallback
              const emailPrefix = profile.email.split('@')[0];
              buddyName = emailPrefix.charAt(0).toUpperCase() + emailPrefix.slice(1);
            }
          }
          
          
          console.log('Resolved buddy name:', buddyName, 'for partner:', partnerId);
          console.log('Partnership details:', {
            id: p.id,
            user1_id: p.user1_id,
            user2_id: p.user2_id,
            current_user_id: currentUser?.id,
            status: p.status,
            isReceiver: p.user2_id === currentUser?.id
          });
          
          return {
            id: p.id,
            buddy_name: buddyName,
            shared_habits: ['Meditation', 'Exercise'], // TODO: get from database
            status: p.status,
            created_at: new Date(p.created_at),
            // Add fields to track who sent/received the request
            user1_id: p.user1_id,
            user2_id: p.user2_id,
            isReceiver: p.user2_id === currentUser?.id // Current user is the receiver
          };
        })
      );

      setConnections(formattedConnections);
    } catch (error) {
      console.error('Error fetching connections:', error);
      // Fallback with sample data
      setConnections([
        {
          id: 'sample-1',
          buddy_name: 'Sarah M.',
          shared_habits: ['Morning Exercise', 'Reading'],
          status: 'pending',
          created_at: new Date(),
          user1_id: 'sample-user1',
          user2_id: currentUser?.id || 'current-user',
          isReceiver: true
        }
      ]);
    }
  };

  const findBuddies = async () => {
    setLoading(true);
    try {
      // Get users with similar habits
      const { data: profiles, error } = await supabase
        .from('profiles')
        .select(`
          id,
          name,
          full_name,
          avatar_url
        `)
        .neq('id', currentUser?.id)
        .limit(10);

      if (error) throw error;

      // Transform to potential buddies with mock compatibility data
      const buddies: PotentialBuddy[] = (profiles || []).map((profile, index) => ({
        id: profile.id,
        display_name: profile.name || profile.full_name || 'Anonymous User',
        shared_habits: ['Morning Exercise', 'Reading', 'Meditation'][Math.floor(Math.random() * 3)] ? ['Morning Exercise', 'Reading'] : ['Meditation', 'Journaling'],
        compatibility_score: 75 + Math.floor(Math.random() * 25),
        current_streak: Math.floor(Math.random() * 30) + 1,
        avatar_url: profile.avatar_url
      }));

      setPotentialBuddies(buddies);
    } catch (error) {
      console.error('Error finding buddies:', error);
      // Fallback to mock data
      const mockBuddies: PotentialBuddy[] = [
        {
          id: '1',
          display_name: 'Sarah M.',
          shared_habits: ['Morning Exercise', 'Reading'],
          compatibility_score: 95,
          current_streak: 12
        },
        {
          id: '2', 
          display_name: 'Mike R.',
          shared_habits: ['Meditation', 'Journaling'],
          compatibility_score: 88,
          current_streak: 8
        }
      ];
      setPotentialBuddies(mockBuddies);
    } finally {
      setLoading(false);
    }
  };

  const sendBuddyRequest = async (buddyId: string, buddyName: string) => {
    setSendingRequest(buddyId);
    try {
      // Check if partnership already exists (in either direction)
      const { data: existing, error: checkError } = await supabase
        .from('partnerships')
        .select('id')
        .or(`and(user1_id.eq.${currentUser?.id},user2_id.eq.${buddyId}),and(user1_id.eq.${buddyId},user2_id.eq.${currentUser?.id})`)
        .single();

      if (checkError && checkError.code !== 'PGRST116') {
        throw checkError;
      }

      if (existing) {
        toast({
          title: "Already Connected",
          description: `You already have a connection with ${buddyName}.`,
          variant: "destructive"
        });
        return;
      }

      const { error } = await supabase
        .from('partnerships')
        .insert({
          user1_id: currentUser?.id,
          user2_id: buddyId,
          status: 'pending'
        });

      if (error) throw error;

      toast({
        title: "Buddy Request Sent!",
        description: `Your buddy request has been sent to ${buddyName}.`,
      });

      // Remove from potential buddies and refresh connections
      setPotentialBuddies(prev => prev.filter(b => b.id !== buddyId));
      fetchConnections();
    } catch (error) {
      console.error('Error sending buddy request:', error);
      toast({
        title: "Error",
        description: "Failed to send buddy request. Please try again.",
        variant: "destructive"
      });
    } finally {
      setSendingRequest(null);
    }
  };

  const acceptBuddyRequest = async (connectionId: string) => {
    try {
      const { error } = await supabase
        .from('partnerships')
        .update({ status: 'active' })
        .eq('id', connectionId);

      if (error) throw error;

      toast({
        title: "Buddy Request Accepted!",
        description: "You're now connected as accountability buddies!",
      });

      fetchConnections();
    } catch (error) {
      console.error('Error accepting buddy request:', error);
      toast({
        title: "Error",
        description: "Failed to accept buddy request. Please try again.",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="space-y-6">
      {/* Existing Connections */}
      {connections.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="w-5 h-5 text-[#596D59]" />
              Your Buddy Connections
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {connections.map((connection) => (
              <Card key={connection.id} className="border-[#596D59]/20">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Avatar>
                        <AvatarFallback className="bg-[#596D59] text-white">
                          {connection.buddy_name.split(' ').map(n => n[0]).join('')}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-medium text-[#001B30]">{connection.buddy_name}</p>
                        <div className="flex items-center gap-2 mt-1">
                          <Badge 
                            variant={connection.status === 'active' ? 'default' : 'secondary'}
                            className={connection.status === 'active' ? 'bg-green-100 text-green-800' : ''}
                          >
                            {connection.status === 'active' ? 'Active Buddy' : 'Pending'}
                          </Badge>
                        </div>
                        <div className="flex flex-wrap gap-1 mt-2">
                          {connection.shared_habits.map((habit) => (
                            <span key={habit} className="text-xs bg-[#596D59]/10 text-[#596D59] px-2 py-1 rounded">
                              {habit}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                    {connection.status === 'pending' && (
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          onClick={() => acceptBuddyRequest(connection.id)}
                          className="bg-green-600 hover:bg-green-700 text-white"
                        >
                          <CheckCircle className="w-4 h-4 mr-1" />
                          Accept
                        </Button>
                        <Badge variant="outline" className="text-xs">
                          {connection.isReceiver ? 'Received Request' : 'Sent Request'}
                        </Badge>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Find New Buddies */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="w-5 h-5 text-[#596D59]" />
            Find Your Habit Buddy
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="text-center">
            <Button 
              onClick={findBuddies}
              disabled={loading}
              className="bg-[#596D59] hover:bg-[#596D59]/90"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Finding Matches...
                </>
              ) : (
                <>
                  <Target className="w-4 h-4 mr-2" />
                  Find Compatible Buddies
                </>
              )}
            </Button>
          </div>

          {potentialBuddies.length > 0 && (
            <div className="space-y-3">
              <h4 className="font-medium text-[#001B30]">Recommended Matches</h4>
              {potentialBuddies.map((buddy) => (
                <Card key={buddy.id} className="border-[#596D59]/20">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <Avatar>
                          <AvatarFallback className="bg-[#596D59] text-white">
                            {buddy.display_name.split(' ').map(n => n[0]).join('')}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium text-[#001B30]">{buddy.display_name}</p>
                          <div className="flex items-center gap-2 mt-1">
                            <Badge variant="secondary" className="text-xs">
                              {buddy.compatibility_score}% match
                            </Badge>
                            <Badge variant="outline" className="text-xs">
                              {buddy.current_streak} day streak
                            </Badge>
                          </div>
                          <div className="flex flex-wrap gap-1 mt-2">
                            {buddy.shared_habits.map((habit) => (
                              <span key={habit} className="text-xs bg-[#596D59]/10 text-[#596D59] px-2 py-1 rounded">
                                {habit}
                              </span>
                            ))}
                          </div>
                        </div>
                      </div>
                      <Button
                        size="sm"
                        onClick={() => sendBuddyRequest(buddy.id, buddy.display_name)}
                        disabled={sendingRequest === buddy.id}
                        className="bg-[#596D59] hover:bg-[#596D59]/90"
                      >
                        {sendingRequest === buddy.id ? (
                          <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                          <>
                            <UserPlus className="w-4 h-4 mr-1" />
                            Connect
                          </>
                        )}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};