import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { supabase } from '@/lib/supabase';
import { toast } from '@/components/ui/use-toast';
import { RefreshCw, Settings } from 'lucide-react';

const TierAccessFixer = () => {
  const [isFixing, setIsFixing] = useState(false);

  const fixTierAccess = async () => {
    setIsFixing(true);
    try {
      // Fix Freemium tier
      const { error: freemiumError } = await supabase
        .from('subscription_tiers')
        .update({
          allowed_routes: ['/dashboard', '/billing', '/notifications', '/profile', '/gather', '/wins-wall', '/community-feed']
        })
        .eq('name', 'Freemium');

      if (freemiumError) throw freemiumError;

      // Fix Accountability Essentials tier
      const { error: essentialsError } = await supabase
        .from('subscription_tiers')
        .update({
          allowed_routes: ['/dashboard', '/habits', '/goals', '/partnerships', '/billing', '/notifications', '/profile', '/gather', '/wins-wall', '/community-feed']
        })
        .eq('name', 'Accountability Essentials');

      if (essentialsError) throw essentialsError;

      toast({
        title: "Success",
        description: "Subscription tier access has been fixed!"
      });

    } catch (error) {
      console.error('Error fixing tier access:', error);
      toast({
        title: "Error",
        description: "Failed to fix tier access",
        variant: "destructive"
      });
    } finally {
      setIsFixing(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Settings className="h-5 w-5" />
          Subscription Tier Access Fixer
        </CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-gray-600 mb-4">
          This will update the allowed_routes for Freemium and Accountability Essentials tiers.
        </p>
        <Button 
          onClick={fixTierAccess} 
          disabled={isFixing}
          className="w-full"
        >
          {isFixing ? (
            <>
              <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
              Fixing Access...
            </>
          ) : (
            'Fix Tier Access'
          )}
        </Button>
      </CardContent>
    </Card>
  );
};

export default TierAccessFixer;