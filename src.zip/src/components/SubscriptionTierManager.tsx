import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Plus, Edit, Trash2, DollarSign } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { toast } from '@/components/ui/use-toast';

interface SubscriptionTier {
  id: string;
  name: string;
  price: number;
  billing_period: string;
  features: string[];
  max_groups: number;
  max_goals: number;
  is_active: boolean;
  stripe_price_id?: string;
  created_at: string;
}

const SubscriptionTierManager: React.FC = () => {
  const [tiers, setTiers] = useState<SubscriptionTier[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingTier, setEditingTier] = useState<SubscriptionTier | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    stripe_product_id: '',
    allowed_routes: '',
    is_active: true
  });

  const loadTiers = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('subscription_tiers')
        .select('*')
        .order('price_monthly', { ascending: true });

      if (error) throw error;
      setTiers(data || []);
    } catch (error) {
      console.error('Error loading tiers:', error);
      toast({
        title: "Error",
        description: error?.message || 'Failed to load subscription tiers',
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      const routesArray = formData.allowed_routes
        .split(',')
        .map(route => route.trim())
        .filter(route => route.length > 0);

      const tierData = {
        name: formData.name,
        description: formData.description,
        stripe_product_id: formData.stripe_product_id || null,
        allowed_routes: routesArray,
        is_active: formData.is_active,
        updated_at: new Date().toISOString()
      };

      if (editingTier) {
        const { error } = await supabase
          .from('subscription_tiers')
          .update(tierData)
          .eq('id', editingTier.id);
        
        if (error) throw error;
        toast({ title: "Success", description: "Subscription tier updated" });
      } else {
        const { error } = await supabase
          .from('subscription_tiers')
          .insert([{ ...tierData, created_at: new Date().toISOString() }]);
        
        if (error) throw error;
        toast({ title: "Success", description: "Subscription tier created" });
      }

      setIsDialogOpen(false);
      resetForm();
      loadTiers();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error?.message || 'Failed to save subscription tier',
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const deleteTier = async (id: string) => {
    if (!confirm('Are you sure you want to delete this subscription tier?')) return;
    
    try {
      const { error } = await supabase
        .from('subscription_tiers')
        .delete()
        .eq('id', id);
      
      if (error) throw error;
      toast({ title: "Success", description: "Subscription tier deleted" });
      loadTiers();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error?.message || 'Failed to delete subscription tier',
        variant: "destructive"
      });
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      stripe_product_id: '',
      allowed_routes: '',
      is_active: true
    });
    setEditingTier(null);
  };

  const openEditDialog = (tier: SubscriptionTier) => {
    setEditingTier(tier);
    setFormData({
      name: tier.name,
      description: tier.description || '',
      stripe_product_id: tier.stripe_product_id || '',
      allowed_routes: tier.allowed_routes?.join(', ') || '',
      is_active: tier.is_active
    });
    setIsDialogOpen(true);
  };

  useEffect(() => {
    loadTiers();
  }, []);

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold">Subscription Tiers</h3>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={resetForm}>
              <Plus className="h-4 w-4 mr-2" />
              Add Tier
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>
                {editingTier ? 'Edit Subscription Tier' : 'Create Subscription Tier'}
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="name">Name</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                />
              </div>
              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  rows={3}
                />
              </div>
              <div>
                <Label htmlFor="stripe_product_id">Stripe Product ID</Label>
                <Input
                  id="stripe_product_id"
                  value={formData.stripe_product_id}
                  onChange={(e) => setFormData({ ...formData, stripe_product_id: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="allowed_routes">Allowed Routes (comma-separated)</Label>
                <Input
                  id="allowed_routes"
                  value={formData.allowed_routes}
                  onChange={(e) => setFormData({ ...formData, allowed_routes: e.target.value })}
                  placeholder="/premium, /advanced, /pro"
                />
              </div>
              <div className="flex items-center space-x-2">
                <Switch
                  id="is_active"
                  checked={formData.is_active}
                  onCheckedChange={(checked) => setFormData({ ...formData, is_active: checked })}
                />
                <Label htmlFor="is_active">Active</Label>
              </div>
              <div className="flex gap-2">
                <Button type="submit" disabled={loading}>
                  {editingTier ? 'Update' : 'Create'}
                </Button>
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancel
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-4">
        {tiers.map((tier) => (
          <Card key={tier.id}>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <Crown className="h-5 w-5" />
                  {tier.name}
                </CardTitle>
                <div className="flex items-center gap-2">
                  <Badge variant={tier.is_active ? "default" : "secondary"}>
                    {tier.is_active ? 'Active' : 'Inactive'}
                  </Badge>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => openEditDialog(tier)}
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => deleteTier(tier.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {tier.description && (
                  <p className="text-sm text-muted-foreground">{tier.description}</p>
                )}
                {tier.stripe_product_id && (
                  <p className="text-xs">
                    <span className="font-medium">Stripe Product:</span> {tier.stripe_product_id}
                  </p>
                )}
                {tier.allowed_routes && tier.allowed_routes.length > 0 && (
                  <div className="text-xs">
                    <span className="font-medium">Allowed Routes:</span>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {tier.allowed_routes.map((route, index) => (
                        <Badge key={index} variant="outline" className="text-xs">
                          {route}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
        
        {tiers.length === 0 && !loading && (
          <Card>
            <CardContent className="p-6 text-center text-muted-foreground">
              No subscription tiers found. Create your first tier to get started.
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};

export default SubscriptionTierManager;