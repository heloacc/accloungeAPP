import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Smartphone, Bell, Download, Settings } from 'lucide-react';

const PWANotificationGuide: React.FC = () => {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Bell className="h-5 w-5" />
          PWA Notification Guide
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <Alert>
          <Smartphone className="h-4 w-4" />
          <AlertDescription>
            For best notification experience, install ACCLOUNGE as a PWA app on your device.
          </AlertDescription>
        </Alert>

        <div className="space-y-3">
          <div className="flex items-start gap-3">
            <Download className="h-5 w-5 mt-0.5 text-primary" />
            <div>
              <h4 className="font-medium">1. Install PWA App</h4>
              <p className="text-sm text-muted-foreground">
                Look for "Install App" or "Add to Home Screen" option in your browser menu
              </p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <Settings className="h-5 w-5 mt-0.5 text-primary" />
            <div>
              <h4 className="font-medium">2. Enable Notifications</h4>
              <p className="text-sm text-muted-foreground">
                Click "Enable PWA" button above to grant notification permissions
              </p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <Bell className="h-5 w-5 mt-0.5 text-primary" />
            <div>
              <h4 className="font-medium">3. Receive Notifications</h4>
              <p className="text-sm text-muted-foreground">
                Get real-time updates even when the app is closed (PWA app only)
              </p>
            </div>
          </div>
        </div>

        <div className="text-xs text-muted-foreground border-t pt-3">
          <p><strong>Browser notifications:</strong> Work when browser tab is open</p>
          <p><strong>PWA app notifications:</strong> Work even when app is closed (recommended)</p>
        </div>
      </CardContent>
    </Card>
  );
};

export default PWANotificationGuide;