import React, { useState, useEffect } from 'react';
import { useSubscriptionAccess } from '@/hooks/useSubscriptionAccess';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Lock, Crown, Zap } from 'lucide-react';

interface TierBasedPageGuardProps {
  children: React.ReactNode;
  pagePath: string;
  fallbackComponent?: React.ReactNode;
}

const TierBasedPageGuard: React.FC<TierBasedPageGuardProps> = ({
  children,
  pagePath,
  fallbackComponent
}) => {
  const { checkPageAccess, userTier, loading } = useSubscriptionAccess();
  const [hasAccess, setHasAccess] = useState(false);
  const [requiredTier, setRequiredTier] = useState<string>('');
  const [checkingAccess, setCheckingAccess] = useState(true);

  useEffect(() => {
    const checkAccess = async () => {
      setCheckingAccess(true);
      try {
        const result = await checkPageAccess(pagePath);
        setHasAccess(result.hasAccess);
        setRequiredTier(result.requiredTier || '');
      } catch (error) {
        console.error('Error checking page access:', error);
        setHasAccess(false);
      } finally {
        setCheckingAccess(false);
      }
    };

    checkAccess();
  }, [pagePath, checkPageAccess]);

  if (loading || checkingAccess) {
    return (
      <div className="flex items-center justify-center min-h-[200px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (hasAccess) {
    return <>{children}</>;
  }

  if (fallbackComponent) {
    return <>{fallbackComponent}</>;
  }

  const getTierIcon = (tier: string) => {
    switch (tier.toLowerCase()) {
      case 'premium':
        return <Crown className="h-8 w-8 text-yellow-500" />;
      case 'pro':
        return <Zap className="h-8 w-8 text-purple-500" />;
      default:
        return <Lock className="h-8 w-8 text-gray-500" />;
    }
  };

  return (
    <div className="flex items-center justify-center min-h-[400px] p-4">
      <Card className="max-w-md w-full">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            {getTierIcon(requiredTier)}
          </div>
          <CardTitle>Upgrade Required</CardTitle>
        </CardHeader>
        <CardContent className="text-center space-y-4">
          <p className="text-muted-foreground">
            This page requires a <strong>{requiredTier}</strong> subscription to access.
          </p>
          <p className="text-sm text-muted-foreground">
            Your current plan: <strong>{userTier?.name || 'Free'}</strong>
          </p>
          <div className="flex gap-2 justify-center">
            <Button onClick={() => window.dispatchEvent(new CustomEvent('navigate-to-tab', { 
              detail: { tab: 'billing' }
            }))}>
              Upgrade Now
            </Button>
            <Button variant="outline" onClick={() => window.history.back()}>
              Go Back
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default TierBasedPageGuard;
