import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { MessageSquare, TrendingUp, TrendingDown, Minus, Users } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';
import { CheckInChat } from './CheckInChat';

interface MomentumData {
  id: string;
  user_id: string;
  goals_completion_rate: number;
  streak_status: 'active' | 'lost' | 'declining';
  community_engagement_score: number;
  last_active_at: string;
  trend: 'improving' | 'stable' | 'declining';
  user_name?: string;
  user_email?: string;
}

export default function MemberMomentumWithChat() {
  const [momentumData, setMomentumData] = useState<MomentumData[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedMember, setSelectedMember] = useState<MomentumData | null>(null);
  const [chatOpen, setChatOpen] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    fetchMomentumData();
  }, []);

  const fetchMomentumData = async () => {
    try {
      // Get data from momentum_metrics table with user profiles
      const { data: momentumData, error: momentumError } = await supabase
        .from('momentum_metrics')
        .select(`
          *,
          profiles(name, full_name, email)
        `);

      if (momentumError) {
        throw momentumError;
      }

      // If no data exists, show empty state (don't create mock data)
      if (!momentumData || momentumData.length === 0) {
        console.log('No momentum metrics found. Users need to engage with the platform first.');
        setMomentumData([]);
        return;
      }

      const formattedData = momentumData.map(item => ({
        ...item,
        user_name: item.profiles?.full_name || item.profiles?.name || 'Unknown User',
        user_email: item.profiles?.email || ''
      }));

      setMomentumData(formattedData);
    } catch (error) {
      console.error('Error fetching momentum data:', error);
      toast({
        title: "Error",
        description: "Failed to load member momentum data",
        variant: "destructive"
      });
      setMomentumData([]);
    } finally {
      setLoading(false);
    }
  };

  const getMomentumStatus = (trend: string, engagementScore: number, streakStatus: string) => {
    // If user has active streaks and decent engagement, they shouldn't be red
    if (streakStatus === 'active' && engagementScore > 40) {
      return trend === 'improving' ? 'Green' : 'Amber';
    }
    
    if (trend === 'declining' || engagementScore < 30) return 'Red';
    if (trend === 'stable' && engagementScore < 70) return 'Amber';
    return 'Green';
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Green': return 'bg-green-100 text-green-800';
      case 'Amber': return 'bg-yellow-100 text-yellow-800';
      case 'Red': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'improving': return <TrendingUp className="w-4 h-4 text-green-600" />;
      case 'declining': return <TrendingDown className="w-4 h-4 text-red-600" />;
      default: return <Minus className="w-4 h-4 text-gray-600" />;
    }
  };

  const openChat = (member: MomentumData) => {
    setSelectedMember(member);
    setChatOpen(true);
  };

  const recalculateMetrics = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('recalculate-momentum-metrics');
      
      if (error) throw error;
      
      toast({
        title: "Success",
        description: `Recalculated metrics for ${data.processed_users} users`,
      });
      
      await fetchMomentumData();
    } catch (error) {
      console.error('Error recalculating metrics:', error);
      toast({
        title: "Error",
        description: "Failed to recalculate momentum metrics",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div className="flex justify-center p-8">Loading member momentum...</div>;
  }

  return (
    <div className="space-y-4 sm:space-y-6 p-2 sm:p-0">
      <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4">
        <h1 className="text-xl sm:text-2xl font-bold">Member Momentum</h1>
        <div className="flex flex-col sm:flex-row gap-2">
          <Button 
            onClick={recalculateMetrics}
            variant="outline"
            disabled={loading}
            className="w-full sm:w-auto text-sm"
          >
            {loading ? 'Recalculating...' : 'Recalculate Metrics'}
          </Button>
          <Badge variant="outline" className="text-xs">Admin/Moderator View</Badge>
        </div>
      </div>

      <div className="grid gap-3 sm:gap-4">
        {momentumData.map((member) => {
          const status = getMomentumStatus(member.trend, member.community_engagement_score, member.streak_status);
          
          return (
            <Card key={member.id} className="overflow-hidden">
              <CardHeader className="pb-3 px-3 sm:px-6">
                <div className="flex flex-col sm:flex-row sm:justify-between sm:items-start gap-2">
                  <div className="min-w-0 flex-1">
                    <CardTitle className="text-base sm:text-lg truncate">{member.user_name}</CardTitle>
                    <p className="text-xs sm:text-sm text-gray-600 truncate">{member.user_email}</p>
                  </div>
                  <Badge className={`${getStatusColor(status)} text-xs shrink-0`}>{status}</Badge>
                </div>
              </CardHeader>
              <CardContent className="px-3 sm:px-6">
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 mb-4">
                  <div className="text-center">
                    <div className="flex items-center justify-center gap-1 mb-1">
                      {getTrendIcon(member.trend)}
                      <span className="text-xs sm:text-sm font-medium">Goal Completion</span>
                    </div>
                    <p className="text-lg sm:text-xl font-bold">{member.goals_completion_rate}%</p>
                  </div>
                  <div className="text-center">
                    <p className="text-xs sm:text-sm font-medium mb-1">Streak Status</p>
                    <Badge 
                      variant={member.streak_status === 'active' ? 'default' : 'destructive'}
                      className="text-xs"
                    >
                      {member.streak_status}
                    </Badge>
                  </div>
                  <div className="text-center">
                    <p className="text-xs sm:text-sm font-medium mb-1">Engagement</p>
                    <p className="text-lg sm:text-xl font-bold">{member.community_engagement_score}</p>
                  </div>
                  <div className="text-center">
                    <p className="text-xs sm:text-sm font-medium mb-1">Last Active</p>
                    <p className="text-xs sm:text-sm">{new Date(member.last_active_at).toLocaleDateString()}</p>
                  </div>
                </div>
                
                <Button 
                  onClick={() => openChat(member)}
                  className="w-full text-sm"
                  size="sm"
                >
                  <MessageSquare className="w-4 h-4 mr-2" />
                  Open Chat
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {momentumData.length === 0 && (
        <Card>
          <CardContent className="text-center py-6 sm:py-8 px-4">
            <p className="text-gray-600 text-sm sm:text-base">No member momentum data available yet.</p>
            <p className="text-xs sm:text-sm text-gray-500 mt-2">Data will appear as members engage with the platform.</p>
          </CardContent>
        </Card>
      )}

      <Dialog open={chatOpen} onOpenChange={setChatOpen}>
        <DialogContent className="max-w-2xl max-h-[80vh]">
          <DialogHeader>
            <DialogTitle>Chat with {selectedMember?.user_name}</DialogTitle>
          </DialogHeader>
          {selectedMember && (
            <CheckInChat
              recipientId={selectedMember.user_id}
              recipientName={selectedMember.user_name || 'Member'}
              isAdminView={true}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}