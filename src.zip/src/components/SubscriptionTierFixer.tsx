import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/components/ui/use-toast';
import { RefreshCw, Settings } from 'lucide-react';

interface SubscriptionTier {
  id: string;
  name: string;
  description?: string;
  stripe_product_id?: string;
  allowed_routes?: string[];
  is_active: boolean;
  price_monthly?: string;
}

const SubscriptionTierFixer = () => {
  const [tiers, setTiers] = useState<SubscriptionTier[]>([]);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const loadTiers = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('subscription_tiers')
        .select('*')
        .order('price_monthly');

      if (error) throw error;
      setTiers(data || []);
    } catch (error: any) {
      toast({
        title: "Error Loading Tiers",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const fixFreemiumTier = async () => {
    setLoading(true);
    try {
      const freemiumTier = tiers.find(t => t.name === 'Freemium');
      if (!freemiumTier) {
        toast({
          title: "Error",
          description: "Freemium tier not found",
          variant: "destructive"
        });
        return;
      }

      const { error } = await supabase
        .from('subscription_tiers')
        .update({
          allowed_routes: ['/dashboard', '/billing', '/notifications', '/profile', '/gather', '/wins-wall', '/community-feed'],
          is_active: true
        })
        .eq('id', freemiumTier.id);

      if (error) throw error;
      
      toast({
        title: "Success",
        description: "Freemium tier access updated"
      });
      
      loadTiers();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const fixAccountabilityEssentialsTier = async () => {
    setLoading(true);
    try {
      const essentialsTier = tiers.find(t => t.name === 'Accountability Essentials');
      if (!essentialsTier) {
        toast({
          title: "Error",
          description: "Accountability Essentials tier not found",
          variant: "destructive"
        });
        return;
      }

      const { error } = await supabase
        .from('subscription_tiers')
        .update({
          allowed_routes: ['/dashboard', '/habits', '/goals', '/billing', '/notifications', '/profile', '/gather', '/wins-wall', '/community-feed'],
          is_active: true
        })
        .eq('id', essentialsTier.id);

      if (error) throw error;
      
      toast({
        title: "Success",
        description: "Accountability Essentials tier access updated"
      });
      
      loadTiers();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadTiers();
  }, []);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Fix Subscription Tiers</h2>
        <Button onClick={loadTiers} disabled={loading}>
          <RefreshCw className="h-4 w-4 mr-2" />
          Refresh
        </Button>
      </div>

      <div className="grid gap-4">
        <Card>
          <CardHeader>
            <CardTitle>Quick Fixes</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex gap-4">
              <Button onClick={fixFreemiumTier} disabled={loading}>
                <Settings className="h-4 w-4 mr-2" />
                Fix Freemium Access
              </Button>
              <Button onClick={fixAccountabilityEssentialsTier} disabled={loading}>
                <Settings className="h-4 w-4 mr-2" />
                Fix Essentials Access
              </Button>
            </div>
            <p className="text-sm text-muted-foreground">
              This will update the allowed_routes for each tier to match the requirements.
            </p>
          </CardContent>
        </Card>

        {tiers.map((tier) => (
          <Card key={tier.id}>
            <CardContent className="p-4">
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <h3 className="text-lg font-semibold">{tier.name}</h3>
                    <Badge variant={tier.is_active ? "default" : "secondary"}>
                      {tier.is_active ? "Active" : "Inactive"}
                    </Badge>
                  </div>
                  {tier.description && (
                    <p className="text-sm text-muted-foreground mb-2">{tier.description}</p>
                  )}
                  <div className="text-sm">
                    <div className="mb-2">
                      <strong>Stripe Product ID:</strong> {tier.stripe_product_id || 'Not set'}
                    </div>
                    <div className="mb-2">
                      <strong>Price:</strong> ${tier.price_monthly || '0.00'}/month
                    </div>
                    <div>
                      <strong>Allowed Routes:</strong>
                      <div className="mt-1 flex flex-wrap gap-1">
                        {tier.allowed_routes?.map((route) => (
                          <Badge key={route} variant="outline" className="text-xs">
                            {route}
                          </Badge>
                        )) || <span className="text-muted-foreground">No routes configured</span>}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default SubscriptionTierFixer;