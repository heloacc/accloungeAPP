import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Users, Lock, Send, CheckCircle, Clock } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

interface GroupBrowserProps {
  userId: string;
}

interface Group {
  id: string;
  name: string;
  description: string;
  is_private: boolean;
  member_count: number;
  has_pending_request?: boolean;
}

const GroupBrowser: React.FC<GroupBrowserProps> = ({ userId }) => {
  const [groups, setGroups] = useState<Group[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedGroup, setSelectedGroup] = useState<Group | null>(null);
  const [application, setApplication] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    let isMounted = true;
    
    const loadGroups = async () => {
      if (userId && isMounted) {
        await fetchAvailableGroups();
      }
    };
    
    loadGroups();
    
    return () => {
      isMounted = false;
    };
  }, [userId]);

  const fetchAvailableGroups = async () => {
    try {
      console.log('Fetching available groups for user:', userId);
      
      // Get all non-archived groups
      const { data: allGroups, error: groupsError } = await supabase
        .from('acircle_groups')
        .select('id, name, description, is_private')
        .eq('is_archived', false);

      if (groupsError) {
        console.error('Error fetching groups:', groupsError);
        throw groupsError;
      }

      console.log('All groups found:', allGroups?.length || 0, allGroups);

      // Get groups user is already a member of
      const { data: userMemberships } = await supabase
        .from('acircle_members')
        .select('group_id')
        .eq('user_id', userId);

      const memberGroupIds = userMemberships?.map(m => m.group_id) || [];
      console.log('User is member of groups:', memberGroupIds);

      // For regular users, filter out groups they're already members of
      // For admin users, show all groups with appropriate status
      const availableGroups = allGroups?.filter(group => {
        // Always show groups the user is not a member of
        return !memberGroupIds.includes(group.id);
      }) || [];

      console.log('Available groups after filtering:', availableGroups.length);
      console.log('Available groups after filtering:', availableGroups.length);

      // Check for pending requests
      const { data: requests } = await supabase
        .from('acircle_join_requests')
        .select('group_id')
        .eq('user_id', userId)
        .eq('status', 'pending');

      const pendingGroupIds = requests?.map(r => r.group_id) || [];
      // Get member counts for each group
      const groupsWithMemberCounts = await Promise.all(
        availableGroups.map(async (group) => {
          const { count } = await supabase
            .from('acircle_members')
            .select('*', { count: 'exact', head: true })
            .eq('group_id', group.id);
          
          return {
            id: group.id,
            name: group.name,
            description: group.description,
            is_private: group.is_private,
            member_count: count || 0,
            has_pending_request: pendingGroupIds.includes(group.id)
          };
        })
      );

      console.log('Final groups with status:', groupsWithMemberCounts);
      setGroups(groupsWithMemberCounts);
    } catch (error) {
      console.error('Error fetching groups:', error);
      setGroups([]);
    } finally {
      setLoading(false);
    }
  };

  const handleJoinRequest = async () => {
    if (!selectedGroup || !application.trim()) {
      toast({
        title: "Error",
        description: "Please provide an application message.",
        variant: "destructive",
      });
      return;
    }

    setSubmitting(true);
    try {
      console.log('Submitting join request for user:', userId, 'group:', selectedGroup.id);
      
      const { error } = await supabase
        .from('acircle_join_requests')
        .insert([{
          user_id: userId,
          group_id: selectedGroup.id,
          questionnaire_response: application.trim(),
          status: 'pending'
        }]);

      if (error) {
        console.error('Database error:', error);
        throw error;
      }

      console.log('Join request submitted successfully');

      // Try to send notification to admins/moderators (but don't fail if this fails)
      try {
        const { data: notificationResult, error: notificationError } = await supabase.functions.invoke('admin-operations', {
          body: {
            operation: 'notify_join_request',
            data: {
              group_id: selectedGroup.id,
              user_id: userId
            }
          }
        });
        
        if (notificationError) {
          console.warn('Notification error:', notificationError);
        } else {
          console.log('Notification sent successfully:', notificationResult);
        }
      } catch (notificationError) {
        console.warn('Failed to send notification:', notificationError);
        // Continue anyway - the request was submitted successfully
      }

      toast({
        title: "Request Sent",
        description: `Your request to join ${selectedGroup.name} has been submitted.`,
      });

      setApplication('');
      setSelectedGroup(null);
      await fetchAvailableGroups();
    } catch (error: any) {
      console.error('Error submitting request:', error);
      
      // Provide more specific error messages
      let errorMessage = "Failed to submit join request. Please try again.";
      if (error.message?.includes('row-level security') || error.message?.includes('policy')) {
        errorMessage = "Permission error occurred. Your request may have been submitted successfully. Please refresh the page and check if your request appears as pending.";
      } else if (error.message?.includes('duplicate') || error.code === '23505') {
        errorMessage = "You already have a pending request for this group.";
      } else if (error.message) {
        errorMessage = error.message;
      }
      
      toast({
        title: "Error",
        description: errorMessage,
        variant: "destructive",
      });
      
      // Refresh the groups list to check if the request was actually submitted
      setTimeout(() => {
        fetchAvailableGroups();
      }, 1000);
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return <div className="text-center py-4">Loading available groups...</div>;
  }

  if (groups.length === 0) {
    return (
      <Card>
        <CardContent className="pt-6 text-center">
          <Users className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
          <p className="text-muted-foreground">No groups available to join at the moment.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
      {groups.map((group) => (
        <Card key={group.id}>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span className="flex items-center gap-2">
                <Users className="h-4 w-4" />
                {group.name}
              </span>
              <div className="flex gap-1">
                {group.is_private && (
                  <Badge variant="outline" className="text-xs">
                    <Lock className="h-3 w-3 mr-1" />
                    Private
                  </Badge>
                )}
              </div>
            </CardTitle>
            <p className="text-sm text-muted-foreground">{group.description}</p>
          </CardHeader>
          <CardContent>
            <div className="flex justify-between items-center mb-4">
              <span className="text-sm text-muted-foreground">
                {group.member_count} members
              </span>
            </div>
            
            {group.has_pending_request ? (
              <Button disabled className="w-full">
                <Clock className="h-4 w-4 mr-2" />
                Request Pending
              </Button>
            ) : (
              <Dialog>
                <DialogTrigger asChild>
                  <Button 
                    className="w-full" 
                    onClick={() => setSelectedGroup(group)}
                  >
                    Request to Join
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Request to Join {selectedGroup?.name}</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <p className="text-sm text-muted-foreground">
                      Tell the group administrators why you'd like to join this group.
                    </p>
                    <Textarea
                      placeholder="Why would you like to join this group? What are your goals and how do you think this group can help you achieve them?"
                      value={application}
                      onChange={(e) => setApplication(e.target.value)}
                      rows={4}
                    />
                    <div className="flex gap-2 justify-end">
                      <Button
                        variant="outline"
                        onClick={() => {
                          setSelectedGroup(null);
                          setApplication('');
                        }}
                      >
                        Cancel
                      </Button>
                      <Button
                        onClick={handleJoinRequest}
                        disabled={submitting || !application.trim()}
                      >
                        <Send className="h-4 w-4 mr-2" />
                        {submitting ? 'Sending...' : 'Send Request'}
                      </Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            )}
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

export default GroupBrowser;