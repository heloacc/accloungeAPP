import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Check, Flame } from 'lucide-react';

interface Habit {
  id: string;
  title: string;
  current_streak: number;
  done_today: boolean;
  linked_goal_id?: string;
  linked_goal_title?: string;
}

interface TodaysHabitsProps {
  habits: Habit[];
  onToggleHabit: (habitId: string) => void;
}

export const TodaysHabits: React.FC<TodaysHabitsProps> = ({ habits = [], onToggleHabit }) => {
  const [confetti, setConfetti] = useState(false);
  const completedCount = habits?.filter(h => h.done_today).length || 0;
  const allCompleted = completedCount === habits?.length && habits?.length > 0;

  const handleToggle = (habitId: string) => {
    onToggleHabit(habitId);
    const newCompletedCount = habits?.filter(h => h.id === habitId ? !h.done_today : h.done_today).length || 0;
    if (newCompletedCount === habits?.length && habits?.length > 0) {
      setConfetti(true);
      setTimeout(() => setConfetti(false), 2000);
    }
  };

  return (
    <Card className="mb-4 sm:mb-6">
      <CardHeader className="flex flex-row items-center justify-between pb-3 sm:pb-4">
        <CardTitle className="text-lg sm:text-xl font-semibold">Today's Habits</CardTitle>
        <div className="flex items-center gap-2">
          {allCompleted && confetti && (
            <span className="animate-bounce text-xl sm:text-2xl">🎉</span>
          )}
          <Badge variant="secondary" className="text-xs sm:text-sm">{completedCount}/{habits?.length || 0}</Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-2 sm:space-y-3">
        {habits.map((habit) => (
          <div key={habit.id} className="flex items-center justify-between p-2 sm:p-3 rounded-lg border bg-card">
            <div className="flex items-center gap-2 sm:gap-3 flex-1 min-w-0">
              <Button
                variant={habit.done_today ? "default" : "outline"}
                size="sm"
                onClick={() => handleToggle(habit.id)}
                className={`flex-shrink-0 h-8 w-8 sm:h-9 sm:w-9 ${habit.done_today ? "bg-green-600 hover:bg-green-700" : ""}`}
              >
                <Check className="h-3 w-3 sm:h-4 sm:w-4" />
              </Button>
              <div className="min-w-0 flex-1">
                <p className={`font-medium text-sm sm:text-base truncate ${habit.done_today ? 'line-through text-muted-foreground' : ''}`}>
                  {habit.title}
                </p>
                {habit.linked_goal_title && (
                  <p className="text-xs sm:text-sm text-muted-foreground truncate">
                    Linked to: {habit.linked_goal_title}
                  </p>
                )}
              </div>
            </div>
            <div className="flex items-center gap-1 sm:gap-2 flex-shrink-0">
              <Flame className="h-3 w-3 sm:h-4 sm:w-4 text-orange-500" />
              <span className="font-bold text-orange-500 text-sm sm:text-base">{habit.current_streak}</span>
            </div>
          </div>
        ))}
        
        {allCompleted && (
          <div className="text-center p-3 sm:p-4 bg-green-50 rounded-lg border border-green-200">
            <p className="text-green-800 font-medium text-sm sm:text-base">🎉 All habits completed!</p>
            <p className="text-xs sm:text-sm text-green-600">Hit 30 days to unlock the Consistency Queen 👑 badge.</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};