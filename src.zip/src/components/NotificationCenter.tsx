import React, { useState, useEffect } from 'react';
import { useAppContext } from '@/contexts/OptimizedAppContext';
import UserNotifications from './UserNotifications';
import PWANotificationGuide from './PWANotificationGuide';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Bell, Settings } from 'lucide-react';
import { requestNotificationPermission } from '@/utils/pwaUtils';

const NotificationCenter: React.FC = () => {
  const { currentUser, notifications } = useAppContext();
  const [pwaNotifsEnabled, setPwaNotifsEnabled] = useState(false);

  useEffect(() => {
    // Check current PWA notification permission
    if ('Notification' in window) {
      setPwaNotifsEnabled(Notification.permission === 'granted');
    }
  }, []);

  const handleEnablePWANotifications = async () => {
    try {
      console.log('Requesting notification permission...');
      const granted = await requestNotificationPermission();
      console.log('Permission granted:', granted);
      setPwaNotifsEnabled(granted);
      
      if (granted) {
        // Test notification to confirm it works
        new Notification('ACCLOUNGE', {
          body: 'PWA notifications are now enabled!',
          icon: '/placeholder.svg'
        });
      }
    } catch (error) {
      console.error('Error requesting notification permission:', error);
    }
  };

  if (!currentUser?.id) {
    return (
      <Card>
        <CardContent className="p-6 text-center">
          <Bell className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
          <p>Please log in to view notifications</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Bell className="h-8 w-8 text-primary" />
          <div>
            <h1 className="text-3xl font-bold">Notifications</h1>
            <p className="text-muted-foreground">Stay updated with your progress and community</p>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          <Badge variant={pwaNotifsEnabled ? "default" : "secondary"}>
            PWA: {pwaNotifsEnabled ? "Enabled" : "Disabled"}
          </Badge>
          {!pwaNotifsEnabled && (
            <Button 
              onClick={handleEnablePWANotifications}
              size="sm"
              variant="outline"
            >
              <Settings className="h-4 w-4 mr-1" />
              Enable PWA
            </Button>
          )}
        </div>
      </div>

      {/* In-app notifications from admin */}
      {notifications.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>System Announcements</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {notifications.slice(0, 3).map((notification) => (
                <div key={notification.id} className="p-3 border rounded-lg">
                  <h4 className="font-medium">{notification.title}</h4>
                  <p className="text-sm text-muted-foreground">{notification.message}</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    {notification.createdAt.toLocaleDateString()}
                  </p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* User-specific notifications from database */}
      <UserNotifications userId={currentUser.id} />
      
      {/* PWA notification guide */}
      <PWANotificationGuide />
    </div>
  );
};

export default NotificationCenter;