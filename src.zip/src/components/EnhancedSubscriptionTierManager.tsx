import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Plus, Edit, Trash2, DollarSign, Crown } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { toast } from '@/components/ui/use-toast';
import UserSubscriptionManager from '@/components/UserSubscriptionManager';

interface SubscriptionTier {
  id: string;
  name: string;
  description: string;
  price_monthly: string;
  price_yearly: string;
  billing_period: string;
  features: string[];
  max_groups: number;
  max_partnerships: number;
  is_active: boolean;
  stripe_price_id?: string;
  stripe_product_id?: string;
  created_at: string;
}

const EnhancedSubscriptionTierManager: React.FC = () => {
  const [tiers, setTiers] = useState<SubscriptionTier[]>([]);
  const [loading, setLoading] = useState(false);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingTier, setEditingTier] = useState<SubscriptionTier | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    price_monthly: '0.00',
    price_yearly: '0.00',
    billing_period: 'monthly',
    features: '',
    max_groups: 5,
    max_partnerships: 10,
    is_active: true,
    stripe_price_id: '',
    stripe_product_id: ''
  });

  const loadTiers = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('subscription_tiers')
        .select('*')
        .order('price');
      
      if (error) throw error;
      setTiers(data || []);
    } catch (error: any) {
      toast({
        title: "Error",
        description: error?.message || 'Failed to load subscription tiers',
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      const featuresArray = formData.features
        .split(',')
        .map(feature => feature.trim())
        .filter(feature => feature.length > 0);

      const tierData = {
        name: formData.name,
        price: formData.price,
        billing_period: formData.billing_period,
        features: featuresArray,
        max_groups: formData.max_groups,
        max_goals: formData.max_goals,
        is_active: formData.is_active,
        stripe_price_id: formData.stripe_price_id || null,
        updated_at: new Date().toISOString()
      };

      if (editingTier) {
        const { error } = await supabase
          .from('subscription_tiers')
          .update(tierData)
          .eq('id', editingTier.id);
        
        if (error) throw error;
        toast({ title: "Success", description: "Subscription tier updated" });
      } else {
        const { error } = await supabase
          .from('subscription_tiers')
          .insert([{ ...tierData, created_at: new Date().toISOString() }]);
        
        if (error) throw error;
        toast({ title: "Success", description: "Subscription tier created" });
      }

      setIsDialogOpen(false);
      resetForm();
      loadTiers();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error?.message || 'Failed to save subscription tier',
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const deleteTier = async (id: string) => {
    if (!confirm('Are you sure you want to delete this subscription tier?')) return;
    
    try {
      const { error } = await supabase
        .from('subscription_tiers')
        .delete()
        .eq('id', id);
      
      if (error) throw error;
      toast({ title: "Success", description: "Subscription tier deleted" });
      loadTiers();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error?.message || 'Failed to delete subscription tier',
        variant: "destructive"
      });
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      price: 0,
      billing_period: 'monthly',
      features: '',
      max_groups: 5,
      max_goals: 10,
      is_active: true,
      stripe_price_id: ''
    });
    setEditingTier(null);
  };

  const openEditDialog = (tier: SubscriptionTier) => {
    setEditingTier(tier);
    setFormData({
      name: tier.name,
      price: tier.price,
      billing_period: tier.billing_period,
      features: tier.features?.join(', ') || '',
      max_groups: tier.max_groups,
      max_goals: tier.max_goals,
      is_active: tier.is_active,
      stripe_price_id: tier.stripe_price_id || ''
    });
    setIsDialogOpen(true);
  };

  useEffect(() => {
    loadTiers();
  }, []);

  return (
    <div className="space-y-6">
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <h3 className="text-lg font-semibold">Subscription Tiers</h3>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button onClick={resetForm}>
                <Plus className="h-4 w-4 mr-2" />
                Add Tier
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md sm:max-w-lg">
              <DialogHeader>
                <DialogTitle>
                  {editingTier ? 'Edit Subscription Tier' : 'Create Subscription Tier'}
                </DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="name">Name</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    required
                  />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <Label htmlFor="price">Price</Label>
                    <Input
                      id="price"
                      type="number"
                      step="0.01"
                      value={formData.price}
                      onChange={(e) => setFormData({ ...formData, price: parseFloat(e.target.value) || 0 })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="billing_period">Billing</Label>
                    <Select value={formData.billing_period} onValueChange={(value) => setFormData({ ...formData, billing_period: value })}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="monthly">Monthly</SelectItem>
                        <SelectItem value="yearly">Yearly</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div>
                  <Label htmlFor="features">Features (comma-separated)</Label>
                  <Textarea
                    id="features"
                    value={formData.features}
                    onChange={(e) => setFormData({ ...formData, features: e.target.value })}
                    placeholder="Unlimited groups, Priority support, Advanced analytics"
                    rows={2}
                  />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <Label htmlFor="max_groups">Max Groups</Label>
                    <Input
                      id="max_groups"
                      type="number"
                      value={formData.max_groups}
                      onChange={(e) => setFormData({ ...formData, max_groups: parseInt(e.target.value) || 0 })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="max_goals">Max Goals</Label>
                    <Input
                      id="max_goals"
                      type="number"
                      value={formData.max_goals}
                      onChange={(e) => setFormData({ ...formData, max_goals: parseInt(e.target.value) || 0 })}
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="stripe_price_id">Stripe Price ID</Label>
                  <Input
                    id="stripe_price_id"
                    value={formData.stripe_price_id}
                    onChange={(e) => setFormData({ ...formData, stripe_price_id: e.target.value })}
                    placeholder="price_1234567890"
                  />
                </div>
                <div className="flex items-center space-x-2">
                  <Switch
                    id="is_active"
                    checked={formData.is_active}
                    onCheckedChange={(checked) => setFormData({ ...formData, is_active: checked })}
                  />
                  <Label htmlFor="is_active">Active</Label>
                </div>
                <div className="flex gap-2">
                  <Button type="submit" disabled={loading}>
                    {editingTier ? 'Update' : 'Create'}
                  </Button>
                  <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                    Cancel
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        <div className="grid gap-4">
          {tiers.map((tier) => (
            <Card key={tier.id}>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <Crown className="h-5 w-5" />
                    {tier.name}
                    <Badge variant="outline" className="ml-2">
                      <DollarSign className="h-3 w-3 mr-1" />
                      {tier.price}/{tier.billing_period}
                    </Badge>
                  </CardTitle>
                  <div className="flex items-center gap-2">
                    <Badge variant={tier.is_active ? "default" : "secondary"}>
                      {tier.is_active ? 'Active' : 'Inactive'}
                    </Badge>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => openEditDialog(tier)}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => deleteTier(tier.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="font-medium">Max Groups:</span> {tier.max_groups}
                    </div>
                    <div>
                      <span className="font-medium">Max Goals:</span> {tier.max_goals}
                    </div>
                  </div>
                  {tier.features && tier.features.length > 0 && (
                    <div className="text-sm">
                      <span className="font-medium">Features:</span>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {tier.features.map((feature, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {feature}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                  {tier.stripe_price_id && (
                    <p className="text-xs text-muted-foreground">
                      <span className="font-medium">Stripe Price ID:</span> {tier.stripe_price_id}
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
          
          {tiers.length === 0 && !loading && (
            <Card>
              <CardContent className="p-6 text-center text-muted-foreground">
                No subscription tiers found. Create your first tier to get started.
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      <UserSubscriptionManager />
    </div>
  );
};

export default EnhancedSubscriptionTierManager;