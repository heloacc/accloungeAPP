import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Plus, Edit, Trash2, ExternalLink } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { toast } from '@/components/ui/use-toast';

interface Tier {
  id: string;
  name: string;
  description?: string;
  stripe_product_id?: string;
  stripe_price_id?: string;
  price_monthly: number;
  price_yearly: number;
  features: string[] | null;
  is_active: boolean;
  max_groups: number;
  max_partnerships: number;
  priority_support: boolean;
  analytics_access: boolean;
  custom_branding: boolean;
}

export default function ComprehensiveTierManager() {
  const [tiers, setTiers] = useState<Tier[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingTier, setEditingTier] = useState<Tier | null>(null);
  
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    stripe_product_id: '',
    stripe_price_id: '',
    price_monthly: '',
    price_yearly: '',
    features: '',
    max_groups: '1',
    max_partnerships: '1',
    priority_support: false,
    analytics_access: false,
    custom_branding: false
  });

  useEffect(() => {
    fetchTiers();
  }, []);

  const fetchTiers = async () => {
    try {
      const { data, error } = await supabase
        .from('subscription_tiers')
        .select('*')
        .order('price_monthly', { ascending: true });

      if (error) throw error;
      setTiers(data || []);
    } catch (error) {
      console.error('Error:', error);
      toast({
        title: "Error",
        description: "Failed to load tiers",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const tierData = {
        name: formData.name,
        description: formData.description || null,
        stripe_product_id: formData.stripe_product_id || null,
        stripe_price_id: formData.stripe_price_id || null,
        price_monthly: Number(formData.price_monthly) || 0,
        price_yearly: Number(formData.price_yearly) || 0,
        price: Number(formData.price_monthly) || 0,
        currency: 'USD',
        billing_interval: 'monthly',
        billing_period: 'monthly',
        features: formData.features ? formData.features.split('\n').filter(f => f.trim()) : [],
        is_active: true,
        max_groups: Number(formData.max_groups) || 1,
        max_partnerships: Number(formData.max_partnerships) || 1,
        priority_support: formData.priority_support,
        analytics_access: formData.analytics_access,
        custom_branding: formData.custom_branding,
        allowed_routes: []
      };

      if (editingTier) {
        const { error } = await supabase
          .from('subscription_tiers')
          .update(tierData)
          .eq('id', editingTier.id);
        
        if (error) throw error;
        toast({ title: "Success", description: "Tier updated successfully" });
      } else {
        const { error } = await supabase
          .from('subscription_tiers')
          .insert([tierData]);
        
        if (error) throw error;
        toast({ title: "Success", description: "Tier created successfully" });
      }

      resetForm();
      fetchTiers();
    } catch (error: any) {
      console.error('Error:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to save tier",
        variant: "destructive"
      });
    }
  };

  const deleteTier = async (tierId: string) => {
    if (!confirm('Delete this tier? This action cannot be undone.')) return;

    try {
      const { error } = await supabase
        .from('subscription_tiers')
        .delete()
        .eq('id', tierId);

      if (error) throw error;
      
      toast({ title: "Success", description: "Tier deleted successfully" });
      fetchTiers();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to delete tier",
        variant: "destructive"
      });
    }
  };

  const editTier = (tier: Tier) => {
    setEditingTier(tier);
    setFormData({
      name: tier.name,
      description: tier.description || '',
      stripe_product_id: tier.stripe_product_id || '',
      stripe_price_id: tier.stripe_price_id || '',
      price_monthly: tier.price_monthly.toString(),
      price_yearly: tier.price_yearly.toString(),
      features: tier.features ? tier.features.join('\n') : '',
      max_groups: tier.max_groups.toString(),
      max_partnerships: tier.max_partnerships.toString(),
      priority_support: tier.priority_support,
      analytics_access: tier.analytics_access,
      custom_branding: tier.custom_branding
    });
    setShowForm(true);
  };

  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      stripe_product_id: '',
      stripe_price_id: '',
      price_monthly: '',
      price_yearly: '',
      features: '',
      max_groups: '1',
      max_partnerships: '1',
      priority_support: false,
      analytics_access: false,
      custom_branding: false
    });
    setEditingTier(null);
    setShowForm(false);
  };

  const toggleTierStatus = async (tierId: string, currentStatus: boolean) => {
    try {
      const { error } = await supabase
        .from('subscription_tiers')
        .update({ is_active: !currentStatus })
        .eq('id', tierId);

      if (error) throw error;
      
      toast({ 
        title: "Success", 
        description: `Tier ${!currentStatus ? 'activated' : 'deactivated'}` 
      });
      fetchTiers();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to update tier status",
        variant: "destructive"
      });
    }
  };

  if (loading) return <div className="p-6">Loading subscription tiers...</div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold">Subscription Tiers</h3>
          <p className="text-sm text-muted-foreground">
            Create and manage subscription tiers with Stripe integration
          </p>
        </div>
        <Button onClick={() => setShowForm(true)} size="sm">
          <Plus className="h-4 w-4 mr-2" />
          Add Tier
        </Button>
      </div>

      {showForm && (
        <Card>
          <CardHeader>
            <CardTitle>{editingTier ? 'Edit Tier' : 'Create New Tier'}</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name">Tier Name *</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="e.g., Basic, Pro, Enterprise"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="stripe_product_id">Stripe Product ID</Label>
                  <Input
                    id="stripe_product_id"
                    value={formData.stripe_product_id}
                    onChange={(e) => setFormData({ ...formData, stripe_product_id: e.target.value })}
                    placeholder="prod_xxxxx"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="stripe_price_id">Stripe Price ID</Label>
                  <Input
                    id="stripe_price_id"
                    value={formData.stripe_price_id}
                    onChange={(e) => setFormData({ ...formData, stripe_price_id: e.target.value })}
                    placeholder="price_xxxxx"
                  />
                </div>
                <div>
                  <Label htmlFor="price_monthly">Monthly Price ($) *</Label>
                  <Input
                    id="price_monthly"
                    type="number"
                    step="0.01"
                    value={formData.price_monthly}
                    onChange={(e) => setFormData({ ...formData, price_monthly: e.target.value })}
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="price_yearly">Yearly Price ($)</Label>
                  <Input
                    id="price_yearly"
                    type="number"
                    step="0.01"
                    value={formData.price_yearly}
                    onChange={(e) => setFormData({ ...formData, price_yearly: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="max_groups">Max Groups</Label>
                  <Input
                    id="max_groups"
                    type="number"
                    value={formData.max_groups}
                    onChange={(e) => setFormData({ ...formData, max_groups: e.target.value })}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="max_partnerships">Max Partnerships</Label>
                  <Input
                    id="max_partnerships"
                    type="number"
                    value={formData.max_partnerships}
                    onChange={(e) => setFormData({ ...formData, max_partnerships: e.target.value })}
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Brief description of this tier"
                />
              </div>

              <div>
                <Label htmlFor="features">Features (one per line)</Label>
                <Textarea
                  id="features"
                  value={formData.features}
                  onChange={(e) => setFormData({ ...formData, features: e.target.value })}
                  rows={4}
                  placeholder="Feature 1&#10;Feature 2&#10;Feature 3"
                />
              </div>

              <div className="space-y-4">
                <Label>Additional Features</Label>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="priority_support"
                      checked={formData.priority_support}
                      onCheckedChange={(checked) => setFormData({ ...formData, priority_support: checked })}
                    />
                    <Label htmlFor="priority_support">Priority Support</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="analytics_access"
                      checked={formData.analytics_access}
                      onCheckedChange={(checked) => setFormData({ ...formData, analytics_access: checked })}
                    />
                    <Label htmlFor="analytics_access">Analytics Access</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="custom_branding"
                      checked={formData.custom_branding}
                      onCheckedChange={(checked) => setFormData({ ...formData, custom_branding: checked })}
                    />
                    <Label htmlFor="custom_branding">Custom Branding</Label>
                  </div>
                </div>
              </div>

              <div className="flex gap-2">
                <Button type="submit">
                  {editingTier ? 'Update Tier' : 'Create Tier'}
                </Button>
                <Button type="button" variant="outline" onClick={resetForm}>
                  Cancel
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      <div className="grid gap-4">
        {tiers.map((tier) => (
          <Card key={tier.id} className={!tier.is_active ? 'opacity-60' : ''}>
            <CardContent className="p-6">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-3">
                    <h4 className="text-xl font-semibold">{tier.name}</h4>
                    <Badge variant={tier.is_active ? "default" : "secondary"}>
                      {tier.is_active ? 'Active' : 'Inactive'}
                    </Badge>
                    {tier.stripe_product_id && (
                      <Badge variant="outline" className="text-xs">
                        <ExternalLink className="h-3 w-3 mr-1" />
                        Stripe Connected
                      </Badge>
                    )}
                  </div>
                  
                  <div className="text-2xl font-bold mb-2 text-green-600">
                    ${tier.price_monthly}/month
                    {tier.price_yearly > 0 && (
                      <span className="text-sm font-normal text-muted-foreground ml-2">
                        or ${tier.price_yearly}/year
                      </span>
                    )}
                  </div>

                  {tier.description && (
                    <p className="text-muted-foreground mb-3">{tier.description}</p>
                  )}

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4 text-sm">
                    <div>
                      <span className="font-medium">Max Groups:</span> {tier.max_groups}
                    </div>
                    <div>
                      <span className="font-medium">Max Partnerships:</span> {tier.max_partnerships}
                    </div>
                    <div>
                      <span className="font-medium">Priority Support:</span> {tier.priority_support ? '✓' : '✗'}
                    </div>
                    <div>
                      <span className="font-medium">Analytics:</span> {tier.analytics_access ? '✓' : '✗'}
                    </div>
                  </div>

                  {tier.stripe_product_id && (
                    <div className="text-xs text-muted-foreground mb-2">
                      <strong>Stripe Product ID:</strong> {tier.stripe_product_id}
                      {tier.stripe_price_id && (
                        <span className="ml-4">
                          <strong>Price ID:</strong> {tier.stripe_price_id}
                        </span>
                      )}
                    </div>
                  )}

                  {tier.features && tier.features.length > 0 && (
                    <div className="text-sm">
                      <p className="font-medium mb-2">Features:</p>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-1">
                        {tier.features.map((feature, index) => (
                          <div key={index} className="flex items-center gap-2">
                            <span className="w-1.5 h-1.5 bg-green-500 rounded-full flex-shrink-0"></span>
                            <span>{feature}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                <div className="flex flex-col gap-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => toggleTierStatus(tier.id, tier.is_active)}
                  >
                    {tier.is_active ? 'Deactivate' : 'Activate'}
                  </Button>
                  <Button variant="ghost" size="sm" onClick={() => editTier(tier)}>
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => deleteTier(tier.id)}
                    className="text-red-600 hover:text-red-700"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}

        {tiers.length === 0 && (
          <Card>
            <CardContent className="p-8 text-center">
              <div className="mb-4">
                <h3 className="text-lg font-semibold mb-2">No Subscription Tiers</h3>
                <p className="text-muted-foreground">
                  Create your first subscription tier to start monetizing your app.
                </p>
              </div>
              <Button onClick={() => setShowForm(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Create First Tier
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}