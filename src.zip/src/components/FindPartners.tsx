import React, { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import PartnerMatching from './PartnerMatching';
import PartnershipDashboard from './PartnershipDashboard';

const FindPartners = () => {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Partner Network</h1>
        <p className="text-gray-600 mt-2">Find accountability partners and manage your connections</p>
      </div>

      <Tabs defaultValue="find" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="find">Find Partners</TabsTrigger>
          <TabsTrigger value="my-partners">My Partners</TabsTrigger>
        </TabsList>
        
        <TabsContent value="find" className="mt-6">
          <PartnerMatching />
        </TabsContent>
        
        <TabsContent value="my-partners" className="mt-6">
          <PartnershipDashboard />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default FindPartners;