import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useUserData } from '@/hooks/useUserData';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { CheckCircle, X, Clock, User, MessageSquare, Users, Shield } from 'lucide-react';
import AdminGroupDeleteManager from '@/components/AdminGroupDeleteManager';

interface JoinRequest {
  id: string;
  user_id: string;
  group_id: string;
  questionnaire_response: string;
  status: string;
  created_at: string;
  profiles: {
    full_name: string;
    email: string;
  };
  acircle_groups: {
    name: string;
    is_private: boolean;
  };
}

interface Group {
  id: string;
  name: string;
  description: string;
  is_private: boolean;
  member_count: number;
  pending_requests: number;
}

const AllGroupsManager = () => {
  const [allJoinRequests, setAllJoinRequests] = useState<JoinRequest[]>([]);
  const [groups, setGroups] = useState<Group[]>([]);
  const [loading, setLoading] = useState(true);
  const [processingRequest, setProcessingRequest] = useState<string | null>(null);

  const { user, isAdmin } = useUserData();

  useEffect(() => {
    if (user && isAdmin) {
      fetchAllJoinRequests();
      fetchAllGroups();
    }
  }, [user, isAdmin]);

  const fetchAllJoinRequests = async () => {
    try {
      const { data } = await supabase
        .from('acircle_join_requests')
        .select(`
          *,
          profiles!acircle_join_requests_user_id_fkey(full_name, email),
          acircle_groups!acircle_join_requests_group_id_fkey(name, is_private)
        `)
        .order('created_at', { ascending: false });

      setAllJoinRequests(data || []);
    } catch (error) {
      console.error('Error fetching all join requests:', error);
    }
  };

  const fetchAllGroups = async () => {
    try {
      // First get all groups
      const { data: allGroups } = await supabase
        .from('acircle_groups')
        .select('id, name, description, is_private')
        .eq('is_archived', false);

      if (!allGroups) {
        setGroups([]);
        return;
      }

      // Get member counts and pending request counts for each group
      const groupsWithCounts = await Promise.all(
        allGroups.map(async (group) => {
          // Get member count
          const { count: memberCount } = await supabase
            .from('acircle_members')
            .select('*', { count: 'exact', head: true })
            .eq('group_id', group.id);

          // Get pending request count
          const { count: pendingCount } = await supabase
            .from('acircle_join_requests')
            .select('*', { count: 'exact', head: true })
            .eq('group_id', group.id)
            .eq('status', 'pending');

          return {
            id: group.id,
            name: group.name,
            description: group.description,
            is_private: group.is_private,
            member_count: memberCount || 0,
            pending_requests: pendingCount || 0
          };
        })
      );

      setGroups(groupsWithCounts);
    } catch (error) {
      console.error('Error fetching groups:', error);
      setGroups([]);
    } finally {
      setLoading(false);
    }
  };

  const handleRequest = async (requestId: string, action: 'approved' | 'rejected') => {
    setProcessingRequest(requestId);
    
    try {
      const request = allJoinRequests.find(r => r.id === requestId);
      if (!request) return;

      // Update request status
      const { error: updateError } = await supabase
        .from('acircle_join_requests')
        .update({
          status: action,
          reviewed_at: new Date().toISOString(),
          reviewed_by: user?.id
        })
        .eq('id', requestId);

      if (updateError) throw updateError;

      // If approved, add user to group
      if (action === 'approved') {
        const { error: memberError } = await supabase
          .from('acircle_members')
          .insert([{
            group_id: request.group_id,
            user_id: request.user_id
          }]);

        if (memberError) throw memberError;
      }

      // Refresh the lists
      fetchAllJoinRequests();
      fetchAllGroups();
    } catch (error) {
      console.error('Error processing request:', error);
    } finally {
      setProcessingRequest(null);
    }
  };

  if (!isAdmin) {
    return (
      <div className="p-6">
        <Card>
          <CardContent className="p-6 text-center">
            <Shield className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
            <h3 className="text-lg font-semibold mb-2">Admin Access Required</h3>
            <p className="text-muted-foreground">
              You need admin privileges to manage all groups and join requests.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (loading) {
    return <div className="p-6">Loading group management...</div>;
  }

  const pendingRequests = allJoinRequests.filter(r => r.status === 'pending');
  const processedRequests = allJoinRequests.filter(r => r.status !== 'pending');

  return (
    <div className="p-6 max-w-6xl mx-auto space-y-6">
      <div>
        <h2 className="text-2xl font-bold mb-2 flex items-center gap-2">
          <Users className="h-6 w-6" />
          All Groups Management
          <Badge className="bg-yellow-600 text-white text-xs">Admin</Badge>
        </h2>
        <p className="text-muted-foreground">Manage join requests and view all groups</p>
      </div>

      <Tabs defaultValue="requests" className="w-full">
        <TabsList className="grid w-full grid-cols-2 mb-4">
          <TabsTrigger value="requests" className="text-xs sm:text-sm px-2 sm:px-4">
            <span className="hidden sm:inline">Join Requests</span>
            <span className="sm:hidden">Requests</span>
            <span className="ml-1">({pendingRequests.length})</span>
          </TabsTrigger>
          <TabsTrigger value="groups" className="text-xs sm:text-sm px-2 sm:px-4">
            <span className="hidden sm:inline">All Groups</span>
            <span className="sm:hidden">Groups</span>
            <span className="ml-1">({groups.length})</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="requests" className="space-y-6">
          {/* Pending Requests */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5" />
                Pending Requests ({pendingRequests.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              {pendingRequests.length === 0 ? (
                <p className="text-muted-foreground text-center py-4">
                  No pending requests across all groups
                </p>
              ) : (
                <div className="space-y-4">
                  {pendingRequests.map((request) => (
                    <div key={request.id} className="border rounded-lg p-4 space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <User className="h-4 w-4" />
                           <span className="font-medium">{request.profiles?.full_name || 'Unknown User'}</span>
                          <span className="text-sm text-muted-foreground">
                             ({request.profiles?.email || 'No email'})
                          </span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge variant="outline">
                            {request.acircle_groups.name}
                          </Badge>
                          {request.acircle_groups.is_private && (
                            <Badge variant="secondary" className="text-xs">Private</Badge>
                          )}
                          <Badge variant="secondary">
                            {new Date(request.created_at).toLocaleDateString()}
                          </Badge>
                        </div>
                      </div>
                      
                      <div className="bg-gray-50 p-3 rounded-md">
                        <div className="flex items-center gap-2 mb-2">
                          <MessageSquare className="h-4 w-4" />
                          <span className="font-medium text-sm">Application:</span>
                        </div>
                        <p className="text-sm">{request.questionnaire_response}</p>
                      </div>

                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          onClick={() => handleRequest(request.id, 'approved')}
                          disabled={processingRequest === request.id}
                          className="bg-green-600 hover:bg-green-700"
                        >
                          <CheckCircle className="h-4 w-4 mr-1" />
                          Approve
                        </Button>
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={() => handleRequest(request.id, 'rejected')}
                          disabled={processingRequest === request.id}
                        >
                          <X className="h-4 w-4 mr-1" />
                          Reject
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Recent Decisions */}
          {processedRequests.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Recent Decisions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {processedRequests.slice(0, 10).map((request) => (
                    <div key={request.id} className="flex flex-col sm:flex-row sm:items-center justify-between p-3 border rounded-lg gap-2">
                      <div className="flex items-center gap-2 min-w-0 flex-1">
                        <User className="h-4 w-4 flex-shrink-0" />
                         <span className="font-medium truncate">{request.profiles?.full_name || 'Unknown User'}</span>
                        <span className="text-sm text-muted-foreground hidden sm:inline">→</span>
                        <span className="text-sm truncate">{request.acircle_groups.name}</span>
                      </div>
                      <div className="flex items-center gap-2 flex-shrink-0">
                        <Badge variant={request.status === 'approved' ? 'default' : 'destructive'}>
                          {request.status}
                        </Badge>
                        <span className="text-xs sm:text-sm text-muted-foreground">
                          {new Date(request.created_at).toLocaleDateString()}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>
        <TabsContent value="groups" className="space-y-6">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {groups.map((group) => (
              <Card key={group.id}>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span className="flex items-center gap-2">
                      <Users className="h-4 w-4" />
                      {group.name}
                    </span>
                    {group.is_private && (
                      <Badge variant="outline" className="text-xs">Private</Badge>
                    )}
                  </CardTitle>
                  <p className="text-sm text-muted-foreground">{group.description}</p>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Members:</span>
                      <Badge variant="secondary">{group.member_count}</Badge>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Pending Requests:</span>
                      <Badge variant={group.pending_requests > 0 ? 'default' : 'secondary'}>
                        {group.pending_requests}
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
          
          {/* Admin Group Delete Manager */}
          <AdminGroupDeleteManager 
            groups={groups} 
            onGroupDeleted={fetchAllGroups}
          />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default AllGroupsManager;