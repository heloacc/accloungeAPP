import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Trash2, Plus, Lock } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/components/ui/use-toast';

interface SubscriptionTier {
  id: string;
  name: string;
  is_active: boolean;
}

interface PageAccessRule {
  id: string;
  page_path: string;
  page_name?: string;
  minimum_tier_id?: string;
  is_premium_only: boolean;
  tier_name?: string;
}

const FixedPageAccessManager: React.FC = () => {
  const [rules, setRules] = useState<PageAccessRule[]>([]);
  const [tiers, setTiers] = useState<SubscriptionTier[]>([]);
  const [loading, setLoading] = useState(false);
  const [newRule, setNewRule] = useState({
    page_path: '',
    page_name: '',
    minimum_tier_id: '',
    is_premium_only: false
  });
  const { toast } = useToast();

  const loadTiers = async () => {
    try {
      const { data, error } = await supabase
        .from('subscription_tiers')
        .select('id, name, is_active')
        .eq('is_active', true)
        .order('name');

      if (error) throw error;
      setTiers(data || []);
    } catch (error: any) {
      console.error('Error loading tiers:', error);
      toast({
        title: "Error loading tiers",
        description: error.message,
        variant: "destructive"
      });
    }
  };

  const loadRules = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('page_access_rules')
        .select(`
          id,
          page_path,
          page_name,
          minimum_tier_id,
          is_premium_only,
          subscription_tiers!minimum_tier_id (
            name
          )
        `)
        .order('page_path');

      if (error) throw error;
      
      const rulesWithTierNames = (data || []).map(rule => ({
        ...rule,
        tier_name: rule.subscription_tiers?.name || 'No tier required'
      }));
      
      setRules(rulesWithTierNames);
    } catch (error: any) {
      toast({
        title: "Error loading rules",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const addRule = async () => {
    if (!newRule.page_path.trim()) {
      toast({
        title: "Error",
        description: "Page path is required",
        variant: "destructive"
      });
      return;
    }

    try {
      const ruleData = {
        page_path: newRule.page_path.trim(),
        page_name: newRule.page_name.trim() || null,
        minimum_tier_id: newRule.minimum_tier_id || null,
        is_premium_only: newRule.is_premium_only
      };

      const { error } = await supabase
        .from('page_access_rules')
        .insert([ruleData]);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Page access rule created successfully"
      });

      setNewRule({
        page_path: '',
        page_name: '',
        minimum_tier_id: '',
        is_premium_only: false
      });

      loadRules();
    } catch (error: any) {
      toast({
        title: "Error creating rule",
        description: error.message,
        variant: "destructive"
      });
    }
  };

  const deleteRule = async (id: string) => {
    if (!confirm('Are you sure you want to delete this rule?')) return;

    try {
      const { error } = await supabase
        .from('page_access_rules')
        .delete()
        .eq('id', id);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Page access rule deleted"
      });

      loadRules();
    } catch (error: any) {
      toast({
        title: "Error deleting rule",
        description: error.message,
        variant: "destructive"
      });
    }
  };

  useEffect(() => {
    loadTiers();
    loadRules();
  }, []);

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Lock className="h-5 w-5" />
            Create Page Access Rule
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="page-path">Page Path *</Label>
                <Input
                  id="page-path"
                  placeholder="/admin, /premium-features"
                  value={newRule.page_path}
                  onChange={(e) => setNewRule({ ...newRule, page_path: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="page-name">Page Name</Label>
                <Input
                  id="page-name"
                  placeholder="Admin Dashboard, Premium Features"
                  value={newRule.page_name}
                  onChange={(e) => setNewRule({ ...newRule, page_name: e.target.value })}
                />
              </div>
            </div>
            
            <div>
              <Label htmlFor="tier-select">Required Subscription Tier</Label>
              <Select 
                value={newRule.minimum_tier_id} 
                onValueChange={(value) => setNewRule({ ...newRule, minimum_tier_id: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select required tier (optional)" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">No tier required</SelectItem>
                  {tiers.map((tier) => (
                    <SelectItem key={tier.id} value={tier.id}>
                      {tier.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <Button onClick={addRule} className="w-full" disabled={loading}>
              <Plus className="h-4 w-4 mr-2" />
              Create Access Rule
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Page Access Rules ({rules.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center py-8">Loading page access rules...</div>
          ) : rules.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              No page access rules configured. Create your first rule above.
            </div>
          ) : (
            <div className="space-y-3">
              {rules.map((rule) => (
                <div key={rule.id} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <h3 className="font-medium">{rule.page_path}</h3>
                      {rule.page_name && (
                        <span className="text-sm text-muted-foreground">({rule.page_name})</span>
                      )}
                    </div>
                    <div className="flex items-center gap-2 mt-1">
                      <Badge variant={rule.minimum_tier_id ? "default" : "secondary"}>
                        {rule.tier_name}
                      </Badge>
                      {rule.is_premium_only && (
                        <Badge variant="destructive">Premium Only</Badge>
                      )}
                    </div>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => deleteRule(rule.id)}
                    disabled={loading}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {tiers.length === 0 && (
        <Card>
          <CardContent className="p-6 text-center text-amber-600">
            <p>⚠️ No active subscription tiers found. Create subscription tiers first to enable tier-based access control.</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default FixedPageAccessManager;