import { useState, useEffect } from 'react';
import { useAppContext } from '@/contexts/AppContext';
import { supabase } from '@/lib/supabase';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import PostScheduler from '@/components/PostScheduler';
import PostActions from '@/components/PostActions';
import UniversalModerationActions from '@/components/UniversalModerationActions';
import ModeratorBadge from '@/components/ModeratorBadge';
import { 
  MessageCircle, 
  Bell, 
  BellOff, 
  Send,
  Hash
} from 'lucide-react';

interface GatherMessage {
  id: string;
  author: string;
  avatar: string;
  time: string;
  content: string;
  isSubscriber: boolean;
  is_pinned?: boolean;
  author_name?: string;
  user_id?: string;
  created_at?: string;
  user_role?: string;
}

const GatherFeed = () => {
  const { currentUser } = useAppContext();
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [newMessage, setNewMessage] = useState('');
  const [messages, setMessages] = useState<GatherMessage[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchMessages();
    
    const channel = supabase
      .channel('gather_messages')
      .on('postgres_changes', 
        { event: 'INSERT', schema: 'public', table: 'posts', filter: 'category=eq.Gather' },
        (payload) => {
          const newPost = payload.new;
          const message: GatherMessage = {
            id: newPost.id,
            author: newPost.author_name || 'Anonymous',
            avatar: newPost.author_name ? newPost.author_name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase() : 'AN',
            time: formatTimeAgo(new Date(newPost.created_at)),
            content: newPost.content,
            isSubscriber: true,
            is_pinned: newPost.is_pinned,
            author_name: newPost.author_name,
            user_id: newPost.user_id,
            created_at: newPost.created_at
          };
          setMessages(prev => [message, ...prev]);
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / (1000 * 60));
    
    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins} min ago`;
    const diffHours = Math.floor(diffMins / 60);
    if (diffHours < 24) return `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`;
    const diffDays = Math.floor(diffHours / 24);
    return `${diffDays} day${diffDays > 1 ? 's' : ''} ago`;
  };

  const fetchMessages = async () => {
    try {
      const { data, error } = await supabase
        .from('posts')
        .select('*')
        .eq('category', 'Gather')
        .eq('recovery_status', 'active')
        .order('is_pinned', { ascending: false })
        .order('created_at', { ascending: false })
        .limit(50);

      if (error) throw error;

      const formattedMessages = data.map(post => ({
        id: post.id,
        author: post.author_name || 'Anonymous',
        avatar: post.author_name ? post.author_name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase() : 'AN',
        time: formatTimeAgo(new Date(post.created_at)),
        content: post.content,
        isSubscriber: true,
        is_pinned: post.is_pinned,
        author_name: post.author_name,
        user_id: post.user_id,
        created_at: post.created_at
      }));

      setMessages(formattedMessages);
    } catch (error) {
      console.error('Error fetching messages:', error);
    } finally {
      setLoading(false);
    }
  };

  const addPost = async (content: string, scheduledFor?: Date) => {
    try {
      const { data, error } = await supabase
        .from('posts')
        .insert([{
          content,
          category: 'Gather',
          author_name: currentUser?.name || 'Anonymous',
          user_id: currentUser?.id,
          recovery_status: 'active',
          scheduled_for: scheduledFor || null
        }])
        .select()
        .single();

      if (error) throw error;

      if (!scheduledFor) {
        const message: GatherMessage = {
          id: data.id,
          author: data.author_name || 'Anonymous',
          avatar: data.author_name ? data.author_name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase() : 'AN',
          time: 'Just now',
          content: data.content,
          isSubscriber: true,
          is_pinned: data.is_pinned,
          author_name: data.author_name,
          user_id: data.user_id,
          created_at: data.created_at
        };
        setMessages(prev => [message, ...prev]);
      }

      return { success: true };
    } catch (error) {
      console.error('Error adding post:', error);
      return { success: false, error };
    }
  };

  const subscriberCount = messages.filter(m => m.isSubscriber).length + (isSubscribed ? 1 : 0);

  return (
    <div className="w-full max-w-none space-y-6 p-2 sm:p-4 md:p-6">{/* Made wider and responsive */}
      <div className="flex justify-between items-center">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <Hash className="h-6 w-6 text-acclounge-olive" />
            <h2 className="text-2xl font-bold">Gather</h2>
            <Badge className="bg-acclounge-olive text-white">
              {subscriberCount} subscribed
            </Badge>
          </div>
          <p className="text-muted-foreground">
            Come gather in the lounge, connect share ideas, and be human.
          </p>
        </div>
        
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            {isSubscribed ? <Bell className="h-4 w-4" /> : <BellOff className="h-4 w-4" />}
            <span className="text-sm">Notifications</span>
            <Switch 
              checked={isSubscribed} 
              onCheckedChange={setIsSubscribed}
            />
          </div>
        </div>
      </div>

      <Card>
        <CardContent className="p-4">
          <div className="space-y-3">
            <Textarea
              placeholder="Share something with the community..."
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              className="min-h-[80px]"
            />
            <div className="flex justify-between items-center">
              <PostScheduler 
                onSchedule={(scheduledFor) => addPost(newMessage, new Date(scheduledFor))} 
                isAdmin={currentUser?.isAdmin || false}
                isModerator={currentUser?.isModerator || false}
              />
              <Button 
                onClick={() => addPost(newMessage).then(() => setNewMessage(''))} 
                className="bg-acclounge-brown hover:bg-acclounge-brown/90"
                disabled={!newMessage.trim()}
              >
                <Send className="h-4 w-4 mr-2" />
                Send
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="space-y-4">
        {loading ? (
          <div className="text-center py-8">Loading messages...</div>
        ) : messages.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            No messages yet. Be the first to start the conversation!
          </div>
        ) : (
          messages.map((message) => (
            <Card key={message.id} className={`border-acclounge-slate/20 ${message.is_pinned ? 'border-yellow-400 bg-yellow-50' : ''}`}>
              <CardContent className="p-4">
                <div className="flex items-start gap-3">
                  <Avatar>
                    <AvatarFallback className="bg-acclounge-brown text-white">
                      {message.avatar}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <p className="font-semibold">{message.author}</p>
                      {message.isSubscriber && (
                        <Badge className="bg-green-100 text-green-800 text-xs">
                          <Bell className="h-3 w-3 mr-1" />
                          Subscriber
                        </Badge>
                      )}
                      <span className="text-sm text-muted-foreground">{message.time}</span>
                    </div>
                    <p className="text-sm text-left">{message.content}</p>
                  </div>
                  <div className="flex gap-2">
                    <PostActions 
                      post={message} 
                      table="posts" 
                      onPostUpdated={fetchMessages}
                    />
                    <UniversalModerationActions
                      postId={message.id}
                      isPinned={message.is_pinned}
                      tableName="posts"
                      onPostUpdated={fetchMessages}
                      onPostDeleted={fetchMessages}
                    />
                  </div>
                </div>
              </CardContent>

            </Card>
          ))
        )}
      </div>
    </div>
  );
};

export { GatherFeed };
export default GatherFeed;