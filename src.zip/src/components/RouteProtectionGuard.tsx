import React from 'react';
import { useUserTier } from '@/hooks/useUserTier';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Lock, Crown, Zap, ArrowRight } from 'lucide-react';

interface RouteProtectionGuardProps {
  children: React.ReactNode;
  requiredTier: 'Freemium' | 'Accountability Essentials' | 'All Access';
  routePath: string;
  fallbackComponent?: React.ReactNode;
}

const RouteProtectionGuard: React.FC<RouteProtectionGuardProps> = ({
  children,
  requiredTier,
  routePath,
  fallbackComponent
}) => {
  const { userTier, loading, canAccessTier, getTierLevel } = useUserTier();

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[200px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  // Check if user has access to this tier level
  if (canAccessTier(requiredTier)) {
    return <>{children}</>;
  }

  // Show custom fallback if provided
  if (fallbackComponent) {
    return <>{fallbackComponent}</>;
  }

  const getTierIcon = (tier: string) => {
    switch (tier) {
      case 'All Access':
        return <Crown className="h-8 w-8 text-purple-500" />;
      case 'Accountability Essentials':
        return <Zap className="h-8 w-8 text-purple-500" />;
      default:
        return <Lock className="h-8 w-8 text-gray-500" />;
    }
  };

  const getTierColor = (tier: string) => {
    switch (tier) {
      case 'All Access': return 'bg-gradient-to-r from-purple-50 to-blue-50 border-purple-200';
      case 'Accountability Essentials': return 'bg-gradient-to-r from-purple-50 to-blue-50 border-purple-200';
      default: return 'bg-gray-50 border-gray-200';
    }
  };

  const getTierFeatures = (tier: string) => {
    switch (tier) {
      case 'All Access':
        return ['Advanced Analytics', 'Admin Features', 'Premium Support', 'All Features Unlocked'];
      case 'Accountability Essentials':
        return ['Goal Tracking', 'Group Features', 'Partnership Tools', 'Wins Wall'];
      default:
        return ['Basic Features'];
    }
  };

  return (
    <div className="flex items-center justify-center min-h-[500px] p-4">
      <Card className={`max-w-lg w-full ${getTierColor(requiredTier)}`}>
        <CardHeader className="text-center pb-4">
          <div className="flex justify-center mb-4">
            {getTierIcon(requiredTier)}
          </div>
          <CardTitle className="text-2xl mb-2">Upgrade Required</CardTitle>
          <p className="text-muted-foreground">
            This page requires a <strong>{requiredTier}</strong> subscription
          </p>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="text-center">
            <div className="flex items-center justify-center gap-2 mb-2">
              <Badge variant="outline" className="text-sm">
                Current: {userTier?.name || 'No Subscription'}
              </Badge>
              <ArrowRight className="h-4 w-4 text-muted-foreground" />
              <Badge className="text-sm bg-primary text-primary-foreground">
                Required: {requiredTier}
              </Badge>
            </div>
          </div>

          <div className="border rounded-lg p-4 bg-white/50">
            <h4 className="font-semibold mb-3 text-center">
              {requiredTier} Features:
            </h4>
            <ul className="space-y-2">
              {getTierFeatures(requiredTier).map((feature, index) => (
                <li key={index} className="flex items-center gap-2 text-sm">
                  <div className="w-1.5 h-1.5 bg-primary rounded-full"></div>
                  {feature}
                </li>
              ))}
            </ul>
          </div>

          <div className="text-center text-sm text-muted-foreground mb-4">
            <p>Route: <code className="bg-white/70 px-2 py-1 rounded text-xs">{routePath}</code></p>
          </div>

          <div className="flex gap-3 justify-center">
            <Button 
              onClick={() => window.dispatchEvent(new CustomEvent('navigate-to-tab', { 
                detail: { tab: 'billing' }
              }))}
              className="flex-1"
            >
              Upgrade Now
            </Button>
            <Button 
              variant="outline" 
              onClick={() => window.history.back()}
              className="flex-1"
            >
              Go Back
            </Button>
          </div>

          <div className="text-center">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => window.dispatchEvent(new CustomEvent('navigate-to-tab', { 
                detail: { tab: 'dashboard' }
              }))}
              className="text-muted-foreground"
            >
               Return to Dashboard
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default RouteProtectionGuard;