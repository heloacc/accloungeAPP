import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Crown, Medal, Trophy, Flame, Calendar, Users } from 'lucide-react';

interface Participant {
  id: string;
  user_id: string;
  full_name: string;
  current_streak: number;
  best_streak: number;
  joined_at: string;
  last_completed: string;
  rank: number;
}

interface CompetitionParticipantsViewProps {
  competition: {
    id: string;
    habit_name: string;
    end_date: string;
    participants: Participant[];
    participant_count?: number;
    status: 'active' | 'paused' | 'ended';
  };
}

export const CompetitionParticipantsView: React.FC<CompetitionParticipantsViewProps> = ({ 
  competition 
}) => {
  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1: return <Crown className="w-4 h-4 text-yellow-500" />;
      case 2: return <Medal className="w-4 h-4 text-gray-400" />;
      case 3: return <Medal className="w-4 h-4 text-amber-600" />;
      default: return <Trophy className="w-4 h-4 text-gray-400" />;
    }
  };

  const getRankColor = (rank: number) => {
    switch (rank) {
      case 1: return 'bg-yellow-50 border-yellow-200';
      case 2: return 'bg-gray-50 border-gray-200';
      case 3: return 'bg-amber-50 border-amber-200';
      default: return 'bg-white border-gray-200';
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return <Badge className="bg-green-100 text-green-800">Active</Badge>;
      case 'paused':
        return <Badge className="bg-yellow-100 text-yellow-800">Paused</Badge>;
      case 'ended':
        return <Badge className="bg-gray-100 text-gray-800">Ended</Badge>;
      default:
        return <Badge variant="secondary">Unknown</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Competition Header */}
      <Card>
        <CardHeader>
          <div className="flex justify-between items-start">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Flame className="w-5 h-5 text-orange-500" />
                {competition.habit_name} Competition
              </CardTitle>
              <div className="flex items-center gap-4 text-sm text-muted-foreground mt-2">
                <div className="flex items-center gap-1">
                  <Calendar className="w-4 h-4" />
                  Ends: {new Date(competition.end_date).toLocaleDateString()}
                </div>
                <div className="flex items-center gap-1">
                  <Users className="w-4 h-4" />
                  {competition.participant_count} participants
                </div>
              </div>
            </div>
            {getStatusBadge(competition.status)}
          </div>
        </CardHeader>
      </Card>

      {/* Participants Leaderboard */}
      <Card>
        <CardHeader>
          <CardTitle>Leaderboard</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {competition.participants.map((participant) => (
              <div
                key={participant.id}
                className={`p-4 rounded-lg border-2 ${getRankColor(participant.rank)}`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-2">
                      {getRankIcon(participant.rank)}
                      <span className="font-semibold text-lg">#{participant.rank}</span>
                    </div>
                    <Avatar className="w-10 h-10">
                      <AvatarFallback className="text-sm">
                        {participant.full_name.slice(0, 2).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium">{participant.full_name}</p>
                      <p className="text-sm text-muted-foreground">
                        Joined: {new Date(participant.joined_at).toLocaleDateString()}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        Best streak: {participant.best_streak} days
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="flex items-center gap-1 justify-end">
                      <Flame className="w-5 h-5 text-orange-500" />
                      <span className="text-2xl font-bold">
                        {participant.current_streak}
                      </span>
                    </div>
                    <p className="text-sm text-muted-foreground">current streak</p>
                    {participant.last_completed && (
                      <p className="text-xs text-muted-foreground">
                        Last: {new Date(participant.last_completed).toLocaleDateString()}
                      </p>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>

          {competition.participants.length === 0 && (
            <div className="text-center py-8">
              <Users className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">No Participants Yet</h3>
              <p className="text-muted-foreground">
                This competition is waiting for participants to join.
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};