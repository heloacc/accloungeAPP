import React, { useState, useEffect } from 'react';
import { useAppContext } from '@/contexts/OptimizedAppContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Bell, X, Check, AlertCircle, Info, CheckCircle, Eye, XCircle, Clock } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { toast } from '@/components/ui/use-toast';

interface Notification {
  type: string;
  title: string;
  message: string;
  created_at: string;
  read: boolean; // Fixed column name to match database
}

interface UserNotificationsProps {
  userId: string;
}

const UserNotifications: React.FC<UserNotificationsProps> = ({ userId }) => {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (userId) {
      fetchNotifications();
    }
  }, [userId]);

  const fetchNotifications = async () => {
    try {
      setLoading(true);
      setError(null);
      
      const { data, error } = await supabase
        .from('notifications')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false })
        .limit(20);

      if (error) {
        console.error('Error fetching notifications:', error);
        setError('Failed to load notifications');
        return;
      }

      setNotifications(data || []);
    } catch (error) {
      console.error('Error in fetchNotifications:', error);
      setError('Failed to load notifications');
    } finally {
      setLoading(false);
    }
  };

  const markAsRead = async (notificationId: string) => {
    try {
      const { error } = await supabase
        .from('notifications')
        .update({ read: true })
        .eq('id', notificationId);

      if (error) {
        console.error('Error marking notification as read:', error);
        return;
      }

      setNotifications(prev => 
        prev.map(n => n.id === notificationId ? { ...n, read: true } : n)
      );
    } catch (error) {
      console.error('Error in markAsRead:', error);
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'join_request_approved': return <CheckCircle className="h-4 w-4 text-green-600" />;
      case 'join_request_rejected': return <XCircle className="h-4 w-4 text-red-600" />;
      case 'accountability_checkin': return <Clock className="h-4 w-4 text-orange-600" />;
      default: return <Bell className="h-4 w-4 text-blue-600" />;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'join_request_approved': return 'bg-green-50 border-green-200';
      case 'join_request_rejected': return 'bg-red-50 border-red-200';
      case 'accountability_checkin': return 'bg-orange-50 border-orange-200';
      default: return 'bg-blue-50 border-blue-200';
    }
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="p-6">
          <p className="text-center">Loading notifications...</p>
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card>
        <CardContent className="p-6 text-center">
          <Bell className="h-12 w-12 mx-auto mb-4 text-red-500" />
          <p className="text-red-600 mb-2">{error}</p>
          <Button onClick={fetchNotifications} size="sm" variant="outline">
            Try Again
          </Button>
        </CardContent>
      </Card>
    );
  }

  if (notifications.length === 0) {
    return (
      <Card>
        <CardContent className="p-6 text-center">
          <Bell className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
          <p className="text-muted-foreground">No notifications yet.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">Your Notifications</h3>
        <Badge variant="outline">
          {notifications.filter(n => !n.read).length} unread
        </Badge>
      </div>
      
      {notifications.map((notification) => (
        <Card 
          key={notification.id} 
          className={`${getTypeColor(notification.type)} ${!notification.read ? 'ring-2 ring-blue-200' : ''}`}
        >
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-base flex items-center gap-2">
                {getTypeIcon(notification.type)}
                {notification.title}
              </CardTitle>
              <div className="flex items-center gap-2">
                {!notification.read && (
                  <Badge variant="secondary" className="text-xs">New</Badge>
                )}
                <span className="text-xs text-muted-foreground">
                  {new Date(notification.created_at).toLocaleDateString()}
                </span>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-sm mb-3">{notification.message}</p>
            {!notification.read && (
              <Button
                size="sm"
                variant="outline"
                onClick={() => markAsRead(notification.id)}
                className="flex items-center gap-1"
              >
                <Eye className="h-3 w-3" />
                Mark as Read
              </Button>
            )}
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

export default UserNotifications;