import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calendar, CheckCircle, Plus, Target, Flame, TrendingUp, Trash2, X } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabase';
import AsyncErrorBoundary from '@/components/AsyncErrorBoundary';
import AnimatedHabitCard from './AnimatedHabitCard';

interface Habit {
  id: string;
  title: string;
  description?: string;
  frequency: string;
  target_count: number;
  current_streak: number;
  longest_streak: number;
  created_at: string;
  updated_at: string;
}

const UnifiedHabitTracker = () => {
  const [habits, setHabits] = useState<Habit[]>([]);
  const [loading, setLoading] = useState(true);
  const [completionStatus, setCompletionStatus] = useState<Record<string, boolean>>({});
  const [newHabit, setNewHabit] = useState({
    title: '',
    description: '',
    frequency: 'daily',
    target_count: 21
  });
  const [isAddingHabit, setIsAddingHabit] = useState(false);

  const commitmentOptions = [
    { value: 7, label: '7 days - Quick Start' },
    { value: 21, label: '21 days - Habit Formation' },
    { value: 30, label: '30 days - Monthly Challenge' },
    { value: 45, label: '45 days - Extended Practice' },
    { value: 90, label: '90 days - Transformation' },
    { value: 180, label: '180 days - Lifestyle Change' }
  ];

  useEffect(() => {
    fetchHabits();
    loadTodayCompletions();
  }, []);

  const loadTodayCompletions = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const today = new Date().toISOString().split('T')[0];
      
      const { data: logs } = await supabase
        .from('habit_logs')
        .select('habit_id, status')
        .eq('user_id', user.id)
        .eq('date', today)
        .eq('status', 'done');

      if (logs) {
        const completions: Record<string, boolean> = {};
        logs.forEach(log => {
          completions[log.habit_id] = true;
        });
        setCompletionStatus(completions);
      }
    } catch (error) {
      console.error('Error loading today completions:', error);
    }
  };

  const fetchHabits = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('unified-habits-goals');
      
      if (error) {
        console.error('Error fetching habits:', error);
        throw error;
      }
      
      console.log('Habits data received:', data);
      setHabits(data?.habits || []);
    } catch (error) {
      console.error('Error fetching habits:', error);
      toast({
        title: "Error",
        description: "Failed to load habits. Please refresh the page.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const addHabit = async () => {
    if (!newHabit.title.trim()) {
      toast({
        title: "Error",
        description: "Please enter a habit title",
        variant: "destructive"
      });
      return;
    }

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        toast({
          title: "Error",
          description: "You must be logged in to create habits",
          variant: "destructive"
        });
        return;
      }

      const { error } = await supabase
        .from('habits')
        .insert([{
          user_id: user.id,
          title: newHabit.title,
          description: newHabit.description,
          frequency: newHabit.frequency,
          target_count: newHabit.target_count,
          current_streak: 0
        }]);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Habit created successfully!",
      });

      setNewHabit({ title: '', description: '', frequency: 'daily', target_count: 21 });
      setIsAddingHabit(false);
      fetchHabits();
    } catch (error) {
      console.error('Error adding habit:', error);
      toast({
        title: "Error",
        description: "Failed to create habit. Please try again.",
        variant: "destructive"
      });
    }
  };

  const toggleHabit = async (habitId: string) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        toast({
          title: "Error",
          description: "You must be logged in to complete habits",
          variant: "destructive"
        });
        return;
      }

      const today = new Date().toISOString().split('T')[0];
      
      // Check if already completed today
      const { data: existingLog } = await supabase
        .from('habit_logs')
        .select('status')
        .eq('habit_id', habitId)
        .eq('user_id', user.id)
        .eq('date', today)
        .single();

      const newStatus = existingLog?.status === 'done' ? 'missed' : 'done';
      
      // Update completion status immediately for UI responsiveness
      setCompletionStatus(prev => ({
        ...prev,
        [habitId]: newStatus === 'done'
      }));
      
      // Upsert habit log
      const { error: logError } = await supabase
        .from('habit_logs')
        .upsert({
          habit_id: habitId,
          user_id: user.id,
          date: today,
          status: newStatus
        }, {
          onConflict: 'habit_id,user_id,date'
        });

      if (logError) throw logError;

      // Recalculate streak and stats using the same logic as useHabitCompletion
      await recalculateHabitStats(habitId, user.id);

      toast({
        title: "Success",
        description: newStatus === 'done' 
          ? "Habit completed for today!"
          : "Habit unmarked for today",
      });

      // Refresh habits to show updated streak
      fetchHabits();
    } catch (error) {
      console.error('Error updating habit:', error);
      // Revert completion status on error
      setCompletionStatus(prev => ({
        ...prev,
        [habitId]: !prev[habitId]
      }));
      toast({
        title: "Error",
        description: "Failed to update habit. Please try again.",
        variant: "destructive"
      });
    }
  };

  const recalculateHabitStats = async (habitId: string, userId: string) => {
    try {
      // Get all habit logs for this habit, ordered by date
      const { data: logs } = await supabase
        .from('habit_logs')
        .select('date, status')
        .eq('habit_id', habitId)
        .eq('user_id', userId)
        .order('date', { ascending: false }); // Order by date descending (newest first)

      if (!logs) return;

      // Calculate current streak (consecutive days from today backwards)
      const today = new Date().toISOString().split('T')[0];
      let currentStreak = 0;
      
      // Create a map for faster lookup
      const logMap = new Map(logs.map(log => [log.date, log.status]));
      
      // Start checking from today and go backwards
      // eslint-disable-next-line prefer-const
      let checkDate = new Date(today);
      
      while (true) {
        const dateStr = checkDate.toISOString().split('T')[0];
        const status = logMap.get(dateStr);
        
        if (status === 'done') {
          // Completed day - add to streak
          currentStreak++;
        } else if (status === 'missed') {
          // Explicitly missed day - break streak
          break;
        } else {
          // No log for this day
          if (dateStr === today) {
            // If today has no log, it means habit wasn't completed yet
            // Don't break streak, just move to previous day
          } else {
            // Gap in past days breaks the streak
            break;
          }
        }
        
        // Move to previous day
        checkDate.setDate(checkDate.getDate() - 1);
        
        // Prevent infinite loop (max 365 days back)
        if (currentStreak > 365 || checkDate < new Date('2020-01-01')) break;
      }

      // Calculate longest streak by going through all logs chronologically
      let longestStreak = 0;
      let tempStreak = 0;
      
      // Sort logs chronologically for longest streak calculation
      const chronologicalLogs = [...logs].reverse();
      
      for (const log of chronologicalLogs) {
        if (log.status === 'done') {
          tempStreak++;
          longestStreak = Math.max(longestStreak, tempStreak);
        } else {
          tempStreak = 0;
        }
      }

      // Calculate total completions
      const totalCompletions = logs.filter(l => l.status === 'done').length;

      // Update habit record
      await supabase
        .from('habits')
        .update({
          current_streak: currentStreak,
          longest_streak: Math.max(longestStreak, currentStreak),
          total_completions: totalCompletions
        })
        .eq('id', habitId);

    } catch (error) {
      console.error('Error recalculating habit stats:', error);
    }
  };

  const deleteHabit = async (habitId: string) => {
    try {
      const { error } = await supabase
        .from('habits')
        .delete()
        .eq('id', habitId);

      if (error) throw error;
      
      toast({
        title: "Success",
        description: "Habit deleted successfully!",
      });
      
      fetchHabits();
    } catch (error) {
      console.error('Error deleting habit:', error);
      toast({
        title: "Error",
        description: "Failed to delete habit. Please try again.",
        variant: "destructive"
      });
    }
  };

  const isCompletedToday = (habitId: string) => {
    return completionStatus[habitId] || false;
  };

  if (loading) {
    return <div className="p-6">Loading habits...</div>;
  }

  return (
    <AsyncErrorBoundary componentName="Unified Habit Tracker">
      <div className="space-y-6 p-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h2 className="text-2xl font-bold">Habit Tracker</h2>
            <p className="text-muted-foreground">Build lasting habits with proper streak tracking</p>
          </div>
          <Button 
            onClick={() => setIsAddingHabit(true)}
            size="lg" 
            className="bg-black text-white hover:bg-gray-800 font-semibold px-6 py-3"
          >
            <Plus className="h-5 w-5 mr-2" />
            Add New Habit
          </Button>
        </div>

        {/* Add Habit Dialog */}
        {isAddingHabit && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg p-6 w-full max-w-md mx-4">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">Add New Habit</h3>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setIsAddingHabit(false)}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Habit Title</label>
                  <Input
                    value={newHabit.title}
                    onChange={(e) => setNewHabit({ ...newHabit, title: e.target.value })}
                    placeholder="e.g., Drink 8 glasses of water"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-2">Description (Optional)</label>
                  <Textarea
                    value={newHabit.description}
                    onChange={(e) => setNewHabit({ ...newHabit, description: e.target.value })}
                    placeholder="Why is this habit important to you?"
                    rows={3}
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-2">Frequency</label>
                  <Select
                    value={newHabit.frequency}
                    onValueChange={(value) => setNewHabit({ ...newHabit, frequency: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="daily">Daily</SelectItem>
                      <SelectItem value="weekly">Weekly</SelectItem>
                      <SelectItem value="weekdays">Weekdays Only</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-2">Commitment Duration</label>
                  <Select
                    value={newHabit.target_count.toString()}
                    onValueChange={(value) => setNewHabit({ ...newHabit, target_count: parseInt(value) })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {commitmentOptions.map((option) => (
                        <SelectItem key={option.value} value={option.value.toString()}>
                          {option.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="flex gap-3 mt-6">
                <Button
                  variant="outline"
                  onClick={() => setIsAddingHabit(false)}
                  className="flex-1"
                >
                  Cancel
                </Button>
                <Button
                  onClick={addHabit}
                  className="flex-1 bg-black text-white hover:bg-gray-800"
                  disabled={!newHabit.title.trim()}
                >
                  Add Habit
                </Button>
              </div>
            </div>
          </div>
        )}

        {habits.length === 0 ? (
          <div className="flex items-center justify-center py-12">
            <div className="text-center">
              <Target className="h-16 w-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">No habits yet</h3>
              <p className="text-gray-500 mb-6 max-w-sm">
                Start building lasting habits with proper streak tracking!
              </p>
              <Button onClick={() => setIsAddingHabit(true)} className="bg-black text-white hover:bg-gray-800">
                <Plus className="h-4 w-4 mr-2" />
                Add Your First Habit
              </Button>
            </div>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 gap-4">
            {habits.map((habit) => (
              <AnimatedHabitCard
                key={habit.id}
                habit={habit}
                onToggle={toggleHabit}
                onDelete={deleteHabit}
                isCompletedToday={isCompletedToday(habit.id)}
              />
            ))}
          </div>
        )}
      </div>
    </AsyncErrorBoundary>
  );
};

export default UnifiedHabitTracker;