import React, { useState } from 'react';
import GroupCreationForm from './GroupCreationForm';
import { useAppContext } from '@/contexts/OptimizedAppContext';

const GroupCreationWrapper = () => {
  const { setActiveTab } = useAppContext();

  const handleGroupCreated = () => {
    // Navigate back to groups tab after successful creation
    setActiveTab('groups');
  };

  const handleCancel = () => {
    // Navigate back to groups tab on cancel
    setActiveTab('groups');
  };

  return (
    <div className="p-6">
      <GroupCreationForm 
        onGroupCreated={handleGroupCreated}
        onCancel={handleCancel}
      />
    </div>
  );
};

export default GroupCreationWrapper;