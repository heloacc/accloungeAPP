import { useEffect } from 'react';
import { useAppContext } from '@/contexts/OptimizedAppContext';
import { supabase } from '@/lib/supabase';

const UserProfileFixer = () => {
  const { currentUser, setCurrentUser } = useAppContext();

  useEffect(() => {
    const fixUserProfile = async () => {
      if (!currentUser?.id) return;

      try {
        console.log('Checking user profile for:', currentUser.id);
        
        // Get fresh profile data
        const { data: profile, error } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', currentUser.id)
          .single();

        if (error) {
          console.error('Error fetching profile:', error);
          return;
        }

        if (profile) {
          console.log('Profile data:', profile);
          
          // Update user with correct name from profile
          const updatedUser = {
            ...currentUser,
            name: profile.name || currentUser.email?.split('@')[0] || 'User',
            isAdmin: profile.is_admin || false,
          };
          
          console.log('Updating user with:', updatedUser);
          setCurrentUser(updatedUser);
        }
      } catch (error) {
        console.error('Error fixing user profile:', error);
      }
    };

    fixUserProfile();
  }, [currentUser?.id, setCurrentUser]);

  return null; // This component doesn't render anything
};

export default UserProfileFixer;