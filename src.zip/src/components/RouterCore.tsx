import React from 'react';
import { PROTECTED_ROUTES, ensureValidRoute } from '@/utils/navigationPersistence';
import Dashboard from './Dashboard';
import CommunityFeed from './CommunityFeed';
import ActiveCircle from './ActiveCircle';
import AccountabilityGroupsSimplified from './AccountabilityGroupsSimplified';
import WinsWall from './WinsWall';
import Gather from './Gather';
import UserProfile from './UserProfile';


interface RouterCoreProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  currentUser: any;
}

/**
 * RouterCore - Core routing logic isolated and protected
 * This ensures critical routes always work regardless of other errors
 */
const RouterCore: React.FC<RouterCoreProps> = ({ activeTab, setActiveTab, currentUser }) => {
  // Ensure we have a valid route
  const validatedRoute = ensureValidRoute(activeTab);
  
  // Protected routing - these routes must always work
  const protectedRoutes = {
    'dashboard': () => <Dashboard onNavigate={setActiveTab} />,
    'community': () => <CommunityFeed />,
    'active-circle': () => <ActiveCircle />,
    'groups': () => <AccountabilityGroupsSimplified onNavigate={setActiveTab} />,
    'wins-wall': () => <WinsWall />,
    'gather': () => <Gather />,
    'profile': () => <UserProfile />,
  };

  // Check if this is a protected route using validated route
  if (protectedRoutes[validatedRoute as keyof typeof protectedRoutes]) {
    try {
      console.log('RouterCore: Loading protected route:', activeTab);
      return protectedRoutes[validatedRoute as keyof typeof protectedRoutes]();
    } catch (error) {
      console.error('RouterCore: Error in protected route:', activeTab, error);
      return <Dashboard onNavigate={setActiveTab} />;
    }
  }

  // Return null for non-protected routes (handled by parent)
  return null;
};

export default RouterCore;