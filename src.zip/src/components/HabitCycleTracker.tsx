import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { RefreshCw, Calendar, Target, TrendingUp, Settings } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';

interface Habit {
  id: string;
  title: string;
  target_count: number;
  current_streak: number;
  completed_dates: string[];
  created_at: string;
}

interface HabitCycleTrackerProps {
  habits: Habit[];
}

const HabitCycleTracker: React.FC<HabitCycleTrackerProps> = ({ habits }) => {
  const [selectedCycleDuration, setSelectedCycleDuration] = useState<number>(21);

  const cycleDurations = [
    { value: 21, label: '21 Day Cycle', description: 'Habit Formation' },
    { value: 30, label: '30 Day Cycle', description: 'Monthly Challenge' },
    { value: 90, label: '90 Day Cycle', description: 'Lifestyle Change' }
  ];

  const calculateCycleProgress = (habit: Habit, cycleDuration: number) => {
    const startDate = new Date(habit.created_at);
    const today = new Date();
    const daysSinceStart = Math.floor((today.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
    
    const currentCycle = Math.floor(daysSinceStart / cycleDuration) + 1;
    const daysInCurrentCycle = daysSinceStart % cycleDuration;
    const progress = (daysInCurrentCycle / cycleDuration) * 100;
    const daysRemaining = cycleDuration - daysInCurrentCycle;
    const isCompleted = daysInCurrentCycle >= cycleDuration;
    
    return { 
      currentCycle, 
      daysInCurrentCycle, 
      progress: Math.min(progress, 100), 
      daysRemaining: Math.max(daysRemaining, 0), 
      isCompleted 
    };
  };

  const getCycleCompletionRate = (habit: Habit, cycleDuration: number) => {
    const startDate = new Date(habit.created_at);
    const today = new Date();
    const daysSinceStart = Math.floor((today.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
    const daysInCurrentCycle = daysSinceStart % cycleDuration;
    const completionsInCycle = habit.completed_dates.filter(date => {
      const completionDate = new Date(date);
      const daysSinceCompletion = Math.floor((today.getTime() - completionDate.getTime()) / (1000 * 60 * 60 * 24));
      return daysSinceCompletion <= daysInCurrentCycle;
    }).length;
    
    return daysInCurrentCycle > 0 ? Math.round((completionsInCycle / (daysInCurrentCycle + 1)) * 100) : 0;
  };

  if (habits.length === 0) {
    return (
      <Card className="border-dashed">
        <CardContent className="text-center py-8">
          <RefreshCw className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-semibold mb-2">No Habits to Track</h3>
          <p className="text-muted-foreground">
            Create some habits first to see their cycle progress.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <RefreshCw className="h-5 w-5 text-blue-500" />
          <h3 className="text-lg font-semibold">Habit Cycles</h3>
        </div>
        <div className="flex gap-2">
          {cycleDurations.map((cycle) => (
            <Button
              key={cycle.value}
              variant={selectedCycleDuration === cycle.value ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedCycleDuration(cycle.value)}
            >
              {cycle.value} Days
            </Button>
          ))}
        </div>
      </div>

      <div className="grid gap-4">
        {habits.map((habit) => {
          const cycleData = calculateCycleProgress(habit, selectedCycleDuration);
          const completionRate = getCycleCompletionRate(habit, selectedCycleDuration);
          
          return (
            <Card key={habit.id} className="border-l-4 border-l-blue-500">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg">{habit.title}</CardTitle>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline">
                      Cycle {cycleData.currentCycle}
                    </Badge>
                    {completionRate >= 80 && (
                      <Badge variant="secondary" className="bg-green-100 text-green-800">
                        On Track
                      </Badge>
                    )}
                  </div>
                </div>
              </CardHeader>
              
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Cycle Progress ({selectedCycleDuration} days)</span>
                    <span>{Math.round(cycleData.progress)}%</span>
                  </div>
                  <Progress value={cycleData.progress} className="h-2" />
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>Day {cycleData.daysInCurrentCycle + 1} of {selectedCycleDuration}</span>
                    <span>{cycleData.daysRemaining} days remaining</span>
                  </div>
                </div>
                
                <div className="grid grid-cols-3 gap-4 text-sm">
                  <div className="flex items-center gap-2">
                    <TrendingUp className="h-4 w-4 text-blue-500" />
                    <div>
                      <div className="font-medium">{habit.current_streak}</div>
                      <div className="text-xs text-muted-foreground">Current Streak</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Target className="h-4 w-4 text-green-500" />
                    <div>
                      <div className="font-medium">{completionRate}%</div>
                      <div className="text-xs text-muted-foreground">Completion Rate</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-purple-500" />
                    <div>
                      <div className="font-medium">{habit.completed_dates?.length || 0}</div>
                      <div className="text-xs text-muted-foreground">Total Days</div>
                    </div>
                  </div>
                </div>

                {cycleData.progress >= 100 && (
                  <div className="bg-green-50 p-3 rounded-lg border border-green-200">
                    <div className="flex items-center gap-2 text-green-800">
                      <RefreshCw className="h-4 w-4" />
                      <span className="font-medium">Cycle Complete!</span>
                    </div>
                    <p className="text-sm text-green-600 mt-1">
                      Congratulations! You've completed a {selectedCycleDuration}-day cycle. 
                      Keep going to build lasting habits!
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
};

export default HabitCycleTracker;