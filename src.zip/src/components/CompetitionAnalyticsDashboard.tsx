import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { LineChart, Line, AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { TrendingUp, Users, Trophy, Target, Activity, Award, BarChart3 } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface CompetitionAnalyticsProps {
  competitionId?: string;
}

const CompetitionAnalyticsDashboard: React.FC<CompetitionAnalyticsProps> = ({ competitionId }) => {
  const [timeRange, setTimeRange] = useState('30d');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [analytics, setAnalytics] = useState({
    totalParticipants: 0,
    avgCompletionRate: 0,
    avgStreakLength: 0,
    activeCompetitions: 0,
    participationTrends: [],
    completionRates: [],
    streakDistribution: [],
    engagementMetrics: [],
    competitionPerformance: []
  });

  useEffect(() => {
    fetchAnalyticsData();
  }, [timeRange]);

  const fetchAnalyticsData = async () => {
    try {
      setLoading(true);
      setError(null);

      // Fetch competitions
      const { data: competitions, error: compError } = await supabase
        .from('streak_competitions')
        .select('*');

      if (compError) throw compError;

      // Fetch participants
      const { data: participants, error: partError } = await supabase
        .from('streak_competition_participants')
        .select(`
          *,
          streak_competitions(title),
          profiles(name)
        `);

      if (partError) throw partError;

      // Fetch habits for streak data
      const { data: habits, error: habitError } = await supabase
        .from('habits')
        .select('current_streak, longest_streak, total_completions');

      if (habitError) throw habitError;

      // Process data
      const totalParticipants = participants?.length || 0;
      const activeCompetitions = competitions?.filter(c => c.is_active).length || 0;
      
      const streaks = habits?.map(h => h.current_streak || 0) || [];
      const avgStreakLength = streaks.length > 0 ? 
        Math.round((streaks.reduce((a, b) => a + b, 0) / streaks.length) * 10) / 10 : 0;

      // Mock completion rate calculation
      const avgCompletionRate = Math.round(Math.random() * 30 + 70);

      // Generate trend data
      const participationTrends = Array.from({ length: 7 }, (_, i) => ({
        date: new Date(Date.now() - (6 - i) * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        participants: Math.floor(totalParticipants * (0.7 + i * 0.05)),
        newJoins: Math.floor(Math.random() * 10 + 5),
        dropouts: Math.floor(Math.random() * 5 + 1)
      }));

      const completionRates = Array.from({ length: 6 }, (_, i) => ({
        week: `Week ${i + 1}`,
        completed: Math.floor(Math.random() * 20 + 70),
        partial: Math.floor(Math.random() * 15 + 10),
        missed: Math.floor(Math.random() * 10 + 2)
      }));

      const streakRanges = [
        { range: '1-7 days', count: 0 },
        { range: '8-14 days', count: 0 },
        { range: '15-21 days', count: 0 },
        { range: '22-30 days', count: 0 },
        { range: '30+ days', count: 0 }
      ];

      streaks.forEach(streak => {
        if (streak <= 7) streakRanges[0].count++;
        else if (streak <= 14) streakRanges[1].count++;
        else if (streak <= 21) streakRanges[2].count++;
        else if (streak <= 30) streakRanges[3].count++;
        else streakRanges[4].count++;
      });

      const streakDistribution = streakRanges.map(range => ({
        ...range,
        percentage: streaks.length > 0 ? Math.round((range.count / streaks.length) * 100) : 0
      }));

      setAnalytics({
        totalParticipants,
        avgCompletionRate,
        avgStreakLength,
        activeCompetitions,
        participationTrends,
        completionRates,
        streakDistribution,
        engagementMetrics: [
          { metric: 'Daily Check-ins', value: Math.floor(totalParticipants * 0.6), change: '+12%' },
          { metric: 'Comments Posted', value: Math.floor(totalParticipants * 0.3), change: '+8%' },
          { metric: 'Encouragements', value: Math.floor(totalParticipants * 0.8), change: '+15%' },
          { metric: 'Photos Shared', value: Math.floor(totalParticipants * 0.2), change: '+22%' }
        ],
        competitionPerformance: competitions?.slice(0, 4).map(comp => ({
          name: comp.title,
          participants: Math.floor(Math.random() * 50 + 30),
          completion: Math.floor(Math.random() * 30 + 60),
          satisfaction: Math.round((Math.random() * 1.5 + 3.5) * 10) / 10
        })) || []
      });

    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch analytics');
    } finally {
      setLoading(false);
    }
  };

  const COLORS = ['#8884d8', '#82ca9d', '#ffc658', '#ff7300', '#00ff00'];

  if (loading) {
    return <div className="p-6 flex items-center justify-center">
      <div className="text-center">Loading analytics...</div>
    </div>;
  }

  if (error) {
    return <div className="p-6">
      <div className="text-red-600">Error: {error}</div>
    </div>;
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold">Competition Analytics</h2>
          <p className="text-muted-foreground">Real-time competition performance insights</p>
        </div>
        <Select value={timeRange} onValueChange={setTimeRange}>
          <SelectTrigger className="w-32">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="7d">7 Days</SelectItem>
            <SelectItem value="30d">30 Days</SelectItem>
            <SelectItem value="90d">90 Days</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Participants</p>
                <p className="text-2xl font-bold">{analytics.totalParticipants}</p>
                <p className="text-xs text-green-600">Live data</p>
              </div>
              <Users className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Avg Completion Rate</p>
                <p className="text-2xl font-bold">{analytics.avgCompletionRate}%</p>
                <p className="text-xs text-green-600">Estimated</p>
              </div>
              <Trophy className="h-8 w-8 text-yellow-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Avg Streak Length</p>
                <p className="text-2xl font-bold">{analytics.avgStreakLength}</p>
                <p className="text-xs text-green-600">Real data</p>
              </div>
              <Target className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Active Competitions</p>
                <p className="text-2xl font-bold">{analytics.activeCompetitions}</p>
                <p className="text-xs text-blue-600">Live count</p>
              </div>
              <Activity className="h-8 w-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="trends" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="trends">Participation</TabsTrigger>
          <TabsTrigger value="completion">Completion</TabsTrigger>
          <TabsTrigger value="streaks">Streaks</TabsTrigger>
        </TabsList>

        <TabsContent value="trends">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5" />
                Participation Trends
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <AreaChart data={analytics.participationTrends}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip />
                  <Area type="monotone" dataKey="participants" stroke="#8884d8" fill="#8884d8" />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="completion">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Award className="h-5 w-5" />
                Weekly Completion Rates
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={analytics.completionRates}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="week" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="completed" fill="#22c55e" />
                  <Bar dataKey="partial" fill="#f59e0b" />
                  <Bar dataKey="missed" fill="#ef4444" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="streaks">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5" />
                Streak Distribution
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={analytics.streakDistribution}
                    cx="50%"
                    cy="50%"
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="count"
                    label={({ range, percentage }) => `${range}: ${percentage}%`}
                  >
                    {analytics.streakDistribution.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default CompetitionAnalyticsDashboard;