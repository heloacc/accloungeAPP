import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { CheckCircle, X, Send } from 'lucide-react';

interface JoinRequest {
  id: string;
  user_id: string;
  questionnaire_response: string;
  status: string;
  created_at: string;
  profiles: {
    full_name: string;
    email: string;
  };
}

interface GroupMember {
  id: string;
  user_id: string;
  profiles: {
    full_name: string;
    email: string;
  };
}

interface Group {
  id: string;
  name: string;
  description?: string;
}

const ActiveCircleNotifications = () => {
  const [joinRequests, setJoinRequests] = useState<JoinRequest[]>([]);
  const [members, setMembers] = useState<GroupMember[]>([]);
  const [groups, setGroups] = useState<Group[]>([]);
  const [selectedGroupId, setSelectedGroupId] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [processingRequest, setProcessingRequest] = useState<string | null>(null);
  const [sendingNotification, setSendingNotification] = useState(false);
  
  // Notification form state
  const [notificationTitle, setNotificationTitle] = useState('');
  const [notificationMessage, setNotificationMessage] = useState('');
  const [notificationType, setNotificationType] = useState('announcement');

  useEffect(() => {
    fetchGroups();
  }, []);

  useEffect(() => {
    if (selectedGroupId) {
      fetchJoinRequests();
      fetchMembers(selectedGroupId);
    }
  }, [selectedGroupId]);

  const fetchGroups = async () => {
    try {
      setLoading(true);
      setError(null);
      
      const { data, error } = await supabase
        .from('acircle_groups')
        .select('id, name, description')
        .order('name');

      if (error) {
        console.error('Error fetching groups:', error);
        setError(`Failed to load groups: ${error.message}`);
        setGroups([]);
      } else {
        setGroups(data || []);
        if (data && data.length > 0 && !selectedGroupId) {
          setSelectedGroupId(data[0].id);
        }
      }
    } catch (error) {
      console.error('Error fetching groups:', error);
      setError('Failed to load groups. Please refresh the page.');
      setGroups([]);
    } finally {
      setLoading(false);
    }
  };

  const fetchMembers = async (groupId: string) => {
    try {
      console.log('🔍 Fetching members for group:', groupId);
      
      // First get member user_ids
      const { data: memberData, error: memberError } = await supabase
        .from('acircle_members')
        .select('user_id')
        .eq('group_id', groupId);

      if (memberError) {
        console.error('❌ Error fetching member IDs:', memberError);
        return;
      }

      console.log('📋 Raw member data:', memberData);

      if (!memberData || memberData.length === 0) {
        console.log('⚠️ No members found for group');
        setMembers([]);
        return;
      }

      // Get user IDs
      const userIds = memberData.map(m => m.user_id);
      console.log('👥 User IDs:', userIds);

      // Then get profiles for those users
      const { data: profiles, error: profileError } = await supabase
        .from('profiles')
        .select('id, full_name, email')
        .in('id', userIds);

      if (profileError) {
        console.error('❌ Error fetching profiles:', profileError);
        setMembers([]);
        return;
      }

      // Combine member data with profiles
      const membersWithProfiles = memberData.map(member => {
        const profile = profiles?.find(p => p.id === member.user_id);
        return {
          id: member.user_id, // Using user_id as id for simplicity
          user_id: member.user_id,
          profiles: {
            full_name: profile?.full_name || 'Unknown User',
            email: profile?.email || 'No email'
          }
        };
      }).filter(member => member.profiles.full_name !== 'Unknown User');

      console.log('✅ Final member count:', membersWithProfiles.length);
      setMembers(membersWithProfiles);
    } catch (error) {
      console.error('❌ Error in fetchMembers:', error);
      setMembers([]);
    }
  };

  const fetchJoinRequests = async () => {
    try {
      if (!selectedGroupId) {
        setJoinRequests([]);
        return;
      }
      
      const { data, error } = await supabase
        .from('acircle_join_requests')
        .select(`
          *,
          profiles!acircle_join_requests_user_id_fkey(full_name, email)
        `)
        .eq('group_id', selectedGroupId)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching join requests:', error);
        setJoinRequests([]);
      } else {
        setJoinRequests(data || []);
      }
    } catch (error) {
      console.error('Error fetching join requests:', error);
      setJoinRequests([]);
    }
  };

  const handleRequest = async (requestId: string, action: 'approved' | 'rejected') => {
    setProcessingRequest(requestId);
    
    try {
      const request = joinRequests.find(r => r.id === requestId);
      if (!request) return;

      const { error: updateError } = await supabase
        .from('acircle_join_requests')
        .update({
          status: action,
          reviewed_at: new Date().toISOString(),
          reviewed_by: (await supabase.auth.getUser()).data.user?.id
        })
        .eq('id', requestId);

      if (updateError) throw updateError;

      if (action === 'approved') {
        const { error: memberError } = await supabase
          .from('acircle_members')
          .insert([{
            group_id: selectedGroupId,
            user_id: request.user_id
          }]);

        if (memberError) throw memberError;
      }

      fetchJoinRequests();
      fetchMembers(selectedGroupId);
    } catch (error) {
      console.error('Error processing request:', error);
    } finally {
      setProcessingRequest(null);
    }
  };

  const sendNotificationToMembers = async () => {
    if (!notificationTitle.trim() || !notificationMessage.trim() || !selectedGroupId) {
      alert('Please fill in all fields and select a group');
      return;
    }

    if (members.length === 0) {
      alert('No members found in the selected group');
      return;
    }

    setSendingNotification(true);
    
    try {
      console.log(`Sending notification to ${members.length} members in group ${selectedGroupId}`);
      
      const notifications = members.map(member => ({
        user_id: member.user_id,
        title: notificationTitle.trim(),
        message: notificationMessage.trim(),
        type: 'group_notification',
        group_id: selectedGroupId,
        read: false,
        created_at: new Date().toISOString()
      }));

      const { data, error } = await supabase
        .from('notifications')
        .insert(notifications)
        .select();

      if (error) throw error;

      setNotificationTitle('');
      setNotificationMessage('');
      const selectedGroup = groups.find(g => g.id === selectedGroupId);
      alert(`✅ Notification sent successfully to ${members.length} members in ${selectedGroup?.name || 'selected group'}!`);
    } catch (error) {
      console.error('Error sending notification:', error);
      alert(`❌ Failed to send notification: ${error.message || 'Unknown error'}. Please try again.`);
    } finally {
      setSendingNotification(false);
    }
  };

  if (loading) {
    return (
      <div className="p-6">
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
              <p>Loading groups...</p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6">
        <Card>
          <CardContent className="pt-6">
            <div className="text-center text-red-600">
              <p className="mb-4">{error}</p>
              <Button onClick={fetchGroups} variant="outline">
                Retry
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (groups.length === 0) {
    return (
      <div className="p-6">
        <Card>
          <CardContent className="pt-6">
            <div className="text-center text-muted-foreground">
              <p>No groups found. Create a group first to manage notifications.</p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }
  const pendingRequests = joinRequests.filter(r => r.status === 'pending');
  const selectedGroup = groups.find(g => g.id === selectedGroupId);

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6">
      <div>
        <h2 className="text-2xl font-bold mb-2">Group Management</h2>
        <p className="text-muted-foreground">Manage join requests and send notifications</p>
      </div>
      <div className="space-y-2">
        <label className="text-sm font-medium">Select Group</label>
        <Select value={selectedGroupId} onValueChange={setSelectedGroupId}>
          <SelectTrigger>
            <SelectValue placeholder="Choose a group" />
          </SelectTrigger>
          <SelectContent>
            {groups.map((group) => (
              <SelectItem key={group.id} value={group.id}>
                {group.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <Tabs defaultValue="notifications" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="requests">Join Requests</TabsTrigger>
          <TabsTrigger value="notifications">Send Notifications</TabsTrigger>
        </TabsList>

        <TabsContent value="requests">
          <Card>
            <CardHeader>
              <CardTitle>Pending Requests ({pendingRequests.length})</CardTitle>
            </CardHeader>
            <CardContent>
              {pendingRequests.length === 0 ? (
                <p className="text-center py-4">No pending requests</p>
              ) : (
                <div className="space-y-4">
                  {pendingRequests.map((request) => (
                    <div key={request.id} className="border rounded-lg p-4 space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="font-medium">{request.profiles?.full_name || 'Unknown User'}</span>
                        <Badge variant="secondary">
                          {new Date(request.created_at).toLocaleDateString()}
                        </Badge>
                      </div>
                      <p className="text-sm bg-gray-50 p-3 rounded">{request.questionnaire_response}</p>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          onClick={() => handleRequest(request.id, 'approved')}
                          disabled={processingRequest === request.id}
                          className="bg-green-600 hover:bg-green-700"
                        >
                          <CheckCircle className="h-4 w-4 mr-1" />
                          Approve
                        </Button>
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={() => handleRequest(request.id, 'rejected')}
                          disabled={processingRequest === request.id}
                        >
                          <X className="h-4 w-4 mr-1" />
                          Reject
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="notifications">
          <Card>
            <CardHeader>
              <CardTitle>Send Notification</CardTitle>
              <p className="text-sm text-muted-foreground">
                {members.length} members in {selectedGroup?.name || 'selected group'}
              </p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Type</label>
                <Select value={notificationType} onValueChange={setNotificationType}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="announcement">Announcement</SelectItem>
                    <SelectItem value="reminder">Reminder</SelectItem>
                    <SelectItem value="motivational">Motivational</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Title</label>
                <Input
                  placeholder="Enter notification title..."
                  value={notificationTitle}
                  onChange={(e) => setNotificationTitle(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Message</label>
                <Textarea
                  placeholder="Enter your message..."
                  value={notificationMessage}
                  onChange={(e) => setNotificationMessage(e.target.value)}
                  rows={4}
                />
              </div>

              <Button
                onClick={sendNotificationToMembers}
                disabled={sendingNotification || !notificationTitle.trim() || !notificationMessage.trim()}
                className="w-full"
              >
                <Send className="h-4 w-4 mr-2" />
                {sendingNotification ? 'Sending...' : `Send to ${members.length} members`}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default ActiveCircleNotifications;