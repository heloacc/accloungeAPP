import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAppContext } from '@/contexts/OptimizedAppContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { CheckCircle, MessageSquare, Calendar, Heart, Send, Loader2 } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';

interface CheckIn {
  id: string;
  user_id: string;
  user_name: string;
  avatar_url?: string;
  message: string;
  mood: string;
  timestamp: Date;
  supportCount: number;
}

export const AccountabilityCheckIns = () => {
  const { currentUser } = useAppContext();
  const [checkInMessage, setCheckInMessage] = useState('');
  const [checkIns, setCheckIns] = useState<CheckIn[]>([]);
  const [loading, setLoading] = useState(true);
  const [posting, setPosting] = useState(false);

  useEffect(() => {
    fetchCheckIns();
  }, []);

  const fetchCheckIns = async () => {
    try {
      // Join acircle_posts with profiles table to get user info
      const { data: checkIns, error } = await supabase
        .from('acircle_posts')
        .select(`
          id,
          content,
          created_at,
          user_id,
          post_type,
          profiles!fk_acircle_posts_user_id (
            name,
            full_name,
            avatar_url
          )
        `)
        .eq('post_type', 'check_in')
        .order('created_at', { ascending: false })
        .limit(20);
      
      if (error) throw error;

      // Transform database check-ins to component format
      const formattedCheckIns: CheckIn[] = (checkIns || []).map(post => ({
        id: post.id,
        user_id: post.user_id,
        user_name: post.profiles?.name || post.profiles?.full_name || 'Community Member',
        avatar_url: post.profiles?.avatar_url,
        message: post.content,
        mood: 'motivated',
        timestamp: new Date(post.created_at),
        supportCount: 0
      }));

      setCheckIns(formattedCheckIns);
    } catch (error) {
      console.error('Error fetching check-ins:', error);
      setCheckIns([
        {
          id: '1',
          user_id: 'mock1',
          user_name: 'Alex K.',
          message: 'Had a challenging day but still managed to complete my morning routine. Small wins matter!',
          mood: 'determined',
          timestamp: new Date(Date.now() - 30 * 60 * 1000),
          supportCount: 3
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  const sendCheckIn = async () => {
    if (!checkInMessage.trim() || !currentUser) return;
    
    setPosting(true);
    try {
      const { error } = await supabase
        .from('acircle_posts')
        .insert({
          user_id: currentUser.id,
          content: checkInMessage,
          post_type: 'check_in',
          group_id: null
        });

      if (error) throw error;

      toast({
        title: "Check-in Sent!",
        description: "Your check-in has been shared with the community.",
      });

      setCheckInMessage('');
      fetchCheckIns();
    } catch (error) {
      console.error('Error sending check-in:', error);
      toast({
        title: "Error",
        description: "Failed to send check-in. Please try again.",
        variant: "destructive"
      });
    } finally {
      setPosting(false);
    }
  };

  const sendEncouragement = (checkInId: string) => {
    toast({
      title: "Encouragement Sent!",
      description: "Your support has been sent to your buddy.",
    });
  };



  if (loading) {
    return (
      <Card>
        <CardContent className="p-6 text-center">
          <Loader2 className="w-6 h-6 animate-spin mx-auto mb-2" />
          <p className="text-muted-foreground">Loading check-ins...</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Send Check-In */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MessageSquare className="w-5 h-5 text-[#596D59]" />
            Daily Check-In
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Textarea
            placeholder="Share your progress, challenges, or ask for support..."
            value={checkInMessage}
            onChange={(e) => setCheckInMessage(e.target.value)}
            className="min-h-[100px]"
          />
          <Button 
            onClick={sendCheckIn}
            disabled={!checkInMessage.trim() || posting}
            className="bg-[#596D59] hover:bg-[#596D59]/90"
          >
            {posting ? (
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            ) : (
              <Send className="w-4 h-4 mr-2" />
            )}
            {posting ? 'Sending...' : 'Send Check-In'}
          </Button>
        </CardContent>
      </Card>

      {/* Recent Check-Ins */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="w-5 h-5 text-[#596D59]" />
            Buddy Updates
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {checkIns.length === 0 ? (
            <div className="text-center py-8">
              <MessageSquare className="w-12 h-12 text-[#7E8E9D] mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-[#001B30] mb-2">No Check-ins Yet</h3>
              <p className="text-[#7E8E9D]">Be the first to share a daily check-in!</p>
            </div>
          ) : (
            checkIns.map((checkIn) => (
              <Card key={checkIn.id} className="border-[#596D59]/20">
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    <Avatar className="w-8 h-8">
                      <AvatarFallback className="bg-[#596D59] text-white text-sm">
                        {checkIn.user_name.split(' ').map(n => n[0]).join('')}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <span className="font-medium text-[#001B30]">{checkIn.user_name}</span>
                        <span className="text-xs text-[#7E8E9D]">
                          {checkIn.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                      <p className="text-[#2C2C44] mb-3">{checkIn.message}</p>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => sendEncouragement(checkIn.id)}
                        className="text-[#596D59] border-[#596D59]/30 hover:bg-[#596D59]/10"
                      >
                        <Heart className="w-4 h-4 mr-1" />
                        Send Support
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </CardContent>
      </Card>
    </div>
  );
};