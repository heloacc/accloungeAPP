import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { supabase } from '@/lib/supabase';

interface EmailVerificationProps {
  email: string;
  onVerificationComplete: () => void;
}

export default function EmailVerification({ email, onVerificationComplete }: EmailVerificationProps) {
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');
  const [countdown, setCountdown] = useState(0);

  useEffect(() => {
    // Check if user is already verified
    const checkVerification = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (user?.email_confirmed_at) {
        onVerificationComplete();
      }
    };
    
    checkVerification();

    // Listen for auth state changes (email verification)
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      if (event === 'SIGNED_IN' && session?.user?.email_confirmed_at) {
        onVerificationComplete();
      }
    });

    return () => subscription.unsubscribe();
  }, [onVerificationComplete]);

  useEffect(() => {
    if (countdown > 0) {
      const timer = setTimeout(() => setCountdown(countdown - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [countdown]);

  const resendVerification = async () => {
    setLoading(true);
    setMessage('');

    try {
      const { error } = await supabase.auth.resend({
        type: 'signup',
        email: email,
      });
      
      if (error) throw error;
      
      setMessage('Verification email sent! Check your inbox.');
      setCountdown(60); // 60 second cooldown
    } catch (error: any) {
      setMessage(error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle>Verify Your Email</CardTitle>
        </CardHeader>
        <CardContent className="text-center space-y-4">
          <div className="text-6xl mb-4">📧</div>
          <p className="text-gray-600">
            We've sent a verification link to:
          </p>
          <p className="font-semibold text-gray-900">{email}</p>
          <p className="text-sm text-gray-500">
            Click the link in your email to verify your account and continue.
          </p>
          
          {message && (
            <p className="text-sm text-gray-600 bg-gray-100 p-2 rounded">{message}</p>
          )}
          
          <div className="space-y-2">
            <Button 
              onClick={resendVerification} 
              disabled={loading || countdown > 0}
              variant="outline"
              className="w-full"
            >
              {loading ? 'Sending...' : 
               countdown > 0 ? `Resend in ${countdown}s` : 
               'Resend Verification Email'}
            </Button>
            
            <Button 
              onClick={() => window.location.reload()} 
              variant="ghost"
              className="w-full"
            >
              I've verified my email
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}