import React, { useState, useEffect, Suspense } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { useAppContext } from '@/contexts/UnifiedAppContext';
import { useUserRole } from '@/hooks/useUserRole';
import { useUserTier } from '@/hooks/useUserTier';
import { EnhancedErrorBoundary } from './EnhancedErrorBoundary';
import LoadingScreen from './LoadingScreen';

// Navigation and UI imports
import EnhancedAnalytics from './EnhancedAnalytics';
import SimpleAnalyticsDashboard from './SimpleAnalyticsDashboard';
import BulkUserImport from './BulkUserImport';
import AdminTierManager from './AdminTierManager';
import TierAssignmentManager from './TierAssignmentManager';
import SubscriptionTierGuard from './SubscriptionTierGuard';
import { SubscriptionTierEnforcement } from './SubscriptionTierEnforcement';
import DynamicPageAccessManager from './DynamicPageAccessManager';
import SubscriptionManager from './SubscriptionManager';
import UnifiedHabitsGoals from './UnifiedHabitsGoals';
import AllGroupsManager from './AllGroupsManager';
import AdminNotifications from './AdminNotifications';
import PostRecovery from './PostRecovery';
import Achievements from './Achievements';
import NotificationCenter from './NotificationCenter';
import Resources from './Resources';
import AutomatedGoalProgressTracker from './AutomatedGoalProgressTracker';
import GoalMilestoneManager from './GoalMilestoneManager';
import StreamlinedAuth from './StreamlinedAuth';
import EnhancedUserProfile from './EnhancedUserProfile';
import NotificationDisplay from '@/components/NotificationDisplay';
import ReminderManager from '@/components/ReminderManager';
import SubscriptionPlans from './SubscriptionPlans';
import { TierBasedFeatureDemo } from './TierBasedFeatureDemo';
import { Toaster } from '@/components/ui/toaster';
import { toast } from '@/components/ui/use-toast';
import AccountabilityGroups from './AccountabilityGroups';
import RoleBasedGroupsView from './RoleBasedGroupsView';
import ActiveCircle from './ActiveCircle';
import CommunityFeedTabs from './CommunityFeedTabs';
import MemberMomentumWithChat from './MemberMomentumWithChat';

import UserManagement from './UserManagement';
import ComprehensiveUserManagement from './ComprehensiveUserManagement';

import NavigationGuard from './NavigationGuard';
import SimpleSubscriptionManager from './SimpleSubscriptionManager';
import RouteGuard from './RouteGuard';
import { EnhancedPWAPrompt } from './EnhancedPWAPrompt';
import { RealDataDashboard } from './RealDataDashboard';
import GroupCreationWrapper from './GroupCreationWrapper';
import { HabitSocialHub } from './HabitSocialHub';
import ResponsiveNavigation from './ResponsiveNavigation';
import SystemHealthMonitor from './SystemHealthMonitor';
import AdminDashboard from './AdminDashboard';
import FindPartners from './FindPartners';
const AppLayout = () => {
  const { activeTab, setActiveTab, currentUser, isLoading } = useAppContext();

  // Set up event listener for custom navigation events
  useEffect(() => {
    const handleNavigateToTab = (event: CustomEvent) => {
      const { tab, data } = event.detail;
      setActiveTab(tab, data);
    };

    window.addEventListener('navigate-to-tab', handleNavigateToTab as EventListener);
    
    return () => {
      window.removeEventListener('navigate-to-tab', handleNavigateToTab as EventListener);
    };
  }, [setActiveTab]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-acclounge-sage/10">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-acclounge-brown mx-auto mb-4"></div>
          <p className="text-acclounge-slate">Loading...</p>
        </div>
      </div>
    );
  }

  if (!currentUser) {
    return <StreamlinedAuth onSuccess={() => {}} />;
  }

  const renderContent = () => {
    const content = (() => {
      switch (activeTab) {
        case 'dashboard': return <RealDataDashboard />;
        case 'habits-goals': 
          return (
            <SubscriptionTierEnforcement pagePath="/habits">
              <UnifiedHabitsGoals />
            </SubscriptionTierEnforcement>
          );
        case 'achievements': return <Achievements />;
        case 'notifications': return <NotificationCenter />;
        case 'groups': 
          return (
            <SubscriptionTierEnforcement pagePath="/groups">
              <RoleBasedGroupsView onNavigate={setActiveTab} />
            </SubscriptionTierEnforcement>
          );
        case 'active-circle': return <ActiveCircle />;
        case 'community-feed': return <CommunityFeedTabs onNavigate={setActiveTab} />;
        case 'find-partners': 
          return (
            <SubscriptionTierEnforcement pagePath="/partnerships">
              <FindPartners />
            </SubscriptionTierEnforcement>
          );
        case 'social-habits':
          return (
            <SubscriptionTierEnforcement pagePath="/partnerships">
              <HabitSocialHub />
            </SubscriptionTierEnforcement>
          );
        case 'reminders': return <ReminderManager />;
        case 'resources': return <Resources />;
        case 'profile': return <EnhancedUserProfile />;
        case 'member-momentum': 
          return (
            <NavigationGuard requiredCapability="member_momentum" fallbackMessage="Admin or Moderator access required">
              <MemberMomentumWithChat />
            </NavigationGuard>
          );

        case 'admin-dashboard': 
          return (
            <RouteGuard requiredRoute="/admin">
              <AdminDashboard />
            </RouteGuard>
          );
        case 'all-groups-manager': 
          return (
            <RouteGuard requiredRoute="/admin">
              <AllGroupsManager />
            </RouteGuard>
          );
        case 'admin-notifications': 
          return (
            <RouteGuard requiredRoute="/admin">
              <AdminNotifications />
            </RouteGuard>
          );
        case 'post-recovery': return <PostRecovery />;
        case 'page-access-manager': 
          return (
            <RouteGuard requiredRoute="/admin">
              <DynamicPageAccessManager />
            </RouteGuard>
          );
        case 'subscription': return <SubscriptionManager />;
        case 'tier-demo': return <TierBasedFeatureDemo />;
        case 'admin-tier-manager':
          return (
            <RouteGuard requiredRoute="/admin">
              <AdminTierManager />
            </RouteGuard>
          );
        case 'billing':
          return (
            <RouteGuard requiredRoute="/billing">
              <SubscriptionPlans />
            </RouteGuard>
          );
        case 'admin-notifications-manager':
          return (
            <RouteGuard requiredRoute="/admin">
              <AdminNotifications />
            </RouteGuard>
          );
        case 'group-creation': 
          return (
            <RouteGuard requiredRoute="/groups">
              <GroupCreationWrapper />
            </RouteGuard>
          );
        case 'users': 
          return (
            <RouteGuard requiredRoute="/admin">
              <UserManagement />
            </RouteGuard>
          );
        case 'comprehensive-user-management': 
          return (
            <RouteGuard requiredRoute="/admin">
              <ComprehensiveUserManagement />
            </RouteGuard>
          );
        case 'analytics': 
          return (
            <RouteGuard requiredRoute="/analytics">
              <EnhancedAnalytics />
            </RouteGuard>
          );
        case 'user-analytics':
          return <SimpleAnalyticsDashboard />;
        case 'bulk-import': 
          return (
            <RouteGuard requiredRoute="/admin">
              <BulkUserImport />
            </RouteGuard>
          );
        case 'tier-assignment':
          return (
            <RouteGuard requiredRoute="/admin">
              <TierAssignmentManager />
            </RouteGuard>
          );
        case 'goal-progress': return <AutomatedGoalProgressTracker />;
        case 'goal-milestones': return <GoalMilestoneManager />;
        default: return <RealDataDashboard />;
      }
    })();
    return (
      <EnhancedErrorBoundary>
        <Suspense fallback={<LoadingScreen />}>
          {content}
        </Suspense>
      </EnhancedErrorBoundary>
    );
  };

  return (
    <EnhancedErrorBoundary>
      <div className="flex min-h-screen bg-acclounge-sage/5">
        <EnhancedErrorBoundary fallback={<div>Navigation Error</div>}>
          <ResponsiveNavigation activeTab={activeTab} setActiveTab={setActiveTab} />
        </EnhancedErrorBoundary>
        
        <main className="flex-1 overflow-auto lg:ml-56">
          <div className="pt-16 lg:pt-4 w-full">
            <div className="w-full px-2 sm:px-4 lg:px-6 max-w-none">
              {/* System Health Monitor for Admin Users */}
              {currentUser?.isAdmin && (
                <div className="mb-4">
                  <SystemHealthMonitor showDetails={false} />
                </div>
              )}
              <div className="w-full overflow-x-hidden">
                {renderContent()}
              </div>
            </div>
          </div>
        </main>
        
        <EnhancedErrorBoundary fallback={<div>Notification Error</div>}>
          <NotificationDisplay />
        </EnhancedErrorBoundary>
        
        <EnhancedErrorBoundary fallback={<div>PWA Error</div>}>
          <EnhancedPWAPrompt showOnLoad={true} />
        </EnhancedErrorBoundary>
        
        <Toaster />
      </div>
    </EnhancedErrorBoundary>
  );
};

export default AppLayout;