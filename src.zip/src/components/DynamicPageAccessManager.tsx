import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Trash2, Plus, Lock, Shield } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { toast } from '@/components/ui/use-toast';

interface PageAccessRule {
  id: string;
  page_path: string;
  required_plan_id: string | null;
  minimum_tier_id: string | null;
  created_at: string;
  updated_at: string;
}

interface SubscriptionTier {
  id: string;
  name: string;
  price_monthly: number;
  is_active: boolean;
}

const DynamicPageAccessManager = () => {
  const [rules, setRules] = useState<PageAccessRule[]>([]);
  const [tiers, setTiers] = useState<SubscriptionTier[]>([]);
  const [loading, setLoading] = useState(false);
  const [newRule, setNewRule] = useState({
    page_path: '',
    minimum_tier_id: null as string | null,
    required_plan_id: null as string | null
  });

  const loadRules = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('page_access_rules')
        .select('*')
        .order('page_path');

      if (error) throw error;
      setRules(data || []);
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const loadTiers = async () => {
    try {
      const { data, error } = await supabase
        .from('subscription_tiers')
        .select('id, name, price_monthly, is_active')
        .eq('is_active', true)
        .order('price_monthly');

      if (error) throw error;
      setTiers(data || []);
    } catch (error: any) {
      console.error('Error loading tiers:', error);
    }
  };

  const addRule = async () => {
    if (!newRule.page_path.trim()) {
      toast({
        title: "Error",
        description: "Page path is required",
        variant: "destructive"
      });
      return;
    }

    try {
      const { error } = await supabase
        .from('page_access_rules')
        .insert([{
          page_path: newRule.page_path.trim(),
          minimum_tier_id: newRule.minimum_tier_id,
          required_plan_id: newRule.required_plan_id
        }]);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Page access rule added"
      });

      setNewRule({
        page_path: '',
        minimum_tier_id: null,
        required_plan_id: null
      });

      loadRules();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    }
  };

  const deleteRule = async (id: string) => {
    try {
      const { error } = await supabase
        .from('page_access_rules')
        .delete()
        .eq('id', id);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Page access rule deleted"
      });

      loadRules();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    }
  };

  const getTierName = (tierId: string | null) => {
    if (!tierId) return 'Free Access';
    const tier = tiers.find(t => t.id === tierId);
    return tier?.name || 'Unknown Tier';
  };

  const getTierPrice = (tierId: string | null) => {
    if (!tierId) return '';
    const tier = tiers.find(t => t.id === tierId);
    return tier ? `($${tier.price_monthly}/mo)` : '';
  };

  const getAccessBadgeColor = (rule: PageAccessRule) => {
    if (!rule.minimum_tier_id) return 'secondary';
    const tier = tiers.find(t => t.id === rule.minimum_tier_id);
    if (!tier) return 'outline';
    
    const price = tier.price_monthly;
    if (price === 0) return 'secondary';
    if (price < 15) return 'default';
    return 'destructive';
  };

  useEffect(() => {
    loadRules();
    loadTiers();
  }, []);

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Add Page Access Rule
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <Label htmlFor="page-path">Page Path</Label>
              <Input
                id="page-path"
                placeholder="/analytics, /premium-features, /pro-dashboard"
                value={newRule.page_path}
                onChange={(e) => setNewRule({ ...newRule, page_path: e.target.value })}
              />
            </div>
            
            <div>
              <Label htmlFor="minimum-tier">Minimum Tier Required</Label>
              <Select 
                value={newRule.minimum_tier_id || 'free-access'} 
                onValueChange={(value) => setNewRule({ ...newRule, minimum_tier_id: value === 'free-access' ? null : value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Free Access" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="free-access">Free Access</SelectItem>
                  {tiers.map((tier) => (
                    <SelectItem key={tier.id} value={tier.id}>
                      {tier.name} (${tier.price_monthly}/mo)
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <Button onClick={addRule} className="w-full">
              <Plus className="h-4 w-4 mr-2" />
              Add Access Rule
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Current Page Access Rules</CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center py-4">Loading...</div>
          ) : rules.length === 0 ? (
            <div className="text-center py-4 text-muted-foreground">
              No page access rules configured
            </div>
          ) : (
            <div className="space-y-3">
              {rules.map((rule) => (
                <div key={rule.id} className="flex items-center justify-between p-4 border rounded-lg">
                  <div>
                    <h3 className="font-medium flex items-center gap-2">
                      <Lock className="h-4 w-4" />
                      {rule.page_path}
                    </h3>
                    <div className="flex items-center gap-2 mt-2">
                      <Badge variant={getAccessBadgeColor(rule)}>
                        {getTierName(rule.minimum_tier_id)} {getTierPrice(rule.minimum_tier_id)}
                      </Badge>
                      {rule.required_plan_id && rule.required_plan_id !== rule.minimum_tier_id && (
                        <Badge variant="outline">
                          Specific: {getTierName(rule.required_plan_id)}
                        </Badge>
                      )}
                    </div>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => deleteRule(rule.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default DynamicPageAccessManager;