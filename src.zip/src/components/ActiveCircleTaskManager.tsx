import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useUserData } from '@/hooks/useUserData';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Plus, CheckCircle, Clock } from 'lucide-react';

interface GroupTask {
  id: string;
  title: string;
  description: string;
  completed: boolean;
  completed_by: string;
  group_goal_id: string;
  created_at: string;
  profiles: { full_name: string };
}

interface ActiveCircleTaskManagerProps {
  goalId: string;
  onTaskUpdate: () => void;
}

const ActiveCircleTaskManager = ({ goalId, onTaskUpdate }: ActiveCircleTaskManagerProps) => {
  const [tasks, setTasks] = useState<GroupTask[]>([]);
  const [isAddingTask, setIsAddingTask] = useState(false);
  const [newTask, setNewTask] = useState({
    title: '',
    description: ''
  });

  const { user } = useUserData();

  useEffect(() => {
    fetchTasks();
  }, [goalId]);

  const fetchTasks = async () => {
    try {
      const { data } = await supabase
        .from('acircle_group_tasks')
        .select('*')
        .eq('group_goal_id', goalId)
        .order('created_at', { ascending: false });

      setTasks(data || []);
    } catch (error) {
      console.error('Error fetching tasks:', error);
    }
  };

  const addTask = async () => {
    if (!user || !newTask.title.trim()) return;

    try {
      const { error } = await supabase
        .from('acircle_group_tasks')
        .insert([{
          ...newTask,
          group_goal_id: goalId,
          completed: false,
          completed_by: null
        }]);

      if (!error) {
        setNewTask({ title: '', description: '' });
        setIsAddingTask(false);
        fetchTasks();
        onTaskUpdate();
      }
    } catch (error) {
      console.error('Error adding task:', error);
    }
  };

  const toggleTask = async (taskId: string, completed: boolean) => {
    if (!user) return;

    try {
      const { error } = await supabase
        .from('acircle_group_tasks')
        .update({
          completed,
          completed_by: completed ? user.id : null
        })
        .eq('id', taskId);

      if (!error) {
        fetchTasks();
        onTaskUpdate();

        // Call edge function to update goal progress
        await supabase.functions.invoke('update-goal-progress', {
          body: { goalId }
        });
      }
    } catch (error) {
      console.error('Error updating task:', error);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h4 className="font-semibold">Tasks</h4>
        <Button
          size="sm"
          variant="outline"
          onClick={() => setIsAddingTask(true)}
        >
          <Plus className="h-4 w-4 mr-1" />
          Add Task
        </Button>
      </div>

      {isAddingTask && (
        <Card>
          <CardContent className="pt-4 space-y-3">
            <Input
              placeholder="Task title"
              value={newTask.title}
              onChange={(e) => setNewTask({ ...newTask, title: e.target.value })}
            />
            <Input
              placeholder="Task description (optional)"
              value={newTask.description}
              onChange={(e) => setNewTask({ ...newTask, description: e.target.value })}
            />
            <div className="flex gap-2">
              <Button onClick={addTask} size="sm">
                Add Task
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setIsAddingTask(false);
                  setNewTask({ title: '', description: '' });
                }}
              >
                Cancel
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="space-y-2">
        {tasks.map((task) => (
          <div
            key={task.id}
            className="flex items-center gap-3 p-3 border rounded-lg"
          >
            <Checkbox
              checked={task.completed}
              onCheckedChange={(checked) => toggleTask(task.id, !!checked)}
            />
            <div className="flex-1">
              <div className={`font-medium ${task.completed ? 'line-through text-muted-foreground' : ''}`}>
                {task.title}
              </div>
              {task.description && (
                <div className="text-sm text-muted-foreground">
                  {task.description}
                </div>
              )}
            </div>
            <div className="flex items-center gap-2">
              {task.completed ? (
                <Badge variant="default" className="bg-green-100 text-green-800">
                  <CheckCircle className="h-3 w-3 mr-1" />
                  Complete
                </Badge>
              ) : (
                <Badge variant="secondary">
                  <Clock className="h-3 w-3 mr-1" />
                  Pending
                </Badge>
              )}
            </div>
          </div>
        ))}
        {tasks.length === 0 && (
          <div className="text-center py-4 text-muted-foreground">
            No tasks yet. Add one to get started!
          </div>
        )}
      </div>
    </div>
  );
};

export default ActiveCircleTaskManager;