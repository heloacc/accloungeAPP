import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Shield, Lock, CheckCircle, XCircle, Settings } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { toast } from '@/components/ui/use-toast';

interface TierConfig {
  id: string;
  name: string;
  price_monthly: number;
  is_active: boolean;
}

interface AccessRule {
  id: string;
  route_path: string;
  minimum_tier_id: string;
  is_premium_only: boolean;
  is_active: boolean;
  tier_name?: string;
}

export default function ProductionPageAccessEnforcer() {
  const [tiers, setTiers] = useState<TierConfig[]>([]);
  const [rules, setRules] = useState<AccessRule[]>([]);
  const [loading, setLoading] = useState(true);
  const [enforcing, setEnforcing] = useState(false);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      // Fetch active tiers
      const { data: tierData, error: tierError } = await supabase
        .from('subscription_tiers')
        .select('id, name, price_monthly, is_active')
        .eq('is_active', true)
        .order('price_monthly');

      if (tierError) throw tierError;
      setTiers(tierData || []);

      // Fetch access rules
      const { data: rulesData, error: rulesError } = await supabase
        .from('page_access_rules')
        .select(`
          *,
          subscription_tiers!minimum_tier_id (name)
        `)
        .order('route_path');

      if (rulesError) throw rulesError;
      
      const rulesWithTierNames = (rulesData || []).map(rule => ({
        ...rule,
        tier_name: rule.subscription_tiers?.name || 'Unknown'
      }));
      
      setRules(rulesWithTierNames);
    } catch (error) {
      console.error('Error fetching data:', error);
      toast({
        title: "Error",
        description: "Failed to load access control data",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const enforceProductionAccess = async () => {
    setEnforcing(true);
    try {
      const freemiumTier = tiers.find(t => t.name === 'Freemium');
      const essentialsTier = tiers.find(t => t.name === 'Accountability Essentials');
      const allAccessTier = tiers.find(t => t.name === 'All Access');

      if (!freemiumTier || !essentialsTier || !allAccessTier) {
        throw new Error('Required tiers not found. Please configure all three tiers first.');
      }

      // Production access rules with strict tier enforcement
      const productionRules = [
        // Freemium tier - basic features only
        { route_path: '/dashboard', minimum_tier_id: freemiumTier.id, is_premium_only: false },
        { route_path: '/profile', minimum_tier_id: freemiumTier.id, is_premium_only: false },
        { route_path: '/habits', minimum_tier_id: freemiumTier.id, is_premium_only: false },
        { route_path: '/community-feed', minimum_tier_id: freemiumTier.id, is_premium_only: false },
        { route_path: '/billing', minimum_tier_id: freemiumTier.id, is_premium_only: false },
        
        // Accountability Essentials - group features
        { route_path: '/goals', minimum_tier_id: essentialsTier.id, is_premium_only: true },
        { route_path: '/groups', minimum_tier_id: essentialsTier.id, is_premium_only: true },
        { route_path: '/partnerships', minimum_tier_id: essentialsTier.id, is_premium_only: true },
        { route_path: '/wins-wall', minimum_tier_id: essentialsTier.id, is_premium_only: true },
        { route_path: '/accountability', minimum_tier_id: essentialsTier.id, is_premium_only: true },
        
        // All Access - premium features
        { route_path: '/analytics', minimum_tier_id: allAccessTier.id, is_premium_only: true },
        { route_path: '/admin', minimum_tier_id: allAccessTier.id, is_premium_only: true },
        { route_path: '/advanced-tracking', minimum_tier_id: allAccessTier.id, is_premium_only: true },
        { route_path: '/premium-features', minimum_tier_id: allAccessTier.id, is_premium_only: true }
      ];

      // Clear existing rules
      await supabase
        .from('page_access_rules')
        .delete()
        .neq('id', '00000000-0000-0000-0000-000000000000');

      // Insert production rules
      const { error } = await supabase
        .from('page_access_rules')
        .insert(productionRules.map(rule => ({
          ...rule,
          is_active: true
        })));

      if (error) throw error;

      toast({
        title: "Success",
        description: "Production access control rules enforced successfully"
      });
      
      fetchData();
    } catch (error: any) {
      console.error('Error:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to enforce production access rules",
        variant: "destructive"
      });
    } finally {
      setEnforcing(false);
    }
  };

  const validateAccessControl = () => {
    const issues = [];
    
    // Check if all required tiers exist
    const requiredTiers = ['Freemium', 'Accountability Essentials', 'All Access'];
    const missingTiers = requiredTiers.filter(tierName => 
      !tiers.find(t => t.name === tierName)
    );
    
    if (missingTiers.length > 0) {
      issues.push(`Missing required tiers: ${missingTiers.join(', ')}`);
    }

    // Check if essential routes are protected
    const essentialRoutes = ['/goals', '/groups', '/partnerships', '/analytics'];
    const unprotectedRoutes = essentialRoutes.filter(route => 
      !rules.find(r => r.route_path === route && r.is_active)
    );
    
    if (unprotectedRoutes.length > 0) {
      issues.push(`Unprotected premium routes: ${unprotectedRoutes.join(', ')}`);
    }

    return issues;
  };

  const validationIssues = validateAccessControl();

  if (loading) return <div className="p-6">Loading access control system...</div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Production Page Access Enforcer
          </h3>
          <p className="text-sm text-muted-foreground">
            Configure and enforce strict tier-based page access for production
          </p>
        </div>
        <Button 
          onClick={enforceProductionAccess} 
          disabled={enforcing || validationIssues.length > 0}
          className="bg-green-600 hover:bg-green-700"
        >
          {enforcing ? 'Enforcing...' : 'Enforce Production Access'}
        </Button>
      </div>

      {validationIssues.length > 0 && (
        <Alert className="border-red-200 bg-red-50">
          <XCircle className="h-4 w-4 text-red-600" />
          <AlertDescription className="text-red-800">
            <strong>Validation Issues:</strong>
            <ul className="mt-2 list-disc list-inside">
              {validationIssues.map((issue, index) => (
                <li key={index}>{issue}</li>
              ))}
            </ul>
          </AlertDescription>
        </Alert>
      )}

      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Settings className="h-5 w-5" />
              Active Tiers ({tiers.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {tiers.map((tier) => (
                <div key={tier.id} className="flex justify-between items-center p-2 bg-gray-50 rounded">
                  <span className="font-medium">{tier.name}</span>
                  <Badge variant="outline">${tier.price_monthly}/mo</Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Lock className="h-5 w-5" />
              Access Rules ({rules.filter(r => r.is_active).length} active)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {rules.map((rule) => (
                <div key={rule.id} className={`flex justify-between items-center p-2 rounded ${
                  rule.is_active ? 'bg-green-50' : 'bg-gray-50'
                }`}>
                  <div>
                    <code className="text-sm">{rule.route_path}</code>
                    <div className="text-xs text-muted-foreground">
                      {rule.tier_name} {rule.is_premium_only && '(Premium)'}
                    </div>
                  </div>
                  {rule.is_active ? (
                    <CheckCircle className="h-4 w-4 text-green-600" />
                  ) : (
                    <XCircle className="h-4 w-4 text-gray-400" />
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Production Access Matrix</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-sm space-y-4">
            <div>
              <h4 className="font-semibold text-blue-600 mb-2">Freemium Tier Access:</h4>
              <p className="text-muted-foreground">Dashboard, Profile, Basic Habits, Community Feed, Billing</p>
            </div>
            <div>
              <h4 className="font-semibold text-purple-600 mb-2">Accountability Essentials Access:</h4>
              <p className="text-muted-foreground">All Freemium + Goals, Groups, Partnerships, Wins Wall, Accountability Features</p>
            </div>
            <div>
              <h4 className="font-semibold text-green-600 mb-2">All Access Tier Access:</h4>
              <p className="text-muted-foreground">All Features + Analytics, Admin, Advanced Tracking, Premium Features</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}