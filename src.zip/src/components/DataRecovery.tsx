import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { DataBackupManager, BackupData } from '@/utils/dataBackupManager';
import { PostPersistenceManager } from '@/utils/postPersistence';
import { useAppContext } from '@/contexts/AppContext';
import { RefreshCw, Download, Upload, AlertTriangle } from 'lucide-react';

export const DataRecovery: React.FC = () => {
  const { currentUser } = useAppContext();
  const [backups, setBackups] = useState<BackupData[]>([]);
  const [failedPosts, setFailedPosts] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [recovering, setRecovering] = useState<string | null>(null);

  useEffect(() => {
    loadRecoveryData();
  }, [currentUser]);

  const loadRecoveryData = async () => {
    setLoading(true);
    try {
      if (currentUser) {
        const userBackups = await DataBackupManager.getUserBackups(currentUser.id);
        setBackups(userBackups);
      }
      
      const failed = PostPersistenceManager.getFailedPosts();
      setFailedPosts(failed);
    } catch (error) {
      console.error('Failed to load recovery data:', error);
    } finally {
      setLoading(false);
    }
  };

  const retryFailedPosts = async () => {
    setLoading(true);
    try {
      await PostPersistenceManager.retryFailedPosts();
      await loadRecoveryData();
    } catch (error) {
      console.error('Failed to retry posts:', error);
    } finally {
      setLoading(false);
    }
  };

  const exportBackupData = () => {
    const data = {
      backups,
      failedPosts,
      localBackups: PostPersistenceManager.getBackupData(),
      exportDate: new Date().toISOString()
    };
    
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `acclounge-backup-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (!currentUser) {
    return (
      <Alert>
        <AlertTriangle className="h-4 w-4" />
        <AlertDescription>
          Please sign in to access data recovery features.
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <RefreshCw className="h-5 w-5" />
            Data Recovery & Backup
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <Button onClick={loadRecoveryData} disabled={loading}>
              <RefreshCw className="h-4 w-4 mr-2" />
              Refresh
            </Button>
            <Button onClick={retryFailedPosts} disabled={loading || failedPosts.length === 0}>
              <Upload className="h-4 w-4 mr-2" />
              Retry Failed Posts ({failedPosts.length})
            </Button>
            <Button onClick={exportBackupData} variant="outline">
              <Download className="h-4 w-4 mr-2" />
              Export Backup
            </Button>
          </div>

          {failedPosts.length > 0 && (
            <Alert>
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                You have {failedPosts.length} failed posts that can be retried.
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      {backups.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Content Backups ({backups.length})</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {backups.map((backup) => (
                <div key={backup.id} className="flex items-center justify-between p-3 border rounded">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <Badge variant="secondary">{backup.type}</Badge>
                      <span className="text-sm text-gray-500">
                        {new Date(backup.timestamp).toLocaleString()}
                      </span>
                    </div>
                    <p className="text-sm truncate">{backup.content}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};