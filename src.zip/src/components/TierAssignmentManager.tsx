import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Search, UserCheck, Crown } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';

interface User {
  id: string;
  email: string;
  display_name?: string;
  current_tier?: string;
}

interface Tier {
  id: string;
  name: string;
  stripe_product_id: string;
}

export default function TierAssignmentManager() {
  const [users, setUsers] = useState<User[]>([]);
  const [tiers, setTiers] = useState<Tier[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(false);
  const [assigning, setAssigning] = useState<string | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    loadTiers();
    loadUsers();
  }, []);

  const loadTiers = async () => {
    try {
      const { data, error } = await supabase
        .from('subscription_tiers')
        .select('id, name, stripe_product_id')
        .eq('is_active', true)
        .order('name');

      if (error) throw error;
      setTiers(data || []);
    } catch (error) {
      toast({
        title: "Error loading tiers",
        description: error instanceof Error ? error.message : "Unknown error",
        variant: "destructive"
      });
    }
  };

  const loadUsers = async () => {
    setLoading(true);
    try {
      // Simple approach: get all users with RPC function
      let allUsersData;
      const { data: rpcData, error: allUsersError } = await supabase.rpc('get_all_users_with_profiles');
      
      if (allUsersError) {
        console.error('RPC error, falling back to profiles:', allUsersError);
        // Fallback to profiles table
        const { data: profilesData, error: profilesError } = await supabase
          .from('profiles')
          .select('id, email, name, full_name, subscription_tier')
          .order('email');
        
        if (profilesError) throw profilesError;
        allUsersData = profilesData;
      } else {
        allUsersData = rpcData;
      }

      // Get tiers for mapping
      const { data: tiersData } = await supabase
        .from('subscription_tiers')
        .select('id, name')
        .eq('is_active', true);

      const tierMap = new Map();
      tiersData?.forEach(tier => tierMap.set(tier.id, tier.name));

      // Map users with tier names
      const usersWithTiers = (allUsersData || []).map(user => ({
        id: user.id,
        email: user.email || 'No email',
        display_name: user.name || user.full_name || user.email?.split('@')[0],
        current_tier: user.subscription_tier ? 
          (tierMap.get(user.subscription_tier) || 'Unknown') : 
          'Unknown'
      }));
      
      setUsers(usersWithTiers);
    } catch (error) {
      toast({
        title: "Error loading users",
        description: "Failed to load user list",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const assignTier = async (userId: string, tierId: string) => {
    setAssigning(userId);
    try {
      // Handle freemium tier assignment (set to null)
      const tierValue = tierId === 'freemium' ? null : tierId;
      
      console.log('Assigning tier:', { userId, tierId, tierValue });

      // First, ensure the user exists in profiles table
      const { data: existingProfile, error: profileCheckError } = await supabase
        .from('profiles')
        .select('id, email')
        .eq('id', userId)
        .single();

      if (profileCheckError) {
        console.error('Profile check error:', profileCheckError);
        throw new Error(`User profile not found: ${profileCheckError.message}`);
      }

      console.log('Found existing profile:', existingProfile);

      // Update the user's subscription tier in profiles table
      const { error: updateError } = await supabase
        .from('profiles')
        .update({ 
          subscription_tier: tierValue,
          updated_at: new Date().toISOString()
        })
        .eq('id', userId);

      if (updateError) {
        console.error('Profile update error:', updateError);
        throw new Error(`Failed to update profile: ${updateError.message}`);
      }

      console.log('Profile updated successfully');

      // Update or insert into user_subscription_links table
      if (tierValue) {
        // First check if tier exists
        const { data: tierExists, error: tierCheckError } = await supabase
          .from('subscription_tiers')
          .select('id')
          .eq('id', tierValue)
          .single();

        if (tierCheckError) {
          console.error('Tier check error:', tierCheckError);
          throw new Error(`Invalid tier ID: ${tierCheckError.message}`);
        }

        console.log('Tier exists:', tierExists);

        const { error: linkError } = await supabase
          .from('user_subscription_links')
          .upsert({
            user_id: userId,
            tier_id: tierValue,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString()
          }, {
            onConflict: 'user_id'
          });

        if (linkError) {
          console.error('Link table error:', linkError);
          throw new Error(`Failed to update subscription link: ${linkError.message}`);
        }

        console.log('Subscription link updated successfully');
      } else {
        // Remove from user_subscription_links if setting to freemium
        const { error: deleteError } = await supabase
          .from('user_subscription_links')
          .delete()
          .eq('user_id', userId);

        if (deleteError) {
          console.error('Link delete error:', deleteError);
          // Don't throw error for delete operations as record might not exist
          console.warn('Could not delete subscription link:', deleteError);
        } else {
          console.log('Subscription link deleted successfully');
        }
      }

      toast({
        title: "Tier assigned successfully",
        description: `User tier has been updated to ${tierId === 'freemium' ? 'Freemium' : tiers.find(t => t.id === tierId)?.name || 'Unknown'}`
      });

      loadUsers(); // Refresh the user list
    } catch (error) {
      console.error('Error assigning tier:', error);
      toast({
        title: "Error assigning tier",
        description: error instanceof Error ? error.message : "Failed to update user tier",
        variant: "destructive"
      });
    } finally {
      setAssigning(null);
    }
  };

  const filteredUsers = users.filter(user =>
    user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (user.display_name && user.display_name.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold flex items-center gap-2">
          <UserCheck className="h-6 w-6" />
          User Tier Assignment
        </h2>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Search Users</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search by email or name..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-4">
        {loading ? (
          <Card>
            <CardContent className="p-6 text-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
              <p className="mt-2 text-muted-foreground">Loading users...</p>
            </CardContent>
          </Card>
        ) : filteredUsers.length === 0 ? (
          <Card>
            <CardContent className="p-6 text-center text-muted-foreground">
              No users found matching your search.
            </CardContent>
          </Card>
        ) : (
          filteredUsers.map((user) => (
            <Card key={user.id}>
              <CardContent className="p-4">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-semibold">{user.display_name || user.email}</h3>
                      {user.current_tier !== 'Freemium' && (
                        <Crown className="h-4 w-4 text-yellow-500" />
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground">{user.email}</p>
                    <Badge variant={user.current_tier === 'Freemium' ? 'secondary' : 'default'} className="mt-1">
                      {user.current_tier}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-2">
                    <Select onValueChange={(tierId) => assignTier(user.id, tierId)}>
                      <SelectTrigger className="w-48">
                        <SelectValue placeholder="Assign tier..." />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="freemium">Freemium (Default)</SelectItem>
                        {tiers.map((tier) => (
                          <SelectItem key={tier.id} value={tier.id}>
                            {tier.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {assigning === user.id && (
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-primary"></div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}