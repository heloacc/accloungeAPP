import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useAppContext } from '@/contexts/AppContext';
import { useUserData } from '@/hooks/useUserData';
import { supabase } from '@/lib/supabase';
import { Users, Plus, Clock, CheckCircle, UserPlus, MessageCircle, Shield, Search } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';
import GroupBrowser from '@/components/GroupBrowser';
import JoinRequestManager from '@/components/JoinRequestManager';
import AllGroupsManager from '@/components/AllGroupsManager';
import GroupCreationForm from '@/components/GroupCreationForm';
import IsolatedErrorBoundary from '@/components/IsolatedErrorBoundary';

interface Member {
  id: number;
  name: string;
  avatar: string;
  role: 'admin' | 'member';
}

interface Group {
  id: string;
  name: string;
  description: string;
  category: string;
  members: Member[];
  maxMembers: number;
  isPrivate: boolean;
  joinRequests: number;
  lastActivity: string;
  isArchived?: boolean;
  userRole?: string | null;
}

const AccountabilityGroups = ({ onNavigate }: { onNavigate?: (tab: string, data?: any) => void }) => {
  const { canCreateGroups, currentUser } = useAppContext();
  const [groups, setGroups] = useState<Group[]>([]);
  const [joinRequests, setJoinRequests] = useState<{[key: number]: boolean}>({});
  const [isCreatingGroup, setIsCreatingGroup] = useState(false);
  const [newGroup, setNewGroup] = useState({
    name: '',
    description: '',
    category: '',
    maxMembers: 8,
    isPrivate: false
  });
  const { user, isAdmin } = useUserData();
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    let isMounted = true;
    
    const loadGroups = async () => {
      if (user?.id && isMounted) {
        console.log('Fetching groups for user:', user.id, 'isAdmin:', isAdmin);
        try {
          await fetchGroups();
        } catch (error) {
          console.error('Error in loadGroups:', error);
          if (isMounted) {
            setGroups([]);
          }
        }
      }
    };

    loadGroups();
    
    return () => {
      isMounted = false;
    };
  }, [user?.id]);

  const fetchGroups = async () => {
    if (!currentUser?.id) return;
    
    setLoading(true);
    try {
      const allAccessibleGroups = new Map();
      
      if (isAdmin) {
        const { data: allGroups } = await supabase
          .from('acircle_groups')
          .select('*')
          .order('created_at', { ascending: false });

        if (allGroups) {
          allGroups.forEach(group => {
            allAccessibleGroups.set(group.id, {
              ...group,
              userRole: 'admin'
            });
          });
        }
      } else {
        const { data: userGroups } = await supabase
          .from('acircle_members')
          .select(`
            group_id,
            role,
            acircle_groups (
              id, name, description, is_private, is_archived, created_at, max_members, has_goals, has_tasks, has_leaderboard
            )
          `)
          .eq('user_id', currentUser.id);

        const { data: publicGroups } = await supabase
          .from('acircle_groups')
          .select('*')
          .eq('is_archived', false)
          .eq('is_private', false);

        userGroups?.forEach(membership => {
          if (membership.acircle_groups) {
            const group = membership.acircle_groups;
            allAccessibleGroups.set(group.id, {
              ...group,
              userRole: membership.role || 'member'
            });
          }
        });

        publicGroups?.forEach(group => {
          if (!allAccessibleGroups.has(group.id)) {
            allAccessibleGroups.set(group.id, {
              ...group,
              userRole: null
            });
          }
        });
      }

      const formattedGroups = Array.from(allAccessibleGroups.values()).map(group => ({
        id: group.id,
        name: group.name,
        description: group.description,
        category: 'General',
        members: [],
        maxMembers: group.max_members || 8,
        joinRequests: 0,
        lastActivity: 'Recently',
        isPrivate: group.is_private,
        isArchived: group.is_archived,
        userRole: group.userRole,
        hasGoals: group.has_goals,
        hasTasks: group.has_tasks,
        hasLeaderboard: group.has_leaderboard
      }));

      setGroups(formattedGroups);
      console.log('Fetched groups:', formattedGroups);
    } catch (error) {
      console.error('Error fetching groups:', error);
      toast({
        title: "Error",
        description: "Failed to load groups. Please try again.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleGroupCreated = () => {
    setIsCreatingGroup(false);
    fetchGroups();
  };

  const handleGroupAccess = (groupId: string) => {
    console.log('Accessing group:', groupId);
    sessionStorage.setItem('selectedGroupId', groupId);
    
    if (onNavigate) {
      onNavigate('active-circle', { groupId });
      toast({
        title: "Navigating to Group",
        description: "Loading group in Active Circle...",
      });
    } else {
      window.dispatchEvent(new CustomEvent('navigate-to-tab', { 
        detail: { tab: 'active-circle', data: { groupId } }
      }));
      toast({
        title: "Navigating to Group",
        description: "Loading group in Active Circle...",
      });
    }
  };

  return (
    <div className="space-y-6 p-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-[#001B30]">Accountability Groups</h2>
          <p className="text-[#7E8E9D]">Join groups and build accountability together</p>
        </div>
        <Button 
          className="bg-black text-white hover:bg-gray-800"
          disabled={!canCreateGroups}
          onClick={() => setIsCreatingGroup(true)}
        >
          <Plus className="h-4 w-4 mr-2" />
          Create Group
          {!canCreateGroups && <Shield className="h-4 w-4 ml-2" />}
        </Button>
      </div>

      {isCreatingGroup && (
        <IsolatedErrorBoundary componentName="Group Creation Form">
          <GroupCreationForm
            onGroupCreated={handleGroupCreated}
            onCancel={() => setIsCreatingGroup(false)}
          />
        </IsolatedErrorBoundary>
      )}

      {isAdmin && (
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-6">
          <div className="flex items-center gap-2 text-yellow-800">
            <Shield className="h-5 w-5" />
            <span className="font-medium">Admin Mode Active</span>
          </div>
          <p className="text-sm text-yellow-700 mt-1">
            You have admin access to all groups regardless of membership status.
          </p>
        </div>
      )}

      <Tabs defaultValue="my-groups" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="my-groups">My Groups</TabsTrigger>
          <TabsTrigger value="browse">
            <Search className="h-4 w-4 mr-2" />
            Browse Groups
          </TabsTrigger>
          <TabsTrigger value="requests">Join Requests</TabsTrigger>
        </TabsList>

        <TabsContent value="my-groups" className="space-y-6">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {groups.filter(group => group.userRole || isAdmin).map((group) => (
              <Card key={group.id} className={`border-[#596D59]/20 hover:shadow-md transition-shadow ${group.isArchived ? 'opacity-75 bg-gray-50' : ''}`}>
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <CardTitle className="flex items-center gap-2 text-[#001B30]">
                      <Users className="h-5 w-5 text-[#596D59]" />
                      {group.name}
                      {group.isArchived && (
                        <Badge className="ml-2 bg-gray-500 text-white text-xs">ARCHIVED</Badge>
                      )}
                      {isAdmin && (
                        <Badge className="ml-2 bg-yellow-600 text-white text-xs">ADMIN ACCESS</Badge>
                      )}
                    </CardTitle>
                    {group.isPrivate && (
                      <Badge variant="outline" className="text-xs border-[#7E8E9D] text-[#7E8E9D]">Private</Badge>
                    )}
                  </div>
                  <p className="text-sm text-[#7E8E9D]">{group.description}</p>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex gap-2">
                    <Button 
                      className="flex-1 bg-blue-600 hover:bg-blue-700 text-white"
                      onClick={() => handleGroupAccess(group.id)}
                    >
                      <Users className="h-4 w-4 mr-2" />
                      Enter Group
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="browse" className="space-y-6">
          <IsolatedErrorBoundary componentName="Group Browser">
            {user?.id && <GroupBrowser userId={user.id} />}
          </IsolatedErrorBoundary>
        </TabsContent>

        <TabsContent value="requests" className="space-y-6">
          <IsolatedErrorBoundary componentName="Join Request Manager">
            {isAdmin ? (
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">All Join Requests (Admin View)</h3>
                <AllGroupsManager />
              </div>
            ) : (
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Join Requests</h3>
                {groups
                  .filter(group => group.userRole === 'moderator' || group.userRole === 'admin')
                  .map(group => (
                    <div key={group.id} className="space-y-4">
                      <h4 className="text-md font-medium">Requests for {group.name}</h4>
                      <JoinRequestManager groupId={group.id} userRole={group.userRole || 'member'} />
                    </div>
                  ))}
                {groups.filter(group => group.userRole === 'moderator' || group.userRole === 'admin').length === 0 && (
                  <p className="text-muted-foreground">You don't have permission to manage any group requests.</p>
                )}
              </div>
            )}
          </IsolatedErrorBoundary>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default AccountabilityGroups;