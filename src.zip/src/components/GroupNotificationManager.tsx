import React, { useState, useEffect } from 'react';
import { useAppContext } from '@/contexts/OptimizedAppContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Users, Send, MessageSquare } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabase';

const GroupNotificationManager = () => {
  const { currentUser } = useAppContext();
  const [groups, setGroups] = useState([]);
  const [selectedGroup, setSelectedGroup] = useState('');
  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchGroups();
  }, []);

  const fetchGroups = async () => {
    try {
      const { data, error } = await supabase
        .from('acircle_groups')
        .select('id, name, member_count')
        .order('name');

      if (error) throw error;
      setGroups(data || []);
    } catch (error) {
      console.error('Error fetching groups:', error);
    }
  };

  const handleSendGroupNotification = async () => {
    if (!selectedGroup || !title.trim() || !message.trim()) {
      toast({
        title: "Validation Error",
        description: "Please select a group and fill in all fields.",
        variant: "destructive"
      });
      return;
    }

    setLoading(true);
    try {
      // Get group members
      const { data: members, error: membersError } = await supabase
        .from('acircle_members')
        .select('user_id')
        .eq('group_id', selectedGroup);

      if (membersError) throw membersError;

      if (members && members.length > 0) {
        const notifications = members.map(member => ({
          user_id: member.user_id,
          type: 'group_announcement',
          title: title.trim(),
          message: message.trim(),
          read: false,
          metadata: { group_id: selectedGroup }
        }));

        const { error } = await supabase
          .from('notifications')
          .insert(notifications);

        if (error) throw error;

        toast({
          title: "Group Notification Sent",
          description: `Notification sent to ${members.length} group members.`,
        });

        setTitle('');
        setMessage('');
        setSelectedGroup('');
      }
    } catch (error) {
      console.error('Error sending group notification:', error);
      toast({
        title: "Error",
        description: "Failed to send group notification. Please try again.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Users className="h-5 w-5" />
          Send Group Notification
        </CardTitle>
        <CardDescription>
          Send targeted notifications to specific groups
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <label className="text-sm font-medium mb-2 block">Select Group</label>
          <Select value={selectedGroup} onValueChange={setSelectedGroup}>
            <SelectTrigger>
              <SelectValue placeholder="Choose a group..." />
            </SelectTrigger>
            <SelectContent>
              {groups.map((group) => (
                <SelectItem key={group.id} value={group.id}>
                  <div className="flex items-center justify-between w-full">
                    <span>{group.name}</span>
                    <Badge variant="secondary" className="ml-2">
                      {group.member_count || 0} members
                    </Badge>
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div>
          <label className="text-sm font-medium mb-2 block">Title</label>
          <Input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Enter notification title..."
            maxLength={100}
          />
        </div>

        <div>
          <label className="text-sm font-medium mb-2 block">Message</label>
          <Textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Enter your group notification message..."
            rows={4}
            maxLength={500}
          />
          <p className="text-xs text-muted-foreground mt-1">
            {message.length}/500 characters
          </p>
        </div>

        <Button 
          onClick={handleSendGroupNotification} 
          disabled={loading}
          className="w-full"
        >
          <Send className="h-4 w-4 mr-2" />
          {loading ? 'Sending...' : 'Send to Group'}
        </Button>
      </CardContent>
    </Card>
  );
};

export default GroupNotificationManager;