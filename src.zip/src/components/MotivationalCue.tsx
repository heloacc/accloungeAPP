import { Card, CardContent } from '@/components/ui/card';
import { Sparkles, Heart, Zap } from 'lucide-react';
import { useState, useEffect } from 'react';

interface MotivationalCueProps {
  userStats: {
    habits_count: number;
    goals_count: number;
    current_streak: number;
    total_completions: number;
  } | null;
  recentAchievements: any[];
}

const MotivationalCue = ({ userStats, recentAchievements }: MotivationalCueProps) => {
  const [currentCue, setCurrentCue] = useState<any>(null);

  const motivationalMessages = [
    {
      message: "Small steps lead to big changes. Keep going! 🌟",
      icon: Sparkles,
      color: "text-acclounge-brown"
    },
    {
      message: "Your consistency is building something amazing! 💪",
      icon: Zap,
      color: "text-acclounge-sage"
    },
    {
      message: "Every habit completed is a victory worth celebrating! 🎉",
      icon: Heart,
      color: "text-acclounge-olive"
    },
    {
      message: "Progress, not perfection. You're doing great! ✨",
      icon: Sparkles,
      color: "text-acclounge-navy"
    }
  ];

  const getPersonalizedMessage = () => {
    // If recent achievement, highlight it
    if (recentAchievements.length > 0) {
      const latest = recentAchievements[0];
      return {
        message: `🏆 Amazing! You just unlocked "${latest.name}"!`,
        icon: Sparkles,
        color: "text-yellow-600"
      };
    }

    // If good streak, encourage
    if (userStats?.current_streak && userStats.current_streak >= 7) {
      return {
        message: `🔥 ${userStats.current_streak} days strong! You're unstoppable!`,
        icon: Zap,
        color: "text-orange-600"
      };
    }

    // If many completions, celebrate
    if (userStats?.total_completions && userStats.total_completions >= 50) {
      return {
        message: `💯 ${userStats.total_completions} completions! You're a habit master!`,
        icon: Heart,
        color: "text-acclounge-brown"
      };
    }

    // Random motivational message
    return motivationalMessages[Math.floor(Math.random() * motivationalMessages.length)];
  };

  useEffect(() => {
    setCurrentCue(getPersonalizedMessage());
  }, [userStats, recentAchievements]);

  if (!currentCue) return null;

  const Icon = currentCue.icon;

  return (
    <Card className="bg-gradient-to-r from-acclounge-sage/10 to-acclounge-brown/10 border-acclounge-sage/30">
      <CardContent className="p-4">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-white rounded-full shadow-sm">
            <Icon className={`h-5 w-5 ${currentCue.color}`} />
          </div>
          <p className="text-gray-800 font-medium flex-1">{currentCue.message}</p>
        </div>
      </CardContent>
    </Card>
  );
};

export default MotivationalCue;