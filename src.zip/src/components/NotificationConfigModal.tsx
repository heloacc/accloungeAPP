import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { Bell, Mail, Smartphone, Clock, Target, Users } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/lib/supabase';
import { useAppContext } from '@/contexts/OptimizedAppContext';

interface NotificationConfigModalProps {
  isOpen: boolean;
  onClose: () => void;
  type: 'email' | 'push';
}

interface NotificationSettings {
  habit_reminders: boolean;
  goal_deadlines: boolean;
  group_updates: boolean;
  achievement_alerts: boolean;
  weekly_summary: boolean;
  partner_activity: boolean;
}

const NotificationConfigModal: React.FC<NotificationConfigModalProps> = ({
  isOpen,
  onClose,
  type
}) => {
  const { currentUser } = useAppContext();
  const { toast } = useToast();
  const [settings, setSettings] = useState<NotificationSettings>({
    habit_reminders: true,
    goal_deadlines: true,
    group_updates: false,
    achievement_alerts: true,
    weekly_summary: true,
    partner_activity: false
  });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (isOpen && currentUser?.id) {
      loadSettings();
    }
  }, [isOpen, currentUser?.id]);

  const loadSettings = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select(`${type}_notifications`)
        .eq('id', currentUser?.id)
        .single();

      if (error) throw error;

      if (data && data[`${type}_notifications`]) {
        setSettings(data[`${type}_notifications`]);
      }
    } catch (error) {
      console.error('Error loading notification settings:', error);
    }
  };

  const saveSettings = async () => {
    if (!currentUser?.id) return;

    try {
      setSaving(true);
      
      const { error } = await supabase
        .from('profiles')
        .update({
          [`${type}_notifications`]: settings
        })
        .eq('id', currentUser.id);

      if (error) throw error;

      toast({
        title: "Settings Saved",
        description: `${type === 'email' ? 'Email' : 'Push'} notification preferences updated successfully`
      });
      
      onClose();
    } catch (error) {
      console.error('Error saving settings:', error);
      toast({
        title: "Error",
        description: "Failed to save notification settings",
        variant: "destructive"
      });
    } finally {
      setSaving(false);
    }
  };

  const updateSetting = (key: keyof NotificationSettings, value: boolean) => {
    setSettings(prev => ({
      ...prev,
      [key]: value
    }));
  };

  const notificationOptions = [
    {
      key: 'habit_reminders' as keyof NotificationSettings,
      title: 'Habit Reminders',
      description: 'Get reminded to complete your daily habits',
      icon: Clock
    },
    {
      key: 'goal_deadlines' as keyof NotificationSettings,
      title: 'Goal Deadlines',
      description: 'Alerts for upcoming goal deadlines',
      icon: Target
    },
    {
      key: 'group_updates' as keyof NotificationSettings,
      title: 'Group Updates',
      description: 'New posts and activities in your groups',
      icon: Users
    },
    {
      key: 'achievement_alerts' as keyof NotificationSettings,
      title: 'Achievement Alerts',
      description: 'Celebrate when you unlock new achievements',
      icon: Bell
    },
    {
      key: 'weekly_summary' as keyof NotificationSettings,
      title: 'Weekly Summary',
      description: 'Your progress summary every week',
      icon: Mail
    },
    {
      key: 'partner_activity' as keyof NotificationSettings,
      title: 'Partner Activity',
      description: 'Updates from your accountability partners',
      icon: Users
    }
  ];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            {type === 'email' ? <Mail className="h-5 w-5" /> : <Smartphone className="h-5 w-5" />}
            {type === 'email' ? 'Email' : 'Push'} Notification Settings
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          {notificationOptions.map(({ key, title, description, icon: Icon }) => (
            <Card key={key}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-start gap-3 flex-1">
                    <Icon className="h-5 w-5 text-blue-600 mt-0.5" />
                    <div>
                      <Label htmlFor={key} className="text-sm font-medium cursor-pointer">
                        {title}
                      </Label>
                      <p className="text-xs text-gray-600 mt-1">{description}</p>
                    </div>
                  </div>
                  <Switch
                    id={key}
                    checked={settings[key]}
                    onCheckedChange={(checked) => updateSetting(key, checked)}
                  />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="flex gap-2 pt-4">
          <Button variant="outline" onClick={onClose} className="flex-1">
            Cancel
          </Button>
          <Button onClick={saveSettings} disabled={saving} className="flex-1">
            {saving ? 'Saving...' : 'Save Settings'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default NotificationConfigModal;