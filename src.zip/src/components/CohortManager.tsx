import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Users, TrendingUp, Calendar, Activity } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface CohortData {
  month: string;
  totalUsers: number;
  activeUsers: number;
  retentionRate: number;
  avgGoalsCompleted: number;
  avgHabitsCompleted: number;
}

const CohortManager: React.FC = () => {
  const [cohorts, setCohorts] = useState<CohortData[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadCohortData();
  }, []);

  const loadCohortData = async () => {
    try {
      setLoading(true);
      
      // Get users grouped by signup month
      const { data: users } = await supabase
        .from('profiles')
        .select('id, created_at')
        .order('created_at', { ascending: false });

      if (!users) return;

      // Group users by month and calculate metrics
      const cohortMap = new Map<string, any>();
      
      for (const user of users) {
        const month = new Date(user.created_at).toISOString().slice(0, 7);
        
        if (!cohortMap.has(month)) {
          cohortMap.set(month, {
            month,
            totalUsers: 0,
            userIds: []
          });
        }
        
        const cohort = cohortMap.get(month);
        cohort.totalUsers++;
        cohort.userIds.push(user.id);
      }

      // Calculate additional metrics for each cohort
      const cohortData: CohortData[] = [];
      
      for (const [month, data] of cohortMap) {
        // Get active users (posted in last 30 days)
        const { data: activePosts } = await supabase
          .from('posts')
          .select('user_id')
          .in('user_id', data.userIds)
          .gte('created_at', new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString());

        const activeUsers = new Set(activePosts?.map(p => p.user_id) || []).size;
        
        // Get completed goals and habits for this cohort
        const [goalsResult, habitsResult] = await Promise.all([
          supabase
            .from('goals')
            .select('user_id')
            .in('user_id', data.userIds)
            .eq('status', 'completed'),
          supabase
            .from('habits')
            .select('user_id')
            .in('user_id', data.userIds)
            .eq('is_active', true)
        ]);

        cohortData.push({
          month,
          totalUsers: data.totalUsers,
          activeUsers,
          retentionRate: data.totalUsers > 0 ? Math.round((activeUsers / data.totalUsers) * 100) : 0,
          avgGoalsCompleted: Math.round((goalsResult.data?.length || 0) / data.totalUsers * 10) / 10,
          avgHabitsCompleted: Math.round((habitsResult.data?.length || 0) / data.totalUsers * 10) / 10
        });
      }

      setCohorts(cohortData.slice(0, 12)); // Show last 12 months
    } catch (error) {
      console.error('Error loading cohort data:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div className="p-4">Loading cohort analysis...</div>;
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Cohort Analysis
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {cohorts.map((cohort) => (
              <div key={cohort.month} className="border rounded-lg p-4">
                <div className="flex justify-between items-start mb-3">
                  <div>
                    <h3 className="font-semibold">{cohort.month}</h3>
                    <p className="text-sm text-muted-foreground">{cohort.totalUsers} users joined</p>
                  </div>
                  <Badge variant={cohort.retentionRate > 30 ? "default" : "secondary"}>
                    {cohort.retentionRate}% retention
                  </Badge>
                </div>
                
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                  <div className="flex items-center gap-2">
                    <Activity className="h-4 w-4 text-green-500" />
                    <span>{cohort.activeUsers} active</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <TrendingUp className="h-4 w-4 text-blue-500" />
                    <span>{cohort.avgGoalsCompleted} avg goals</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-purple-500" />
                    <span>{cohort.avgHabitsCompleted} avg habits</span>
                  </div>
                  <div className="text-right">
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className="bg-blue-600 h-2 rounded-full" 
                        style={{ width: `${cohort.retentionRate}%` }}
                      ></div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          <div className="mt-4 pt-4 border-t">
            <Button onClick={loadCohortData} variant="outline" size="sm">
              Refresh Data
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default CohortManager;