import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { useAppContext } from '@/contexts/OptimizedAppContext';
import { useSubscriptionAccess } from '@/hooks/useSubscriptionAccess';
import RouteProtectionGuard from './RouteProtectionGuard';
import LoadingScreen from './LoadingScreen';

interface RouteGuardProps {
  children: React.ReactNode;
  requiredRoute?: string;
  fallback?: React.ReactNode;
}

export default function RouteGuard({ 
  children, 
  requiredRoute,
  fallback 
}: RouteGuardProps) {
  const location = useLocation();
  const { currentUser, isLoading } = useAppContext();
  const { checkPageAccess } = useSubscriptionAccess();
  const [accessResult, setAccessResult] = useState<{
    hasAccess: boolean;
    tier: string;
    requiredTier?: string;
  } | null>(null);
  const [checking, setChecking] = useState(true);

  const routeToCheck = requiredRoute || location.pathname;

  useEffect(() => {
    if (!isLoading && currentUser) {
      checkRouteAccess();
    } else if (!isLoading && !currentUser) {
      setChecking(false);
    }
  }, [isLoading, currentUser, routeToCheck]);

  const checkRouteAccess = async () => {
    setChecking(true);
    try {
      const result = await checkPageAccess(routeToCheck);
      setAccessResult(result);
    } catch (error) {
      console.error('Error checking route access:', error);
      setAccessResult({ hasAccess: false, tier: 'error' });
    } finally {
      setChecking(false);
    }
  };

  if (isLoading || checking) {
    return <LoadingScreen />;
  }

  if (!currentUser) {
    return fallback || <div>Please log in to access this page.</div>;
  }

  if (accessResult && !accessResult.hasAccess) {
    const requiredTierMap: { [key: string]: 'Freemium' | 'Accountability Essentials' | 'All Access' } = {
      'Freemium': 'Freemium',
      'Accountability Essentials': 'Accountability Essentials', 
      'All Access': 'All Access'
    };

    const requiredTier = requiredTierMap[accessResult.requiredTier || 'All Access'] || 'All Access';

    return (
      <RouteProtectionGuard
        requiredTier={requiredTier}
        routePath={routeToCheck}
        fallbackComponent={fallback}
      >
        {children}
      </RouteProtectionGuard>
    );
  }

  return <>{children}</>;
}