import React, { useState, useEffect } from 'react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { CheckCircle, AlertTriangle, XCircle, RefreshCw } from 'lucide-react';
import { FeatureValidator, FeatureValidationResult } from '@/utils/featureValidator';

interface SystemHealthMonitorProps {
  showDetails?: boolean;
  onHealthChange?: (isHealthy: boolean) => void;
}

const SystemHealthMonitor: React.FC<SystemHealthMonitorProps> = ({ 
  showDetails = false, 
  onHealthChange 
}) => {
  const [healthResults, setHealthResults] = useState<Record<string, FeatureValidationResult>>({});
  const [isLoading, setIsLoading] = useState(true);
  const [lastCheck, setLastCheck] = useState<Date | null>(null);

  const checkSystemHealth = async () => {
    setIsLoading(true);
    try {
      const results = await FeatureValidator.validateCriticalFeatures();
      setHealthResults(results);
      setLastCheck(new Date());
      
      const isHealthy = Object.values(results).every(result => result.isValid);
      onHealthChange?.(isHealthy);
    } catch (error) {
      console.error('Health check failed:', error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    checkSystemHealth();
    // Check every 15 minutes (reduced from 10 to further reduce server load)
    const interval = setInterval(checkSystemHealth, 15 * 60 * 1000);
    return () => clearInterval(interval);
  }, []);

  const getStatusIcon = (result: FeatureValidationResult) => {
    if (result.isValid) {
      return <CheckCircle className="h-4 w-4 text-green-500" />;
    }
    return result.errors.length > 0 
      ? <XCircle className="h-4 w-4 text-red-500" />
      : <AlertTriangle className="h-4 w-4 text-yellow-500" />;
  };

  const getStatusBadge = (result: FeatureValidationResult) => {
    if (result.isValid) {
      return <Badge variant="secondary" className="text-green-700 bg-green-100">Healthy</Badge>;
    }
    return result.errors.length > 0
      ? <Badge variant="destructive">Error</Badge>
      : <Badge variant="outline" className="text-yellow-700 border-yellow-300">Warning</Badge>;
  };

  const overallHealth = Object.values(healthResults).every(result => result.isValid);
  const hasErrors = Object.values(healthResults).some(result => result.errors.length > 0);

  if (!showDetails && overallHealth) {
    return null; // Don't show anything if system is healthy and details not requested
  }

  return (
    <Card className="w-full">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium flex items-center gap-2">
          {overallHealth ? (
            <CheckCircle className="h-4 w-4 text-green-500" />
          ) : (
            <AlertTriangle className="h-4 w-4 text-red-500" />
          )}
          System Health
        </CardTitle>
        <Button
          variant="outline"
          size="sm"
          onClick={checkSystemHealth}
          disabled={isLoading}
        >
          <RefreshCw className={`h-3 w-3 mr-1 ${isLoading ? 'animate-spin' : ''}`} />
          Refresh
        </Button>
      </CardHeader>
      <CardContent>
        {!overallHealth && (
          <Alert className={`mb-4 ${hasErrors ? 'border-red-200' : 'border-yellow-200'}`}>
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              {hasErrors 
                ? 'Critical system issues detected. Some features may not work properly.'
                : 'System warnings detected. Monitoring for potential issues.'
              }
            </AlertDescription>
          </Alert>
        )}

        {showDetails && (
          <div className="space-y-2">
            {Object.entries(healthResults).map(([feature, result]) => (
              <div key={feature} className="flex items-center justify-between p-2 border rounded">
                <div className="flex items-center gap-2">
                  {getStatusIcon(result)}
                  <span className="text-sm font-medium capitalize">
                    {feature.replace('_', ' ')}
                  </span>
                </div>
                {getStatusBadge(result)}
              </div>
            ))}
          </div>
        )}

        {lastCheck && (
          <p className="text-xs text-muted-foreground mt-2">
            Last checked: {lastCheck.toLocaleTimeString()}
          </p>
        )}
      </CardContent>
    </Card>
  );
};

export default SystemHealthMonitor;