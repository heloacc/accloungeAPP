import React from 'react';
import { useUserTier, UserTier } from '@/hooks/useUserTier';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Lock, Crown, Zap } from 'lucide-react';

interface FeatureGuardProps {
  children: React.ReactNode;
  requiredTier: UserTier;
  featureName?: string;
  fallback?: React.ReactNode;
}

const FeatureGuard: React.FC<FeatureGuardProps> = ({ 
  children, 
  requiredTier, 
  featureName = 'This feature',
  fallback 
}) => {
  const { tier, loading, isPremium, isEnterprise } = useUserTier();

  if (loading) {
    return (
      <div className="flex items-center justify-center p-4">
        <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const hasAccess = () => {
    switch (requiredTier) {
      case 'freemium':
        return true;
      case 'premium':
        return isPremium;
      case 'enterprise':
        return isEnterprise;
      default:
        return false;
    }
  };

  if (hasAccess()) {
    return <>{children}</>;
  }

  if (fallback) {
    return <>{fallback}</>;
  }

  const getIcon = () => {
    switch (requiredTier) {
      case 'premium':
        return <Crown className="h-6 w-6 text-purple-600" />;
      case 'enterprise':
        return <Zap className="h-6 w-6 text-purple-600" />;
      default:
        return <Lock className="h-6 w-6 text-gray-600" />;
    }
  };

  const getUpgradeMessage = () => {
    switch (requiredTier) {
      case 'premium':
        return `${featureName} requires a Premium subscription.`;
      case 'enterprise':
        return `${featureName} requires an Enterprise subscription.`;
      default:
        return `${featureName} requires a subscription upgrade.`;
    }
  };

  return (
    <Card className="border-dashed border-2">
      <CardHeader className="text-center pb-2">
        <div className="mx-auto mb-2 p-2 bg-gray-100 rounded-full w-fit">
          {getIcon()}
        </div>
        <CardTitle className="text-lg">Upgrade Required</CardTitle>
      </CardHeader>
      <CardContent className="text-center space-y-3">
        <p className="text-sm text-muted-foreground">
          {getUpgradeMessage()}
        </p>
        <p className="text-xs text-muted-foreground">
          Current plan: <span className="capitalize font-medium">{tier}</span>
        </p>
        <Dialog>
          <DialogTrigger asChild>
            <Button size="sm" className="w-full">
              Upgrade to {requiredTier}
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Upgrade Your Plan</DialogTitle>
            </DialogHeader>
            <div className="p-4 text-center">
              <p>Upgrade to unlock {featureName.toLowerCase()} and more premium features!</p>
              <Button className="mt-4">Choose Plan</Button>
            </div>
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  );
};

export default FeatureGuard;