import { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Download, X } from 'lucide-react';
import { showInstallPrompt, getInstallPrompt } from '../utils/pwaUtils';
import { MobilePWAInstaller } from './MobilePWAInstaller';

export function PWAInstallPrompt() {
  const [showPrompt, setShowPrompt] = useState(false);
  const [isInstalled, setIsInstalled] = useState(false);
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    // Detect mobile device
    const checkMobile = () => {
      const userAgent = navigator.userAgent;
      const isMobileDevice = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(userAgent);
      const isSmallScreen = window.innerWidth <= 768;
      return isMobileDevice || isSmallScreen;
    };

    setIsMobile(checkMobile());

    // Check if already installed
    const isStandalone = window.matchMedia('(display-mode: standalone)').matches;
    const isInWebAppiOS = (window.navigator as any).standalone === true;
    setIsInstalled(isStandalone || isInWebAppiOS);

    // For desktop, show prompt if installable and not installed
    if (!checkMobile()) {
      const checkInstallable = () => {
        const deferredPrompt = getInstallPrompt();
        if (deferredPrompt && !isInstalled) {
          setShowPrompt(true);
        }
      };

      checkInstallable();
      window.addEventListener('beforeinstallprompt', checkInstallable);

      return () => {
        window.removeEventListener('beforeinstallprompt', checkInstallable);
      };
    }
  }, [isInstalled]);

  const handleInstall = async () => {
    const installed = await showInstallPrompt();
    if (installed) {
      setShowPrompt(false);
      setIsInstalled(true);
    }
  };

  const handleDismiss = () => {
    setShowPrompt(false);
    localStorage.setItem('pwa-install-dismissed', 'true');
  };

  // On mobile, use the enhanced mobile installer
  if (isMobile) {
    return <MobilePWAInstaller onDismiss={handleDismiss} />;
  }

  // Desktop install prompt
  if (!showPrompt || isInstalled) return null;

  return (
    <Card className="fixed bottom-4 left-4 right-4 z-50 mx-auto max-w-sm">
      <CardContent className="flex items-center gap-3 p-4">
        <Download className="h-8 w-8 text-primary" />
        <div className="flex-1">
          <h3 className="font-semibold">Install ACCLOUNGE</h3>
          <p className="text-sm text-muted-foreground">
            Install our app for a better experience
          </p>
        </div>
        <div className="flex gap-2">
          <Button size="sm" onClick={handleInstall}>
            Install
          </Button>
          <Button size="sm" variant="ghost" onClick={handleDismiss}>
            <X className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}