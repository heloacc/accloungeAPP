import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Target, TrendingUp, Flame } from 'lucide-react';

interface QuickTrackersProps {
  recentHabits: any[];
  activeGoals: any[];
  userStats: {
    habits_count: number;
    goals_count: number;
    current_streak: number;
    total_completions: number;
  } | null;
}

const QuickTrackers = ({ recentHabits, activeGoals, userStats }: QuickTrackersProps) => {
  const isCompletedToday = (habit: any) => {
    const today = new Date().toISOString().split('T')[0];
    return habit.completed_dates?.includes(today) || false;
  };

  return (
    <div className="grid md:grid-cols-2 gap-4">
      {/* Habits Quick View */}
      <Card className="border-gray-200">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-sm">
            <Target className="h-4 w-4 text-[#596D59]" />
            Habits ({userStats?.habits_count || 0})
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {recentHabits.slice(0, 3).map((habit) => (
            <div key={habit.id} className="flex items-center justify-between p-2 rounded-lg bg-gray-50">
              <div className="flex items-center gap-2 min-w-0 flex-1">
                <div className={`w-2 h-2 rounded-full ${isCompletedToday(habit) ? 'bg-green-500' : 'bg-gray-300'}`} />
                <span className="text-sm font-medium truncate">{habit.title}</span>
                <div className="flex items-center gap-1 text-xs text-gray-600">
                  <Flame className="h-3 w-3" />
                  {habit.current_streak}
                </div>
              </div>
              <Badge variant={isCompletedToday(habit) ? "default" : "secondary"} className="text-xs">
                {isCompletedToday(habit) ? '✓' : '○'}
              </Badge>
            </div>
          ))}
          {recentHabits.length === 0 && (
            <p className="text-sm text-gray-500 text-center py-4">No habits yet</p>
          )}
        </CardContent>
      </Card>

      {/* Goals Quick View */}
      <Card className="border-gray-200">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-sm">
            <TrendingUp className="h-4 w-4 text-[#596D59]" />
            Goals ({userStats?.goals_count || 0})
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {activeGoals.slice(0, 3).map((goal) => (
            <div key={goal.id} className="space-y-2 p-2 rounded-lg bg-gray-50">
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium truncate">{goal.title}</span>
                <Badge variant="outline" className="text-xs">{goal.category}</Badge>
              </div>
              <Progress value={(goal.current_value / goal.target_value) * 100} className="h-1" />
              <p className="text-xs text-gray-600">
                {goal.current_value}/{goal.target_value} {goal.unit}
              </p>
            </div>
          ))}
          {activeGoals.length === 0 && (
            <p className="text-sm text-gray-500 text-center py-4">No active goals</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default QuickTrackers;