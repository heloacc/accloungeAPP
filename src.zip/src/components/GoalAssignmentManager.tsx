import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/lib/supabase';
import { UserPlus, Target } from 'lucide-react';

interface GoalAssignmentManagerProps {
  groupId: string;
  userRole: string;
}

interface Goal {
  id: string;
  title: string;
  description: string;
}

interface Member {
  id: string;
  username: string;
  role: string;
}

interface Assignment {
  id: string;
  goal: Goal;
  assigned_to: string;
  member: Member;
  status: string;
}

export function GoalAssignmentManager({ groupId, userRole }: GoalAssignmentManagerProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [goals, setGoals] = useState<Goal[]>([]);
  const [members, setMembers] = useState<Member[]>([]);
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [selectedGoal, setSelectedGoal] = useState('');
  const [selectedMember, setSelectedMember] = useState('');

  useEffect(() => {
    if (isOpen) {
      fetchData();
    }
  }, [isOpen, groupId]);

  const fetchData = async () => {
    // Fetch goals
    const { data: goalsData } = await supabase
      .from('acircle_group_goals')
      .select('*')
      .eq('group_id', groupId)
      .eq('status', 'active');

    // Fetch members
    const { data: membersData } = await supabase
      .from('acircle_members')
      .select('user_id, role, profiles(id, username)')
      .eq('group_id', groupId);

    // Fetch assignments
    const { data: assignmentsData } = await supabase
      .from('acircle_goal_assignments')
      .select(`
        *,
        acircle_group_goals(id, title, description),
        profiles(id, username)
      `)
      .eq('group_id', groupId)
      .eq('status', 'active');

    setGoals(goalsData || []);
    setMembers(membersData?.map(m => ({
      id: m.profiles.id,
      username: m.profiles.username,
      role: m.role
    })) || []);
    setAssignments(assignmentsData?.map(a => ({
      id: a.id,
      goal: a.acircle_group_goals,
      assigned_to: a.assigned_to,
      member: { id: a.profiles.id, username: a.profiles.username, role: '' },
      status: a.status
    })) || []);
  };

  const handleAssign = async () => {
    if (!selectedGoal || !selectedMember) return;

    try {
      const { error } = await supabase
        .from('acircle_goal_assignments')
        .insert({
          group_id: groupId,
          goal_id: selectedGoal,
          assigned_to: selectedMember,
          assigned_by: (await supabase.auth.getUser()).data.user?.id
        });

      if (error) throw error;

      setSelectedGoal('');
      setSelectedMember('');
      fetchData();
    } catch (error) {
      console.error('Error assigning goal:', error);
    }
  };

  if (!['admin', 'moderator'].includes(userRole)) {
    return null;
  }

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm">
          <UserPlus className="w-4 h-4 mr-2" />
          Assign Goals
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Goal Assignment Manager</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Select value={selectedGoal} onValueChange={setSelectedGoal}>
                <SelectTrigger>
                  <SelectValue placeholder="Select goal" />
                </SelectTrigger>
                <SelectContent>
                  {goals.map(goal => (
                    <SelectItem key={goal.id} value={goal.id}>
                      {goal.title}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Select value={selectedMember} onValueChange={setSelectedMember}>
                <SelectTrigger>
                  <SelectValue placeholder="Select member" />
                </SelectTrigger>
                <SelectContent>
                  {members.map(member => (
                    <SelectItem key={member.id} value={member.id}>
                      {member.username}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <Button onClick={handleAssign} disabled={!selectedGoal || !selectedMember}>
            Assign Goal
          </Button>
          
          <div className="space-y-2 max-h-60 overflow-y-auto">
            <h4 className="font-medium">Current Assignments</h4>
            {assignments.map(assignment => (
              <Card key={assignment.id}>
                <CardContent className="p-3">
                  <div className="flex justify-between items-center">
                    <div>
                      <span className="font-medium">{assignment.goal.title}</span>
                      <span className="text-sm text-gray-600 ml-2">
                        → {assignment.member.username}
                      </span>
                    </div>
                    <Badge variant="secondary">{assignment.status}</Badge>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}