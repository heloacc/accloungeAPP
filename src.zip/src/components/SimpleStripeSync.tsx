import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { CreditCard, Plus, Edit, Trash2, RefreshCw, ExternalLink } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { toast } from '@/components/ui/use-toast';

interface SubscriptionTier {
  id: string;
  name: string;
  description?: string;
  price_monthly: string;
  price_yearly: string;
  currency: string;
  is_active: boolean;
  features: string[] | null;
  stripe_product_id?: string;
}

export default function SimpleStripeSync() {
  const [tiers, setTiers] = useState<SubscriptionTier[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingTier, setEditingTier] = useState<SubscriptionTier | null>(null);
  
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    price_monthly: '',
    price_yearly: '',
    features: '',
    stripe_product_id: ''
  });

  useEffect(() => {
    fetchTiers();
  }, []);

  const fetchTiers = async () => {
    try {
      const { data, error } = await supabase
        .from('subscription_tiers')
        .select('*')
        .order('price_monthly', { ascending: true });

      if (error) throw error;
      setTiers(data || []);
    } catch (error) {
      console.error('Error fetching tiers:', error);
      toast({
        title: "Error",
        description: "Failed to fetch subscription tiers",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const tierData = {
        name: formData.name,
        description: formData.description || null,
        price_monthly: formData.price_monthly,
        price_yearly: formData.price_yearly || '0.00',
        currency: 'USD',
        billing_interval: 'monthly',
        features: formData.features ? formData.features.split('\n').filter(f => f.trim()) : null,
        is_active: true,
        stripe_product_id: formData.stripe_product_id || null
      };

      if (editingTier) {
        const { error } = await supabase
          .from('subscription_tiers')
          .update(tierData)
          .eq('id', editingTier.id);
        
        if (error) throw error;
        toast({ title: "Success", description: "Tier updated successfully" });
      } else {
        const { error } = await supabase
          .from('subscription_tiers')
          .insert([tierData]);
        
        if (error) throw error;
        toast({ title: "Success", description: "Tier created successfully" });
      }

      resetForm();
      fetchTiers();
    } catch (error) {
      console.error('Error saving tier:', error);
      toast({
        title: "Error",
        description: "Failed to save subscription tier. Check console for details.",
        variant: "destructive"
      });
    }
  };

  const deleteTier = async (tierId: string) => {
    if (!confirm('Are you sure you want to delete this tier?')) return;

    try {
      const { error } = await supabase
        .from('subscription_tiers')
        .delete()
        .eq('id', tierId);

      if (error) throw error;
      
      toast({ title: "Success", description: "Tier deleted successfully" });
      fetchTiers();
    } catch (error) {
      console.error('Error deleting tier:', error);
      toast({
        title: "Error",
        description: "Failed to delete tier",
        variant: "destructive"
      });
    }
  };

  const editTier = (tier: SubscriptionTier) => {
    setEditingTier(tier);
    setFormData({
      name: tier.name,
      description: tier.description || '',
      price_monthly: tier.price_monthly,
      price_yearly: tier.price_yearly,
      features: tier.features ? tier.features.join('\n') : '',
      stripe_product_id: tier.stripe_product_id || ''
    });
    setShowForm(true);
  };

  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      price_monthly: '',
      price_yearly: '',
      features: '',
      stripe_product_id: ''
    });
    setEditingTier(null);
    setShowForm(false);
  };

  if (loading) {
    return <div className="p-6">Loading subscription tiers...</div>;
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <CreditCard className="h-6 w-6" />
            Subscription Tiers & Stripe Sync
          </h2>
          <p className="text-muted-foreground">
            Create tiers and link them to Stripe products for payment processing
          </p>
        </div>
        <div className="flex gap-2">
          <Button 
            onClick={() => window.open('https://dashboard.stripe.com/products', '_blank')}
            variant="outline"
          >
            <ExternalLink className="h-4 w-4 mr-2" />
            Stripe Dashboard
          </Button>
          <Button onClick={() => setShowForm(true)} className="bg-[#623822] hover:bg-[#4a2a1a]">
            <Plus className="h-4 w-4 mr-2" />
            Add Tier
          </Button>
        </div>
      </div>

      <Card className="bg-blue-50 border-blue-200">
        <CardContent className="p-4">
          <h3 className="font-semibold text-blue-900 mb-2">How It Works:</h3>
          <ol className="text-sm text-blue-800 space-y-1 list-decimal list-inside">
            <li>Create subscription tiers here with pricing and features</li>
            <li>Create matching products in your Stripe Dashboard</li>
            <li>Copy the Stripe Product ID and link it to your tier</li>
            <li>Customers pay through Stripe, then access is granted based on the product ID</li>
          </ol>
        </CardContent>
      </Card>

      {showForm && (
        <Card>
          <CardHeader>
            <CardTitle>{editingTier ? 'Edit Tier' : 'Create New Tier'}</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Tier Name *</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="e.g. Premium, Pro, Enterprise"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="stripe_product_id">Stripe Product ID</Label>
                  <Input
                    id="stripe_product_id"
                    value={formData.stripe_product_id}
                    onChange={(e) => setFormData({ ...formData, stripe_product_id: e.target.value })}
                    placeholder="prod_xxxxxxxxxx"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="price_monthly">Monthly Price (USD) *</Label>
                  <Input
                    id="price_monthly"
                    type="number"
                    step="0.01"
                    value={formData.price_monthly}
                    onChange={(e) => setFormData({ ...formData, price_monthly: e.target.value })}
                    placeholder="9.99"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="price_yearly">Yearly Price (USD)</Label>
                  <Input
                    id="price_yearly"
                    type="number"
                    step="0.01"
                    value={formData.price_yearly}
                    onChange={(e) => setFormData({ ...formData, price_yearly: e.target.value })}
                    placeholder="99.99"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Brief description of this tier"
                  rows={2}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="features">Features (one per line)</Label>
                <Textarea
                  id="features"
                  value={formData.features}
                  onChange={(e) => setFormData({ ...formData, features: e.target.value })}
                  placeholder="Unlimited groups&#10;Priority support&#10;Advanced analytics"
                  rows={4}
                />
              </div>

              <div className="flex gap-2">
                <Button type="submit" className="bg-[#623822] hover:bg-[#4a2a1a]">
                  {editingTier ? 'Update Tier' : 'Create Tier'}
                </Button>
                <Button type="button" variant="outline" onClick={resetForm}>
                  Cancel
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {tiers.map((tier) => (
          <Card key={tier.id} className={!tier.is_active ? 'opacity-60' : ''}>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">{tier.name}</CardTitle>
                <div className="flex items-center gap-2">
                  <Badge variant={tier.is_active ? "default" : "secondary"}>
                    {tier.is_active ? 'Active' : 'Inactive'}
                  </Badge>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => editTier(tier)}
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => deleteTier(tier.id)}
                    className="text-red-600 hover:text-red-700"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              {tier.description && (
                <p className="text-sm text-muted-foreground">{tier.description}</p>
              )}
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="text-2xl font-bold">
                  ${tier.price_monthly}/month
                  {tier.price_yearly !== '0.00' && (
                    <div className="text-sm font-normal text-muted-foreground">
                      or ${tier.price_yearly}/year
                    </div>
                  )}
                </div>

                {tier.stripe_product_id && (
                  <div className="text-xs text-muted-foreground">
                    Stripe ID: {tier.stripe_product_id}
                  </div>
                )}
                
                {tier.features && tier.features.length > 0 && (
                  <div>
                    <p className="text-sm font-medium mb-2">Features:</p>
                    <ul className="text-sm space-y-1">
                      {tier.features.map((feature, index) => (
                        <li key={index} className="flex items-center gap-2">
                          <span className="w-1.5 h-1.5 bg-[#623822] rounded-full"></span>
                          {feature}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {tiers.length === 0 && (
        <Card>
          <CardContent className="p-6 text-center">
            <CreditCard className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
            <h3 className="text-lg font-semibold mb-2">No Subscription Tiers Found</h3>
            <p className="text-muted-foreground mb-4">
              Create your first subscription tier to get started with payments.
            </p>
            <Button onClick={() => setShowForm(true)} className="bg-[#623822] hover:bg-[#4a2a1a]">
              <Plus className="h-4 w-4 mr-2" />
              Create Tier
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}