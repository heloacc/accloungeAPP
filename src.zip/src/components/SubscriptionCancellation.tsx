import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { AlertTriangle, CreditCard } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { toast } from '@/components/ui/use-toast';
import { useAppContext } from '@/contexts/AppContext';

const SubscriptionCancellation: React.FC = () => {
  const { currentUser } = useAppContext();
  const [loading, setLoading] = useState(false);

  const cancelSubscription = async () => {
    if (!currentUser?.id) return;
    
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('subscription-management', {
        body: { 
          action: 'cancel_subscription',
          user_id: currentUser.id
        }
      });

      if (error) throw error;

      toast({
        title: "Subscription Cancelled",
        description: "Your subscription has been cancelled successfully. You'll retain access until the end of your billing period.",
      });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || 'Failed to cancel subscription',
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <CreditCard className="h-5 w-5" />
          Cancel Subscription
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-start gap-3 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
          <AlertTriangle className="h-5 w-5 text-yellow-600 mt-0.5" />
          <div>
            <p className="font-medium text-yellow-800">Important Notice</p>
            <p className="text-sm text-yellow-700 mt-1">
              Cancelling your subscription will end your access to premium features at the end of your current billing period.
            </p>
          </div>
        </div>
        
        <Button 
          onClick={cancelSubscription}
          disabled={loading}
          variant="destructive"
          className="w-full"
        >
          {loading ? 'Cancelling...' : 'Cancel My Subscription'}
        </Button>
      </CardContent>
    </Card>
  );
};

export default SubscriptionCancellation;