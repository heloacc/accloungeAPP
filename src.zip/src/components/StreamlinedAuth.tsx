import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { supabase } from '@/lib/supabase';
import { Mail, ArrowRight, Loader2 } from 'lucide-react';
import LoginForm from './LoginForm';
import { OnboardingPWAPrompt } from './OnboardingPWAPrompt';
import AvatarUpload from './AvatarUpload';

interface StreamlinedAuthProps {
  onSuccess: () => void;
}

const StreamlinedAuth = ({ onSuccess }: StreamlinedAuthProps) => {
  const [mode, setMode] = useState<'choice' | 'signup' | 'login'>('choice');
  const [step, setStep] = useState<'email' | 'verify' | 'name' | 'avatar' | 'questions' | 'pwa-setup'>('email');
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [avatarUrl, setAvatarUrl] = useState('');
  const [questions, setQuestions] = useState({
    q1: '', // What brings you to AccLounge?
    q2: '', // What's one habit you're excited to build?
    q3: ''  // How do you prefer to be supported?
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');
  const [resendCooldown, setResendCooldown] = useState(0);

  // Check if user is already authenticated and needs onboarding
  // Check if user is already authenticated and needs onboarding
  useEffect(() => {
    const checkAuthStatus = async () => {
      try {
        const timeoutPromise = new Promise((_, reject) => 
          setTimeout(() => reject(new Error('Auth check timeout')), 800)
        );
        
        const authPromise = supabase.auth.getSession();
        
        const result = await Promise.race([authPromise, timeoutPromise]).catch(() => ({
          data: { session: null },
          error: null
        }));
        
        const { data: { session } } = result as any;
        
        if (session?.user) {
          // User is authenticated, check their profile with timeout
          const profilePromise = supabase
            .from('profiles')
            .select('name, onboarding_completed, role')
            .eq('id', session.user.id)
            .single();
            
          const profileTimeoutPromise = new Promise((_, reject) => 
            setTimeout(() => reject(new Error('Profile check timeout')), 600)
          );
          
          const profileResult = await Promise.race([profilePromise, profileTimeoutPromise]).catch(() => ({
            data: null,
            error: null
          }));
          
          const { data: profile } = profileResult as any;
          
          if (!profile?.onboarding_completed) {
            // User needs to complete onboarding
            setMode('signup');
            if (!profile?.name) {
              setStep('name');
            } else {
              setStep('questions');
            }
            setEmail(session.user.email || '');
            setName(profile?.name || '');
          }
        }
      } catch (error) {
        console.log('Auth check failed or timed out:', error);
        // Don't block the UI if auth check fails
      }
    };
    
    checkAuthStatus();
  }, []);

  // Cooldown timer effect
  useEffect(() => {
    if (resendCooldown > 0) {
      const timer = setTimeout(() => setResendCooldown(resendCooldown - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [resendCooldown]);

  const handleEmailSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const { error } = await supabase.auth.signUp({
        email,
        password: Math.random().toString(36).slice(-8) + 'A1!', // Temporary password
        options: {
          emailRedirectTo: `${window.location.origin}/auth/callback`
        }
      });

      if (error) throw error;

      setMessage('Check your email for a verification link!');
      setStep('verify');
      setResendCooldown(60); // 60 second cooldown
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleResendEmail = async () => {
    if (resendCooldown > 0) return;
    
    setLoading(true);
    setError('');

    try {
      const { error } = await supabase.auth.resend({
        type: 'signup',
        email,
        options: {
          emailRedirectTo: `${window.location.origin}/auth/callback`
        }
      });

      if (error) throw error;

      setMessage('Verification email sent again!');
      setResendCooldown(60); // 60 second cooldown
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleNameSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const { data: { user } } = await supabase.auth.getUser();
    if (user) {
      // Update profile with name
      await supabase.from('profiles').upsert({
        id: user.id,
        email: user.email,
        name: name.trim()
      });
      setStep('avatar');
    }
  };

  const handleQuestionsSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('No user found');

      // Save intro questions
      await supabase.from('intro_questions').insert({
        user_id: user.id,
        question_1: questions.q1,
        question_2: questions.q2,
        question_3: questions.q3
      });

      // Create intro post content
      const introContent = `👋 Hey everyone! I'm ${name} and I'm excited to join AccLounge!

🎯 What brings me here: ${questions.q1}

💪 One habit I'm excited to build: ${questions.q2}

🤝 How I prefer to be supported: ${questions.q3}

Looking forward to connecting with you all! 🚀`;

      // Create intro post
      await supabase.from('posts').insert({
        user_id: user.id,
        author_name: name,
        content: introContent,
        category: 'Mindset',
        is_intro_post: true
      });

      // Mark onboarding as complete
      await supabase.from('profiles').update({
        onboarding_completed: true
      }).eq('id', user.id);

      // Move to PWA setup step
      setStep('pwa-setup');
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };
  // Show login/signup choice first
  if (mode === 'choice') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 p-4">
        <Card className="w-full max-w-md mx-auto">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl">Welcome to AccLounge</CardTitle>
            <p className="text-muted-foreground">Your accountability community awaits</p>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button 
              onClick={() => setMode('signup')} 
              className="w-full"
            >
              Join AccLounge
            </Button>
            <Button 
              onClick={() => setMode('login')} 
              variant="outline" 
              className="w-full"
            >
              I already have an account
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Show login form for existing users
  if (mode === 'login') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 p-4">
        <LoginForm 
          onSuccess={() => {
            console.log('Login success callback triggered');
            onSuccess();
          }}
          onSwitchToSignup={() => setMode('signup')}
        />
      </div>
    );
  }

  // Signup flow for new users only
  if (mode === 'signup' && step === 'email') {
    return (
      <Card className="w-full max-w-md mx-auto">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl">Join AccLounge</CardTitle>
          <p className="text-muted-foreground">Enter your email to get started</p>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleEmailSubmit} className="space-y-4">
            <div>
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="your@email.com"
                required
              />
            </div>
            {error && (
              <Alert variant="destructive">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}
            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Mail className="h-4 w-4 mr-2" />}
              Continue with Email
            </Button>
            <div className="text-center">
              <Button 
                type="button"
                variant="link" 
                onClick={() => setMode('login')}
                className="text-sm"
              >
                Already have an account? Sign in
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    );
  }

  if (mode === 'signup' && step === 'verify') {
    return (
      <Card className="w-full max-w-md mx-auto">
        <CardHeader className="text-center">
          <CardTitle>✅ Verification Email Sent!</CardTitle>
          <p className="text-muted-foreground">We sent a verification link to <strong>{email}</strong></p>
        </CardHeader>
        <CardContent className="text-center">
          <div className="space-y-4">
            <div className="p-6 bg-green-50 rounded-lg border border-green-200">
              <Mail className="h-12 w-12 mx-auto mb-3 text-green-600" />
              <p className="text-green-800 font-medium mb-2">Check your inbox!</p>
              <p className="text-sm text-green-700">Click the verification link in your email to continue setting up your account</p>
              <p className="text-xs text-green-600 mt-3">
                The link will bring you back here to complete your profile
              </p>
            </div>
            {message && (
              <Alert>
                <AlertDescription>{message}</AlertDescription>
              </Alert>
            )}
            {error && (
              <Alert variant="destructive">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}
            <div className="space-y-3">
              <Button 
                onClick={handleResendEmail}
                variant="outline" 
                className="w-full"
                disabled={loading || resendCooldown > 0}
              >
                {loading ? (
                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                ) : (
                  <Mail className="h-4 w-4 mr-2" />
                )}
                {resendCooldown > 0 
                  ? `Resend in ${resendCooldown}s` 
                  : 'Resend verification email'
                }
              </Button>
              <p className="text-xs text-gray-500">
                Didn't receive an email? Check your spam folder
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (mode === 'signup' && step === 'name') {
    return (
      <Card className="w-full max-w-md mx-auto">
        <CardHeader className="text-center">
          <CardTitle>What's your name?</CardTitle>
          <p className="text-muted-foreground">This is how you'll appear to other members</p>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleNameSubmit} className="space-y-4">
            <div>
              <Label htmlFor="name">Full Name</Label>
              <Input
                id="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Enter your name"
                required
              />
            </div>
            <Button type="submit" className="w-full">
              Continue
              <ArrowRight className="h-4 w-4 ml-2" />
            </Button>
          </form>
        </CardContent>
      </Card>
    );
  }

  // Avatar upload step
  if (mode === 'signup' && step === 'avatar') {
    return (
      <Card className="w-full max-w-md mx-auto">
        <CardHeader className="text-center">
          <CardTitle>Add a profile photo</CardTitle>
          <p className="text-muted-foreground">Help others recognize you in the community (optional)</p>
        </CardHeader>
        <CardContent className="space-y-6">
          <AvatarUpload
            currentAvatar={avatarUrl}
            userName={name}
            onAvatarUpdate={setAvatarUrl}
            size="xl"
          />
          <div className="flex gap-3">
            <Button 
              variant="outline" 
              onClick={() => setStep('questions')}
              className="flex-1"
            >
              Skip for now
            </Button>
            <Button 
              onClick={() => setStep('questions')}
              className="flex-1"
            >
              Continue
              <ArrowRight className="h-4 w-4 ml-2" />
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Questions step for signup only
  if (mode === 'signup' && step === 'questions') {
    return (
      <Card className="w-full max-w-2xl mx-auto">
        <CardHeader className="text-center">
          <CardTitle>Tell us about yourself</CardTitle>
          <p className="text-muted-foreground">Your answers will be shared as your intro post to help others connect with you</p>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleQuestionsSubmit} className="space-y-6">
            <div>
              <Label htmlFor="q1" className="text-base font-medium">What brings you to AccLounge?</Label>
              <Input
                id="q1"
                value={questions.q1}
                onChange={(e) => setQuestions({...questions, q1: e.target.value})}
                placeholder="e.g., I want to build better habits and find accountability..."
                className="mt-2"
                required
              />
            </div>
            <div>
              <Label htmlFor="q2" className="text-base font-medium">What's one habit you're excited to build?</Label>
              <Input
                id="q2"
                value={questions.q2}
                onChange={(e) => setQuestions({...questions, q2: e.target.value})}
                placeholder="e.g., Daily meditation, regular exercise, reading..."
                className="mt-2"
                required
              />
            </div>
            <div>
              <Label htmlFor="q3" className="text-base font-medium">How do you prefer to be supported?</Label>
              <Input
                id="q3"
                value={questions.q3}
                onChange={(e) => setQuestions({...questions, q3: e.target.value})}
                placeholder="e.g., Daily check-ins, weekly goals, gentle reminders..."
                className="mt-2"
                required
              />
            </div>
            {error && (
              <Alert variant="destructive">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}
            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
              Complete Setup & Join Community
            </Button>
          </form>
        </CardContent>
      </Card>
    );
  }

  // PWA setup step for new users
  if (mode === 'signup' && step === 'pwa-setup') {
    return (
      <OnboardingPWAPrompt onComplete={onSuccess} />
    );
  }

  // Fallback - should not reach here
  return null;
};

export default StreamlinedAuth;