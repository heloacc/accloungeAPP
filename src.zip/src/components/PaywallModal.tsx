import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Lock, Crown, ExternalLink } from 'lucide-react';

interface PaywallModalProps {
  isOpen: boolean;
  onClose: () => void;
  feature: string;
  requiredTier?: string;
  reason: 'no_tier' | 'upgrade_required' | 'restricted_by_invite';
}

export default function PaywallModal({ 
  isOpen, 
  onClose, 
  feature, 
  requiredTier = 'Premium',
  reason 
}: PaywallModalProps) {
  
  const getTitle = () => {
    switch (reason) {
      case 'no_tier':
        return 'Subscription Required';
      case 'upgrade_required':
        return 'Upgrade Required';
      case 'restricted_by_invite':
        return 'Access Restricted';
      default:
        return 'Premium Feature';
    }
  };

  const getDescription = () => {
    switch (reason) {
      case 'no_tier':
        return 'This feature requires an active subscription plan.';
      case 'upgrade_required':
        return `This feature requires the ${requiredTier} plan or higher.`;
      case 'restricted_by_invite':
        return 'This feature is not available with your current invite permissions.';
      default:
        return 'This is a premium feature.';
    }
  };

  const handleUpgrade = () => {
    // In a real implementation, this would redirect to Stripe Checkout
    // For now, we'll just show a placeholder
    window.open('https://billing.stripe.com/p/login/test_placeholder', '_blank');
  };

  if (reason === 'restricted_by_invite') {
    return (
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Lock className="w-5 h-5 text-orange-500" />
              {getTitle()}
            </DialogTitle>
            <DialogDescription>
              {getDescription()}
            </DialogDescription>
          </DialogHeader>
          
          <div className="text-center py-6">
            <p className="text-sm text-muted-foreground">
              Contact your administrator for access to this feature.
            </p>
          </div>

          <div className="flex justify-end">
            <Button variant="outline" onClick={onClose}>
              Close
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Crown className="w-5 h-5 text-yellow-500" />
            {getTitle()}
          </DialogTitle>
          <DialogDescription>
            {getDescription()}
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4 py-4">
          <div className="bg-gradient-to-r from-blue-50 to-purple-50 p-4 rounded-lg border">
            <div className="flex items-center justify-between mb-2">
              <h4 className="font-semibold">Requested Feature</h4>
              <Badge variant="secondary">{feature}</Badge>
            </div>
            <p className="text-sm text-muted-foreground">
              Unlock this feature and many more with {requiredTier}.
            </p>
          </div>

          <div className="bg-gray-50 p-4 rounded-lg">
            <h4 className="font-semibold mb-2">{requiredTier} Plan Benefits</h4>
            <ul className="text-sm space-y-1 text-muted-foreground">
              <li>• Access to all premium features</li>
              <li>• Advanced analytics and insights</li>
              <li>• Priority customer support</li>
              <li>• Unlimited accountability groups</li>
            </ul>
          </div>
        </div>

        <div className="flex gap-2">
          <Button onClick={handleUpgrade} className="flex-1 flex items-center gap-2">
            <ExternalLink className="w-4 h-4" />
            Upgrade to {requiredTier}
          </Button>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}