import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Loader2, CheckCircle, XCircle } from 'lucide-react';

interface AuthCallbackProps {
  onVerificationComplete: () => void;
}

const AuthCallback = ({ onVerificationComplete }: AuthCallbackProps) => {
  const [status, setStatus] = useState<'loading' | 'success' | 'error'>('loading');
  const [message, setMessage] = useState('');

  useEffect(() => {
    const handleAuthCallback = async () => {
      try {
        // Get URL parameters for auth callback
        const urlParams = new URLSearchParams(window.location.search);
        const hashParams = new URLSearchParams(window.location.hash.substring(1));
        
        // Check for auth callback parameters
        const accessToken = hashParams.get('access_token');
        const refreshToken = hashParams.get('refresh_token');
        const type = urlParams.get('type') || hashParams.get('type');
        
        if (accessToken && refreshToken) {
          // Set the session using the tokens from the callback
          const { data, error } = await supabase.auth.setSession({
            access_token: accessToken,
            refresh_token: refreshToken
          });
          
          if (error) {
            console.error('Session setup error:', error);
            throw error;
          }
          
          if (data.session?.user) {
            setStatus('success');
            setMessage('Email verified successfully!');
            // Immediate callback for better UX - no artificial delay needed
            onVerificationComplete();
          } else {
            throw new Error('No session created after verification');
          }
        } else {
          // Fallback: try to get current session
          const { data, error } = await supabase.auth.getSession();
          
          if (error) {
            console.error('Auth callback error:', error);
            throw error;
          }

          if (data.session?.user) {
            setStatus('success');
            setMessage('Email verified successfully!');
            // Immediate callback for better UX - no artificial delay needed
            onVerificationComplete();
          } else {
            throw new Error('No valid session found');
          }
        }
      } catch (error: any) {
        console.error('Verification error:', error);
        setStatus('error');
        setMessage(error.message || 'Verification failed. Please try signing in again.');
      }
    };

    handleAuthCallback();
  }, [onVerificationComplete]);


  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <CardTitle>Email Verification</CardTitle>
        </CardHeader>
        <CardContent className="text-center space-y-4">
          {status === 'loading' && (
            <>
              <Loader2 className="h-12 w-12 animate-spin mx-auto text-blue-500" />
              <p>Verifying your email...</p>
            </>
          )}
          
          {status === 'success' && (
            <>
              <CheckCircle className="h-12 w-12 mx-auto text-green-500" />
              <p className="text-green-600">{message}</p>
              <p className="text-sm text-gray-500">Redirecting you to continue setup...</p>
            </>
          )}
          
          {status === 'error' && (
            <>
              <XCircle className="h-12 w-12 mx-auto text-red-500" />
              <p className="text-red-600">{message}</p>
              <p className="text-sm text-gray-500">Please try again or contact support.</p>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default AuthCallback;