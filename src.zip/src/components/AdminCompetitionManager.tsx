import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Flame, Plus, Calendar, Users, Trash2 } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';

interface Competition {
  id: string;
  habit_name: string;
  end_date: string;
  created_at: string;
  participant_count?: number;
}

export const AdminCompetitionManager = () => {
  const [competitions, setCompetitions] = useState<Competition[]>([]);
  const [habits, setHabits] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [newCompetition, setNewCompetition] = useState({
    habit_name: '',
    end_date: '',
    duration_days: 30
  });

  useEffect(() => {
    fetchCompetitions();
    fetchAvailableHabits();
  }, []);

  const fetchCompetitions = async () => {
    try {
      const { data, error } = await supabase
        .from('streak_competitions')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;

      const competitionsWithCounts = await Promise.all(
        (data || []).map(async (comp) => {
          const { count } = await supabase
            .from('streak_competition_participants')
            .select('*', { count: 'exact' })
            .eq('competition_id', comp.id);

          return { ...comp, participant_count: count || 0 };
        })
      );

      setCompetitions(competitionsWithCounts);
    } catch (error) {
      console.error('Error fetching competitions:', error);
      toast({
        title: "Error",
        description: "Failed to load competitions",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchAvailableHabits = async () => {
    try {
      const { data, error } = await supabase
        .from('habits')
        .select('name')
        .not('name', 'is', null);

      if (error) throw error;

      const uniqueHabits = [...new Set(data?.map(h => h.name) || [])];
      setHabits(uniqueHabits);
    } catch (error) {
      console.error('Error fetching habits:', error);
    }
  };

  const createCompetition = async () => {
    if (!newCompetition.habit_name || !newCompetition.end_date) {
      toast({
        title: "Error",
        description: "Please fill in all required fields",
        variant: "destructive"
      });
      return;
    }

    try {
      const { error } = await supabase
        .from('streak_competitions')
        .insert({
          habit_name: newCompetition.habit_name,
          end_date: newCompetition.end_date,
          created_at: new Date().toISOString()
        });

      if (error) throw error;

      toast({
        title: "Success",
        description: "Competition created successfully!"
      });

      setIsCreateOpen(false);
      setNewCompetition({ habit_name: '', end_date: '', duration_days: 30 });
      fetchCompetitions();
    } catch (error) {
      console.error('Error creating competition:', error);
      toast({
        title: "Error",
        description: "Failed to create competition",
        variant: "destructive"
      });
    }
  };

  const deleteCompetition = async (id: string) => {
    if (!confirm('Are you sure you want to delete this competition?')) return;

    try {
      await supabase
        .from('streak_competition_participants')
        .delete()
        .eq('competition_id', id);

      const { error } = await supabase
        .from('streak_competitions')
        .delete()
        .eq('id', id);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Competition deleted successfully"
      });

      fetchCompetitions();
    } catch (error) {
      console.error('Error deleting competition:', error);
      toast({
        title: "Error",
        description: "Failed to delete competition",
        variant: "destructive"
      });
    }
  };

  const getEndDate = (days: number) => {
    const date = new Date();
    date.setDate(date.getDate() + days);
    return date.toISOString().split('T')[0];
  };

  if (loading) {
    return <div className="text-center p-8">Loading competitions...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Competition Management</h2>
          <p className="text-muted-foreground">Create and manage streak competitions</p>
        </div>
        
        <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
          <DialogTrigger asChild>
            <Button className="flex items-center gap-2">
              <Plus className="w-4 h-4" />
              Create Competition
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create New Competition</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="habit">Habit Name</Label>
                <Select value={newCompetition.habit_name} onValueChange={(value) => 
                  setNewCompetition(prev => ({ ...prev, habit_name: value }))
                }>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a habit" />
                  </SelectTrigger>
                  <SelectContent>
                    {habits.map(habit => (
                      <SelectItem key={habit} value={habit}>{habit}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label htmlFor="duration">Duration</Label>
                <Select value={newCompetition.duration_days.toString()} onValueChange={(value) => {
                  const days = parseInt(value);
                  setNewCompetition(prev => ({ 
                    ...prev, 
                    duration_days: days,
                    end_date: getEndDate(days)
                  }));
                }}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="7">1 Week</SelectItem>
                    <SelectItem value="14">2 Weeks</SelectItem>
                    <SelectItem value="30">1 Month</SelectItem>
                    <SelectItem value="60">2 Months</SelectItem>
                    <SelectItem value="90">3 Months</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="end_date">End Date</Label>
                <Input
                  id="end_date"
                  type="date"
                  value={newCompetition.end_date}
                  onChange={(e) => setNewCompetition(prev => ({ ...prev, end_date: e.target.value }))}
                />
              </div>

              <Button onClick={createCompetition} className="w-full">
                Create Competition
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-4">
        {competitions.map((competition) => (
          <Card key={competition.id}>
            <CardContent className="p-4">
              <div className="flex justify-between items-start">
                <div className="flex items-start gap-3">
                  <Flame className="w-5 h-5 text-orange-500 mt-1" />
                  <div>
                    <h3 className="font-semibold text-lg">{competition.habit_name} Competition</h3>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground mt-1">
                      <div className="flex items-center gap-1">
                        <Calendar className="w-4 h-4" />
                        Ends: {new Date(competition.end_date).toLocaleDateString()}
                      </div>
                      <div className="flex items-center gap-1">
                        <Users className="w-4 h-4" />
                        {competition.participant_count} participants
                      </div>
                    </div>
                    <Badge variant={new Date(competition.end_date) > new Date() ? "default" : "secondary"} className="mt-2">
                      {new Date(competition.end_date) > new Date() ? "Active" : "Ended"}
                    </Badge>
                  </div>
                </div>
                
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => deleteCompetition(competition.id)}
                    className="text-red-600 hover:text-red-700"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {competitions.length === 0 && (
        <Card>
          <CardContent className="p-8 text-center">
            <Flame className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">No Competitions Yet</h3>
            <p className="text-muted-foreground mb-4">Create your first streak competition to get started.</p>
            <Button onClick={() => setIsCreateOpen(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Create Competition
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default AdminCompetitionManager;