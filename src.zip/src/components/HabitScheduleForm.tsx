import React from 'react';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Input } from '@/components/ui/input';

interface ScheduleData {
  frequency: 'daily' | 'weekly' | 'custom';
  weekdays?: string[];
  customDays?: number;
}

interface HabitScheduleFormProps {
  schedule: ScheduleData;
  onChange: (schedule: ScheduleData) => void;
}

const WEEKDAYS = [
  { id: 'monday', label: 'Mon' },
  { id: 'tuesday', label: 'Tue' },
  { id: 'wednesday', label: 'Wed' },
  { id: 'thursday', label: 'Thu' },
  { id: 'friday', label: 'Fri' },
  { id: 'saturday', label: 'Sat' },
  { id: 'sunday', label: 'Sun' }
];

export default function HabitScheduleForm({ schedule, onChange }: HabitScheduleFormProps) {
  const handleFrequencyChange = (frequency: string) => {
    onChange({
      ...schedule,
      frequency: frequency as 'daily' | 'weekly' | 'custom'
    });
  };

  const handleWeekdayToggle = (weekday: string, checked: boolean) => {
    const weekdays = schedule.weekdays || [];
    const updated = checked 
      ? [...weekdays, weekday]
      : weekdays.filter(day => day !== weekday);
    
    onChange({
      ...schedule,
      weekdays: updated
    });
  };

  const handleCustomDaysChange = (value: string) => {
    const days = parseInt(value) || 1;
    onChange({
      ...schedule,
      customDays: Math.max(1, Math.min(7, days))
    });
  };

  return (
    <div className="space-y-4">
      <div>
        <Label>Frequency</Label>
        <Select value={schedule.frequency} onValueChange={handleFrequencyChange}>
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="daily">Daily</SelectItem>
            <SelectItem value="weekly">Weekly</SelectItem>
            <SelectItem value="custom">Custom</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {schedule.frequency === 'weekly' && (
        <div>
          <Label>Days of the Week</Label>
          <div className="flex flex-wrap gap-2 mt-2">
            {WEEKDAYS.map((day) => (
              <div key={day.id} className="flex items-center space-x-2">
                <Checkbox
                  id={day.id}
                  checked={(schedule.weekdays || []).includes(day.id)}
                  onCheckedChange={(checked) => handleWeekdayToggle(day.id, checked as boolean)}
                />
                <Label htmlFor={day.id} className="text-sm">{day.label}</Label>
              </div>
            ))}
          </div>
        </div>
      )}

      {schedule.frequency === 'custom' && (
        <div>
          <Label htmlFor="customDays">Days per Week</Label>
          <Input
            id="customDays"
            type="number"
            min="1"
            max="7"
            value={schedule.customDays || 1}
            onChange={(e) => handleCustomDaysChange(e.target.value)}
            className="w-24"
          />
        </div>
      )}
    </div>
  );
}