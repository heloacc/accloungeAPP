import { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Download, X, Smartphone, Monitor } from 'lucide-react';
import { showInstallPrompt, getInstallPrompt } from '../utils/pwaUtils';
import { MobilePWAInstaller } from './MobilePWAInstaller';

interface EnhancedPWAPromptProps {
  showOnLoad?: boolean;
  showInOnboarding?: boolean;
  onDismiss?: () => void;
  onInstall?: () => void;
}

export function EnhancedPWAPrompt({ 
  showOnLoad = true, 
  showInOnboarding = false,
  onDismiss,
  onInstall 
}: EnhancedPWAPromptProps) {
  const [showPrompt, setShowPrompt] = useState(false);
  const [isInstalled, setIsInstalled] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  const [hasBeenDismissed, setHasBeenDismissed] = useState(false);

  useEffect(() => {
    // Check if user has dismissed the prompt before
    const dismissed = localStorage.getItem('pwa-install-dismissed');
    if (dismissed && !showInOnboarding) {
      setHasBeenDismissed(true);
      return;
    }

    // Detect mobile device
    const checkMobile = () => {
      const userAgent = navigator.userAgent;
      const isMobileDevice = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(userAgent);
      const isSmallScreen = window.innerWidth <= 768;
      return isMobileDevice || isSmallScreen;
    };

    setIsMobile(checkMobile());

    // Check if already installed
    const isStandalone = window.matchMedia('(display-mode: standalone)').matches;
    const isInWebAppiOS = (window.navigator as any).standalone === true;
    setIsInstalled(isStandalone || isInWebAppiOS);

    // Show prompt logic
    if (!isStandalone && !isInWebAppiOS && !hasBeenDismissed) {
      if (showInOnboarding) {
        // Always show during onboarding
        setShowPrompt(true);
      } else if (showOnLoad) {
        // Show on site visit with delay
        const timer = setTimeout(() => {
          setShowPrompt(true);
        }, 3000); // 3 second delay

        return () => clearTimeout(timer);
      }
    }

    // Listen for install prompt event
    const handleBeforeInstallPrompt = () => {
      if (!hasBeenDismissed) {
        setShowPrompt(true);
      }
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, [showOnLoad, showInOnboarding, hasBeenDismissed]);

  const handleInstall = async () => {
    const installed = await showInstallPrompt();
    if (installed) {
      setShowPrompt(false);
      setIsInstalled(true);
      onInstall?.();
    }
  };

  const handleDismiss = () => {
    setShowPrompt(false);
    if (!showInOnboarding) {
      localStorage.setItem('pwa-install-dismissed', 'true');
      setHasBeenDismissed(true);
    }
    onDismiss?.();
  };

  // Don't show if installed or dismissed (unless in onboarding)
  if (isInstalled || (!showPrompt && !showInOnboarding)) return null;

  // Mobile version
  if (isMobile) {
    return (
      <Card className={`${showInOnboarding ? 'w-full' : 'fixed bottom-4 left-4 right-4 z-50 mx-auto max-w-sm'}`}>
        <CardContent className="p-6">
          <div className="flex items-start gap-4">
            <div className="rounded-full bg-primary/10 p-3">
              <Smartphone className="h-6 w-6 text-primary" />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-lg">Install ACCLOUNGE</h3>
              <p className="text-sm text-muted-foreground mt-1 mb-4">
                Get the full app experience with offline access, push notifications, and faster loading.
              </p>
              <div className="space-y-2 text-xs text-muted-foreground">
                <p>📱 Add to home screen for quick access</p>
                <p>🔔 Receive accountability reminders</p>
                <p>⚡ Works offline when needed</p>
              </div>
            </div>
          </div>
          <div className="flex gap-3 mt-6">
            <Button onClick={handleInstall} className="flex-1">
              <Download className="h-4 w-4 mr-2" />
              Install App
            </Button>
            <Button variant="outline" onClick={handleDismiss}>
              <X className="h-4 w-4" />
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Desktop version
  return (
    <Card className={`${showInOnboarding ? 'w-full' : 'fixed bottom-4 right-4 z-50 max-w-sm'}`}>
      <CardContent className="p-6">
        <div className="flex items-start gap-4">
          <div className="rounded-full bg-primary/10 p-3">
            <Monitor className="h-6 w-6 text-primary" />
          </div>
          <div className="flex-1">
            <h3 className="font-semibold text-lg">Install ACCLOUNGE</h3>
            <p className="text-sm text-muted-foreground mt-1 mb-4">
              Install our desktop app for the best experience.
            </p>
            <div className="space-y-2 text-xs text-muted-foreground">
              <p>🚀 Faster loading and better performance</p>
              <p>🔔 Desktop notifications</p>
              <p>📂 Appears in your applications</p>
            </div>
          </div>
        </div>
        <div className="flex gap-3 mt-6">
          <Button onClick={handleInstall} className="flex-1">
            <Download className="h-4 w-4 mr-2" />
            Install
          </Button>
          <Button variant="outline" onClick={handleDismiss}>
            <X className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}