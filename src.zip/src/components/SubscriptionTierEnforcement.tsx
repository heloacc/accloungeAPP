import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useStableUserRole } from '@/hooks/useStableUserRole';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Lock, Crown, Zap, CheckCircle } from 'lucide-react';

interface EnforcementProps {
  children: React.ReactNode;
  pagePath: string;
}

interface TierInfo {
  name: string;
  allowed_routes: string[];
}

export const SubscriptionTierEnforcement: React.FC<EnforcementProps> = ({
  children,
  pagePath
}) => {
  const [hasAccess, setHasAccess] = useState(false);
  const [loading, setLoading] = useState(true);
  const [userTier, setUserTier] = useState<TierInfo | null>(null);
  const [requiredTier, setRequiredTier] = useState('');
  const { isAdmin } = useStableUserRole();

  useEffect(() => {
    checkAccess();
  }, [pagePath, isAdmin]);
  const checkAccess = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        setHasAccess(false);
        setLoading(false);
        return;
      }

      // Check admin/moderator status first
      const { data: userRole } = await supabase
        .from('user_roles')
        .select('role')
        .eq('user_id', user.id)
        .single();

      const role = userRole?.role?.toLowerCase();
      const isAdminOrMod = role === 'admin' || role === 'moderator';

      // Admin and Moderator bypass all subscription checks
      if (isAdminOrMod) {
        setHasAccess(true);
        setLoading(false);
        return;
      }

      // Get user tier
      const { data: subscription } = await supabase
        .from('user_subscription_links')
        .select(`
          subscription_tiers (
            name,
            allowed_routes
          )
        `)
        .eq('user_id', user.id)
        .eq('status', 'active')
        .single();

      let tier = subscription?.subscription_tiers;
      
      if (!tier) {
        const { data: freemium } = await supabase
          .from('subscription_tiers')
          .select('name, allowed_routes')
          .eq('name', 'Freemium')
          .single();
        tier = freemium;
      }

      setUserTier(tier);

      // Check access with fallback logic
      const allowedRoutes = tier?.allowed_routes || [];
      let access = allowedRoutes.includes(pagePath) || allowedRoutes.includes('*');
      
      // Fallback logic for known tier-route combinations
      if (!access && tier?.name === 'Accountability Essentials') {
        const essentialsRoutes = ['/dashboard', '/habits', '/goals', '/partnerships', '/billing', '/notifications', '/profile', '/gather', '/wins-wall', '/community-feed'];
        access = essentialsRoutes.includes(pagePath);
        
        // Auto-fix the tier routes if access should be granted
        if (access) {
          await supabase
            .from('subscription_tiers')
            .update({ allowed_routes: essentialsRoutes })
            .eq('name', 'Accountability Essentials');
        }
      }
      
      if (!access && tier?.name === 'All Access') {
        const allAccessRoutes = ['/dashboard', '/habits', '/goals', '/groups', '/partnerships', '/billing', '/notifications', '/profile', '/gather', '/wins-wall', '/community-feed', '/analytics'];
        access = allAccessRoutes.includes(pagePath);
        
        // Auto-fix the tier routes if access should be granted
        if (access) {
          await supabase
            .from('subscription_tiers')
            .update({ allowed_routes: allAccessRoutes })
            .eq('name', 'All Access');
        }
      }
      
      setHasAccess(access);
      
      if (!access) {
        if (pagePath === '/habits' || pagePath === '/goals') {
          setRequiredTier('Accountability Essentials');
        } else if (pagePath === '/partnerships') {
          setRequiredTier('Accountability Essentials');
        } else if (pagePath === '/groups') {
          setRequiredTier('All Access');
        }
      }

    } catch (error) {
      console.error('Access check failed:', error);
      setHasAccess(false);
    } finally {
      setLoading(false);
    }
  };

  const handleUpgrade = () => {
    window.dispatchEvent(new CustomEvent('navigate-to-tab', { 
      detail: { tab: 'billing' }
    }));
  };

  if (loading) {
    return <div className="flex justify-center p-8"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div></div>;
  }

  if (hasAccess) {
    return <>{children}</>;
  }

  return (
    <div className="flex items-center justify-center min-h-[400px] p-4">
      <Card className="max-w-md w-full">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <Lock className="h-12 w-12 text-orange-500" />
          </div>
          <CardTitle>Upgrade Required</CardTitle>
        </CardHeader>
        <CardContent className="text-center space-y-4">
          <p className="text-muted-foreground">
            This feature requires <strong>{requiredTier}</strong> or higher.
          </p>
          <div className="flex justify-center">
            <Badge variant="outline">{userTier?.name || 'Freemium'}</Badge>
          </div>
          <div className="space-y-2">
            <Button onClick={handleUpgrade} className="w-full">
              Upgrade Now
            </Button>
            <Button variant="outline" onClick={() => window.history.back()} className="w-full">
              Go Back
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

// Admin Tier Management Component
export const AdminTierManager: React.FC = () => {
  const [users, setUsers] = useState<any[]>([]);
  const [tiers, setTiers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [usersRes, tiersRes] = await Promise.all([
        supabase.from('profiles').select('id, email, subscription_tier').limit(20),
        supabase.from('subscription_tiers').select('*').eq('is_active', true)
      ]);
      
      setUsers(usersRes.data || []);
      setTiers(tiersRes.data || []);
    } catch (error) {
      console.error('Failed to load data:', error);
    } finally {
      setLoading(false);
    }
  };

  const assignTier = async (userId: string, tierId: string) => {
    try {
      const { error } = await supabase.functions.invoke('subscription-management', {
        body: { action: 'assignTier', userId, tierId }
      });
      
      if (!error) {
        loadData();
      }
    } catch (error) {
      console.error('Failed to assign tier:', error);
    }
  };

  if (loading) return <div className="p-4">Loading...</div>;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Tier Management</h2>
        <Badge variant="secondary">Admin Only</Badge>
      </div>
      
      <div className="grid gap-4">
        {users.map(user => (
          <Card key={user.id}>
            <CardContent className="p-4">
              <div className="flex justify-between items-center">
                <div>
                  <p className="font-medium">{user.email}</p>
                  <p className="text-sm text-muted-foreground">
                    Current: {user.subscription_tier || 'Freemium'}
                  </p>
                </div>
                <div className="flex gap-2">
                  {tiers.map(tier => (
                    <Button
                      key={tier.id}
                      size="sm"
                      variant={user.subscription_tier === tier.name ? "default" : "outline"}
                      onClick={() => assignTier(user.id, tier.id)}
                    >
                      {tier.name}
                    </Button>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};