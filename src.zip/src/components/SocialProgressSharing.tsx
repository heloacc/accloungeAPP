import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAppContext } from '@/contexts/OptimizedAppContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Textarea } from '@/components/ui/textarea';
import { Share2, Heart, MessageCircle, Trophy, Flame, TrendingUp, Send, Loader2 } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';

interface ProgressPost {
  id: string;
  user_id: string;
  user_name: string;
  avatar_url?: string;
  content: string;
  achievement: string;
  streak_count: number;
  likes: number;
  comments: number;
  timestamp: Date;
  liked: boolean;
}

export const SocialProgressSharing = () => {
  const { currentUser } = useAppContext();
  const [newPost, setNewPost] = useState('');
  const [posts, setPosts] = useState<ProgressPost[]>([]);
  const [loading, setLoading] = useState(true);
  const [posting, setPosting] = useState(false);

  useEffect(() => {
    fetchPosts();
  }, []);

  const fetchPosts = async () => {
    try {
      // Join acircle_posts with profiles table to get user info, filter by post type
      const { data: posts, error } = await supabase
        .from('acircle_posts')
        .select(`
          id,
          content,
          created_at,
          user_id,
          post_type,
          profiles!fk_acircle_posts_user_id (
            name,
            full_name,
            avatar_url
          )
        `)
        .eq('post_type', 'social_progress')
        .order('created_at', { ascending: false })
        .limit(20);
      
      if (error) throw error;

      // Transform database posts to component format
      const formattedPosts: ProgressPost[] = (posts || []).map(post => ({
        id: post.id,
        user_id: post.user_id,
        user_name: post.profiles?.name || post.profiles?.full_name || 'Community Member',
        avatar_url: post.profiles?.avatar_url,
        content: post.content,
        achievement: 'Progress Update',
        streak_count: 7, // TODO: get from user data
        likes: 0, // TODO: implement likes system
        comments: 0, // TODO: implement comments system
        timestamp: new Date(post.created_at),
        liked: false
      }));

      setPosts(formattedPosts);
    } catch (error) {
      console.error('Error fetching posts:', error);
      // Fallback to mock data if database fails
      setPosts([
        {
          id: '1',
          user_id: 'mock1',
          user_name: 'Sarah M.',
          content: 'Just hit my 30-day meditation streak! The morning clarity is incredible. Who else is building mindful habits?',
          achievement: '30 Day Streak',
          streak_count: 30,
          likes: 12,
          comments: 5,
          timestamp: new Date(Date.now() - 1 * 60 * 60 * 1000),
          liked: false
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  const shareProgress = async () => {
    if (!newPost.trim() || !currentUser) return;
    
    setPosting(true);
    try {
      const { error } = await supabase
        .from('acircle_posts')
        .insert({
          user_id: currentUser.id,
          content: newPost,
          post_type: 'social_progress',
          group_id: null
        });

      if (error) throw error;

      toast({
        title: "Progress Shared!",
        description: "Your progress has been shared with the community.",
      });

      setNewPost('');
      fetchPosts(); // Refresh posts
    } catch (error) {
      console.error('Error sharing progress:', error);
      toast({
        title: "Error",
        description: "Failed to share progress. Please try again.",
        variant: "destructive"
      });
    } finally {
      setPosting(false);
    }
  };

  const toggleLike = (postId: string) => {
    setPosts(posts.map(post => 
      post.id === postId 
        ? { ...post, liked: !post.liked, likes: post.liked ? post.likes - 1 : post.likes + 1 }
        : post
    ));
  };


  if (loading) {
    return (
      <Card>
        <CardContent className="p-6 text-center">
          <Loader2 className="w-6 h-6 animate-spin mx-auto mb-2" />
          <p className="text-muted-foreground">Loading progress posts...</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Share Progress */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Share2 className="w-5 h-5 text-[#596D59]" />
            Share Your Progress
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Textarea
            placeholder="Share your wins, milestones, or challenges with the community..."
            value={newPost}
            onChange={(e) => setNewPost(e.target.value)}
            className="min-h-[100px]"
          />
          <Button 
            onClick={shareProgress}
            disabled={!newPost.trim() || posting}
            className="bg-[#596D59] hover:bg-[#596D59]/90"
          >
            {posting ? (
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            ) : (
              <Send className="w-4 h-4 mr-2" />
            )}
            {posting ? 'Sharing...' : 'Share Progress'}
          </Button>
        </CardContent>
      </Card>

      {/* Progress Feed */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-[#596D59]" />
            Community Progress
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {posts.length === 0 ? (
            <div className="text-center py-8">
              <TrendingUp className="w-12 h-12 text-[#7E8E9D] mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-[#001B30] mb-2">No Progress Posts Yet</h3>
              <p className="text-[#7E8E9D]">Be the first to share your progress!</p>
            </div>
          ) : (
            posts.map((post) => (
              <Card key={post.id} className="border-[#596D59]/20">
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    <Avatar className="w-10 h-10">
                      <AvatarFallback className="bg-[#596D59] text-white">
                        {post.user_name.split(' ').map(n => n[0]).join('')}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <span className="font-medium text-[#001B30]">{post.user_name}</span>
                        <span className="text-xs text-[#7E8E9D]">
                          {post.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                      
                      <div className="flex items-center gap-2 mb-3">
                        <Badge className="bg-gradient-to-r from-orange-500 to-red-500 text-white">
                          <Trophy className="w-3 h-3 mr-1" />
                          {post.achievement}
                        </Badge>
                        {post.streak_count > 0 && (
                          <Badge variant="outline" className="text-orange-600 border-orange-300">
                            <Flame className="w-3 h-3 mr-1" />
                            {post.streak_count} days
                          </Badge>
                        )}
                      </div>
                      
                      <p className="text-[#2C2C44] mb-4">{post.content}</p>
                      
                      <div className="flex items-center gap-4">
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => toggleLike(post.id)}
                          className={`${post.liked ? 'text-red-600' : 'text-[#7E8E9D]'} hover:text-red-600`}
                        >
                          <Heart className={`w-4 h-4 mr-1 ${post.liked ? 'fill-current' : ''}`} />
                          {post.likes}
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          className="text-[#7E8E9D] hover:text-[#596D59]"
                        >
                          <MessageCircle className="w-4 h-4 mr-1" />
                          {post.comments}
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </CardContent>
      </Card>
    </div>
  );
};