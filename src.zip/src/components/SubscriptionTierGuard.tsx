import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Lock, Crown, Zap, Star } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';

interface TierInfo {
  id: string;
  name: string;
  description: string;
  price_monthly: string;
  stripe_product_id: string;
}

interface SubscriptionTierGuardProps {
  children: React.ReactNode;
  requiredTier: string;
  featureName?: string;
}

export default function SubscriptionTierGuard({ 
  children, 
  requiredTier, 
  featureName = "feature" 
}: SubscriptionTierGuardProps) {
  const [hasAccess, setHasAccess] = useState(false);
  const [userTier, setUserTier] = useState<string>('freemium');
  const [availableTiers, setAvailableTiers] = useState<TierInfo[]>([]);
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    checkAccess();
    loadTiers();
  }, [requiredTier]);

  const checkAccess = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        setHasAccess(false);
        setLoading(false);
        return;
      }

      // Check admin/moderator status first
      const { data: userRole } = await supabase
        .from('user_roles')
        .select('role')
        .eq('user_id', user.id)
        .single();

      const role = userRole?.role?.toLowerCase();
      const isAdminOrMod = role === 'admin' || role === 'moderator';
      setIsAdmin(isAdminOrMod);

      // Admins and Moderators have access to everything
      if (isAdminOrMod) {
        setHasAccess(true);
        setUserTier(role === 'admin' ? 'Admin' : 'Moderator');
        setLoading(false);
        return;
      }

      // Check user's subscription tier for regular users
      const { data: userSubscription, error: subError } = await supabase
        .from('user_subscription_links')
        .select(`
          tier_id,
          subscription_tiers (
            id,
            name,
            price_monthly,
            features,
            allowed_routes,
            is_active
          )
        `)
        .eq('user_id', user.id)
        .single();

      if (subError && subError.code !== 'PGRST116') {
        throw subError;
      }

      if (userSubscription?.subscription_tiers) {
        const tier = userSubscription.subscription_tiers;
        setUserTier(tier.name);
        
        // Check if current tier meets requirement
        const tierLevel = getTierLevel(tier.name);
        const requiredLevel = getTierLevel(requiredTier);
        setHasAccess(tierLevel >= requiredLevel);
      } else {
        // Default to Freemium
        setUserTier('Freemium');
        setHasAccess(requiredTier === 'Freemium');
      }
    } catch (error) {
      console.error('Error checking access:', error);
      setHasAccess(false);
    } finally {
      setLoading(false);
    }
  };

  const getTierLevel = (tierName: string): number => {
    switch (tierName) {
      case 'Freemium': return 1;
      case 'Accountability Essentials': return 2;
      case 'All Access': return 3;
      default: return 0;
    }
  };

  const loadTiers = async () => {
    try {
      const { data, error } = await supabase
        .from('subscription_tiers')
        .select('id, name, description, price_monthly, stripe_product_id')
        .eq('is_active', true)
        .order('price_monthly');

      if (error) throw error;
      setAvailableTiers(data || []);
    } catch (error) {
      console.error('Error loading tiers:', error);
    }
  };

  const handleUpgrade = async (tierId: string) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase.functions.invoke('subscription-management', {
        body: {
          action: 'createCheckoutSession',
          userId: user.id,
          tierId
        }
      });

      if (error) throw error;

      if (data.url) {
        window.location.href = data.url;
      }
    } catch (error) {
      toast({
        title: "Error creating checkout session",
        description: error instanceof Error ? error.message : "Unknown error",
        variant: "destructive"
      });
    }
  };

  const getTierIcon = (tierName: string) => {
    const normalized = tierName.toLowerCase();
    if (normalized.includes('accountability') || normalized.includes('essential')) {
      return <Star className="h-6 w-6 text-blue-500" />;
    }
    if (normalized.includes('all') && normalized.includes('access')) {
      return <Crown className="h-6 w-6 text-yellow-500" />;
    }
    if (normalized.includes('freemium')) {
      return <Lock className="h-6 w-6 text-gray-500" />;
    }
    return <Zap className="h-6 w-6 text-purple-500" />;
  };
  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[200px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (hasAccess || isAdmin) {
    return <>{children}</>;
  }

  return (
    <div className="flex items-center justify-center min-h-[400px] p-4">
      <Card className="max-w-2xl w-full">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            {getTierIcon(requiredTier)}
          </div>
          <CardTitle>Upgrade Required</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="text-center">
            <p className="text-muted-foreground mb-2">
              This {featureName} requires a subscription to access.
            </p>
            <div className="flex items-center justify-center gap-2">
              <span className="text-sm">Your current plan:</span>
              <Badge variant={userTier === 'freemium' ? 'secondary' : 'default'}>
                {userTier === 'freemium' ? 'Freemium' : userTier}
              </Badge>
            </div>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            {availableTiers.map((tier) => (
              <Card key={tier.id} className="relative">
                <CardContent className="p-4">
                  <div className="text-center space-y-3">
                    {getTierIcon(tier.name)}
                    <div>
                      <h3 className="font-semibold">{tier.name}</h3>
                      <p className="text-sm text-muted-foreground">{tier.description}</p>
                    </div>
                    <div className="text-2xl font-bold">
                      ${tier.price_monthly}
                      <span className="text-sm font-normal text-muted-foreground">/month</span>
                    </div>
                    <Button 
                      onClick={() => handleUpgrade(tier.id)}
                      className="w-full"
                      variant={tier.name.toLowerCase().includes(requiredTier.toLowerCase()) ? "default" : "outline"}
                    >
                      Choose {tier.name}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="text-center">
            <Button variant="outline" onClick={() => window.history.back()}>
              Go Back
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}