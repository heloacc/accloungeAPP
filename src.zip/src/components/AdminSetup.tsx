import React, { useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useAppContext } from '@/contexts/AppContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { Shield, UserPlus } from 'lucide-react';

const AdminSetup: React.FC = () => {
  const { currentUser } = useAppContext();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState('');

  const grantAdminAccess = async (userEmail: string) => {
    if (!currentUser) return;
    
    setLoading(true);
    try {
      // Find user by email
      const { data: users, error: userError } = await supabase
        .from('profiles')
        .select('id, email')
        .eq('email', userEmail.toLowerCase().trim())
        .single();

      if (userError || !users) {
        toast({
          title: "User Not Found",
          description: "No user found with that email address.",
          variant: "destructive"
        });
        return;
      }

      // Check if already admin
      const { data: existingRole } = await supabase
        .from('user_roles')
        .select('id')
        .eq('user_id', users.id)
        .eq('role', 'Admin')
        .single();

      if (existingRole) {
        toast({
          title: "Already Admin",
          description: "This user already has admin privileges.",
          variant: "default"
        });
        return;
      }

      // Grant admin role
      const { error: roleError } = await supabase
        .from('user_roles')
        .insert({
          user_id: users.id,
          role: 'Admin',
          permissions: { all: true },
          assigned_by: currentUser.id
        });

      if (roleError) throw roleError;

      toast({
        title: "Admin Access Granted",
        description: `${userEmail} now has admin privileges.`,
        variant: "default"
      });

      setEmail('');
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to grant admin access.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const makeCurrentUserAdmin = async () => {
    if (!currentUser) return;
    
    setLoading(true);
    try {
      const { error } = await supabase
        .from('user_roles')
        .insert({
          user_id: currentUser.id,
          role: 'Admin',
          permissions: { all: true },
          assigned_by: currentUser.id
        });

      if (error) throw error;

      toast({
        title: "Admin Access Granted",
        description: "You now have admin privileges. Please refresh the page.",
        variant: "default"
      });

      // Refresh page after a short delay
      setTimeout(() => window.location.reload(), 2000);
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to grant admin access.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto p-6 space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Admin Setup
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <h3 className="font-medium mb-4">Grant Yourself Admin Access</h3>
            <p className="text-sm text-muted-foreground mb-4">
              If you're the site owner, click below to grant yourself admin privileges.
            </p>
            <Button 
              onClick={makeCurrentUserAdmin}
              disabled={loading}
              className="w-full"
            >
              <UserPlus className="h-4 w-4 mr-2" />
              Make Me Admin
            </Button>
          </div>

          <div className="border-t pt-6">
            <h3 className="font-medium mb-4">Grant Admin Access to Another User</h3>
            <div className="space-y-4">
              <div>
                <Label htmlFor="email">User Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="user@example.com"
                />
              </div>
              <Button 
                onClick={() => grantAdminAccess(email)}
                disabled={loading || !email.trim()}
                className="w-full"
              >
                <UserPlus className="h-4 w-4 mr-2" />
                Grant Admin Access
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AdminSetup;