import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Calendar, Target, TrendingUp } from 'lucide-react';

interface Goal {
  id: string;
  title: string;
  progress_percent: number;
  state: 'active' | 'in_progress' | 'completed' | 'overdue' | 'stagnant';
  linked_habits_count: number;
  deadline?: string;
  target_date?: string;
  days_since_update?: number;
}

interface GoalsProgressProps {
  goals: Goal[];
}

export const GoalsProgress: React.FC<GoalsProgressProps> = ({ goals }) => {
  const formatDeadline = (deadline: string) => {
    const date = new Date(deadline);
    const now = new Date();
    const diffTime = date.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays < 0) return 'Overdue';
    if (diffDays === 0) return 'Due today';
    if (diffDays === 1) return 'Due tomorrow';
    return `${diffDays} days left`;
  };

  const isStagnant = (lastActivity?: string) => {
    if (!lastActivity) return false;
    const lastDate = new Date(lastActivity);
    const now = new Date();
    const diffDays = Math.ceil((now.getTime() - lastDate.getTime()) / (1000 * 60 * 60 * 24));
    return diffDays >= 7;
  };

  return (
    <Card className="mb-6">
      <CardHeader>
        <CardTitle className="text-xl font-semibold flex items-center gap-2">
          <Target className="h-5 w-5" />
          Your Goals in Progress
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {goals.map((goal) => (
           <div key={goal.id} className="p-4 rounded-lg border bg-card">
             <div className="flex justify-between items-start mb-3">
               <h3 className="font-semibold text-lg">{goal.title}</h3>
               <div className="flex gap-2">
                 {goal.state === 'overdue' && (
                   <Badge variant="destructive">Overdue</Badge>
                 )}
                 {goal.state === 'completed' && (
                   <Badge variant="default" className="bg-green-500">Completed</Badge>
                 )}
               </div>
              </div>
             
             <div className="space-y-3">
               <div>
                 <div className="flex justify-between text-sm mb-1">
                   <span>Progress</span>
                   <span className="font-medium">{goal.progress_percent}%</span>
                 </div>
                 <Progress value={goal.progress_percent} className="h-2" />
               </div>
               
               <div className="flex justify-between items-center text-sm">
                 <div className="flex items-center gap-4">
                   <span className="text-muted-foreground">
                     Fueled by {goal.linked_habits_count} daily habits
                   </span>
                 </div>
                 <TrendingUp className="h-4 w-4 text-green-500" />
               </div>
               
               {goal.state === 'overdue' ? (
                 <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
                   <p className="text-red-800 text-sm">
                     This goal is overdue. Want to set a catch-up plan?
                   </p>
                 </div>
               ) : goal.state === 'stagnant' ? (
                 <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                   <p className="text-yellow-800 text-sm">
                     Your {goal.title} hasn't moved in a week — want to restart your streak?
                   </p>
                 </div>
               ) : goal.state === 'completed' ? (
                 <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                   <p className="text-blue-800 text-sm">
                     🎉 Congratulations! You've completed this goal!
                   </p>
                 </div>
               ) : goal.state === 'in_progress' ? (
                 <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                   <p className="text-green-800 text-sm">
                     Great work! You've moved your {goal.title} forward recently.
                   </p>
                 </div>
               ) : null}
              </div>
             </div>
        ))}
      </CardContent>
    </Card>
  );
};