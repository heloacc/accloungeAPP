import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from '@/components/ui/use-toast';

// CSRF Protection utilities
const generateCSRFToken = (): string => {
  const array = new Uint8Array(32);
  crypto.getRandomValues(array);
  return Array.from(array, byte => byte.toString(16).padStart(2, '0')).join('');
};

const validateCSRFToken = (token: string): boolean => {
  return token && token.length === 64 && /^[a-f0-9]+$/.test(token);
};

const FastAuth: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [isSignUp, setIsSignUp] = useState(false);
  const [showForgotPassword, setShowForgotPassword] = useState(false);
  const [csrfToken, setCsrfToken] = useState<string>('');

  // Generate CSRF token on component mount
  useEffect(() => {
    setCsrfToken(generateCSRFToken());
  }, []);

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // CSRF Protection: Validate token before processing
    if (!validateCSRFToken(csrfToken)) {
      toast({
        title: "Security Error",
        description: "Invalid security token. Please refresh the page and try again.",
        variant: "destructive",
      });
      return;
    }
    
    if (showForgotPassword) {
      if (!email) return;
      setLoading(true);
      
      try {
        const { error } = await supabase.auth.resetPasswordForEmail(email, {
          redirectTo: `${window.location.origin}/reset-password`,
        });
        
        if (error) throw error;
        
        toast({
          title: "Password reset email sent!",
          description: "Check your email for the reset link.",
        });
        setShowForgotPassword(false);
      } catch (error) {
        console.error('Password reset error:', error);
        toast({
          title: "Error",
          description: error instanceof Error ? error.message : 'An error occurred',
          variant: "destructive",
        });
      } finally {
        setLoading(false);
      }
      return;
    }
    
    if (!email || !password) return;

    console.log('Starting auth process:', { email, isSignUp });
    setLoading(true);
    
    try {
      if (isSignUp) {
        console.log('Attempting sign up...');
        const { data, error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            data: { name: email.split('@')[0] }
          }
        });
        
        console.log('Sign up result:', { data: !!data, error });
        
        if (error) throw error;
        
        toast({
          title: "Account created!",
          description: "Please check your email to verify your account.",
        });
      } else {
        console.log('Attempting sign in...');
        const { data, error } = await supabase.auth.signInWithPassword({
          email,
          password,
        });
        
        console.log('Sign in result:', { data: !!data, error });
        
        if (error) throw error;
        
        console.log('Sign in successful');
      }
    } catch (error) {
      console.error('Auth error:', error);
      toast({
        title: "Authentication Error",
        description: error instanceof Error ? error.message : 'Authentication failed',
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl font-bold text-gray-900">
            {showForgotPassword ? 'Reset Password' : 
             isSignUp ? 'Join' : 'Welcome to'} AccLounge
          </CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleAuth} className="space-y-4">
            {/* CSRF Protection: Hidden token field */}
            <input type="hidden" name="csrf_token" value={csrfToken} />
            
            <Input
              type="email"
              placeholder="Email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
            {!showForgotPassword && (
              <Input
                type="password"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            )}
            <Button 
              type="submit" 
              className="w-full" 
              disabled={loading}
            >
              {loading ? 'Loading...' : 
               showForgotPassword ? 'Send Reset Email' :
               isSignUp ? 'Sign Up' : 'Sign In'}
            </Button>
            {!showForgotPassword && (
              <Button
                type="button"
                variant="ghost"
                className="w-full"
                onClick={() => setIsSignUp(!isSignUp)}
              >
                {isSignUp ? 'Already have an account? Sign In' : 'Need an account? Sign Up'}
              </Button>
            )}
            
            {/* Show forgot password link only in sign-in mode */}
            {!isSignUp && !showForgotPassword && (
              <Button
                type="button"
                variant="link"
                className="w-full text-sm text-blue-600 hover:text-blue-800"
                onClick={() => setShowForgotPassword(true)}
              >
                Forgot your password?
              </Button>
            )}
            
            {/* Show back to sign in when in forgot password mode */}
            {showForgotPassword && (
              <Button
                type="button"
                variant="link"
                className="w-full text-sm text-gray-600 hover:text-gray-800"
                onClick={() => setShowForgotPassword(false)}
              >
                Back to Sign In
              </Button>
            )}
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

export default FastAuth;