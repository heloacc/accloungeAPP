import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';

interface PageAccessRule {
  id: string;
  page_path: string;
  page_name: string;
  required_plan_id: string;
  is_premium_only: boolean;
  subscription_plans?: { name: string };
}

interface SubscriptionTier {
  id: string;
  name: string;
}

export default function AdminPageAccessManager() {
  const [rules, setRules] = useState<PageAccessRule[]>([]);
  const [plans, setPlans] = useState<SubscriptionTier[]>([]);
  const [newRule, setNewRule] = useState({
    page_path: '',
    page_name: '',
    required_plan_id: '',
    is_premium_only: false
  });
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      // Load page access rules with subscription tier info
      // Load page access rules with subscription plan info
      const { data: rulesData, error: rulesError } = await supabase
        .from('page_access_rules')
        .select(`
          *,
          subscription_plans!required_plan_id (
            id,
            name
          )
        `);

      if (rulesError) {
        console.error('Rules error:', rulesError);
      }

      // Load subscription plans (not tiers)
      const { data: plansData, error: plansError } = await supabase
        .from('subscription_plans')
        .select('id, name')
        .eq('is_active', true);

      if (plansError) {
        console.error('Plans error:', plansError);
      }

      setRules(rulesData || []);
      setPlans(plansData || []);
    } catch (error) {
      console.error('Load data error:', error);
      toast({
        title: "Error loading data",
        description: error instanceof Error ? error.message : "Unknown error",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleAddRule = async () => {
    if (!newRule.page_path || !newRule.page_name) {
      toast({
        title: "Missing fields",
        description: "Please fill in page path and name",
        variant: "destructive"
      });
      return;
    }

    try {
      const { error } = await supabase
        .from('page_access_rules')
        .insert([newRule]);

      if (error) throw error;

      toast({
        title: "Rule added successfully"
      });

      setNewRule({
        page_path: '',
        page_name: '',
        required_plan_id: '',
        is_premium_only: false
      });

      loadData();
    } catch (error) {
      toast({
        title: "Error adding rule",
        description: error instanceof Error ? error.message : "Unknown error",
        variant: "destructive"
      });
    }
  };

  const handleDeleteRule = async (ruleId: string) => {
    try {
      const { error } = await supabase
        .from('page_access_rules')
        .delete()
        .eq('id', ruleId);

      if (error) throw error;

      toast({
        title: "Rule deleted successfully"
      });

      loadData();
    } catch (error) {
      toast({
        title: "Error deleting rule",
        description: error instanceof Error ? error.message : "Unknown error",
        variant: "destructive"
      });
    }
  };

  const handleTogglePremium = async (ruleId: string, currentValue: boolean) => {
    try {
      const { error } = await supabase
        .from('page_access_rules')
        .update({ is_premium_only: !currentValue })
        .eq('id', ruleId);

      if (error) throw error;

      loadData();
    } catch (error) {
      toast({
        title: "Error updating rule",
        description: error instanceof Error ? error.message : "Unknown error",
        variant: "destructive"
      });
    }
  };

  if (loading) return <div>Loading...</div>;

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">Page Access Management</h2>
      
      <Card>
        <CardHeader>
          <CardTitle>Add New Access Rule</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="page-path">Page Path</Label>
              <Input
                id="page-path"
                placeholder="/dashboard"
                value={newRule.page_path}
                onChange={(e) => setNewRule({ ...newRule, page_path: e.target.value })}
              />
            </div>
            <div>
              <Label htmlFor="page-name">Page Name</Label>
              <Input
                id="page-name"
                placeholder="Dashboard"
                value={newRule.page_name}
                onChange={(e) => setNewRule({ ...newRule, page_name: e.target.value })}
              />
            </div>
          </div>
          
          <div>
            <Label>Required Plan</Label>
            <Select
              value={newRule.required_plan_id}
              onValueChange={(value) => setNewRule({ ...newRule, required_plan_id: value })}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select required plan" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">No specific plan required</SelectItem>
                {plans.map((plan) => (
                  <SelectItem key={plan.id} value={plan.id}>
                    {plan.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center space-x-2">
            <Switch
              id="premium-only"
              checked={newRule.is_premium_only}
              onCheckedChange={(checked) => setNewRule({ ...newRule, is_premium_only: checked })}
            />
            <Label htmlFor="premium-only">Premium subscribers only</Label>
          </div>

          <Button onClick={handleAddRule}>Add Rule</Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Current Access Rules</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {rules.map((rule) => (
              <div key={rule.id} className="flex items-center justify-between p-4 border rounded">
                <div>
                  <p className="font-semibold">{rule.page_name}</p>
                  <p className="text-sm text-muted-foreground">{rule.page_path}</p>
                  <p className="text-sm">
                     Required Plan: {rule.subscription_plans?.name || 'Any'}
                  </p>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="flex items-center space-x-2">
                    <Switch
                      checked={rule.is_premium_only}
                      onCheckedChange={() => handleTogglePremium(rule.id, rule.is_premium_only)}
                    />
                    <Label>Premium Only</Label>
                  </div>
                  <Button
                    variant="destructive"
                    size="sm"
                    onClick={() => handleDeleteRule(rule.id)}
                  >
                    Delete
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}