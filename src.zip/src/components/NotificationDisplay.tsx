import React from 'react';
import { useAppContext } from '@/contexts/OptimizedAppContext';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { X, Megaphone } from 'lucide-react';

const NotificationDisplay: React.FC = () => {
  const { notifications, dismissNotification } = useAppContext();

  const activeNotifications = notifications.filter(n => n.isActive);

  if (activeNotifications.length === 0) {
    return null;
  }

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'motivational': return 'bg-green-100 text-green-800 border-green-200';
      case 'reminder': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'announcement': return 'bg-purple-100 text-purple-800 border-purple-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'motivational': return '💪';
      case 'reminder': return '⏰';
      case 'announcement': return '📢';
      default: return '📝';
    }
  };

  return (
    <div className="fixed top-4 right-4 z-50 space-y-2 max-w-sm">
      {activeNotifications.slice(0, 3).map((notification) => (
        <Card key={notification.id} className={`shadow-lg ${getTypeColor(notification.type)}`}>
          <CardContent className="p-4">
            <div className="flex items-start justify-between gap-3">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <Megaphone className="h-4 w-4" />
                  <Badge variant="secondary" className="text-xs">
                    {getTypeIcon(notification.type)} {notification.type}
                  </Badge>
                </div>
                <h4 className="font-semibold text-sm mb-1">{notification.title}</h4>
                <p className="text-xs opacity-90">{notification.message}</p>
                <p className="text-xs opacity-70 mt-2">
                  From: {notification.createdBy}
                </p>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => dismissNotification(notification.id)}
                className="h-6 w-6 p-0 opacity-70 hover:opacity-100"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          </CardContent>
        </Card>
      ))}
      
      {activeNotifications.length > 3 && (
        <Card className="shadow-lg bg-gray-50 border-gray-200">
          <CardContent className="p-3 text-center">
            <p className="text-xs text-muted-foreground">
              +{activeNotifications.length - 3} more notifications
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default NotificationDisplay;