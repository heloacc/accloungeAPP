import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription } from '@/components/ui/dialog';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Plus, Edit, Trash2, CheckCircle, Circle } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';
import { calculateAndUpdateGoalProgress } from '@/utils/goalProgressCalculator';

interface Goal {
  id: string;
  title: string;
  description?: string;
  target_date?: string;
  status: string;
  completion_percent: number;
  goal_tasks?: Task[];
}

interface Task {
  id: string;
  title: string;
  type: string;
  status: string;
  auto_config?: any;
}

interface Habit {
  id: string;
  title: string;
}

export default function GoalManager() {
  const [goals, setGoals] = useState<Goal[]>([]);
  const [habits, setHabits] = useState<Habit[]>([]);
  const [isGoalDialogOpen, setIsGoalDialogOpen] = useState(false);
  const [isTaskDialogOpen, setIsTaskDialogOpen] = useState(false);
  const [editingGoal, setEditingGoal] = useState<Goal | null>(null);
  const [selectedGoal, setSelectedGoal] = useState<string>('');
  const [goalFormData, setGoalFormData] = useState({
    title: '',
    description: '',
    target_date: '',
    status: 'active'
  });
  const [taskFormData, setTaskFormData] = useState({
    title: '',
    type: 'manual',
    frequency: 'one-time',
    habit_id: '',
    rule: 'count',
    target_number: 1
  });
  const { toast } = useToast();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const { data: user } = await supabase.auth.getUser();
      if (!user.user) return;

      const [goalsRes, habitsRes] = await Promise.all([
        supabase.from('goals').select(`
          *,
          goal_tasks(*)
        `).eq('user_id', user.user.id),
        supabase.from('habits').select('id, title').eq('user_id', user.user.id).eq('is_active', true)
      ]);

      setGoals(goalsRes.data || []);
      setHabits(habitsRes.data || []);
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to load data',
        variant: 'destructive'
      });
    }
  };

  const handleGoalSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const { data: user } = await supabase.auth.getUser();
      if (!user.user) return;

      const goalData = {
        ...goalFormData,
        user_id: user.user.id,
        target_date: goalFormData.target_date || null
      };

      if (editingGoal) {
        await supabase.from('goals').update(goalData).eq('id', editingGoal.id);
      } else {
        await supabase.from('goals').insert(goalData);
      }

      toast({
        title: 'Success',
        description: `Goal ${editingGoal ? 'updated' : 'created'} successfully`
      });

      setIsGoalDialogOpen(false);
      setEditingGoal(null);
      setGoalFormData({ title: '', description: '', target_date: '', status: 'active' });
      loadData();
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to save goal',
        variant: 'destructive'
      });
    }
  };

  const handleTaskSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const { data: user } = await supabase.auth.getUser();
      if (!user.user) return;

      const taskData = {
        goal_id: selectedGoal,
        user_id: user.user.id,
        title: taskFormData.title,
        type: taskFormData.type,
        frequency: taskFormData.frequency, // Add required frequency field
        status: 'open',
        auto_config: taskFormData.type === 'auto' ? {
          habit_id: taskFormData.habit_id,
          rule: taskFormData.rule,
          target_number: taskFormData.target_number
        } : null
      };

      const { data, error } = await supabase.from('goal_tasks').insert(taskData).select();
      
      if (error) throw error;

      toast({
        title: 'Success',
        description: 'Task created successfully'
      });

      setIsTaskDialogOpen(false);
      setTaskFormData({ title: '', type: 'manual', frequency: 'one-time', habit_id: '', rule: 'count', target_number: 1 });
      
      // Force refresh of data to show new task
      await loadData();
    } catch (error) {
      console.error('Task creation error:', error);
      toast({
        title: 'Error',
        description: 'Failed to create task',
        variant: 'destructive'
      });
    }
  };

  const toggleTaskStatus = async (taskId: string, currentStatus: string) => {
    const newStatus = currentStatus === 'done' ? 'open' : 'done';
    
    try {
      await supabase
        .from('goal_tasks')
        .update({ 
          status: newStatus,
          done_at: newStatus === 'done' ? new Date().toISOString() : null
        })
        .eq('id', taskId);

      // Find the goal this task belongs to and update its completion percentage
      const goal = goals.find(g => g.goal_tasks?.some(t => t.id === taskId));
      if (goal) {
        await calculateAndUpdateGoalProgress(goal.id);
      }

      // Refresh data to show updated progress
      await loadData();
      
      toast({
        title: 'Success',
        description: `Task marked as ${newStatus}`
      });
    } catch (error) {
      console.error('Error updating task:', error);
      toast({
        title: 'Error',
        description: 'Failed to update task',
        variant: 'destructive'
      });
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Goal Management</h2>
        <Dialog open={isGoalDialogOpen} onOpenChange={setIsGoalDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => {
              setEditingGoal(null);
              setGoalFormData({ title: '', description: '', target_date: '', status: 'active' });
            }}>
              <Plus className="w-4 h-4 mr-2" />
              Add Goal
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{editingGoal ? 'Edit Goal' : 'Create New Goal'}</DialogTitle>
              <DialogDescription>
                {editingGoal ? 'Modify your existing goal details.' : 'Create a new goal to track your progress towards achieving it.'}
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleGoalSubmit} className="space-y-4">
              <div>
                <Label htmlFor="title">Goal Title</Label>
                <Input
                  id="title"
                  value={goalFormData.title}
                  onChange={(e) => setGoalFormData({ ...goalFormData, title: e.target.value })}
                  placeholder="e.g., Run a 5K race"
                  required
                />
              </div>
              
              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={goalFormData.description}
                  onChange={(e) => setGoalFormData({ ...goalFormData, description: e.target.value })}
                  placeholder="Describe your goal..."
                />
              </div>

              <div>
                <Label htmlFor="target_date">Target Date</Label>
                <Input
                  id="target_date"
                  type="date"
                  value={goalFormData.target_date}
                  onChange={(e) => setGoalFormData({ ...goalFormData, target_date: e.target.value })}
                />
              </div>

              <div>
                <Label htmlFor="status">Status</Label>
                <Select
                  value={goalFormData.status}
                  onValueChange={(value) => setGoalFormData({ ...goalFormData, status: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="paused">Paused</SelectItem>
                    <SelectItem value="completed">Completed</SelectItem>
                    <SelectItem value="archived">Archived</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex justify-end space-x-2">
                <Button type="button" variant="outline" onClick={() => setIsGoalDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit">
                  {editingGoal ? 'Update' : 'Create'} Goal
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-6">
        {goals.map((goal) => (
          <Card key={goal.id}>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-xl">{goal.title}</CardTitle>
                <div className="flex items-center space-x-2">
                  <Badge variant={goal.status === 'active' ? 'default' : 'secondary'}>
                    {goal.status}
                  </Badge>
                  <Dialog open={isTaskDialogOpen} onOpenChange={setIsTaskDialogOpen}>
                    <DialogTrigger asChild>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => setSelectedGoal(goal.id)}
                      >
                        <Plus className="w-4 h-4 mr-1" />
                        Task
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Add Task to {goal.title}</DialogTitle>
                        <DialogDescription>
                          Create a new task to help you achieve this goal. Tasks can be manual or automatically tracked through habits.
                        </DialogDescription>
                      </DialogHeader>
                      <form onSubmit={handleTaskSubmit} className="space-y-4">
                        <div>
                          <Label htmlFor="task_title">Task Title</Label>
                          <Input
                            id="task_title"
                            value={taskFormData.title}
                            onChange={(e) => setTaskFormData({ ...taskFormData, title: e.target.value })}
                            placeholder="e.g., Complete 12 runs"
                            required
                          />
                        </div>

                        <div>
                          <Label htmlFor="task_type">Task Type</Label>
                          <Select
                            value={taskFormData.type}
                            onValueChange={(value) => setTaskFormData({ ...taskFormData, type: value })}
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="manual">Manual</SelectItem>
                              <SelectItem value="auto">Automatic (Habit-driven)</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        {taskFormData.type === 'auto' && (
                          <>
                            <div>
                              <Label htmlFor="habit">Linked Habit</Label>
                              <Select
                                value={taskFormData.habit_id}
                                onValueChange={(value) => setTaskFormData({ ...taskFormData, habit_id: value })}
                              >
                                <SelectTrigger>
                                  <SelectValue placeholder="Select a habit" />
                                </SelectTrigger>
                                <SelectContent>
                                  {habits.map((habit) => (
                                    <SelectItem key={habit.id} value={habit.id}>
                                      {habit.title}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                            </div>

                            <div>
                              <Label htmlFor="target">Target Count</Label>
                              <Input
                                id="target"
                                type="number"
                                min="1"
                                value={taskFormData.target_number}
                                onChange={(e) => setTaskFormData({ ...taskFormData, target_number: parseInt(e.target.value) })}
                              />
                            </div>
                          </>
                        )}

                        <div className="flex justify-end space-x-2">
                          <Button type="button" variant="outline" onClick={() => setIsTaskDialogOpen(false)}>
                            Cancel
                          </Button>
                          <Button type="submit">Create Task</Button>
                        </div>
                      </form>
                    </DialogContent>
                  </Dialog>
                </div>
              </div>
              {goal.description && (
                <p className="text-muted-foreground">{goal.description}</p>
              )}
              <Progress value={goal.completion_percent} className="mt-2" />
              <p className="text-sm text-muted-foreground">{goal.completion_percent}% complete</p>
            </CardHeader>
            <CardContent>
              {goal.goal_tasks && goal.goal_tasks.length > 0 && (
                <div className="space-y-2">
                  <h4 className="font-medium">Tasks:</h4>
                  {goal.goal_tasks.map((task) => (
                    <div key={task.id} className="flex items-center justify-between p-2 border rounded">
                      <div className="flex items-center space-x-2">
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => task.type === 'manual' && toggleTaskStatus(task.id, task.status)}
                          disabled={task.type === 'auto'}
                        >
                          {task.status === 'done' ? (
                            <CheckCircle className="w-4 h-4 text-green-600" />
                          ) : (
                            <Circle className="w-4 h-4" />
                          )}
                        </Button>
                        <span className={task.status === 'done' ? 'line-through text-muted-foreground' : ''}>
                          {task.title}
                        </span>
                        <Badge variant="outline" className="text-xs">
                          {task.type}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}