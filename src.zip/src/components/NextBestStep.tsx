import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ArrowRight, Target, CheckSquare, Flame } from 'lucide-react';

interface NextBestStepProps {
  userStats: {
    habits_count: number;
    goals_count: number;
    current_streak: number;
    total_completions: number;
  } | null;
  recentHabits: any[];
  activeGoals: any[];
  onNavigate?: (tab: string) => void;
}

const NextBestStep = ({ userStats, recentHabits, activeGoals, onNavigate }: NextBestStepProps) => {
  const getNextBestAction = () => {
    // If no habits or goals, suggest creating one
    if (!userStats?.habits_count && !userStats?.goals_count) {
      return {
        title: "Start your journey",
        description: "Create your first habit to begin building consistency",
        action: "Create Habit",
        actionType: "habits",
        icon: Target
      };
    }

    // If has habits but no streak, encourage completion
    if (userStats?.habits_count && userStats?.current_streak === 0) {
      return {
        title: "Build your streak",
        description: "Complete a habit today to start your streak",
        action: "Track Habits",
        actionType: "habits",
        icon: Flame
      };
    }

    // If has goals but low completion, focus on goals
    if (activeGoals.length > 0) {
      return {
        title: "Make progress on your goals",
        description: "Update your goal progress to stay on track",
        action: "Update Goals",
        actionType: "goals",
        icon: CheckSquare
      };
    }

    // Default encouragement
    return {
      title: "Keep up the momentum",
      description: "You're doing great! Consider adding a new challenge",
      action: "Add Goal",
      actionType: "goals",
      icon: Target
    };
  };

  const nextAction = getNextBestAction();
  const Icon = nextAction.icon;

  return (
    <Card className="border-l-4 border-l-[#596D59] bg-gradient-to-r from-green-50 to-blue-50">
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-[#596D59] rounded-lg">
              <Icon className="h-5 w-5 text-white" />
            </div>
            <div>
              <h3 className="font-semibold text-gray-900">{nextAction.title}</h3>
              <p className="text-sm text-gray-600">{nextAction.description}</p>
            </div>
          </div>
          <Button 
            onClick={() => onNavigate?.(nextAction.actionType)}
            className="bg-[#596D59] hover:bg-[#4a5a4a] text-white"
          >
            {nextAction.action}
            <ArrowRight className="h-4 w-4 ml-2" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default NextBestStep;