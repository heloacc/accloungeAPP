import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Plus, Edit, Trash2, Save, X } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { toast } from '@/components/ui/use-toast';

interface Tier {
  id: string;
  name: string;
  description?: string;
  stripe_product_id?: string;
  stripe_price_id?: string;
  price_monthly: number;
  price_yearly: number;
  features: string[];
  is_active: boolean;
  max_groups: number;
  max_partnerships: number;
}

export default function RobustTierManager() {
  const [tiers, setTiers] = useState<Tier[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [showAddForm, setShowAddForm] = useState(false);

  const [newTier, setNewTier] = useState({
    name: '',
    description: '',
    stripe_product_id: '',
    stripe_price_id: '',
    price_monthly: 0,
    price_yearly: 0,
    max_groups: 1,
    max_partnerships: 1
  });

  useEffect(() => {
    loadTiers();
  }, []);

  const loadTiers = async () => {
    try {
      setError(null);
      const { data, error: fetchError } = await supabase
        .from('subscription_tiers')
        .select('*')
        .order('price_monthly');

      if (fetchError) throw fetchError;
      setTiers(data || []);
    } catch (err: any) {
      setError(err.message);
      toast({
        title: "Error",
        description: "Failed to load tiers",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const saveTier = async () => {
    try {
      const tierData = {
        ...newTier,
        price: newTier.price_monthly,
        currency: 'USD',
        billing_interval: 'monthly',
        billing_period: 'monthly',
        features: [],
        is_active: true,
        allowed_routes: []
      };

      const { error } = await supabase
        .from('subscription_tiers')
        .insert([tierData]);

      if (error) throw error;

      toast({ title: "Success", description: "Tier created" });
      setShowAddForm(false);
      setNewTier({
        name: '',
        description: '',
        stripe_product_id: '',
        stripe_price_id: '',
        price_monthly: 0,
        price_yearly: 0,
        max_groups: 1,
        max_partnerships: 1
      });
      loadTiers();
    } catch (err: any) {
      toast({
        title: "Error",
        description: err.message,
        variant: "destructive"
      });
    }
  };

  const updateTier = async (id: string, updates: Partial<Tier>) => {
    try {
      const { error } = await supabase
        .from('subscription_tiers')
        .update(updates)
        .eq('id', id);

      if (error) throw error;

      toast({ title: "Success", description: "Tier updated" });
      setEditingId(null);
      loadTiers();
    } catch (err: any) {
      toast({
        title: "Error",
        description: err.message,
        variant: "destructive"
      });
    }
  };

  const deleteTier = async (id: string) => {
    if (!confirm('Delete this tier?')) return;

    try {
      const { error } = await supabase
        .from('subscription_tiers')
        .delete()
        .eq('id', id);

      if (error) throw error;

      toast({ title: "Success", description: "Tier deleted" });
      loadTiers();
    } catch (err: any) {
      toast({
        title: "Error",
        description: err.message,
        variant: "destructive"
      });
    }
  };

  if (loading) return <div className="p-4">Loading...</div>;
  if (error) return <div className="p-4 text-red-600">Error: {error}</div>;

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold">Subscription Tiers</h3>
        <Button onClick={() => setShowAddForm(true)} size="sm">
          <Plus className="h-4 w-4 mr-2" />
          Add Tier
        </Button>
      </div>

      {showAddForm && (
        <Card>
          <CardHeader>
            <CardTitle>Create New Tier</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Name</Label>
                <Input
                  value={newTier.name}
                  onChange={(e) => setNewTier({ ...newTier, name: e.target.value })}
                  placeholder="Basic, Pro, etc."
                />
              </div>
              <div>
                <Label>Monthly Price ($)</Label>
                <Input
                  type="number"
                  value={newTier.price_monthly}
                  onChange={(e) => setNewTier({ ...newTier, price_monthly: Number(e.target.value) })}
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Stripe Product ID</Label>
                <Input
                  value={newTier.stripe_product_id}
                  onChange={(e) => setNewTier({ ...newTier, stripe_product_id: e.target.value })}
                  placeholder="prod_xxxxx"
                />
              </div>
              <div>
                <Label>Stripe Price ID</Label>
                <Input
                  value={newTier.stripe_price_id}
                  onChange={(e) => setNewTier({ ...newTier, stripe_price_id: e.target.value })}
                  placeholder="price_xxxxx"
                />
              </div>
            </div>
            <div className="flex gap-2">
              <Button onClick={saveTier}>
                <Save className="h-4 w-4 mr-2" />
                Save
              </Button>
              <Button variant="outline" onClick={() => setShowAddForm(false)}>
                <X className="h-4 w-4 mr-2" />
                Cancel
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="space-y-4">
        {tiers.map((tier) => (
          <Card key={tier.id}>
            <CardContent className="p-4">
              <div className="flex justify-between items-start">
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <h4 className="font-semibold">{tier.name}</h4>
                    <Badge variant={tier.is_active ? "default" : "secondary"}>
                      {tier.is_active ? 'Active' : 'Inactive'}
                    </Badge>
                  </div>
                  <p className="text-lg font-bold text-green-600">${tier.price_monthly}/month</p>
                  {tier.stripe_product_id && (
                    <p className="text-xs text-muted-foreground mt-1">
                      Product: {tier.stripe_product_id}
                    </p>
                  )}
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setEditingId(tier.id)}
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => deleteTier(tier.id)}
                    className="text-red-600"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {tiers.length === 0 && (
        <Card>
          <CardContent className="p-8 text-center">
            <p className="text-muted-foreground mb-4">No subscription tiers found</p>
            <Button onClick={() => setShowAddForm(true)}>Create First Tier</Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}