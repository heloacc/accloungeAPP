import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';
import { Check, Flame, Target, TrendingUp, MessageCircle, AlertTriangle } from 'lucide-react';

interface Habit {
  id: string;
  title: string;
  current_streak: number;
  linked_goal_id?: string;
  linked_goal_title?: string;
  completed_today: boolean;
}

interface Goal {
  id: string;
  title: string;
  completion_percent: number;
  linked_habits_count: number;
  last_activity_at?: string;
  target_date?: string;
  status: string;
}

interface CoachMessage {
  id: string;
  content: string;
  created_at: string;
  is_admin_message: boolean;
}

export default function EnhancedDashboard() {
  const [habits, setHabits] = useState<Habit[]>([]);
  const [goals, setGoals] = useState<Goal[]>([]);
  const [coachMessages, setCoachMessages] = useState<CoachMessage[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();
  const loadDashboardData = async () => {
    try {
      const { data: user } = await supabase.auth.getUser();
      if (!user.user) return;

      const today = new Date().toISOString().split('T')[0];
      
      const [habitsRes, goalsRes] = await Promise.all([
        supabase
          .from('habits')
          .select('*')
          .eq('user_id', user.user.id)
          .eq('is_active', true),
        supabase
          .from('goals')
          .select(`
            *,
            goal_tasks(*)
          `)
          .eq('user_id', user.user.id)
          .in('status', ['active', 'paused'])
      ]);

      if (habitsRes.error) throw habitsRes.error;
      if (goalsRes.error) throw goalsRes.error;

      // Get today's habit logs separately
      const { data: todayLogs } = await supabase
        .from('habit_logs')
        .select('habit_id, status')
        .eq('user_id', user.user.id)
        .eq('date', today);

      // Process habits with completion status
      const processedHabits = (habitsRes.data || []).map(habit => ({
        id: habit.id,
        title: habit.title,
        current_streak: habit.current_streak || 0,
        linked_goal_id: habit.linked_goal_id,
        linked_goal_title: goalsRes.data?.find(g => g.id === habit.linked_goal_id)?.title || null,
        completed_today: todayLogs?.some(log => 
          log.habit_id === habit.id && log.status === 'done'
        ) || false
      }));

      setHabits(processedHabits);
      setGoals(goalsRes.data || []);
    } catch (error) {
      console.error('Error loading dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadDashboardData();
  }, []);

  const handleHabitToggle = async (habitId: string) => {
    try {
      const { data, error } = await supabase.functions.invoke('unified-habits-goals', {
        body: { 
          habitId,
          status: 'done',
          date: new Date().toLocaleDateString('en-CA')
        }
      });

      if (error) throw error;

      // Update local state with real streak data
      setHabits(prev => prev.map(habit => 
        habit.id === habitId 
          ? { 
              ...habit, 
              completed_today: data.done_today,
              current_streak: data.streak_days
            }
          : habit
      ));

      toast({
        title: 'Success',
        description: `Habit completed! Current streak: ${data.streak_days} days`,
      });

      // Reload dashboard to get updated goal progress
      await loadDashboardData();
    } catch (error) {
      console.error('Error toggling habit:', error);
      toast({
        title: 'Error',
        description: 'Failed to update habit',
        variant: 'destructive'
      });
    }
  };

  const isGoalInactive = (goal: Goal) => {
    if (!goal.last_activity_at) return true;
    const weekAgo = new Date();
    weekAgo.setDate(weekAgo.getDate() - 7);
    return new Date(goal.last_activity_at) < weekAgo;
  };

  if (loading) {
    return <div className="flex items-center justify-center p-8">Loading your dashboard...</div>;
  }

  const completedHabits = habits.filter(h => h.completed_today).length;

  return (
    <div className="space-y-6 p-4">
      {/* Today's Habits */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Today's Habits</CardTitle>
          <Badge variant="secondary">{completedHabits}/{habits.length}</Badge>
        </CardHeader>
        <CardContent className="space-y-3">
          {habits.map((habit) => (
            <div key={habit.id} className="flex items-center justify-between p-3 rounded-lg border">
              <div className="flex items-center gap-3">
                <Button
                  variant={habit.completed_today ? "default" : "outline"}
                  size="sm"
                  onClick={() => handleHabitToggle(habit.id)}
                  disabled={habit.completed_today}
                  className={habit.completed_today ? "bg-green-600 hover:bg-green-700" : ""}
                >
                  <Check className="h-4 w-4" />
                </Button>
                <div>
                  <p className={`font-medium ${habit.completed_today ? 'line-through text-muted-foreground' : ''}`}>
                    {habit.title}
                  </p>
                  {habit.linked_goal_title && (
                    <p className="text-sm text-muted-foreground">
                      Linked to: {habit.linked_goal_title}
                    </p>
                  )}
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Flame className="h-4 w-4 text-orange-500" />
                <span className="font-bold text-orange-500">{habit.current_streak}</span>
              </div>
            </div>
          ))}
          {habits.length === 0 && (
            <p className="text-center text-muted-foreground py-4">
              No habits yet. Create one to get started!
            </p>
          )}
        </CardContent>
      </Card>

      {/* Goals in Progress */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="h-5 w-5" />
            Your Goals in Progress
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {goals.map((goal) => (
            <div key={goal.id} className="p-4 border rounded-lg">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-medium">{goal.title}</h3>
                {goal.target_date && new Date(goal.target_date) < new Date() && (
                  <Badge variant="destructive">Overdue</Badge>
                )}
              </div>
              
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span>Progress</span>
                  <span>{goal.completion_percent}%</span>
                </div>
                <Progress value={goal.completion_percent} />
                
                <div className="flex items-center justify-between text-sm text-muted-foreground">
                  <span>✅ {Math.round((goal.completion_percent / 100) * 5)}/5 tasks</span>
                  <span>Fueled by {goal.linked_habits_count} daily habits</span>
                  <TrendingUp className="h-4 w-4" />
                </div>
              </div>

              {isGoalInactive(goal) && (
                <div className="mt-3 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                  <div className="flex items-center gap-2 text-yellow-800">
                    <AlertTriangle className="h-4 w-4" />
                    <span className="text-sm">
                      Your {goal.title} hasn't moved in a week — want to restart your streak?
                    </span>
                  </div>
                </div>
              )}
            </div>
          ))}
          {goals.length === 0 && (
            <p className="text-center text-muted-foreground py-4">
              No active goals. Create one to track your progress!
            </p>
          )}
        </CardContent>
      </Card>

      {/* Coach Messages */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <MessageCircle className="h-5 w-5" />
              Your Coach Messages
            </div>
            <Badge>All Access</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {coachMessages.length > 0 ? (
            <div className="space-y-3">
              {coachMessages.map((message) => (
                <div key={message.id} className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                    <span className="text-sm font-medium">🤖</span>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-medium text-sm">Your Coach</span>
                      <Badge variant="secondary">coach</Badge>
                      <span className="text-xs text-muted-foreground">
                        {new Date(message.created_at).toLocaleDateString()}
                      </span>
                    </div>
                    <p className="text-sm">{message.content}</p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-4">
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
                <span className="text-lg">🤖</span>
              </div>
              <div className="space-y-1">
                <div className="flex items-center gap-2 justify-center mb-2">
                  <span className="font-medium text-sm">Your Coach</span>
                  <Badge variant="secondary">coach</Badge>
                  <span className="text-xs text-muted-foreground">1 day ago</span>
                </div>
                <p className="text-sm">Great job setting up your habits! Keep building that momentum.</p>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}