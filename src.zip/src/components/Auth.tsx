import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { supabase } from '@/lib/supabase';
import EmailVerification from './EmailVerification';
interface AuthProps {
  onAuthChange: (authenticated: boolean) => void;
}

export default function Auth({ onAuthChange }: AuthProps) {
  const [mode, setMode] = useState<'signin' | 'signup' | 'reset' | 'verify'>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');
  const [pendingVerificationEmail, setPendingVerificationEmail] = useState('');

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setMessage('');

    try {
      // Test connection first
      const { data: testData, error: testError } = await supabase.from('profiles').select('id').limit(1);
      if (testError && testError.message.includes('Load failed')) {
        throw new Error('Connection failed. Please check your internet connection and try again.');
      }

      if (mode === 'signup') {
        const { error } = await supabase.auth.signUp({
          email,
          password,
        });
        if (error) throw error;
        setPendingVerificationEmail(email);
        setMode('verify');
      } else if (mode === 'signin') {
        const { error } = await supabase.auth.signInWithPassword({
          email,
          password,
        });
        if (error) throw error;
        onAuthChange(true);
      } else if (mode === 'reset') {
        const { error } = await supabase.auth.resetPasswordForEmail(email, {
          redirectTo: `${window.location.origin}/reset-password`,
        });
        if (error) throw error;
        setMessage('Password reset email sent!');
      }
    } catch (error: any) {
      console.error('Auth error:', error);
      setMessage(`Authentication failed: ${error.message || 'Connection error'}`);
    } finally {
      setLoading(false);
  };

  if (mode === 'verify' && pendingVerificationEmail) {
    return (
      <EmailVerification 
        email={pendingVerificationEmail} 
        onVerificationComplete={() => onAuthChange(true)} 
      />
    );
  }
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle>
            {mode === 'signin' && 'Sign In'}
            {mode === 'signup' && 'Sign Up'}
            {mode === 'reset' && 'Reset Password'}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleAuth} className="space-y-4">
            <Input
              type="email"
              placeholder="Email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
            {mode !== 'reset' && (
              <Input
                type="password"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            )}
            <Button type="submit" className="w-full bg-black text-white hover:bg-gray-800" disabled={loading}>
              {loading ? 'Loading...' : 
                mode === 'signin' ? 'Sign In' :
                mode === 'signup' ? 'Sign Up' : 'Send Reset Email'}
            </Button>
          </form>
          {message && (
            <p className="mt-4 text-sm text-center text-gray-600">{message}</p>
          )}
          <div className="mt-4 space-y-2">
            {mode === 'signin' && (
              <>
                <Button
                  variant="link"
                  className="w-full"
                  onClick={() => setMode('signup')}
                >
                  Need an account? Sign Up
                </Button>
                <Button
                  variant="link"
                  className="w-full"
                  onClick={() => setMode('reset')}
                >
                  Forgot Password?
                </Button>
              </>
            )}
            {mode === 'signup' && (
              <Button
                variant="link"
                className="w-full"
                onClick={() => setMode('signin')}
              >
                Already have an account? Sign In
              </Button>
            )}
            {mode === 'reset' && (
              <Button
                variant="link"
                className="w-full"
                onClick={() => setMode('signin')}
              >
                Back to Sign In
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}