import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Trophy, Target, CheckCircle } from 'lucide-react';

interface LeaderboardEntry {
  id: string;
  points: number;
  goals_completed: number;
  tasks_completed: number;
  last_updated: string;
  profiles: {
    full_name: string;
  };
}

interface GroupLeaderboardProps {
  groupId: string;
  readOnly?: boolean;
}

const GroupLeaderboard: React.FC<GroupLeaderboardProps> = ({ groupId, readOnly = false }) => {
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchLeaderboard();
  }, [groupId]);

  const fetchLeaderboard = async () => {
    try {
      const { data, error } = await supabase
        .from('group_leaderboard')
        .select(`
          *,
          profiles:user_id (full_name)
        `)
        .eq('group_id', groupId)
        .order('points', { ascending: false })
        .limit(10);

      if (error) throw error;
      setLeaderboard(data || []);
    } catch (error) {
      console.error('Error fetching leaderboard:', error);
    } finally {
      setLoading(false);
    }
  };

  const getRankIcon = (index: number) => {
    if (index === 0) return <Trophy className="h-5 w-5 text-yellow-500" />;
    if (index === 1) return <Trophy className="h-5 w-5 text-gray-400" />;
    if (index === 2) return <Trophy className="h-5 w-5 text-amber-600" />;
    return <span className="text-sm font-bold text-muted-foreground">#{index + 1}</span>;
  };

  const getRankBadge = (index: number) => {
    if (index === 0) return <Badge className="bg-yellow-500 text-white">1st</Badge>;
    if (index === 1) return <Badge className="bg-gray-400 text-white">2nd</Badge>;
    if (index === 2) return <Badge className="bg-amber-600 text-white">3rd</Badge>;
    return null;
  };

  if (loading) {
    return <div className="text-center py-4">Loading leaderboard...</div>;
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Trophy className="h-5 w-5 text-[#596D59]" />
          Leaderboard
        </CardTitle>
      </CardHeader>
      <CardContent>
        {leaderboard.length === 0 ? (
          <p className="text-center text-muted-foreground py-4">
            No activity yet. Complete goals and tasks to appear on the leaderboard!
          </p>
        ) : (
          <div className="space-y-3">
            {leaderboard.map((entry, index) => (
              <div 
                key={entry.id} 
                className={`flex items-center justify-between p-3 rounded-lg border ${
                  index < 3 ? 'bg-gradient-to-r from-yellow-50 to-orange-50' : 'bg-gray-50'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="flex items-center justify-center w-8">
                    {getRankIcon(index)}
                  </div>
                  <Avatar className="h-8 w-8">
                    <AvatarFallback>
                      {entry.profiles?.full_name?.charAt(0) || 'U'}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="flex items-center gap-2">
                      <p className="font-medium text-sm">
                        {entry.profiles?.full_name || 'Unknown User'}
                      </p>
                      {getRankBadge(index)}
                    </div>
                    <div className="flex items-center gap-4 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Target className="h-3 w-3" />
                        {entry.goals_completed} goals
                      </span>
                      <span className="flex items-center gap-1">
                        <CheckCircle className="h-3 w-3" />
                        {entry.tasks_completed} tasks
                      </span>
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-bold text-lg text-[#596D59]">{entry.points}</p>
                  <p className="text-xs text-muted-foreground">points</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default GroupLeaderboard;