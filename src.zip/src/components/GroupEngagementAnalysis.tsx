import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Users, MessageSquare, Target, TrendingUp } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface GroupEngagement {
  id: string;
  name: string;
  memberCount: number;
  activeMemberCount: number;
  postCount: number;
  goalCompletionRate: number;
  engagementScore: number;
  lastActivity: string;
}

const GroupEngagementAnalysis: React.FC = () => {
  const [groups, setGroups] = useState<GroupEngagement[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadGroupEngagement();
  }, []);

  const loadGroupEngagement = async () => {
    try {
      setLoading(true);

      // Get all groups with member counts
      const { data: groupsData } = await supabase
        .from('acircle_groups')
        .select(`
          id, 
          name, 
          created_at,
          acircle_members(user_id)
        `);

      if (!groupsData) return;

      const engagementData: GroupEngagement[] = [];

      for (const group of groupsData) {
        const memberIds = group.acircle_members?.map((m: any) => m.user_id) || [];
        const memberCount = memberIds.length;

        // Get active members (posted in last 30 days)
        const { data: recentPosts } = await supabase
          .from('group_posts')
          .select('user_id')
          .eq('group_id', group.id)
          .gte('created_at', new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString());

        const activeMemberIds = new Set(recentPosts?.map(p => p.user_id) || []);
        const activeMemberCount = activeMemberIds.size;

        // Get total posts for this group
        const { data: allPosts, count: postCount } = await supabase
          .from('group_posts')
          .select('id', { count: 'exact' })
          .eq('group_id', group.id);

        // Get completed goals for group members
        const { data: completedGoals } = await supabase
          .from('acircle_goal_assignments')
          .select('id')
          .eq('group_id', group.id)
          .eq('status', 'completed');

        const { data: totalGoals } = await supabase
          .from('acircle_goal_assignments')
          .select('id')
          .eq('group_id', group.id);

        const goalCompletionRate = totalGoals?.length > 0 
          ? Math.round((completedGoals?.length || 0) / totalGoals.length * 100) 
          : 0;

        // Calculate engagement score (0-100)
        const activityScore = memberCount > 0 ? (activeMemberCount / memberCount) * 40 : 0;
        const postScore = Math.min((postCount || 0) / memberCount * 10, 30);
        const goalScore = goalCompletionRate * 0.3;
        const engagementScore = Math.round(activityScore + postScore + goalScore);

        // Get last activity
        const { data: lastPost } = await supabase
          .from('group_posts')
          .select('created_at')
          .eq('group_id', group.id)
          .order('created_at', { ascending: false })
          .limit(1);

        const lastActivity = lastPost?.[0]?.created_at 
          ? new Date(lastPost[0].created_at).toLocaleDateString()
          : 'No activity';

        engagementData.push({
          id: group.id,
          name: group.name,
          memberCount,
          activeMemberCount,
          postCount: postCount || 0,
          goalCompletionRate,
          engagementScore,
          lastActivity
        });
      }

      // Sort by engagement score
      engagementData.sort((a, b) => b.engagementScore - a.engagementScore);
      setGroups(engagementData);

    } catch (error) {
      console.error('Error loading group engagement:', error);
    } finally {
      setLoading(false);
    }
  };

  const getEngagementBadge = (score: number) => {
    if (score >= 80) return <Badge className="bg-green-500">High</Badge>;
    if (score >= 50) return <Badge className="bg-yellow-500">Medium</Badge>;
    return <Badge variant="secondary">Low</Badge>;
  };

  if (loading) {
    return <div className="p-4">Loading group engagement analysis...</div>;
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Group Engagement Analysis
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {groups.map((group) => (
              <div key={group.id} className="border rounded-lg p-4">
                <div className="flex justify-between items-start mb-3">
                  <div>
                    <h3 className="font-semibold">{group.name}</h3>
                    <p className="text-sm text-muted-foreground">
                      {group.memberCount} members • Last activity: {group.lastActivity}
                    </p>
                  </div>
                  {getEngagementBadge(group.engagementScore)}
                </div>

                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Engagement Score</span>
                    <span className="text-sm font-medium">{group.engagementScore}/100</span>
                  </div>
                  <Progress value={group.engagementScore} className="h-2" />
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4 text-sm">
                  <div className="flex items-center gap-2">
                    <Users className="h-4 w-4 text-blue-500" />
                    <span>{group.activeMemberCount}/{group.memberCount} active</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <MessageSquare className="h-4 w-4 text-green-500" />
                    <span>{group.postCount} posts</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Target className="h-4 w-4 text-purple-500" />
                    <span>{group.goalCompletionRate}% goals done</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <TrendingUp className="h-4 w-4 text-orange-500" />
                    <span>{Math.round(group.postCount / group.memberCount * 10) / 10} posts/member</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default GroupEngagementAnalysis;