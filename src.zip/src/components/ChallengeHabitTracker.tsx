import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAppContext } from '@/contexts/OptimizedAppContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, Circle, Calendar, Target, Trophy } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';

interface ChallengeCompletion {
  id: string;
  challenge_id: string;
  user_id: string;
  completion_date: string;
  notes?: string;
}

interface ChallengeWithProgress {
  id: string;
  title: string;
  habit_name: string;
  duration_days: number;
  start_date: string;
  end_date: string;
  completions: ChallengeCompletion[];
  total_days: number;
  completed_days: number;
  completion_percentage: number;
}

export const ChallengeHabitTracker = () => {
  const { currentUser } = useAppContext();
  const [challenges, setChallenges] = useState<ChallengeWithProgress[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchUserChallenges();
  }, [currentUser?.id]);

  const fetchUserChallenges = async () => {
    if (!currentUser?.id) return;

    try {
      // Get challenges user is participating in
      const { data: participations, error: participationError } = await supabase
        .from('habit_challenge_participants')
        .select(`
          challenge_id,
          habit_challenges!inner(
            id,
            title,
            habit_name,
            duration_days,
            start_date,
            end_date
          )
        `)
        .eq('user_id', currentUser.id);

      if (participationError) throw participationError;

      // Get completions for each challenge
      const challengesWithProgress = await Promise.all(
        (participations || []).map(async (participation) => {
          const challenge = participation.habit_challenges;
          
          const { data: completions } = await supabase
            .from('habit_challenge_completions')
            .select('*')
            .eq('challenge_id', challenge.id)
            .eq('user_id', currentUser.id)
            .order('completion_date', { ascending: true });

          const startDate = new Date(challenge.start_date);
          const endDate = new Date(challenge.end_date);
          const totalDays = Math.ceil((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24)) + 1;
          const completedDays = completions?.length || 0;
          const completionPercentage = totalDays > 0 ? Math.round((completedDays / totalDays) * 100) : 0;

          return {
            ...challenge,
            completions: completions || [],
            total_days: totalDays,
            completed_days: completedDays,
            completion_percentage: completionPercentage
          };
        })
      );

      setChallenges(challengesWithProgress);
    } catch (error) {
      console.error('Error fetching user challenges:', error);
    } finally {
      setLoading(false);
    }
  };

  const markHabitComplete = async (challengeId: string) => {
    if (!currentUser?.id) {
      toast({
        title: "Error",
        description: "You must be logged in to complete habits.",
        variant: "destructive"
      });
      return;
    }

    try {
      const today = new Date().toISOString().split('T')[0];
      
      // Check if already completed today
      const { data: existing, error: checkError } = await supabase
        .from('habit_challenge_completions')
        .select('id')
        .eq('challenge_id', challengeId)
        .eq('user_id', currentUser.id)
        .eq('completion_date', today)
        .maybeSingle();

      if (checkError) {
        console.error('Error checking existing completion:', checkError);
        throw checkError;
      }

      if (existing) {
        toast({
          title: "Already Completed",
          description: "You've already completed this habit today!",
          variant: "default"
        });
        return;
      }

      const { error: insertError } = await supabase
        .from('habit_challenge_completions')
        .insert({
          challenge_id: challengeId,
          user_id: currentUser.id,
          completion_date: today
        });

      if (insertError) {
        console.error('Error inserting completion:', insertError);
        throw insertError;
      }

      toast({
        title: "Habit Completed! 🎉",
        description: "Great job staying consistent with your challenge!",
      });

      fetchUserChallenges(); // Refresh data
    } catch (error) {
      console.error('Error marking habit complete:', error);
      const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
      toast({
        title: "Error",
        description: `Failed to mark habit as complete: ${errorMessage}`,
        variant: "destructive"
      });
    }
  };

  const isCompletedToday = (challenge: ChallengeWithProgress) => {
    const today = new Date().toISOString().split('T')[0];
    return challenge.completions.some(completion => 
      completion.completion_date === today
    );
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="p-6 text-center">
          <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary mx-auto mb-2"></div>
          <p className="text-muted-foreground">Loading your challenges...</p>
        </CardContent>
      </Card>
    );
  }

  if (challenges.length === 0) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <Trophy className="w-12 h-12 text-[#7E8E9D] mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-[#001B30] mb-2">No Active Challenges</h3>
          <p className="text-[#7E8E9D]">Join a challenge to start tracking your habits!</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-[#001B30] mb-2">My Challenge Progress</h2>
        <p className="text-[#7E8E9D]">Track your daily habit completions</p>
      </div>

      <div className="grid gap-4">
        {challenges.map((challenge) => (
          <Card key={challenge.id}>
            <CardHeader>
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle className="text-lg text-[#001B30]">{challenge.title}</CardTitle>
                  <p className="text-[#7E8E9D] text-sm mt-1">{challenge.habit_name}</p>
                </div>
                <Badge className="bg-[#596D59] text-white">
                  {challenge.completion_percentage}% Complete
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-4 text-sm text-[#7E8E9D]">
                <div className="flex items-center gap-1">
                  <Calendar className="w-4 h-4" />
                  {challenge.completed_days}/{challenge.total_days} days
                </div>
                <div className="flex items-center gap-1">
                  <Target className="w-4 h-4" />
                  Ends {new Date(challenge.end_date).toLocaleDateString()}
                </div>
              </div>

              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-[#596D59] h-2 rounded-full transition-all duration-300" 
                  style={{ width: `${challenge.completion_percentage}%` }}
                ></div>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {isCompletedToday(challenge) ? (
                    <CheckCircle className="w-5 h-5 text-green-600" />
                  ) : (
                    <Circle className="w-5 h-5 text-gray-400" />
                  )}
                  <span className="text-sm">
                    {isCompletedToday(challenge) ? 'Completed today!' : 'Complete today\'s habit'}
                  </span>
                </div>

                {!isCompletedToday(challenge) && (
                  <Button 
                    onClick={() => markHabitComplete(challenge.id)}
                    size="sm"
                    className="bg-[#596D59] hover:bg-[#596D59]/90"
                  >
                    Mark Complete
                  </Button>
                )}
              </div>

              {challenge.completions.length > 0 && (
                <div className="mt-4">
                  <p className="text-sm font-medium text-[#001B30] mb-2">Recent Completions:</p>
                  <div className="flex flex-wrap gap-2">
                    {challenge.completions.slice(-7).map((completion) => (
                      <div
                        key={completion.id}
                        className="flex items-center gap-2 px-3 py-1 bg-green-50 border border-green-200 rounded-lg"
                      >
                        <CheckCircle className="w-4 h-4 text-green-600" />
                        <span className="text-xs text-green-700 font-medium">
                          {new Date(completion.completion_date).toLocaleDateString('en-US', { 
                            month: 'short', 
                            day: 'numeric' 
                          })}
                        </span>
                      </div>
                    ))}
                  </div>
                  {challenge.completions.length === 0 && (
                    <p className="text-sm text-[#7E8E9D] italic">No completions yet. Start your streak today!</p>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};