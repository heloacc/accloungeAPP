import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { MessageSquare, TrendingUp, TrendingDown, Minus, Users } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';

interface MomentumData {
  id: string;
  user_id: string;
  goals_completion_rate: number;
  streak_status: 'active' | 'lost' | 'declining';
  community_engagement_score: number;
  last_active_at: string;
  trend: 'improving' | 'stable' | 'declining';
  user_name?: string;
  user_email?: string;
}

export default function MemberMomentum() {
  const [momentumData, setMomentumData] = useState<MomentumData[]>([]);
  const [loading, setLoading] = useState(true);
  const [sendingCheckIn, setSendingCheckIn] = useState<string | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    fetchMomentumData();
  }, []);

  const fetchMomentumData = async () => {
    try {
      // Use a simpler query without foreign key reference
      const { data, error } = await supabase
        .from('momentum_metrics')
        .select(`
          *,
          profiles(name, email)
        `);

      if (error) {
        console.error('Supabase error:', error);
        throw error;
      }

      console.log('Raw momentum data:', data);

      const formattedData = data?.map(item => ({
        ...item,
        user_name: item.profiles?.name || 'Unknown User',
        user_email: item.profiles?.email || ''
      })) || [];

      console.log('Formatted momentum data:', formattedData);
      setMomentumData(formattedData);
    } catch (error) {
      console.error('Error fetching momentum data:', error);
      toast({
        title: "Error",
        description: "Failed to load member momentum data",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const getMomentumStatus = (trend: string, engagementScore: number) => {
    if (trend === 'declining' || engagementScore < 30) return 'Red';
    if (trend === 'stable' && engagementScore < 70) return 'Amber';
    return 'Green';
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Green': return 'bg-green-100 text-green-800';
      case 'Amber': return 'bg-yellow-100 text-yellow-800';
      case 'Red': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'improving': return <TrendingUp className="w-4 h-4 text-green-600" />;
      case 'declining': return <TrendingDown className="w-4 h-4 text-red-600" />;
      default: return <Minus className="w-4 h-4 text-gray-600" />;
    }
  };

  const sendCheckIn = async (userId: string, userName: string) => {
    setSendingCheckIn(userId);
    
    try {
      const currentUser = await supabase.auth.getUser();
      const senderId = currentUser.data.user?.id;
      
      if (!senderId) throw new Error('Not authenticated');

      const threadId = crypto.randomUUID();
      const checkInMessage = `Hi ${userName}, I noticed some changes in your activity. How are you doing with your goals? I'm here to support you!`;

      // Insert the check-in message
      const { error: messageError } = await supabase
        .from('check_in_messages')
        .insert({
          sender_id: senderId,
          recipient_id: userId,
          message_text: checkInMessage,
          thread_id: threadId,
          is_admin_message: true
        });

      if (messageError) throw messageError;

      // Create a notification for the recipient
      const { error: notificationError } = await supabase
        .from('notifications')
        .insert({
          user_id: userId,
          type: 'accountability_checkin',
          title: 'New Accountability Check-In',
          message: 'You have received a new accountability check-in from the support team.',
          data: { thread_id: threadId }
        });

      if (notificationError) {
        console.error('Error creating notification:', notificationError);
        // Don't throw here - the check-in was sent successfully
      }

      toast({
        title: "Check-in sent!",
        description: `Accountability check-in sent to ${userName}`,
      });
    } catch (error) {
      console.error('Error sending check-in:', error);
      toast({
        title: "Error",
        description: "Failed to send check-in message",
        variant: "destructive"
      });
    } finally {
      setSendingCheckIn(null);
    }
  };

  if (loading) {
    return <div className="flex justify-center p-8">Loading member momentum...</div>;
  }

  const recalculateMetrics = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('recalculate-momentum-metrics');
      
      if (error) throw error;
      
      toast({
        title: "Success",
        description: `Recalculated metrics for ${data.processed_users} users`,
      });
      
      // Refresh the data
      await fetchMomentumData();
    } catch (error) {
      console.error('Error recalculating metrics:', error);
      toast({
        title: "Error",
        description: "Failed to recalculate momentum metrics",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div className="flex justify-center p-8">Loading member momentum...</div>;
  }
  return (
    <div className="space-y-4 sm:space-y-6 p-2 sm:p-0">
      <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4">
        <h1 className="text-xl sm:text-2xl font-bold">Member Momentum</h1>
        <div className="flex flex-col sm:flex-row gap-2">
          <Button 
            onClick={recalculateMetrics}
            variant="outline"
            disabled={loading}
            className="w-full sm:w-auto text-sm"
          >
            {loading ? 'Recalculating...' : 'Recalculate Metrics'}
          </Button>
          <Badge variant="outline" className="text-xs">Admin/Moderator View</Badge>
        </div>
      </div>

      <div className="grid gap-3 sm:gap-4">
        {momentumData.map((member) => {
          const status = getMomentumStatus(member.trend, member.community_engagement_score);
          
          return (
            <Card key={member.id} className="overflow-hidden">
              <CardHeader className="pb-3 px-3 sm:px-6">
                <div className="flex flex-col sm:flex-row sm:justify-between sm:items-start gap-2">
                  <div className="min-w-0 flex-1">
                    <CardTitle className="text-base sm:text-lg truncate">{member.user_name}</CardTitle>
                    <p className="text-xs sm:text-sm text-gray-600 truncate">{member.user_email}</p>
                  </div>
                  <Badge className={`${getStatusColor(status)} text-xs shrink-0`}>{status}</Badge>
                </div>
              </CardHeader>
              <CardContent className="px-3 sm:px-6">
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 mb-4">
                  <div className="text-center">
                    <div className="flex items-center justify-center gap-1 mb-1">
                      {getTrendIcon(member.trend)}
                      <span className="text-xs sm:text-sm font-medium">Goal Completion</span>
                    </div>
                    <p className="text-lg sm:text-xl font-bold">{member.goals_completion_rate}%</p>
                  </div>
                  <div className="text-center">
                    <p className="text-xs sm:text-sm font-medium mb-1">Streak Status</p>
                    <Badge 
                      variant={member.streak_status === 'active' ? 'default' : 'destructive'}
                      className="text-xs"
                    >
                      {member.streak_status}
                    </Badge>
                  </div>
                  <div className="text-center">
                    <p className="text-xs sm:text-sm font-medium mb-1">Engagement</p>
                    <p className="text-lg sm:text-xl font-bold">{member.community_engagement_score}</p>
                  </div>
                  <div className="text-center">
                    <p className="text-xs sm:text-sm font-medium mb-1">Last Active</p>
                    <p className="text-xs sm:text-sm">{new Date(member.last_active_at).toLocaleDateString()}</p>
                  </div>
                </div>
                
                <Button 
                  onClick={() => sendCheckIn(member.user_id, member.user_name || 'Member')}
                  disabled={sendingCheckIn === member.user_id}
                  className="w-full text-sm"
                  size="sm"
                >
                  <MessageSquare className="w-4 h-4 mr-2" />
                  {sendingCheckIn === member.user_id ? 'Sending...' : 'Send Check-In'}
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {momentumData.length === 0 && (
        <Card>
          <CardContent className="text-center py-6 sm:py-8 px-4">
            <p className="text-gray-600 text-sm sm:text-base">No member momentum data available yet.</p>
            <p className="text-xs sm:text-sm text-gray-500 mt-2">Data will appear as members engage with the platform.</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}