import React, { useEffect, useState } from 'react';
import { useAppContext } from '@/contexts/OptimizedAppContext';
import { supabase } from '@/lib/supabase';
import { toast } from '@/components/ui/use-toast';

const EnhancedLoadingScreen: React.FC = () => {
  const { setIsLoading } = useAppContext();
  const [showFallback, setShowFallback] = useState(false);
  const [showError, setShowError] = useState(false);
  const [retryCount, setRetryCount] = useState(0);
  const [isRetrying, setIsRetrying] = useState(false);

  useEffect(() => {
    // Show fallback after 2 seconds
    const fallbackTimer = setTimeout(() => {
      setShowFallback(true);
    }, 2000);

    // Show error state after 5 seconds
    const errorTimer = setTimeout(() => {
      setShowError(true);
      console.warn('Loading taking longer than expected, showing error state');
    }, 5000);

    return () => {
      clearTimeout(fallbackTimer);
      clearTimeout(errorTimer);
    };
  }, []);

  const handleSoftRefresh = async () => {
    if (isRetrying) return;
    
    setIsRetrying(true);
    setRetryCount(prev => prev + 1);
    
    try {
      console.log('Attempting soft refresh...');
      
      // Cancel any pending requests
      if (window.AbortController) {
        window.dispatchEvent(new Event('cancel-requests'));
      }
      
      // Try to refresh the session without logging out
      const { error } = await supabase.auth.refreshSession();
      if (error) {
        console.error('Session refresh failed:', error);
        throw error;
      }
      
      // Reset loading state to trigger re-initialization
      setIsLoading(true);
      
      // Small delay to allow state to settle
      setTimeout(() => {
        setIsLoading(false);
        toast({
          title: "Refreshed successfully",
          description: "Your session has been refreshed.",
        });
      }, 1000);
      
    } catch (error) {
      console.error('Soft refresh failed:', error);
      toast({
        title: "Refresh failed",
        description: "Please try again or contact support if the issue persists.",
        variant: "destructive",
      });
    } finally {
      setIsRetrying(false);
    }
  };

  const handleGoToDashboard = () => {
    // Force clear loading state and go to dashboard
    setIsLoading(false);
    window.dispatchEvent(new CustomEvent('navigate-to-tab', { 
      detail: { tab: 'dashboard' } 
    }));
  };

  const handleSignOut = async () => {
    try {
      await supabase.auth.signOut();
      window.location.href = '/';
    } catch (error) {
      console.error('Sign out error:', error);
      window.location.href = '/';
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="text-center max-w-md mx-auto p-6">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
        <h2 className="text-xl font-semibold text-gray-700 mb-2">Loading AccLounge</h2>
        <p className="text-gray-500 mb-4">Setting up your accountability journey...</p>
        
        {showFallback && !showError && (
          <div className="mt-6">
            <p className="text-sm text-gray-400 mb-3">Taking longer than expected?</p>
            <button 
              onClick={handleSoftRefresh}
              disabled={isRetrying}
              className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed mr-2"
            >
              {isRetrying ? 'Refreshing...' : 'Refresh Session'}
            </button>
          </div>
        )}

        {showError && (
          <div className="mt-6 p-4 bg-red-50 border border-red-200 rounded-lg">
            <p className="text-sm text-red-600 mb-4">
              Unable to load the application. This may be due to network issues or server problems.
            </p>
            <div className="space-y-2">
              <button 
                onClick={handleSoftRefresh}
                disabled={isRetrying}
                className="w-full px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isRetrying ? 'Retrying...' : `Try Again ${retryCount > 0 ? `(${retryCount})` : ''}`}
              </button>
              <button 
                onClick={handleGoToDashboard}
                className="w-full px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors"
              >
                Go to Dashboard
              </button>
              <button 
                onClick={handleSignOut}
                className="w-full px-4 py-2 bg-gray-600 text-white rounded-md hover:bg-gray-700 transition-colors text-sm"
              >
                Sign Out
              </button>
            </div>
            {retryCount > 2 && (
              <p className="text-xs text-gray-500 mt-3">
                If this issue persists, please contact support.
              </p>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default EnhancedLoadingScreen;