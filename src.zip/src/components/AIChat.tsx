import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { 
  Send, 
  Bot, 
  User,
  Lightbulb,
  Target,
  Users,
  Settings
} from 'lucide-react';

const AIChat = () => {
  const [messages, setMessages] = useState([
    {
      id: 1,
      sender: 'ai',
      content: "Hi! I'm your AI Accountability Coach, powered by the MAPS framework. I'm here to help you build better habits and achieve your goals. What would you like to work on today?",
      timestamp: '10:00 AM',
      framework: null
    },
    {
      id: 2,
      sender: 'user',
      content: "I'm struggling to stick to my morning routine. I keep hitting snooze and missing my workout.",
      timestamp: '10:02 AM',
      framework: null
    },
    {
      id: 3,
      sender: 'ai',
      content: "I understand! Let's use the MAPS framework to tackle this. First, let's work on your **Mindset** 🧠 - what thoughts go through your head when the alarm goes off?",
      timestamp: '10:02 AM',
      framework: 'Mindset'
    },
    {
      id: 4,
      sender: 'user',
      content: "Usually something like 'I'm too tired' or 'I can skip just today'",
      timestamp: '10:05 AM',
      framework: null
    },
    {
      id: 5,
      sender: 'ai',
      content: "Perfect awareness! Now for **Action** 🚀 - let's create a simple system: place your alarm across the room and lay out your workout clothes the night before. For **Partnership** 🤝, consider finding a workout buddy. And for **Systems** ⚙️, what if we start with just 10 minutes instead of a full workout?",
      timestamp: '10:06 AM',
      framework: 'Action'
    }
  ]);

  const [newMessage, setNewMessage] = useState('');

  const sendMessage = () => {
    if (newMessage.trim()) {
      const userMessage = {
        id: messages.length + 1,
        sender: 'user' as const,
        content: newMessage,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        framework: null
      };

      // Simulate AI response
      const aiResponse = {
        id: messages.length + 2,
        sender: 'ai' as const,
        content: generateAIResponse(newMessage),
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        framework: getRandomFramework()
      };

      setMessages([...messages, userMessage, aiResponse]);
      setNewMessage('');
    }
  };

  const generateAIResponse = (userMessage: string) => {
    const responses = [
      "That's a great insight! Let's break this down using the MAPS framework to find the best approach for you.",
      "I can help you with that! Which aspect of MAPS do you think would be most helpful here - Mindset, Action, Partnership, or Systems?",
      "Excellent progress! Remember, small consistent actions compound into big results. What's your next step?",
      "Let's focus on building a sustainable system around this habit. What obstacles do you anticipate?",
      "Partnership can be powerful here. Have you considered finding an accountability partner for this goal?"
    ];
    return responses[Math.floor(Math.random() * responses.length)];
  };

  const getRandomFramework = () => {
    const frameworks = ['Mindset', 'Action', 'Partnership', 'Systems'];
    return Math.random() > 0.5 ? frameworks[Math.floor(Math.random() * frameworks.length)] : null;
  };

  const getFrameworkColor = (framework: string) => {
    switch (framework) {
      case 'Mindset': return 'bg-amber-100 text-amber-800';
      case 'Action': return 'bg-green-100 text-green-800';
      case 'Partnership': return 'bg-orange-100 text-orange-800';
      case 'Systems': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getFrameworkIcon = (framework: string) => {
    switch (framework) {
      case 'Mindset': return '🧠';
      case 'Action': return '🚀';
      case 'Partnership': return '🤝';
      case 'Systems': return '⚙️';
      default: return '🎯';
    }
  };

  const quickActions = [
    { label: 'Set a Goal', icon: Target },
    { label: 'Find Partner', icon: Users },
    { label: 'Get Tips', icon: Lightbulb },
    { label: 'Build System', icon: Settings }
  ];

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">AI Accountability Coach</h2>
          <p className="text-muted-foreground">Powered by the MAPS framework</p>
        </div>
        <Badge className="bg-acclounge-sage text-white">
          <Bot className="h-3 w-3 mr-1" />
          Online
        </Badge>
      </div>

      {/* MAPS Framework Quick Reference */}
      <Card className="bg-gradient-to-r from-acclounge-dark to-acclounge-navy text-white">
        <CardContent className="p-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
            <div>
              <div className="text-xl mb-1">🧠</div>
              <div className="text-sm font-medium">Mindset</div>
            </div>
            <div>
              <div className="text-xl mb-1">🚀</div>
              <div className="text-sm font-medium">Action</div>
            </div>
            <div>
              <div className="text-xl mb-1">🤝</div>
              <div className="text-sm font-medium">Partnership</div>
            </div>
            <div>
              <div className="text-xl mb-1">⚙️</div>
              <div className="text-sm font-medium">Systems</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Chat Messages */}
      <Card className="h-96">
        <CardContent className="p-0">
          <div className="h-full flex flex-col">
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {messages.map((message) => (
                <div key={message.id} className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`flex items-start gap-2 max-w-[80%] ${message.sender === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                    <Avatar className="w-8 h-8">
                      <AvatarFallback className={message.sender === 'user' ? 'bg-acclounge-sage' : 'bg-acclounge-navy'}>
                        {message.sender === 'user' ? <User className="h-4 w-4" /> : <Bot className="h-4 w-4" />}
                      </AvatarFallback>
                    </Avatar>
                    <div className={`rounded-lg p-3 ${
                      message.sender === 'user' 
                        ? 'bg-acclounge-sage text-white' 
                        : 'bg-gray-100 text-gray-900'
                    }`}>
                      <p className="text-sm">{message.content}</p>
                      <div className="flex items-center justify-between mt-2">
                        <span className="text-xs opacity-70">{message.timestamp}</span>
                        {message.framework && (
                          <Badge className={`text-xs ${getFrameworkColor(message.framework)}`}>
                            {getFrameworkIcon(message.framework)} {message.framework}
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Quick Actions */}
            <div className="p-4 border-t">
              <div className="flex flex-wrap gap-2 mb-3">
                {quickActions.map((action, index) => {
                  const Icon = action.icon;
                  return (
                    <Button
                      key={index}
                      variant="outline"
                      size="sm"
                      className="text-xs"
                      onClick={() => setNewMessage(`Help me ${action.label.toLowerCase()}`)}
                    >
                      <Icon className="h-3 w-3 mr-1" />
                      {action.label}
                    </Button>
                  );
                })}
              </div>

              {/* Message Input */}
              <div className="flex gap-2">
                <Input
                  placeholder="Ask your AI coach anything..."
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
                  className="flex-1"
                />
                <Button onClick={sendMessage} className="bg-acclounge-sage hover:bg-acclounge-sage/90">
                  <Send className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AIChat;