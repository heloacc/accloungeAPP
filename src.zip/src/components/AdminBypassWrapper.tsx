import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';

interface AdminBypassWrapperProps {
  children: React.ReactNode;
  fallback?: React.ReactNode;
}

export const AdminBypassWrapper: React.FC<AdminBypassWrapperProps> = ({ 
  children, 
  fallback = <div>Loading...</div> 
}) => {
  const [isAdminOrMod, setIsAdminOrMod] = useState<boolean | null>(null);

  useEffect(() => {
    const checkRole = async () => {
      try {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) {
          setIsAdminOrMod(false);
          return;
        }

        const { data: userRole } = await supabase
          .from('user_roles')
          .select('role')
          .eq('user_id', user.id)
          .single();

        const role = userRole?.role?.toLowerCase();
        setIsAdminOrMod(role === 'admin' || role === 'moderator');
      } catch (error) {
        console.error('Error checking role:', error);
        setIsAdminOrMod(false);
      }
    };

    checkRole();
  }, []);

  if (isAdminOrMod === null) {
    return <>{fallback}</>;
  }

  if (isAdminOrMod) {
    return <>{children}</>;
  }

  return <>{fallback}</>;
};

export default AdminBypassWrapper;