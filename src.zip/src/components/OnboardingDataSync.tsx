import React, { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Loader2 } from 'lucide-react';

interface OnboardingData {
  question_1: string; // What brings you to AccLounge?
  question_2: string; // What's one habit you're excited to build?
  question_3: string; // How do you prefer to be supported?
}

export default function OnboardingDataSync() {
  const [onboardingData, setOnboardingData] = useState<OnboardingData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadOnboardingData();
  }, []);

  const loadOnboardingData = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('intro_questions')
        .select('question_1, question_2, question_3')
        .eq('user_id', user.id)
        .single();

      if (error && error.code !== 'PGRST116') { // PGRST116 = no rows returned
        throw error;
      }

      setOnboardingData(data);
    } catch (error) {
      console.error('Error loading onboarding data:', error);
    } finally {
      setLoading(false);
    }
  };



  if (loading) {
    return (
      <Card>
        <CardContent className="p-6 text-center">
          <Loader2 className="w-6 h-6 animate-spin mx-auto mb-2" />
          <p>Loading onboarding data...</p>
        </CardContent>
      </Card>
    );
  }

  if (!onboardingData) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>No Onboarding Data</CardTitle>
        </CardHeader>
        <CardContent>
           <p className="text-muted-foreground">
             No onboarding responses found. Complete the onboarding process to view your responses here.
           </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Your Onboarding Responses</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <h4 className="font-medium mb-1">What brings you to AccLounge?</h4>
          <p className="text-sm text-muted-foreground">{onboardingData.question_1}</p>
        </div>
        
        <div>
          <h4 className="font-medium mb-1">Habit you're excited to build:</h4>
          <p className="text-sm text-muted-foreground">{onboardingData.question_2}</p>
        </div>
        
        <div>
          <h4 className="font-medium mb-1">How you prefer to be supported:</h4>
          <p className="text-sm text-muted-foreground">{onboardingData.question_3}</p>
        </div>
      </CardContent>
    </Card>
  );
}