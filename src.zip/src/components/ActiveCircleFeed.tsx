import { useState, useEffect, useMemo, useCallback, memo } from 'react';
import { useAppContext } from '@/contexts/AppContext';
import { supabase } from '@/lib/supabase';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { AlertCircle, Users, Send, MessageCircle, Pin, Trash2, Bell, BellOff, Heart, MessageSquare } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';
import PostScheduler from '@/components/PostScheduler';
import PostActions from '@/components/PostActions';
import { useUserData } from '@/hooks/useUserData';
import VirtualScrollList from '@/components/VirtualScrollList';
import { usePerformanceMonitor, useDebounce } from '@/hooks/usePerformanceOptimization';

interface Post {
  id: string;
  content: string;
  author_name?: string;
  user_id: string;
  created_at: string;
  is_pinned?: boolean;
  recovery_status?: string;
  post_type?: string;
  tagged_users?: any[];
  profiles?: {
    full_name: string;
  };
}

interface ActiveCircleFeedProps {
  groupId: string;
}

// Memoized Post Component for better performance
const PostItem = memo(({ post, isAdmin, isModerator, onPostUpdate, onPostDelete }: {
  post: Post;
  isAdmin: boolean;
  isModerator: boolean;
  onPostUpdate: (updatedPost: Post) => void;
  onPostDelete: (postId: string) => void;
}) => {
  const getPostIcon = (postType?: string) => {
    switch (postType) {
      case 'match_announcement':
        return <Heart className="h-4 w-4 text-pink-500" />;
      case 'admin_announcement':
        return <MessageCircle className="h-4 w-4 text-blue-500" />;
      default:
        return <MessageSquare className="h-4 w-4 text-gray-500" />;
    }
  };

  const formatPostTime = (createdAt: string) => {
    const now = new Date();
    const postTime = new Date(createdAt);
    const diffInMinutes = Math.floor((now.getTime() - postTime.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 1) return 'Just now';
    if (diffInMinutes < 60) return `${diffInMinutes}m ago`;
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)}h ago`;
    return postTime.toLocaleDateString();
  };

  return (
    <Card className="border-l-4 border-l-[#596D59]">
      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          <div className="flex-shrink-0">
            {getPostIcon(post.post_type)}
          </div>
          <div className="flex-1">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <span className="font-medium text-sm">
                  {post.profiles?.full_name || 'Unknown User'}
                </span>
                <span className="text-xs text-muted-foreground">
                  {formatPostTime(post.created_at)}
                </span>
                {post.post_type === 'match_announcement' && (
                  <Badge variant="secondary" className="text-xs">
                    Match Alert
                  </Badge>
                )}
              </div>
              <PostActions
                post={post}
                isAdmin={isAdmin}
                isModerator={isModerator}
                onPostUpdate={onPostUpdate}
                onPostDelete={onPostDelete}
                table="acircle_posts"
              />
            </div>
            <p className="text-sm text-gray-700 whitespace-pre-wrap">
              {post.content}
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
});

PostItem.displayName = 'PostItem';

const ActiveCircleFeed: React.FC<ActiveCircleFeedProps> = ({ groupId }) => {
  const [posts, setPosts] = useState<Post[]>([]);
  const [newPost, setNewPost] = useState('');
  const [loading, setLoading] = useState(true);
  const [feedNotifications, setFeedNotifications] = useState(true);
  const { user, isAdmin, isModerator } = useUserData();
  
  // Performance monitoring
  const { renderCount, measureRender } = usePerformanceMonitor('ActiveCircleFeed');
  
  // Memoized callbacks for better performance
  const handlePostUpdate = useCallback((updatedPost: Post) => {
    setPosts(prev => prev.map(p => p.id === updatedPost.id ? updatedPost : p));
  }, []);

  const handlePostDelete = useCallback((postId: string) => {
    setPosts(prev => prev.filter(p => p.id !== postId));
  }, []);

  // Memoized post renderer for virtual scrolling
  const renderPost = useCallback((post: Post, index: number) => (
    <PostItem
      key={post.id}
      post={post}
      isAdmin={isAdmin}
      isModerator={isModerator}
      onPostUpdate={handlePostUpdate}
      onPostDelete={handlePostDelete}
    />
  ), [isAdmin, isModerator, handlePostUpdate, handlePostDelete]);

  // Debounced post creation to prevent rapid submissions
  const debouncedCreatePost = useDebounce(async () => {
    if (!newPost.trim()) return;
    
    const renderTime = measureRender(() => {
      // Post creation logic will be handled by the actual createPost function
    });
    
    if (renderTime > 10) {
      console.warn(`Post creation render took ${renderTime.toFixed(2)}ms`);
    }
  }, 300);
  
  // Consolidated useEffect with proper cleanup and debouncing
  // Consolidated useEffect with proper cleanup and debouncing
  useEffect(() => {
    let isMounted = true;
    let channel: any;
    let initTimeout: NodeJS.Timeout | undefined;

    const initializeFeed = async () => {
      if (user && groupId && isMounted) {
        try {
          await Promise.all([
            fetchPosts(),
            fetchNotificationSettings()
          ]);

          // Set up real-time subscription only after initial load
          if (isMounted) {
            channel = supabase
              .channel(`acircle_posts_${groupId}`)
              .on('postgres_changes', 
                { event: 'INSERT', schema: 'public', table: 'acircle_posts', filter: `group_id=eq.${groupId}` },
                (payload) => {
                  if (!isMounted) return;
                  try {
                    const newPost = payload.new;
                    if (newPost && newPost.recovery_status === 'active') {
                      setPosts(prev => [{
                        id: newPost.id,
                        content: newPost.content,
                        post_type: newPost.post_type || 'user_post',
                        tagged_users: newPost.tagged_users || [],
                        created_at: newPost.created_at,
                        user_id: newPost.user_id,
                        is_pinned: newPost.is_pinned || false,
                        recovery_status: newPost.recovery_status,
                        profiles: { full_name: 'New User' }
                      }, ...prev]);
                    }
                  } catch (error) {
                    console.error('Error processing real-time update:', error);
                  }
                }
              )
              .subscribe();
          }
        } catch (error) {
          console.error('Error initializing feed:', error);
        }
      }
    };

    // Immediate initialization for better performance
    initializeFeed();

    return () => {
      isMounted = false;
      if (initTimeout) {
        clearTimeout(initTimeout);
      }
      if (channel) {
        supabase.removeChannel(channel);
      }
    };
  }, [user?.id, groupId]); // Only depend on user ID and groupId

  const fetchPosts = async () => {
    try {
      console.log('Fetching posts for group:', groupId);
      
      const { data, error } = await supabase
        .from('acircle_posts')
        .select(`
          id,
          content,
          post_type,
          tagged_users,
          created_at,
          user_id,
          is_pinned,
          scheduled_for
        `)
        .eq('group_id', groupId)
        .eq('recovery_status', 'active')
        .order('is_pinned', { ascending: false })
        .order('created_at', { ascending: false })
        .limit(20);

      if (error) {
        console.error('Supabase error:', error);
        throw error;
      }

      console.log('Raw data from database:', data);
      console.log('Number of posts found:', data?.length || 0);
      
      if (data) {
        // Get user profiles for the posts
        const userIds = [...new Set(data.map(post => post.user_id))];
        const { data: profiles } = await supabase
          .from('profiles')
          .select('id, full_name')
          .in('id', userIds);

        const profileMap = profiles?.reduce((acc, profile) => {
          acc[profile.id] = profile;
          return acc;
        }, {} as Record<string, any>) || {};

        const postsWithProfiles = data.map(post => ({
          ...post,
          profiles: profileMap[post.user_id] || { full_name: 'Unknown User' }
        }));

        console.log('Setting posts state with:', postsWithProfiles);
        setPosts(postsWithProfiles);
      } else {
        console.log('No data returned, setting empty array');
        setPosts([]);
      }
    } catch (error) {
      console.error('Error fetching posts:', error);
      setPosts([]); // Set empty array on error
    } finally {
      setLoading(false);
    }
  };

  const fetchNotificationSettings = async () => {
    try {
      const { data } = await supabase
        .from('acircle_members')
        .select('feed_notifications')
        .eq('group_id', groupId)
        .eq('user_id', user?.id)
        .single();

      if (data) {
        setFeedNotifications(data.feed_notifications);
      }
    } catch (error) {
      console.error('Error fetching notification settings:', error);
    }
  };

  const createPost = async (scheduledFor?: string) => {
    if (!newPost.trim() || !user) return;

    console.log('Creating post with:', {
      groupId,
      userId: user.id,
      content: newPost,
      userFullName: user.user_metadata?.full_name
    });

    try {
      // Save to database first to ensure persistence across app updates
      const postData = {
        group_id: groupId,
        user_id: user.id,
        content: newPost,
        post_type: 'user_post'
      };

      if (scheduledFor) {
        postData.scheduled_for = scheduledFor;
      }

      const { data, error } = await supabase
        .from('acircle_posts')
        .insert([postData])
        .select()
        .single();

      console.log('Post creation result:', { data, error });

      if (error) throw error;

      // Clear input and refresh posts only after successful save
      setNewPost('');
      console.log('Post created successfully, refreshing feed...');
      fetchPosts();
      // Create notifications for all members who have feed notifications enabled
      const { data: members } = await supabase
        .from('acircle_members')
        .select('user_id')
        .eq('group_id', groupId)
        .eq('feed_notifications', true)
        .neq('user_id', user.id);

      if (members && members.length > 0) {
        const notifications = members.map(member => ({
          user_id: member.user_id,
          type: 'acircle_post',
          title: 'New Active Circle Post',
          message: `${user.user_metadata?.full_name || 'Someone'} posted in Active Circle`,
          data: { group_id: groupId, post_content: newPost.substring(0, 100) }
        }));

        await supabase.from('notifications').insert(notifications);
      }
    } catch (error) {
      console.error('Error creating post:', error);
      
      // Fallback: Add to local state to prevent user frustration
      const tempPost = {
        id: `temp-${Date.now()}`,
        content: newPost,
        post_type: 'user_post',
        tagged_users: [],
        created_at: new Date().toISOString(),
        profiles: { full_name: user.user_metadata?.full_name || 'You' }
      };
      
      setPosts(prevPosts => [tempPost, ...prevPosts]);
      setNewPost('');
      
      // Immediate background retry for better UX
      (async () => {
        try {
          await supabase.from('acircle_posts').insert([{
            group_id: groupId,
            user_id: user.id,
            content: newPost,
            post_type: 'user_post'
          }]);
          // Refresh posts to get the real post with proper ID
          fetchPosts();
        } catch (retryError) {
          console.error('Background retry failed:', retryError);
        }
      })();
    }
  };

  const updateNotificationSettings = async (enabled: boolean) => {
    try {
      const { error } = await supabase
        .from('acircle_members')
        .update({ feed_notifications: enabled })
        .eq('group_id', groupId)
        .eq('user_id', user?.id);

      if (!error) {
        setFeedNotifications(enabled);
      }
    } catch (error) {
      console.error('Error updating notification settings:', error);
    }
  };

  const deletePost = async (postId: string) => {
    if (!isAdmin) return;
    
    try {
      const { error } = await supabase
        .from('acircle_posts')
        .delete()
        .eq('id', postId);

      if (error) throw error;
      
      setPosts(prev => prev.filter(post => post.id !== postId));
    } catch (error) {
      console.error('Error deleting post:', error);
    }
  };

  const formatPostTime = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInHours = (now.getTime() - date.getTime()) / (1000 * 60 * 60);

    if (diffInHours < 1) {
      return 'Just now';
    } else if (diffInHours < 24) {
      return `${Math.floor(diffInHours)}h ago`;
    } else {
      return date.toLocaleDateString();
    }
  };

  const getPostIcon = (postType: string) => {
    switch (postType) {
      case 'match_announcement':
        return <Heart className="h-4 w-4 text-red-500" />;
      case 'goal_update':
        return <Users className="h-4 w-4 text-blue-500" />;
      default:
        return <MessageSquare className="h-4 w-4 text-gray-500" />;
    }
  };

  if (loading) {
    return <div className="p-4">Loading feed...</div>;
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <MessageSquare className="h-5 w-5 text-[#596D59]" />
              Active Circle Feed
            </CardTitle>
            <div className="flex items-center gap-2">
              {feedNotifications ? <Bell className="h-4 w-4" /> : <BellOff className="h-4 w-4" />}
              <Switch
                checked={feedNotifications}
                onCheckedChange={updateNotificationSettings}
              />
              <Label className="text-sm">Notifications</Label>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Textarea
              placeholder="Share your progress, ask for support, or celebrate wins..."
              value={newPost}
              onChange={(e) => setNewPost(e.target.value)}
              rows={3}
            />
            <div className="flex gap-2">
              <PostScheduler
                content={newPost}
                onSchedule={(scheduledFor) => createPost(scheduledFor)}
                onPost={() => createPost()}
                isAdmin={isAdmin}
                isModerator={isModerator}
              />
              <Button 
                onClick={() => createPost()} 
                disabled={!newPost.trim()}
                className="bg-[#596D59] hover:bg-[#596D59]/90"
              >
                <Send className="h-4 w-4 mr-2" />
                Share with Circle
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="space-y-3">
        {posts.length === 0 ? (
          <Card>
            <CardContent className="p-6 text-center text-muted-foreground">
              No posts yet. Be the first to share something with your circle!
            </CardContent>
          </Card>
        ) : (
          <VirtualScrollList
            items={posts}
            itemHeight={120} // Approximate height of each post card
            containerHeight={600} // Fixed height for the scrollable area
            renderItem={renderPost}
            className="space-y-3"
            overscan={5} // Render 5 extra items above and below viewport
          />
        )}
      </div>
    </div>
  );
};

const MemoizedActiveCircleFeed = memo(ActiveCircleFeed);
MemoizedActiveCircleFeed.displayName = 'ActiveCircleFeed';

export { MemoizedActiveCircleFeed as ActiveCircleFeed };
export default MemoizedActiveCircleFeed;