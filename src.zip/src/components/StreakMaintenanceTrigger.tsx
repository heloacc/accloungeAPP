import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { supabase } from '@/lib/supabase';
import { Loader2, Play, CheckCircle, AlertCircle } from 'lucide-react';

export function StreakMaintenanceTrigger() {
  const [isRunning, setIsRunning] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  const triggerMaintenance = async () => {
    setIsRunning(true);
    setError(null);
    setResult(null);

    try {
      const { data, error: functionError } = await supabase.functions.invoke('manual-streak-trigger', {
        body: {}
      });

      if (functionError) {
        throw functionError;
      }

      setResult(data);
    } catch (err: any) {
      setError(err.message || 'Failed to trigger streak maintenance');
    } finally {
      setIsRunning(false);
    }
  };

  return (
    <Card className="w-full max-w-2xl">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Play className="h-5 w-5" />
          Manual Streak Maintenance
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-sm text-muted-foreground">
          This will manually run the streak maintenance job to correct any habit streaks based on completion dates.
        </p>
        
        <Button 
          onClick={triggerMaintenance} 
          disabled={isRunning}
          className="w-full"
        >
          {isRunning ? (
            <>
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              Running Maintenance...
            </>
          ) : (
            <>
              <Play className="h-4 w-4 mr-2" />
              Run Streak Maintenance
            </>
          )}
        </Button>

        {result && (
          <Card className="bg-green-50 border-green-200">
            <CardContent className="pt-4">
              <div className="flex items-start gap-2">
                <CheckCircle className="h-5 w-5 text-green-600 mt-0.5" />
                <div className="space-y-2">
                  <h4 className="font-medium text-green-800">Maintenance Completed</h4>
                  {result.streakMaintenanceResult && (
                    <div className="text-sm text-green-700 space-y-1">
                      <p>• Habits processed: {result.streakMaintenanceResult.updated || 0}</p>
                      <p>• Streaks reset: {result.streakMaintenanceResult.streaksReset || 0}</p>
                      <p>• Execution time: {result.streakMaintenanceResult.executionTime || 0}ms</p>
                      {result.streakMaintenanceResult.updates && result.streakMaintenanceResult.updates.length > 0 && (
                        <details className="mt-2">
                          <summary className="cursor-pointer font-medium">View Updates</summary>
                          <div className="mt-2 space-y-1">
                            {result.streakMaintenanceResult.updates.map((update: any, index: number) => (
                              <p key={index} className="text-xs">
                                Habit {update.id}: {update.oldStreak} → {update.newStreak}
                              </p>
                            ))}
                          </div>
                        </details>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {error && (
          <Card className="bg-red-50 border-red-200">
            <CardContent className="pt-4">
              <div className="flex items-start gap-2">
                <AlertCircle className="h-5 w-5 text-red-600 mt-0.5" />
                <div>
                  <h4 className="font-medium text-red-800">Error</h4>
                  <p className="text-sm text-red-700">{error}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </CardContent>
    </Card>
  );
}