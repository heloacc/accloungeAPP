import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { TrendingUp, Calendar } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface TrendData {
  date: string;
  goalCompletions: number;
  habitCompletions: number;
}

const TimeBasedTrends: React.FC = () => {
  const [trends, setTrends] = useState<TrendData[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadTrends();
  }, []);

  const loadTrends = async () => {
    try {
      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

      const [goalsResult, habitsResult] = await Promise.all([
        // Use updated_at and completed=true instead of completed_at and status
        supabase
          .from('goals')
          .select('updated_at')
          .eq('completed', true)
          .gte('updated_at', thirtyDaysAgo.toISOString()),
        supabase
          .from('habits')
          .select('updated_at')
          .eq('is_active', true)
          .gte('updated_at', thirtyDaysAgo.toISOString())
      ]);

      // Group by date
      const trendMap: { [key: string]: TrendData } = {};
      
      // Initialize last 30 days
      for (let i = 29; i >= 0; i--) {
        const date = new Date();
        date.setDate(date.getDate() - i);
        const dateStr = date.toISOString().split('T')[0];
        trendMap[dateStr] = {
          date: dateStr,
          goalCompletions: 0,
          habitCompletions: 0
        };
      }

      // Count goal completions
      goalsResult.data?.forEach(goal => {
        if (goal.updated_at) {
          const date = goal.updated_at.split('T')[0];
          if (trendMap[date]) {
            trendMap[date].goalCompletions++;
          }
        }
      });

      // Count habit completions
      habitsResult.data?.forEach(habit => {
        if (habit.updated_at) {
          const date = habit.updated_at.split('T')[0];
          if (trendMap[date]) {
            trendMap[date].habitCompletions++;
          }
        }
      });

      setTrends(Object.values(trendMap));
    } catch (error) {
      console.error('Error loading trends:', error);
    } finally {
      setLoading(false);
    }
  };

  const maxCompletions = Math.max(
    ...trends.map(t => t.goalCompletions + t.habitCompletions)
  );

  if (loading) {
    return <div className="text-center py-4">Loading trends...</div>;
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <TrendingUp className="h-5 w-5" />
          30-Day Completion Trends
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="grid grid-cols-7 gap-1 text-xs text-center">
            {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
              <div key={day} className="font-medium text-muted-foreground">{day}</div>
            ))}
          </div>
          
          <div className="grid grid-cols-7 gap-1">
            {trends.slice(-28).map((trend, index) => {
              const total = trend.goalCompletions + trend.habitCompletions;
              const intensity = maxCompletions > 0 ? total / maxCompletions : 0;
              const date = new Date(trend.date);
              
              return (
                <div
                  key={trend.date}
                  className={`
                    aspect-square rounded text-xs flex items-center justify-center
                    ${intensity === 0 ? 'bg-gray-100' : 
                      intensity < 0.3 ? 'bg-green-200' :
                      intensity < 0.6 ? 'bg-green-400' : 'bg-green-600 text-white'}
                  `}
                  title={`${date.toLocaleDateString()}: ${total} completions`}
                >
                  {date.getDate()}
                </div>
              );
            })}
          </div>
          
          <div className="text-sm text-muted-foreground">
            Darker colors indicate more completions
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default TimeBasedTrends;