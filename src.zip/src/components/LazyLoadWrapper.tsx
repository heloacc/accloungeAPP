import React, { Suspense, memo } from 'react';
import { LoadingSpinner } from '@/components/ui/loading-spinner';

interface LazyLoadWrapperProps {
  children: React.ReactNode;
  fallback?: React.ReactNode;
  className?: string;
}

const LazyLoadWrapper = memo(({ children, fallback, className }: LazyLoadWrapperProps) => {
  const defaultFallback = (
    <div className={`flex items-center justify-center p-8 ${className || ''}`}>
      <LoadingSpinner />
      <span className="ml-2 text-sm text-gray-600">Loading...</span>
    </div>
  );

  return (
    <Suspense fallback={fallback || defaultFallback}>
      {children}
    </Suspense>
  );
});

LazyLoadWrapper.displayName = 'LazyLoadWrapper';

export default LazyLoadWrapper;