import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Shield, Plus, Trash2 } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface PageAccessRule {
  id: string;
  page_path: string;
  minimum_tier_id: string | null;
  required_plan_id: string | null;
  created_at: string;
}

interface Tier {
  id: string;
  name: string;
  price_monthly: string;
}

const DynamicPageAccessManagerUI = () => {
  const [rules, setRules] = useState<PageAccessRule[]>([]);
  const [tiers, setTiers] = useState<Tier[]>([]);
  const [loading, setLoading] = useState(false);
  const [newRule, setNewRule] = useState({
    page_path: '',
    minimum_tier_id: null as string | null,
    required_plan_id: null as string | null
  });

  const loadRules = async () => {
    try {
      const { data, error } = await supabase
        .from('page_access_rules')
        .select('*')
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      setRules(data || []);
    } catch (error) {
      console.error('Error loading rules:', error);
    }
  };

  const loadTiers = async () => {
    try {
      const { data, error } = await supabase
        .from('subscription_tiers')
        .select('*')
        .order('price_monthly', { ascending: true });
      
      if (error) throw error;
      setTiers(data || []);
    } catch (error) {
      console.error('Error loading tiers:', error);
    }
  };

  const addRule = async () => {
    if (!newRule.page_path.trim()) return;
    
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('page_access_rules')
        .insert([{
          page_path: newRule.page_path,
          minimum_tier_id: newRule.minimum_tier_id,
          required_plan_id: newRule.required_plan_id
        }])
        .select();
      
      if (error) throw error;
      
      setRules(prev => [data[0], ...prev]);
      setNewRule({
        page_path: '',
        minimum_tier_id: null,
        required_plan_id: null
      });
    } catch (error) {
      console.error('Error adding rule:', error);
    } finally {
      setLoading(false);
    }
  };

  const deleteRule = async (id: string) => {
    try {
      const { error } = await supabase
        .from('page_access_rules')
        .delete()
        .eq('id', id);
      
      if (error) throw error;
      
      setRules(prev => prev.filter(rule => rule.id !== id));
    } catch (error) {
      console.error('Error deleting rule:', error);
    }
  };

  const getAccessBadgeColor = (rule: PageAccessRule) => {
    if (!rule.minimum_tier_id) return 'secondary';
    const tier = tiers.find(t => t.id === rule.minimum_tier_id);
    if (!tier) return 'outline';
    
    const price = parseFloat(tier.price_monthly);
    if (price === 0) return 'secondary';
    if (price < 15) return 'default';
    return 'destructive';
  };

  useEffect(() => {
    loadRules();
    loadTiers();
  }, []);

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Add Page Access Rule
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <Label htmlFor="page-path">Page Path</Label>
              <Input
                id="page-path"
                placeholder="/analytics, /premium-features, /pro-dashboard"
                value={newRule.page_path}
                onChange={(e) => setNewRule({ ...newRule, page_path: e.target.value })}
              />
            </div>
            
            <div>
              <Label htmlFor="minimum-tier">Minimum Tier Required</Label>
              <Select 
                value={newRule.minimum_tier_id || 'free-access'} 
                onValueChange={(value) => setNewRule({ ...newRule, minimum_tier_id: value === 'free-access' ? null : value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Free Access" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="free-access">Free Access</SelectItem>
                  {tiers.map((tier) => (
                    <SelectItem key={tier.id} value={tier.id}>
                      {tier.name} (${tier.price_monthly}/mo)
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {newRule.minimum_tier_id && (
              <div>
                <Label htmlFor="specific-plan">Specific Plan (Optional)</Label>
                <Select 
                  value={newRule.required_plan_id || 'any-plan'} 
                  onValueChange={(value) => setNewRule({ ...newRule, required_plan_id: value === 'any-plan' ? null : value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Any plan at this tier or higher" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="any-plan">Any plan at this tier or higher</SelectItem>
                    {tiers
                      .filter(tier => newRule.minimum_tier_id ? 
                        parseFloat(tier.price_monthly) >= parseFloat(tiers.find(t => t.id === newRule.minimum_tier_id)?.price_monthly || '0') 
                        : true)
                      .map((tier) => (
                        <SelectItem key={tier.id} value={tier.id}>
                          {tier.name} (${tier.price_monthly}/mo)
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            <Button onClick={addRule} className="w-full" disabled={loading}>
              <Plus className="h-4 w-4 mr-2" />
              Add Access Rule
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Current Access Rules</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {rules.map((rule) => (
              <div key={rule.id} className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex items-center gap-3">
                  <div>
                    <p className="font-medium">{rule.page_path}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <Badge variant={getAccessBadgeColor(rule)}>
                        {rule.minimum_tier_id 
                          ? tiers.find(t => t.id === rule.minimum_tier_id)?.name || 'Unknown Tier'
                          : 'Free Access'
                        }
                      </Badge>
                      {rule.required_plan_id && (
                        <Badge variant="outline">
                          {tiers.find(t => t.id === rule.required_plan_id)?.name || 'Specific Plan'}
                        </Badge>
                      )}
                    </div>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => deleteRule(rule.id)}
                  className="text-red-600 hover:text-red-700"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            ))}
            {rules.length === 0 && (
              <p className="text-muted-foreground text-center py-4">
                No access rules configured yet.
              </p>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default DynamicPageAccessManagerUI;