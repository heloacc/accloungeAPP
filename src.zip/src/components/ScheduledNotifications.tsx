import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Calendar, Clock, Send, Trash2 } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabase';

interface ScheduledNotification {
  id: string;
  title: string;
  message: string;
  scheduled_for: string;
  type: string;
  status: 'pending' | 'sent' | 'failed';
  created_at: string;
}

const ScheduledNotifications = () => {
  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  const [scheduledFor, setScheduledFor] = useState('');
  const [type, setType] = useState('reminder');
  const [notifications, setNotifications] = useState<ScheduledNotification[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchScheduledNotifications();
  }, []);

  const fetchScheduledNotifications = async () => {
    try {
      const { data, error } = await supabase
        .from('scheduled_notifications')
        .select('*')
        .order('scheduled_for', { ascending: true });

      if (error) throw error;
      setNotifications(data || []);
    } catch (error) {
      console.error('Error fetching scheduled notifications:', error);
    }
  };

  const scheduleNotification = async () => {
    if (!title.trim() || !message.trim() || !scheduledFor) {
      toast({
        title: "Validation Error",
        description: "Please fill in all fields.",
        variant: "destructive"
      });
      return;
    }

    setLoading(true);
    try {
      const { error } = await supabase
        .from('scheduled_notifications')
        .insert({
          title: title.trim(),
          message: message.trim(),
          scheduled_for: scheduledFor,
          type,
          status: 'pending'
        });

      if (error) throw error;

      toast({
        title: "Notification Scheduled",
        description: "Notification has been scheduled successfully.",
      });

      setTitle('');
      setMessage('');
      setScheduledFor('');
      setType('reminder');
      fetchScheduledNotifications();
    } catch (error) {
      console.error('Error scheduling notification:', error);
      toast({
        title: "Error",
        description: "Failed to schedule notification.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const deleteScheduledNotification = async (id: string) => {
    try {
      const { error } = await supabase
        .from('scheduled_notifications')
        .delete()
        .eq('id', id);

      if (error) throw error;
      
      toast({
        title: "Notification Deleted",
        description: "Scheduled notification has been deleted.",
      });
      
      fetchScheduledNotifications();
    } catch (error) {
      console.error('Error deleting notification:', error);
      toast({
        title: "Error",
        description: "Failed to delete notification.",
        variant: "destructive"
      });
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'sent': return 'bg-green-100 text-green-800';
      case 'failed': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const scheduleRecurringHabitReminders = async () => {
    setLoading(true);
    try {
      // Schedule daily habit reminders for the next 7 days
      const notifications = [];
      for (let i = 1; i <= 7; i++) {
        const date = new Date();
        date.setDate(date.getDate() + i);
        date.setHours(9, 0, 0, 0); // 9 AM each day
        
        notifications.push({
          title: "Don't lose your streak!",
          message: "Complete your daily habits to maintain your progress. Check your habits now!",
          scheduled_for: date.toISOString(),
          type: 'habit_reminder',
          status: 'pending',
          send_in_app: true,
          send_email: false,
          send_pwa: true
        });
      }

      const { error } = await supabase
        .from('scheduled_notifications')
        .insert(notifications);

      if (error) throw error;

      toast({
        title: "Habit Reminders Scheduled",
        description: "Daily habit reminders scheduled for the next 7 days at 9 AM.",
      });

      fetchScheduledNotifications();
    } catch (error) {
      console.error('Error scheduling habit reminders:', error);
      toast({
        title: "Error",
        description: "Failed to schedule habit reminders.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const triggerHabitRemindersNow = async () => {
    setLoading(true);
    try {
      // Get all users and send habit reminders directly
      const { data: users, error: usersError } = await supabase
        .from('profiles')
        .select('id, full_name');

      if (usersError) throw usersError;

      // Create habit reminder notifications for all users
      const notifications = users?.map(user => ({
        user_id: user.id,
        type: 'habit_reminder',
        title: "Don't lose your streak! 🔥",
        message: `Hi ${user.full_name || 'there'}! Time to check off your daily habits and keep your momentum going.`,
        read: false
      })) || [];

      if (notifications.length > 0) {
        const { error } = await supabase
          .from('notifications')
          .insert(notifications);

        if (error) throw error;
      }

      toast({
        title: "Habit Reminders Sent",
        description: `Habit reminders sent to ${notifications.length} users`,
      });
    } catch (error) {
      console.error('Error triggering habit reminders:', error);
      toast({
        title: "Error",
        description: "Failed to send habit reminders.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5" />
              Schedule Notification
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Notification title..."
              maxLength={100}
            />
            <Textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Notification message..."
              rows={3}
              maxLength={500}
            />
            <Select value={type} onValueChange={setType}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="reminder">⏰ Reminder</SelectItem>
                <SelectItem value="motivational">💪 Motivational</SelectItem>
                <SelectItem value="announcement">📢 Announcement</SelectItem>
                <SelectItem value="habit_reminder">🎯 Habit Reminder</SelectItem>
              </SelectContent>
            </Select>
            <Input
              type="datetime-local"
              value={scheduledFor}
              onChange={(e) => setScheduledFor(e.target.value)}
              min={new Date().toISOString().slice(0, 16)}
            />
            <div className="space-y-2">
              <Button onClick={scheduleNotification} disabled={loading} className="w-full">
                <Calendar className="h-4 w-4 mr-2" />
                Schedule Notification
              </Button>
              <Button 
                onClick={scheduleRecurringHabitReminders} 
                disabled={loading} 
                variant="outline" 
                className="w-full"
              >
                🎯 Schedule 7-Day Habit Reminders
              </Button>
              <Button 
                onClick={triggerHabitRemindersNow} 
                disabled={loading} 
                variant="secondary" 
                className="w-full"
              >
                <Send className="h-4 w-4 mr-2" />
                Send Habit Reminders Now
              </Button>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Scheduled Notifications ({notifications.length})</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 max-h-96 overflow-y-auto">
              {notifications.length === 0 ? (
                <div className="text-center text-muted-foreground py-8">
                  <Clock className="h-8 w-8 mx-auto mb-2 opacity-50" />
                  <p>No scheduled notifications</p>
                </div>
              ) : (
                notifications.map((notification) => (
                  <div key={notification.id} className="border rounded-lg p-3">
                    <div className="flex justify-between items-start mb-2">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <Badge className={getStatusColor(notification.status)}>
                            {notification.status}
                          </Badge>
                          <Badge variant="outline">{notification.type}</Badge>
                        </div>
                        <h4 className="font-medium text-sm">{notification.title}</h4>
                        <p className="text-xs text-muted-foreground">{notification.message}</p>
                        <p className="text-xs text-muted-foreground mt-1">
                          📅 {new Date(notification.scheduled_for).toLocaleString()}
                        </p>
                      </div>
                      {notification.status === 'pending' && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => deleteScheduledNotification(notification.id)}
                          className="text-red-500 hover:text-red-700"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default ScheduledNotifications;