import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Users, Lock, Send, Clock, Shield } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { toast } from '@/components/ui/use-toast';

interface GroupPreviewProps {
  group: {
    id: string;
    name: string;
    description: string;
    is_private: boolean;
    has_pending_request: boolean;
    can_request_to_join: boolean;
  };
  cta: React.ReactNode;
  onRequestSent?: () => void;
}

const GroupPreview = ({ group, cta, onRequestSent }: GroupPreviewProps) => {
  const [message, setMessage] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [showDialog, setShowDialog] = useState(false);

  const handleJoinRequest = async () => {
    if (!message.trim()) {
      toast({
        title: "Message Required",
        description: "Please provide a message explaining why you'd like to join.",
        variant: "destructive",
      });
      return;
    }

    setSubmitting(true);
    try {
      const { data, error } = await supabase.functions.invoke('group-access-management', {
        body: { 
          operation: 'join_request',
          groupId: group.id,
          message: message.trim() 
        }
      });

      if (error) throw error;

      toast({
        title: "Request Sent",
        description: `Your request to join ${group.name} has been submitted.`,
      });

      setMessage('');
      setShowDialog(false);
      onRequestSent?.();
    } catch (error: any) {
      console.error('Join request error:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to send join request",
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2 text-2xl">
              <Users className="h-6 w-6" />
              {group.name}
            </CardTitle>
            <div className="flex gap-2">
              {group.is_private && (
                <Badge variant="outline">
                  <Lock className="h-3 w-3 mr-1" />
                  Private
                </Badge>
              )}
              <Badge variant="secondary">
                <Shield className="h-3 w-3 mr-1" />
                Preview Mode
              </Badge>
            </div>
          </div>
          <p className="text-lg text-muted-foreground mt-2">{group.description}</p>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <h3 className="font-medium text-blue-900 mb-2">Join This Group</h3>
            <p className="text-blue-700 text-sm mb-4">
              You're viewing a preview of this group. To access full features and participate, you'll need to join.
            </p>
            
            {group.has_pending_request ? (
              <Button disabled className="w-full">
                <Clock className="h-4 w-4 mr-2" />
                Request Pending
              </Button>
            ) : group.can_request_to_join ? (
              <Dialog open={showDialog} onOpenChange={setShowDialog}>
                <DialogTrigger asChild>
                  <Button className="w-full">
                    <Send className="h-4 w-4 mr-2" />
                    Request to Join
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Request to Join {group.name}</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <p className="text-sm text-muted-foreground">
                      Tell the group administrators why you'd like to join this group.
                    </p>
                    <Textarea
                      placeholder="Why would you like to join this group? What are your goals and how do you think this group can help you achieve them?"
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      rows={4}
                    />
                    <div className="flex gap-2 justify-end">
                      <Button
                        variant="outline"
                        onClick={() => {
                          setShowDialog(false);
                          setMessage('');
                        }}
                      >
                        Cancel
                      </Button>
                      <Button
                        onClick={handleJoinRequest}
                        disabled={submitting || !message.trim()}
                      >
                        <Send className="h-4 w-4 mr-2" />
                        {submitting ? 'Sending...' : 'Send Request'}
                      </Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            ) : (
              <Button disabled className="w-full">
                Not Available
              </Button>
            )}
          </div>

          <div className="text-center text-muted-foreground">
            <p className="text-sm">
              This is a limited preview. Join the group to access full features, discussions, and activities.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default GroupPreview;