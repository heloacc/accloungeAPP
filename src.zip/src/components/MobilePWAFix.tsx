import { useEffect, useState } from 'react';
import { clearMobileCache } from '@/utils/cacheManager';

interface MobilePWAFixProps {
  onRetry?: () => void;
}

const MobilePWAFix = ({ onRetry }: MobilePWAFixProps) => {
  const [isClearing, setIsClearing] = useState(false);

  const handleClearCache = async () => {
    setIsClearing(true);
    try {
      await clearMobileCache();
    } catch (error) {
      console.error('Error clearing mobile cache:', error);
      // Fallback: just reload
      window.location.reload();
    }
  };

  const handleRetry = () => {
    if (onRetry) {
      onRetry();
    } else {
      window.location.reload();
    }
  };

  // Detect if we're on mobile
  const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-50 p-4">
      <div className="max-w-md w-full text-center">
        <div className="text-6xl mb-4">📱</div>
        <h2 className="text-xl font-semibold mb-4 text-[#001B30]">
          {isMobile ? 'Mobile Connection Issue' : 'Loading Issue'}
        </h2>
        <p className="text-gray-600 mb-6">
          The app seems to be stuck initializing. This can happen on mobile networks or when cached data conflicts with new updates.
        </p>
        
        <div className="space-y-3">
          <button
            onClick={handleRetry}
            className="w-full px-4 py-3 bg-[#001B30] text-white rounded-lg hover:bg-[#002A45] transition-colors"
          >
            Try Again
          </button>
          
          <button
            onClick={handleClearCache}
            disabled={isClearing}
            className="w-full px-4 py-3 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition-colors disabled:opacity-50"
          >
            {isClearing ? 'Clearing...' : 'Clear All Data & Restart'}
          </button>
        </div>
        
        <div className="mt-6 text-xs text-gray-500">
          <p>If problems persist:</p>
          <ul className="mt-2 space-y-1">
            <li>• Check your internet connection</li>
            <li>• Try switching between WiFi and mobile data</li>
            <li>• Close and reopen your browser</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default MobilePWAFix;