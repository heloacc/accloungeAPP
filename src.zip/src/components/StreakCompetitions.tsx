import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAppContext } from '@/contexts/OptimizedAppContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Flame, Trophy, Medal, Crown, Target, Users, Loader2, Plus } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';
interface StreakParticipant {
  id: string;
  user_id: string;
  full_name: string;
  current_streak: number;
  best_streak: number;
  last_completed: string;
  rank: number;
}

interface StreakCompetition {
  id: string;
  habit_name: string;
  participants: StreakParticipant[];
  end_date: string;
  is_participating: boolean;
}

export const StreakCompetitions = () => {
  const { currentUser } = useAppContext();
  const [competitions, setCompetitions] = useState<StreakCompetition[]>([]);
  const [loading, setLoading] = useState(true);
  const [myHabits, setMyHabits] = useState<any[]>([]);
  const [showCreateHabitDialog, setShowCreateHabitDialog] = useState(false);
  const [pendingCompetition, setPendingCompetition] = useState<{ id: string; habitName: string } | null>(null);

  useEffect(() => {
    fetchCompetitions();
    fetchMyHabits();
  }, []);
  // Listen for habit completions to update competition streaks
  useEffect(() => {
    const handleHabitCompleted = () => {
      // Add a small delay to ensure database is updated
      setTimeout(() => {
        fetchCompetitions();
      }, 1000);
    };

    const handleHabitUpdated = () => {
      // Also listen for general habit updates
      setTimeout(() => {
        fetchCompetitions();
      }, 1000);
    };

    window.addEventListener('habitCompleted', handleHabitCompleted);
    window.addEventListener('habitUpdated', handleHabitUpdated);
    
    return () => {
      window.removeEventListener('habitCompleted', handleHabitCompleted);
      window.removeEventListener('habitUpdated', handleHabitUpdated);
    };
  }, []);

  const fetchMyHabits = async () => {
    try {
      const { data, error } = await supabase
        .from('habits')
        .select('*')
        .eq('user_id', currentUser?.id);

      if (error) throw error;
      setMyHabits(data || []);
    } catch (error) {
      console.error('Error fetching habits:', error);
    }
  };

  const fetchCompetitions = async () => {
    try {
      const { data: competitions, error } = await supabase
        .from('streak_competitions')
        .select('*')
        .eq('is_active', true);
      const competitionsWithData = await Promise.all(
        (competitions || []).map(async (comp) => {
          // Get participants and their streak data
          const { data: participants } = await supabase
            .from('streak_competition_participants')
            .select(`
              *,
              profile:profiles(full_name)
            `)
            .eq('competition_id', comp.id);

          // Calculate current streaks for each participant
          const participantsWithStreaks = await Promise.all(
            (participants || []).map(async (p) => {
              const { data: streakData } = await supabase
                .rpc('calculate_habit_streak', {
                  p_user_id: p.user_id,
                  p_habit_name: comp.habit_name
                });

              return {
                id: p.id,
                user_id: p.user_id,
                full_name: p.profile?.full_name || 'Anonymous',
                current_streak: streakData || 0,
                best_streak: p.best_streak || 0,
                last_completed: p.last_completed,
                rank: 0
              };
            })
          );

          // Sort by current streak and assign ranks
          const rankedParticipants = participantsWithStreaks
            .sort((a, b) => b.current_streak - a.current_streak)
            .map((p, index) => ({ ...p, rank: index + 1 }));

          // Check if current user is participating
          const isParticipating = participants?.some(p => p.user_id === currentUser?.id) || false;

          return {
            id: comp.id,
            habit_name: comp.habit_name,
            participants: rankedParticipants,
            end_date: comp.end_date,
            is_participating: isParticipating
          };
        })
      );

      setCompetitions(competitionsWithData);
    } catch (error) {
      console.error('Error fetching competitions:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleJoinCompetition = async (competitionId: string, habitName: string) => {
    // Check if user has this habit (case-insensitive matching using title field)
    const userHasHabit = myHabits.some(h => 
      h.title?.toLowerCase().trim() === habitName.toLowerCase().trim()
    );
    
    if (!userHasHabit) {
      // Show confirmation dialog to create habit and join
      setPendingCompetition({ id: competitionId, habitName });
      setShowCreateHabitDialog(true);
      return;
    }

    // User has habit, join directly
    await joinCompetitionDirectly(competitionId);
  };

  const createHabitAndJoinCompetition = async () => {
    if (!pendingCompetition) return;

    try {
      // Create the habit using correct column names
      const { error: habitError } = await supabase
        .from('habits')
        .insert({
          user_id: currentUser?.id,
          title: pendingCompetition.habitName,
          is_active: true,
          current_streak: 0,
          longest_streak: 0,
          total_completions: 0,
          completed_dates: [],
          schedule: { frequency: 'daily' },
          reminder: null
        });
      if (habitError) throw habitError;

      // Refresh habits list
      await fetchMyHabits();

      // Join the competition
      await joinCompetitionDirectly(pendingCompetition.id);

      // Close dialog and clear pending
      setShowCreateHabitDialog(false);
      setPendingCompetition(null);

      toast({
        title: "Success!",
        description: `Created "${pendingCompetition.habitName}" habit and joined the competition!`,
      });

    } catch (error) {
      console.error('Error creating habit and joining competition:', error);
      toast({
        title: "Error",
        description: "Failed to create habit and join competition. Please try again.",
        variant: "destructive"
      });
    }
  };

  const joinCompetitionDirectly = async (competitionId: string) => {
    try {
      const { error } = await supabase
        .from('streak_competition_participants')
        .insert({
          competition_id: competitionId,
          user_id: currentUser?.id,
          joined_at: new Date().toISOString()
        });

      if (error) throw error;

      toast({
        title: "Joined Competition!",
        description: "You're now competing in this streak challenge!",
      });

      fetchCompetitions();
    } catch (error) {
      console.error('Error joining competition:', error);
      toast({
        title: "Error",
        description: "Failed to join competition. Please try again.",
        variant: "destructive"
      });
    }
  };

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1: return <Crown className="w-4 h-4 text-yellow-500" />;
      case 2: return <Medal className="w-4 h-4 text-gray-400" />;
      case 3: return <Medal className="w-4 h-4 text-amber-600" />;
      default: return <Target className="w-4 h-4 text-[#7E8E9D]" />;
    }
  };

  const getRankColor = (rank: number) => {
    switch (rank) {
      case 1: return 'bg-yellow-100 border-yellow-300';
      case 2: return 'bg-gray-100 border-gray-300';
      case 3: return 'bg-amber-100 border-amber-300';
      default: return 'bg-white border-gray-200';
    }
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="p-6 text-center">
          <Loader2 className="w-6 h-6 animate-spin mx-auto mb-2" />
          <p className="text-muted-foreground">Loading competitions...</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-[#001B30]">Streak Competitions</h2>
          <p className="text-[#7E8E9D]">Compete with others to build the longest streaks</p>
        </div>
      </div>

      <div className="grid gap-6">
        {competitions.map((competition) => (
          <Card key={competition.id}>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle className="flex items-center gap-2">
                  <Flame className="w-5 h-5 text-orange-500" />
                  {competition.habit_name} Streak Challenge
                </CardTitle>
                <div className="flex items-center gap-2 text-sm text-[#7E8E9D]">
                  <Users className="w-4 h-4" />
                  {competition.participants.length} participants
                </div>
              </div>
              <p className="text-sm text-[#7E8E9D]">
                Ends {new Date(competition.end_date).toLocaleDateString()}
              </p>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {/* Leaderboard */}
                <div className="space-y-2">
                  {competition.participants.slice(0, 5).map((participant) => (
                    <div
                      key={participant.id}
                      className={`p-3 rounded-lg border-2 ${getRankColor(participant.rank)} ${
                        participant.user_id === currentUser?.id ? 'ring-2 ring-[#596D59]' : ''
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          {getRankIcon(participant.rank)}
                          <Avatar className="w-8 h-8">
                            <AvatarFallback className="text-xs">
                              {participant.full_name.slice(0, 2).toUpperCase()}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="font-medium text-[#001B30]">
                              {participant.full_name}
                              {participant.user_id === currentUser?.id && (
                                <Badge variant="secondary" className="ml-2 text-xs">You</Badge>
                              )}
                            </p>
                            <p className="text-sm text-[#7E8E9D]">
                              Best: {participant.best_streak} days
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="flex items-center gap-1">
                            <Flame className="w-4 h-4 text-orange-500" />
                            <span className="text-lg font-bold text-[#001B30]">
                              {participant.current_streak}
                            </span>
                          </div>
                          <p className="text-xs text-[#7E8E9D]">days</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Progress to leader */}
                {competition.participants.length > 0 && (
                  <div className="mt-4">
                    <div className="flex justify-between text-sm text-[#7E8E9D] mb-2">
                      <span>Progress to Leader</span>
                      <span>{competition.participants[0]?.current_streak || 0} days</span>
                    </div>
                    <Progress 
                      value={
                        competition.participants[0]?.current_streak > 0 
                          ? Math.min(100, (competition.participants.find(p => p.user_id === currentUser?.id)?.current_streak || 0) / competition.participants[0].current_streak * 100)
                          : 0
                      }
                      className="h-2"
                    />
                  </div>
                )}

                {/* Join button */}
                {!competition.is_participating && (
                  <Button 
                    onClick={() => handleJoinCompetition(competition.id, competition.habit_name)}
                    className="w-full bg-[#596D59] hover:bg-[#596D59]/90"
                  >
                    Join Competition
                  </Button>
                )}

                {competition.is_participating && (
                  <div className="text-center">
                    <Badge className="bg-green-100 text-green-800">
                      <Trophy className="w-3 h-3 mr-1" />
                      Participating
                    </Badge>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {competitions.length === 0 && (
        <Card>
          <CardContent className="p-8 text-center">
            <Flame className="w-12 h-12 text-[#7E8E9D] mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-[#001B30] mb-2">No Active Competitions</h3>
            <p className="text-[#7E8E9D]">Streak competitions will appear here when available.</p>
          </CardContent>
        </Card>
      )}

      {/* Create Habit Confirmation Dialog */}
      <AlertDialog open={showCreateHabitDialog} onOpenChange={setShowCreateHabitDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <Plus className="w-5 h-5 text-[#596D59]" />
              Create Habit & Join Competition
            </AlertDialogTitle>
            <AlertDialogDescription>
              You don't have the "{pendingCompetition?.habitName}" habit yet. Would you like to create it and join the competition in one step?
              <br /><br />
              This will:
              <ul className="list-disc list-inside mt-2 space-y-1">
                <li>Create the "{pendingCompetition?.habitName}" habit in your habits list</li>
                <li>Automatically join you in the streak competition</li>
                <li>Start tracking your streak from today</li>
              </ul>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={createHabitAndJoinCompetition}
              className="bg-[#596D59] hover:bg-[#596D59]/90"
            >
              Create Habit & Join
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};
