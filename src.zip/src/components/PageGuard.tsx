import React from 'react';
import SubscriptionGuard from './SubscriptionGuard';

interface PageGuardProps {
  children: React.ReactNode;
  pagePath: string;
  requiresAuth?: boolean;
}

const PageGuard = ({ 
  children, 
  pagePath, 
  requiresAuth = true 
}) => {
  // For now, just wrap with subscription guard
  // Could extend with auth checks if needed
  return (
    <SubscriptionGuard pagePath={pagePath}>
      {children}
    </SubscriptionGuard>
  );
};

export default PageGuard;