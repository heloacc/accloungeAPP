import React, { useState } from 'react';
import { useAppContext } from '@/contexts/AppContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Megaphone, Send, Trash2, Calendar, User, Users } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';
import ActiveCircleNotifications from './ActiveCircleNotifications';
import ScheduledNotifications from './ScheduledNotifications';
import EmailNotifications from './EmailNotifications';
import GroupNotificationManager from './GroupNotificationManager';
import AutomatedReminderSystem from './AutomatedReminderSystem';

const AdminNotifications = () => {
  const { currentUser, notifications, addNotification, removeNotification } = useAppContext();
  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  const [type, setType] = useState<'motivational' | 'reminder' | 'announcement'>('motivational');

  if (!currentUser.isAdmin) {
    return (
      <div className="p-6">
        <Card>
          <CardContent className="pt-6">
            <div className="text-center text-muted-foreground">
              <Megaphone className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>Access denied. Admin privileges required.</p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  const handleSendNotification = async () => {
    if (!title.trim() || !message.trim()) {
      toast({
        title: "Validation Error",
        description: "Please fill in both title and message fields.",
        variant: "destructive"
      });
      return;
    }

    try {
      // Send PWA notification first
      const { sendPWANotification, requestNotificationPermission } = await import('@/utils/pwaUtils');
      
      // Request permission if not already granted and Notification API is available
      if ('Notification' in window && Notification.permission === 'default') {
        await requestNotificationPermission();
      }
      
      // Send PWA notification if supported and permitted
      if ('Notification' in window && Notification.permission === 'granted') {
        sendPWANotification(title.trim(), message.trim());
      }

      // Add to in-app notifications
      addNotification({
        title: title.trim(),
        message: message.trim(),
        type,
        isActive: true
      });

      // Get all users to send notifications to
      const { supabase } = await import('@/lib/supabase');
      const { data: users, error: usersError } = await supabase
        .from('profiles')
        .select('id');

      if (usersError) {
        console.error('Error fetching users:', usersError);
        throw usersError;
      }

      // Create notification records for all users
      if (users && users.length > 0) {
        const notifications = users.map(user => ({
          user_id: user.id,
          type: 'admin_broadcast',
          title: title.trim(),
          message: message.trim(),
          read: false
        }));

        const { error } = await supabase
          .from('notifications')
          .insert(notifications);

        if (error) {
          console.error('Error saving notifications to database:', error);
          throw error;
        }
      }

      toast({
        title: "Notification Sent",
        description: `Notification sent to ${users?.length || 0} users via PWA and in-app channels.`,
      });

      setTitle('');
      setMessage('');
      setType('motivational');
    } catch (error) {
      console.error('Error sending notification:', error);
      toast({
        title: "Error",
        description: `Failed to send notification: ${error.message || 'Unknown error'}. Please try again.`,
        variant: "destructive"
      });
    }
  };

  const getTypeColor = (notificationType: string) => {
    switch (notificationType) {
      case 'motivational': return 'bg-green-100 text-green-800';
      case 'reminder': return 'bg-blue-100 text-blue-800';
      case 'announcement': return 'bg-purple-100 text-purple-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getTypeIcon = (notificationType: string) => {
    switch (notificationType) {
      case 'motivational': return '💪';
      case 'reminder': return '⏰';
      case 'announcement': return '📢';
      default: return '📝';
    }
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center gap-3">
        <Megaphone className="h-8 w-8 text-primary" />
        <div>
          <h1 className="text-3xl font-bold">Admin Notifications</h1>
          <p className="text-muted-foreground">Manage notifications and group requests</p>
        </div>
      </div>

      <Tabs defaultValue="general" className="w-full">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="general" className="flex items-center gap-2">
            <Megaphone className="h-4 w-4" />
            General
          </TabsTrigger>
          <TabsTrigger value="automated" className="flex items-center gap-2">
            <Calendar className="h-4 w-4" />
            Automated
          </TabsTrigger>
          <TabsTrigger value="scheduled" className="flex items-center gap-2">
            <Calendar className="h-4 w-4" />
            Scheduled
          </TabsTrigger>
          <TabsTrigger value="email" className="flex items-center gap-2">
            <Send className="h-4 w-4" />
            Email
          </TabsTrigger>
          <TabsTrigger value="active-circle" className="flex items-center gap-2">
            <Users className="h-4 w-4" />
            Active Circle
          </TabsTrigger>
          <TabsTrigger value="groups" className="flex items-center gap-2">
            <Users className="h-4 w-4" />
            Groups
          </TabsTrigger>
        </TabsList>
        <TabsContent value="automated">
          <AutomatedReminderSystem />
        </TabsContent>
        <TabsContent value="general" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Send Notification Form */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Send className="h-5 w-5" />
                  Send New Notification
                </CardTitle>
                <CardDescription>
                  Create and send notifications to all app users
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">Notification Type</label>
                  <Select value={type} onValueChange={(value: any) => setType(value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="motivational">💪 Motivational</SelectItem>
                      <SelectItem value="reminder">⏰ Reminder</SelectItem>
                      <SelectItem value="announcement">📢 Announcement</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="text-sm font-medium mb-2 block">Title</label>
                  <Input
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="Enter notification title..."
                    maxLength={100}
                  />
                </div>

                <div>
                  <label className="text-sm font-medium mb-2 block">Message</label>
                  <Textarea
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="Enter your notification message..."
                    rows={4}
                    maxLength={500}
                  />
                  <p className="text-xs text-muted-foreground mt-1">
                    {message.length}/500 characters
                  </p>
                </div>

                <Button 
                  onClick={handleSendNotification} 
                  className="w-full bg-black text-white hover:bg-gray-800"
                >
                  <Send className="h-4 w-4 mr-2" />
                  Send Notification
                </Button>
              </CardContent>
            </Card>

            {/* Recent Notifications */}
            <Card>
              <CardHeader>
                <CardTitle>Recent Notifications</CardTitle>
                <CardDescription>
                  View and manage sent notifications ({notifications.length} total)
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {notifications.length === 0 ? (
                    <div className="text-center text-muted-foreground py-8">
                      <Megaphone className="h-8 w-8 mx-auto mb-2 opacity-50" />
                      <p>No notifications sent yet</p>
                    </div>
                  ) : (
                    notifications.map((notification) => (
                      <div key={notification.id} className="border rounded-lg p-3 space-y-2">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <Badge className={getTypeColor(notification.type)}>
                                {getTypeIcon(notification.type)} {notification.type}
                              </Badge>
                            </div>
                            <h4 className="font-medium text-sm">{notification.title}</h4>
                            <p className="text-xs text-muted-foreground mt-1">
                              {notification.message}
                            </p>
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => removeNotification(notification.id)}
                            className="text-red-500 hover:text-red-700"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                        <Separator />
                        <div className="flex items-center gap-4 text-xs text-muted-foreground">
                          <div className="flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            {notification.createdAt.toLocaleDateString()}
                          </div>
                          <div className="flex items-center gap-1">
                            <User className="h-3 w-3" />
                            {notification.createdBy}
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        <TabsContent value="scheduled">
          <ScheduledNotifications />
        </TabsContent>

        <TabsContent value="email">
          <EmailNotifications />
        </TabsContent>

        <TabsContent value="active-circle">
          <ActiveCircleNotifications />
        </TabsContent>

        <TabsContent value="groups">
          <GroupNotificationManager />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default AdminNotifications;