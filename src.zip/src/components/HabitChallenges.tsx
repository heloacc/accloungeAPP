import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAppContext } from '@/contexts/OptimizedAppContext';
import { useUserRole } from '@/hooks/useUserRole';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Trophy, Users, Calendar, Target, Plus, Loader2, Trash2, Shield } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';
interface HabitChallenge {
  id: string;
  title: string;
  description: string;
  habit_name: string;
  duration_days: number;
  start_date: string;
  end_date: string;
  created_by: string;
  participants_count: number;
  is_participant: boolean;
  creator_name: string;
}

export const HabitChallenges = () => {
  const { currentUser } = useAppContext();
  const { isAdmin } = useUserRole();
  const [challenges, setChallenges] = useState<HabitChallenge[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [newChallenge, setNewChallenge] = useState({
    title: '',
    description: '',
    habit_name: '',
    duration_days: 30
  });

  useEffect(() => {
    fetchChallenges();
  }, []);

  const fetchChallenges = async () => {
    try {
      // Get challenges with creator info and participant count
      const { data, error } = await supabase
        .from('habit_challenges')
        .select(`
          *,
          creator:profiles!habit_challenges_created_by_fkey(full_name, name)
        `)
        .gte('end_date', new Date().toISOString().split('T')[0])
        .order('created_at', { ascending: false });

      if (error) throw error;

      // Get participant counts and user participation status
      const challengesWithParticipation = await Promise.all(
        (data || []).map(async (challenge) => {
          // Get participant count
          const { data: participantCount, error: countError } = await supabase
            .from('habit_challenge_participants')
            .select('id', { count: 'exact' })
            .eq('challenge_id', challenge.id);

          if (countError) {
            console.error('Error fetching participant count:', countError);
          }

          // Check if current user is participating
          const { data: participation, error: participationError } = await supabase
            .from('habit_challenge_participants')
            .select('id')
            .eq('challenge_id', challenge.id)
            .eq('user_id', currentUser?.id)
            .maybeSingle();

          if (participationError && participationError.code !== 'PGRST116') {
            console.error('Error checking participation:', participationError);
          }

          return {
            ...challenge,
            creator_name: challenge.creator?.full_name || challenge.creator?.name || 'Unknown Creator',
            participants_count: participantCount?.length || 0,
            is_participant: !!participation
          };
        })
      );

      setChallenges(challengesWithParticipation);
    } catch (error) {
      console.error('Error fetching challenges:', error);
      // Show empty state instead of throwing
      setChallenges([]);
    } finally {
      setLoading(false);
    }
  };

  const createChallenge = async () => {
    try {
      const startDate = new Date();
      const endDate = new Date();
      endDate.setDate(startDate.getDate() + newChallenge.duration_days);

      // Create the challenge
      const { data: challengeData, error: challengeError } = await supabase
        .from('habit_challenges')
        .insert({
          title: newChallenge.title,
          description: newChallenge.description,
          habit_name: newChallenge.habit_name,
          duration_days: newChallenge.duration_days,
          start_date: startDate.toISOString().split('T')[0],
          end_date: endDate.toISOString().split('T')[0],
          created_by: currentUser?.id
        })
        .select()
        .single();

      if (challengeError) throw challengeError;

      // Automatically add creator as participant
      const { error: participantError } = await supabase
        .from('habit_challenge_participants')
        .insert({
          challenge_id: challengeData.id,
          user_id: currentUser?.id,
          joined_at: new Date().toISOString()
        });

      if (participantError) throw participantError;

      toast({
        title: "Challenge Created!",
        description: "Your habit challenge is now live and you're automatically participating.",
      });

      setShowCreateForm(false);
      setNewChallenge({ title: '', description: '', habit_name: '', duration_days: 30 });
      fetchChallenges();
    } catch (error) {
      console.error('Error creating challenge:', error);
      toast({
        title: "Error",
        description: "Failed to create challenge. Please try again.",
        variant: "destructive"
      });
    }
  };

  const joinChallenge = async (challengeId: string) => {
    try {
      const { error } = await supabase
        .from('habit_challenge_participants')
        .insert({
          challenge_id: challengeId,
          user_id: currentUser?.id,
          joined_at: new Date().toISOString()
        });

      if (error) throw error;

      toast({
        title: "Joined Challenge!",
        description: "You're now part of this habit challenge. Good luck!",
      });

      fetchChallenges();
    } catch (error) {
      console.error('Error joining challenge:', error);
      toast({
        title: "Error",
        description: "Failed to join challenge. Please try again.",
        variant: "destructive"
      });
    }
  };

  const deleteChallenge = async (challengeId: string, challengeTitle: string) => {
    if (!isAdmin) return;
    
    if (!confirm(`Are you sure you want to delete the challenge "${challengeTitle}"? This will remove all participants and cannot be undone.`)) {
      return;
    }

    try {
      // Delete participants first
      const { error: participantsError } = await supabase
        .from('habit_challenge_participants')
        .delete()
        .eq('challenge_id', challengeId);

      if (participantsError) throw participantsError;

      // Delete challenge completions
      const { error: completionsError } = await supabase
        .from('habit_challenge_completions')
        .delete()
        .eq('challenge_id', challengeId);

      if (completionsError) throw completionsError;

      // Delete the challenge
      const { error: challengeError } = await supabase
        .from('habit_challenges')
        .delete()
        .eq('id', challengeId);

      if (challengeError) throw challengeError;

      toast({
        title: "Challenge Deleted",
        description: `The challenge "${challengeTitle}" has been permanently deleted.`,
      });

      fetchChallenges();
    } catch (error) {
      console.error('Error deleting challenge:', error);
      toast({
        title: "Error",
        description: "Failed to delete challenge. Please try again.",
        variant: "destructive"
      });
    }
  };

  const completeChallenge = async (challengeId: string) => {
    try {
      const { error } = await supabase
        .from('habit_challenge_completions')
        .insert({
          challenge_id: challengeId,
          user_id: currentUser?.id,
          completed_at: new Date().toISOString()
        });

      if (error) throw error;

      toast({
        title: "Challenge Completed!",
        description: "Congratulations on completing this challenge!",
      });

      fetchChallenges();
    } catch (error) {
      console.error('Error completing challenge:', error);
      toast({
        title: "Error",
        description: "Failed to mark challenge as complete. Please try again.",
        variant: "destructive"
      });
    }
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="p-6 text-center">
          <Loader2 className="w-6 h-6 animate-spin mx-auto mb-2" />
          <p className="text-muted-foreground">Loading challenges...</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-[#001B30]">Habit Challenges</h2>
          <p className="text-[#7E8E9D]">Join challenges and compete with others</p>
          {isAdmin && (
            <div className="flex items-center gap-1 mt-1">
              <Shield className="w-4 h-4 text-red-600" />
              <span className="text-xs text-red-600">Admin: Delete challenges with trash button</span>
            </div>
          )}
        </div>
        <Button onClick={() => setShowCreateForm(!showCreateForm)}>
          <Plus className="w-4 h-4 mr-2" />
          Create Challenge
        </Button>
      </div>

      {showCreateForm && (
        <Card>
          <CardHeader>
            <CardTitle>Create New Challenge</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Input
              placeholder="Challenge title"
              value={newChallenge.title}
              onChange={(e) => setNewChallenge({...newChallenge, title: e.target.value})}
            />
            <Input
              placeholder="Habit name (e.g., 'Morning Exercise')"
              value={newChallenge.habit_name}
              onChange={(e) => setNewChallenge({...newChallenge, habit_name: e.target.value})}
            />
            <Textarea
              placeholder="Challenge description"
              value={newChallenge.description}
              onChange={(e) => setNewChallenge({...newChallenge, description: e.target.value})}
            />
            <Input
              type="number"
              placeholder="Duration (days)"
              value={newChallenge.duration_days}
              onChange={(e) => setNewChallenge({...newChallenge, duration_days: parseInt(e.target.value)})}
            />
            <div className="flex gap-2">
              <Button onClick={createChallenge}>Create Challenge</Button>
              <Button variant="outline" onClick={() => setShowCreateForm(false)}>Cancel</Button>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid gap-4">
        {challenges.map((challenge) => (
          <Card key={challenge.id}>
            <CardContent className="p-6">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="text-lg font-semibold text-[#001B30]">{challenge.title}</h3>
                  <p className="text-[#7E8E9D] text-sm">by {challenge.creator_name}</p>
                </div>
                <div className="flex items-center gap-2">
                  <Badge className="bg-[#596D59] text-white">
                    <Trophy className="w-3 h-3 mr-1" />
                    {challenge.habit_name}
                  </Badge>
                  {isAdmin && (
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => deleteChallenge(challenge.id, challenge.title)}
                      className="h-8 px-2"
                    >
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  )}
                </div>
              </div>
              
              <p className="text-[#2C2C44] mb-4">{challenge.description}</p>
              
              <div className="flex items-center gap-4 text-sm text-[#7E8E9D] mb-4">
                <div className="flex items-center gap-1">
                  <Users className="w-4 h-4" />
                  {challenge.participants_count} participants
                </div>
                <div className="flex items-center gap-1">
                  <Calendar className="w-4 h-4" />
                  {challenge.duration_days} days
                </div>
                <div className="flex items-center gap-1">
                  <Target className="w-4 h-4" />
                  Ends {new Date(challenge.end_date).toLocaleDateString()}
                </div>
              </div>

              {!challenge.is_participant && (
                <Button 
                  onClick={() => joinChallenge(challenge.id)}
                  className="bg-[#596D59] hover:bg-[#596D59]/90"
                >
                  Join Challenge
                </Button>
              )}
              
              {challenge.is_participant && (
                <div className="flex items-center gap-2">
                  <Badge variant="secondary">Participating</Badge>
                  {challenge.created_by === currentUser?.id && (
                    <Badge variant="outline">Your Challenge</Badge>
                  )}
                  <Button
                    size="sm"
                    onClick={() => completeChallenge(challenge.id)}
                    className="bg-green-600 hover:bg-green-700 text-white ml-2"
                  >
                    Mark Complete
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
      {challenges.length === 0 && (
        <Card>
          <CardContent className="p-8 text-center">
            <Trophy className="w-12 h-12 text-[#7E8E9D] mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-[#001B30] mb-2">No Active Challenges</h3>
            <p className="text-[#7E8E9D] mb-4">Be the first to create a habit challenge!</p>
            <Button onClick={() => setShowCreateForm(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Create First Challenge
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
};