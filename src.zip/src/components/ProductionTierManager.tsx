import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { CheckCircle, XCircle, ExternalLink, AlertTriangle } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { toast } from '@/components/ui/use-toast';

interface ProductionTier {
  id: string;
  name: string;
  description: string;
  stripe_product_id: string;
  stripe_price_id: string;
  price_monthly: number;
  price_yearly: number;
  features: string[];
  is_active: boolean;
  max_groups: number;
  max_partnerships: number;
  priority_support: boolean;
  analytics_access: boolean;
  custom_branding: boolean;
  allowed_routes: string[];
}

export default function ProductionTierManager() {
  const [tiers, setTiers] = useState<ProductionTier[]>([]);
  const [loading, setLoading] = useState(true);
  const [validating, setValidating] = useState(false);

  useEffect(() => {
    fetchTiers();
  }, []);

  const fetchTiers = async () => {
    try {
      const { data, error } = await supabase
        .from('subscription_tiers')
        .select('*')
        .order('price_monthly', { ascending: true });

      if (error) throw error;
      setTiers(data || []);
    } catch (error) {
      console.error('Error:', error);
      toast({
        title: "Error",
        description: "Failed to load subscription tiers",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const validateProductionTiers = async () => {
    setValidating(true);
    
    try {
      const validTiers = [
        {
          name: 'Freemium',
          stripe_product_id: 'prod_Suq3rsizpL3AT4',
          price_monthly: 0,
          features: ['Basic habit tracking', 'Personal dashboard', 'Community access'],
          max_groups: 1,
          max_partnerships: 1,
          allowed_routes: ['/dashboard', '/habits', '/profile', '/community-feed']
        },
        {
          name: 'Accountability Essentials',
          stripe_product_id: 'prod_SvWHQGmXBYZmCk',
          price_monthly: 9.99,
          features: ['Everything in Freemium', 'Accountability groups', 'Progress tracking', 'Goal setting'],
          max_groups: 5,
          max_partnerships: 3,
          allowed_routes: ['/dashboard', '/habits', '/goals', '/groups', '/partnerships', '/profile', '/community-feed']
        },
        {
          name: 'All Access',
          stripe_product_id: 'prod_SvWIwXAhncKjy7',
          price_monthly: 19.99,
          features: ['Everything in Essentials', 'Unlimited groups', 'Priority support', 'Advanced analytics', 'Custom branding'],
          max_groups: 999,
          max_partnerships: 999,
          priority_support: true,
          analytics_access: true,
          custom_branding: true,
          allowed_routes: ['/dashboard', '/habits', '/goals', '/groups', '/partnerships', '/profile', '/community-feed', '/analytics', '/admin']
        }
      ];

      for (const tierConfig of validTiers) {
        const existingTier = tiers.find(t => t.stripe_product_id === tierConfig.stripe_product_id);
        
        if (existingTier) {
          // Update existing tier
          const { error } = await supabase
            .from('subscription_tiers')
            .update({
              ...tierConfig,
              is_active: true,
              description: `${tierConfig.name} subscription plan`,
              price_yearly: tierConfig.price_monthly * 10, // 2 months free
              priority_support: tierConfig.priority_support || false,
              analytics_access: tierConfig.analytics_access || false,
              custom_branding: tierConfig.custom_branding || false
            })
            .eq('id', existingTier.id);

          if (error) throw error;
        } else {
          // Create new tier
          const { error } = await supabase
            .from('subscription_tiers')
            .insert([{
              ...tierConfig,
              is_active: true,
              description: `${tierConfig.name} subscription plan`,
              price_yearly: tierConfig.price_monthly * 10,
              priority_support: tierConfig.priority_support || false,
              analytics_access: tierConfig.analytics_access || false,
              custom_branding: tierConfig.custom_branding || false,
              currency: 'USD',
              billing_interval: 'monthly',
              billing_period: 'monthly'
            }]);

          if (error) throw error;
        }
      }

      toast({
        title: "Success",
        description: "Production tiers validated and configured successfully"
      });
      
      fetchTiers();
    } catch (error: any) {
      console.error('Error validating tiers:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to validate production tiers",
        variant: "destructive"
      });
    } finally {
      setValidating(false);
    }
  };

  const toggleTierStatus = async (tierId: string, currentStatus: boolean) => {
    try {
      const { error } = await supabase
        .from('subscription_tiers')
        .update({ is_active: !currentStatus })
        .eq('id', tierId);

      if (error) throw error;
      
      toast({
        title: "Success",
        description: `Tier ${!currentStatus ? 'activated' : 'deactivated'}`
      });
      
      fetchTiers();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to update tier status",
        variant: "destructive"
      });
    }
  };

  if (loading) return <div className="p-6">Loading production tier configuration...</div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold">Production Subscription Tiers</h3>
          <p className="text-sm text-muted-foreground">
            Manage and validate production-ready subscription tiers
          </p>
        </div>
        <Button 
          onClick={validateProductionTiers}
          disabled={validating}
          className="bg-green-600 hover:bg-green-700"
        >
          {validating ? 'Validating...' : 'Validate & Configure'}
        </Button>
      </div>

      <div className="grid gap-4">
        {tiers.map((tier) => (
          <Card key={tier.id} className={!tier.is_active ? 'opacity-60 border-red-200' : 'border-green-200'}>
            <CardContent className="p-6">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-3">
                    <h4 className="text-xl font-semibold">{tier.name}</h4>
                    <Badge variant={tier.is_active ? "default" : "secondary"}>
                      {tier.is_active ? 'Active' : 'Inactive'}
                    </Badge>
                    {tier.stripe_product_id ? (
                      <Badge variant="outline" className="text-xs text-green-600">
                        <CheckCircle className="h-3 w-3 mr-1" />
                        Stripe Connected
                      </Badge>
                    ) : (
                      <Badge variant="outline" className="text-xs text-red-600">
                        <XCircle className="h-3 w-3 mr-1" />
                        No Stripe ID
                      </Badge>
                    )}
                  </div>
                  
                  <div className="text-2xl font-bold mb-2 text-green-600">
                    ${tier.price_monthly}/month
                    {tier.price_yearly > 0 && (
                      <span className="text-sm font-normal text-muted-foreground ml-2">
                        or ${tier.price_yearly}/year
                      </span>
                    )}
                  </div>

                  {tier.description && (
                    <p className="text-muted-foreground mb-3">{tier.description}</p>
                  )}

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4 text-sm">
                    <div>
                      <span className="font-medium">Max Groups:</span> {tier.max_groups === 999 ? 'Unlimited' : tier.max_groups}
                    </div>
                    <div>
                      <span className="font-medium">Max Partnerships:</span> {tier.max_partnerships === 999 ? 'Unlimited' : tier.max_partnerships}
                    </div>
                    <div>
                      <span className="font-medium">Priority Support:</span> {tier.priority_support ? '✓' : '✗'}
                    </div>
                    <div>
                      <span className="font-medium">Analytics:</span> {tier.analytics_access ? '✓' : '✗'}
                    </div>
                  </div>

                  <div className="text-xs text-muted-foreground mb-2">
                    <strong>Stripe Product ID:</strong> {tier.stripe_product_id || 'Not configured'}
                    {tier.stripe_price_id && (
                      <span className="ml-4">
                        <strong>Price ID:</strong> {tier.stripe_price_id}
                      </span>
                    )}
                  </div>

                  {tier.features && tier.features.length > 0 && (
                    <div className="text-sm">
                      <p className="font-medium mb-2">Features:</p>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-1">
                        {tier.features.map((feature, index) => (
                          <div key={index} className="flex items-center gap-2">
                            <CheckCircle className="w-3 h-3 text-green-500 flex-shrink-0" />
                            <span>{feature}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  <Switch
                    checked={tier.is_active}
                    onCheckedChange={() => toggleTierStatus(tier.id, tier.is_active)}
                  />
                  <span className="text-sm">{tier.is_active ? 'Active' : 'Inactive'}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}

        {tiers.length === 0 && (
          <Card className="border-yellow-200">
            <CardContent className="p-8 text-center">
              <AlertTriangle className="h-12 w-12 text-yellow-500 mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">No Production Tiers Found</h3>
              <p className="text-muted-foreground mb-4">
                Configure your production subscription tiers to enable monetization.
              </p>
              <Button onClick={validateProductionTiers} disabled={validating}>
                {validating ? 'Setting Up...' : 'Setup Production Tiers'}
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}