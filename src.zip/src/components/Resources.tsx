import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { BookOpen, ExternalLink, Download, FileText } from 'lucide-react';

const Resources = () => {
  const resources = [
    {
      title: 'Goal Setting Guide',
      description: 'Learn effective strategies for setting and achieving your goals',
      type: 'PDF',
      icon: FileText
    },
    {
      title: 'Habit Formation Toolkit',
      description: 'Tools and techniques for building lasting habits',
      type: 'Guide',
      icon: BookOpen
    },
    {
      title: 'Accountability Best Practices',
      description: 'How to make the most of your accountability partnerships',
      type: 'Article',
      icon: ExternalLink
    }
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Resources</h1>
        <p className="text-gray-600">Helpful guides and tools for your journey</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {resources.map((resource, index) => {
          const IconComponent = resource.icon;
          return (
            <Card key={index} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-center space-x-3">
                  <IconComponent className="h-6 w-6 text-blue-600" />
                  <CardTitle className="text-lg">{resource.title}</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-4">{resource.description}</p>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-500">{resource.type}</span>
                  <Button size="sm" variant="outline">
                    <Download className="h-4 w-4 mr-2" />
                    Access
                  </Button>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
};

export default Resources;