import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useAppContext } from '@/contexts/AppContext';
import { asArray, safeFilter } from '@/utils/asArray';
import { 
  Trophy, 
  Target, 
  Flame, 
  Users, 
  Calendar,
  Star,
  Award,
  Crown,
  Zap,
  Heart,
  CheckCircle,
  Lock
} from 'lucide-react';

const Achievements = () => {
  const { currentUser, achievements, unlockAchievement } = useAppContext();
  const [selectedCategory, setSelectedCategory] = useState('all');

  const achievementCategories = [
    { id: 'all', name: 'All Achievements', icon: Trophy },
    { id: 'habits', name: 'Habits', icon: Target },
    { id: 'social', name: 'Social', icon: Users },
    { id: 'streaks', name: 'Streaks', icon: Flame },
    { id: 'goals', name: 'Goals', icon: CheckCircle }
  ];

  // Safe array operations with logging
  const safeAchievements = asArray(achievements);
  const filteredAchievements = selectedCategory === 'all' 
    ? safeAchievements 
    : safeFilter(safeAchievements, a => a.category === selectedCategory, 'Achievements filter');

  const unlockedCount = safeFilter(safeAchievements, a => a.unlocked, 'Unlocked achievements').length;
  const totalCount = safeAchievements.length;
  const completionPercentage = totalCount > 0 ? Math.round((unlockedCount / totalCount) * 100) : 0;
  const handleTestUnlock = (achievementId: string) => {
    unlockAchievement(achievementId);
  };

  const getAchievementIcon = (iconName: string) => {
    const icons: { [key: string]: any } = {
      Trophy, Target, Flame, Users, Calendar, Star, Award, Crown, Zap, Heart, CheckCircle
    };
    return icons[iconName] || Trophy;
  };

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case 'common': return 'bg-gray-500';
      case 'rare': return 'bg-blue-500';
      case 'epic': return 'bg-amber-500';
      case 'legendary': return 'bg-yellow-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#001B30] to-[#2C2C44] rounded-lg p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold mb-2 flex items-center gap-2">
              <Trophy className="h-6 w-6 text-amber-400" />
              Achievement System
            </h2>
            <p className="text-[#7E8E9D]">Progressive challenges from 7 days to legendary status</p>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-yellow-400">{unlockedCount}/{totalCount}</div>
            <div className="text-sm text-[#7E8E9D]">Unlocked</div>
          </div>
        </div>
        <div className="mt-4">
          <div className="flex justify-between text-sm mb-2">
            <span>Overall Progress</span>
            <span>{completionPercentage}%</span>
          </div>
          <Progress value={completionPercentage} className="h-2" />
        </div>
        
        {/* Achievement Tiers Info */}
        <div className="mt-4 grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
          <div className="bg-gray-600 px-2 py-1 rounded">
            <span className="text-gray-300">Beginner:</span> 7 days
          </div>
          <div className="bg-blue-600 px-2 py-1 rounded">
            <span className="text-blue-200">Intermediate:</span> 30-90 days
          </div>
          <div className="bg-amber-600 px-2 py-1 rounded">
            <span className="text-amber-200">Advanced:</span> 90+ days
          </div>
          <div className="bg-yellow-600 px-2 py-1 rounded">
            <span className="text-yellow-200">Legendary:</span> 6+ months
          </div>
        </div>
      </div>

      {/* Category Tabs */}
      <Tabs value={selectedCategory} onValueChange={setSelectedCategory}>
        <TabsList className="grid w-full grid-cols-5">
          {achievementCategories.map((category) => {
            const Icon = category.icon;
            return (
              <TabsTrigger key={category.id} value={category.id} className="flex items-center gap-2">
                <Icon className="h-4 w-4" />
                <span className="hidden sm:inline">{category.name}</span>
              </TabsTrigger>
            );
          })}
        </TabsList>

        <TabsContent value={selectedCategory} className="mt-6">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {filteredAchievements.map((achievement) => {
              const Icon = getAchievementIcon(achievement.icon);
              const isUnlocked = achievement.unlocked;
              
              return (
                <Card key={achievement.id} className={`relative overflow-hidden transition-all hover:shadow-lg ${
                  isUnlocked ? 'border-yellow-200 bg-yellow-50/30' : 'border-gray-200 bg-gray-50/30'
                }`}>
                  {!isUnlocked && (
                    <div className="absolute inset-0 bg-gray-900/20 backdrop-blur-[1px] z-10 flex items-center justify-center">
                      <Lock className="h-8 w-8 text-gray-500" />
                    </div>
                  )}
                  
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between">
                      <div className={`p-2 rounded-lg ${getRarityColor(achievement.rarity)}`}>
                        <Icon className="h-5 w-5 text-white" />
                      </div>
                      <Badge variant={isUnlocked ? "default" : "secondary"} 
                             className={isUnlocked ? "bg-yellow-500 text-white" : ""}>
                        {achievement.rarity}
                      </Badge>
                    </div>
                    <CardTitle className={`text-lg ${isUnlocked ? 'text-[#001B30]' : 'text-gray-500'}`}>
                      {achievement.name}
                    </CardTitle>
                  </CardHeader>
                  
                  <CardContent>
                    <p className={`text-sm mb-3 ${isUnlocked ? 'text-[#7E8E9D]' : 'text-gray-400'}`}>
                      {achievement.description}
                    </p>
                    
                    {achievement.progress !== undefined && (
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Progress</span>
                          <span>{achievement.progress}/{achievement.target}</span>
                        </div>
                        <Progress 
                          value={(achievement.progress / achievement.target) * 100} 
                          className="h-2" 
                        />
                      </div>
                    )}
                    
                    {achievement.reward && (
                      <div className="mt-3 p-2 bg-yellow-100 rounded-lg">
                        <p className="text-xs text-yellow-800">
                          <Star className="h-3 w-3 inline mr-1" />
                          Reward: {achievement.reward}
                        </p>
                      </div>
                    )}

                    {isUnlocked && achievement.unlockedAt && (
                      <div className="mt-3 text-xs text-green-600">
                        Unlocked on {new Date(achievement.unlockedAt).toLocaleDateString()}
                      </div>
                    )}

                    {/* Test button for development */}
                    {!isUnlocked && (
                      <Button 
                        size="sm" 
                        variant="outline" 
                        className="mt-3 w-full"
                        onClick={() => handleTestUnlock(achievement.id)}
                      >
                        Test Unlock
                      </Button>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>
      </Tabs>

      {/* Recent Achievements */}
      {unlockedCount > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-[#001B30]">
              <Award className="h-5 w-5 text-yellow-500" />
              Recent Achievements
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {safeFilter(safeAchievements, a => a.unlocked, 'Recent achievements')
                .sort((a, b) => new Date(b.unlockedAt!).getTime() - new Date(a.unlockedAt!).getTime())
                .slice(0, 5)
                .map((achievement) => {
                  const Icon = getAchievementIcon(achievement.icon);
                  return (
                    <div key={achievement.id} className="flex items-center gap-3 p-3 bg-yellow-50 rounded-lg">
                      <div className={`p-2 rounded-lg ${getRarityColor(achievement.rarity)}`}>
                        <Icon className="h-4 w-4 text-white" />
                      </div>
                      <div className="flex-1">
                        <p className="font-medium text-[#001B30]">{achievement.name}</p>
                        <p className="text-sm text-[#7E8E9D]">
                          Unlocked {new Date(achievement.unlockedAt!).toLocaleDateString()}
                        </p>
                      </div>
                      <Badge className="bg-yellow-500 text-white">{achievement.rarity}</Badge>
                    </div>
                  );
                })}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default Achievements;