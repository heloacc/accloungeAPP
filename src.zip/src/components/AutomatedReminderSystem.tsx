import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Clock, Target, Calendar, CheckCircle, AlertCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export default function AutomatedReminderSystem() {
  const [isRunning, setIsRunning] = useState(false);
  const [lastRun, setLastRun] = useState<string | null>(null);
  const [stats, setStats] = useState({
    habitReminders: 0,
    goalReminders: 0,
    usersProcessed: 0
  });
  const { toast } = useToast();

  useEffect(() => {
    loadLastRun();
  }, []);

  const loadLastRun = async () => {
    try {
      const { data, error } = await supabase
        .from('system_settings')
        .select('value')
        .eq('key', 'last_reminder_run')
        .single();

      if (!error && data) {
        setLastRun(data.value);
      }
    } catch (error) {
      console.error('Error loading last run:', error);
    }
  };

  const updateLastRun = async () => {
    const now = new Date().toISOString();
    try {
      await supabase
        .from('system_settings')
        .upsert({ 
          key: 'last_reminder_run', 
          value: now 
        });
      setLastRun(now);
    } catch (error) {
      console.error('Error updating last run:', error);
    }
  };

  const processAutomatedReminders = async () => {
    setIsRunning(true);
    const newStats = { habitReminders: 0, goalReminders: 0, usersProcessed: 0 };

    try {
      // Get all users with reminder preferences enabled
      const { data: users, error: usersError } = await supabase
        .from('profiles')
        .select('id, full_name, reminder_settings')
        .not('reminder_settings', 'is', null);

      if (usersError) throw usersError;

      for (const user of users || []) {
        const settings = user.reminder_settings || {};
        newStats.usersProcessed++;

        // Process habit reminders
        if (settings.habit_reminders) {
          const habitCount = await processHabitReminders(user.id, user.full_name);
          newStats.habitReminders += habitCount;
        }

        // Process goal reminders
        if (settings.goal_reminders) {
          const goalCount = await processGoalReminders(user.id, user.full_name);
          newStats.goalReminders += goalCount;
        }
      }

      await updateLastRun();
      setStats(newStats);

      toast({
        title: "Automated Reminders Processed",
        description: `Sent ${newStats.habitReminders} habit and ${newStats.goalReminders} goal reminders to ${newStats.usersProcessed} users.`,
      });
    } catch (error) {
      console.error('Error processing reminders:', error);
      toast({
        title: "Error",
        description: "Failed to process automated reminders.",
        variant: "destructive"
      });
    } finally {
      setIsRunning(false);
    }
  };

  const processHabitReminders = async (userId: string, userName: string): Promise<number> => {
    try {
      // Get incomplete habits for today
      const today = new Date().toISOString().split('T')[0];
      
      const { data: habits, error } = await supabase
        .from('habits')
        .select(`
          id, title, 
          habit_logs!left(id)
        `)
        .eq('user_id', userId)
        .eq('habit_logs.date', today);
      if (error) throw error;

      const incompleteHabits = habits?.filter(habit => 
        !habit.habit_logs || habit.habit_logs.length === 0
      ) || [];

      if (incompleteHabits.length > 0) {
        const habitNames = incompleteHabits.map(h => h.title).join(', ');
        
        await supabase
          .from('notifications')
          .insert({
            user_id: userId,
            type: 'habit_reminder',
            title: `Don't lose your streak! 🔥`,
            message: `Hi ${userName || 'there'}! You have ${incompleteHabits.length} habit(s) to complete today: ${habitNames}`,
            read: false
          });

        return 1;
      }
    } catch (error) {
      console.error('Error processing habit reminders for user:', userId, error);
    }
    return 0;
  };

  const processGoalReminders = async (userId: string, userName: string): Promise<number> => {
    try {
      // Get goals with overdue tasks
      const { data: goals, error } = await supabase
        .from('goals')
        .select(`
          id, title,
          goal_tasks!inner(id, title, completed)
        `)
        .eq('user_id', userId)
        .eq('goal_tasks.completed', false);

      if (error) throw error;

      if (goals && goals.length > 0) {
        const incompleteCount = goals.reduce((sum, goal) => sum + (goal.goal_tasks?.length || 0), 0);
        
        await supabase
          .from('notifications')
          .insert({
            user_id: userId,
            type: 'goal_reminder',
            title: `Goal tasks need attention! 🎯`,
            message: `Hi ${userName || 'there'}! You have ${incompleteCount} incomplete task(s) across ${goals.length} goal(s). Time to make progress!`,
            read: false
          });

        return 1;
      }
    } catch (error) {
      console.error('Error processing goal reminders for user:', userId, error);
    }
    return 0;
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Clock className="w-5 h-5" />
          Automated Reminder System
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="text-center">
            <div className="text-2xl font-bold text-blue-600">{stats.habitReminders}</div>
            <div className="text-sm text-muted-foreground">Habit Reminders Sent</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-green-600">{stats.goalReminders}</div>
            <div className="text-sm text-muted-foreground">Goal Reminders Sent</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-purple-600">{stats.usersProcessed}</div>
            <div className="text-sm text-muted-foreground">Users Processed</div>
          </div>
        </div>

        {lastRun && (
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <CheckCircle className="w-4 h-4" />
            Last run: {new Date(lastRun).toLocaleString()}
          </div>
        )}

        <Button 
          onClick={processAutomatedReminders}
          disabled={isRunning}
          className="w-full"
        >
          {isRunning ? (
            <>
              <AlertCircle className="w-4 h-4 mr-2 animate-spin" />
              Processing Reminders...
            </>
          ) : (
            <>
              <Clock className="w-4 h-4 mr-2" />
              Run Automated Reminders Now
            </>
          )}
        </Button>

        <div className="text-xs text-muted-foreground">
          This system checks all users with reminder preferences enabled and sends notifications for:
          <ul className="list-disc list-inside mt-1 space-y-1">
            <li>Incomplete daily habits</li>
            <li>Overdue goal tasks</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
}