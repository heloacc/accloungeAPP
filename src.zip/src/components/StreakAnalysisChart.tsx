import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Flame, TrendingUp, Award, Calendar } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useSession } from '@/hooks/useSession';

interface StreakData {
  habitId: string;
  habitTitle: string;
  currentStreak: number;
  longestStreak: number;
  category: 'excellent' | 'good' | 'needs_work';
}

const StreakAnalysisChart: React.FC = () => {
  const { session } = useSession();
  const [streaks, setStreaks] = useState<StreakData[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (session?.user?.id) {
      loadStreakData();
    }
  }, [session?.user?.id]);

  const loadStreakData = async () => {
    try {
      setLoading(true);
      const userId = session?.user?.id;

      // Use separate queries to avoid relationship issues
      const { data: habitsData } = await supabase
        .from('habits')
        .select('id, title, current_streak, longest_streak, is_active')
        .eq('user_id', userId)
        .eq('is_active', true);

      const habits = habitsData || [];

      const streakAnalysis: StreakData[] = habits.map(habit => {
        const currentStreak = habit.current_streak || 0;
        const longestStreak = habit.longest_streak || 0;
        
        let category: 'excellent' | 'good' | 'needs_work';
        if (currentStreak >= 21) category = 'excellent';
        else if (currentStreak >= 7) category = 'good';
        else category = 'needs_work';

        return {
          habitId: habit.id,
          habitTitle: habit.title,
          currentStreak,
          longestStreak,
          category
        };
      });

      setStreaks(streakAnalysis.sort((a, b) => b.currentStreak - a.currentStreak));
    } catch (error) {
      console.error('Error loading streak data:', error);
      setStreaks([]);
    } finally {
      setLoading(false);
    }
  };

  const totalStreakDays = streaks.reduce((sum, s) => sum + s.currentStreak, 0);
  const avgStreak = streaks.length > 0 ? Math.round(totalStreakDays / streaks.length) : 0;
  const bestStreak = Math.max(...streaks.map(s => s.longestStreak), 0);
  const excellentHabits = streaks.filter(s => s.category === 'excellent').length;

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'excellent': return 'bg-green-100 text-green-800 border-green-200';
      case 'good': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'needs_work': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold">Streak Analysis</h3>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <Flame className="h-8 w-8 text-orange-600 mx-auto mb-2" />
            <div className="text-2xl font-bold">{totalStreakDays}</div>
            <div className="text-sm text-gray-600">Total Streak Days</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <TrendingUp className="h-8 w-8 text-blue-600 mx-auto mb-2" />
            <div className="text-2xl font-bold">{avgStreak}</div>
            <div className="text-sm text-gray-600">Average Streak</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <Award className="h-8 w-8 text-green-600 mx-auto mb-2" />
            <div className="text-2xl font-bold">{bestStreak}</div>
            <div className="text-sm text-gray-600">Best Streak</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <Calendar className="h-8 w-8 text-purple-600 mx-auto mb-2" />
            <div className="text-2xl font-bold">{excellentHabits}</div>
            <div className="text-sm text-gray-600">21+ Day Streaks</div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Habit Streak Performance</CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex justify-center p-8">
              <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary"></div>
            </div>
          ) : streaks.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              No habit data available. Start tracking habits to see streak analysis.
            </div>
          ) : (
            <div className="space-y-3">
              {streaks.map((streak) => (
                <div key={streak.habitId} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex-1">
                    <div className="flex items-center gap-3">
                      <h4 className="font-medium">{streak.habitTitle}</h4>
                      <Badge className={getCategoryColor(streak.category)}>
                        {streak.category.replace('_', ' ')}
                      </Badge>
                    </div>
                    <div className="text-sm text-gray-600 mt-1">
                      Best streak: {streak.longestStreak} days
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-bold text-orange-600">
                      {streak.currentStreak}
                    </div>
                    <div className="text-sm text-gray-600">days</div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Streak Categories</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 bg-green-50 border border-green-200 rounded-lg">
              <div>
                <div className="font-medium text-green-800">Excellent (21+ days)</div>
                <div className="text-sm text-green-600">Strong habit formation</div>
              </div>
              <div className="text-2xl font-bold text-green-600">
                {streaks.filter(s => s.category === 'excellent').length}
              </div>
            </div>
            <div className="flex items-center justify-between p-3 bg-blue-50 border border-blue-200 rounded-lg">
              <div>
                <div className="font-medium text-blue-800">Good (7-20 days)</div>
                <div className="text-sm text-blue-600">Building momentum</div>
              </div>
              <div className="text-2xl font-bold text-blue-600">
                {streaks.filter(s => s.category === 'good').length}
              </div>
            </div>
            <div className="flex items-center justify-between p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
              <div>
                <div className="font-medium text-yellow-800">Needs Work (0-6 days)</div>
                <div className="text-sm text-yellow-600">Focus area</div>
              </div>
              <div className="text-2xl font-bold text-yellow-600">
                {streaks.filter(s => s.category === 'needs_work').length}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default StreakAnalysisChart;