import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Flame, Plus, Calendar, Users, Trash2, Play, Pause, Square, Eye } from 'lucide-react';
import { CompetitionParticipantsView } from './CompetitionParticipantsView';

interface Competition {
  id: string;
  habit_name: string;
  end_date: string;
  created_at: string;
  is_active: boolean;
  participant_count?: number;
  status: 'active' | 'paused' | 'ended';
}

interface AdminCompetitionUIProps {
  competitions: Competition[];
  habits: string[];
  loading: boolean;
  isCreateOpen: boolean;
  setIsCreateOpen: (open: boolean) => void;
  isViewOpen: boolean;
  setIsViewOpen: (open: boolean) => void;
  selectedCompetition: any;
  newCompetition: {
    title: string;
    description: string;
    habit_name: string;
    start_date: string;
    end_date: string;
    duration_days: number;
  };
  onCreateCompetition: () => void;
  onToggleStatus: (id: string, currentStatus: boolean) => void;
  onEndCompetition: (id: string) => void;
  onDeleteCompetition: (id: string) => void;
  onViewParticipants: (id: string) => void;
  getEndDate: (days: number) => string;
}

export const AdminCompetitionUI: React.FC<AdminCompetitionUIProps> = ({
  competitions,
  habits,
  loading,
  isCreateOpen,
  setIsCreateOpen,
  isViewOpen,
  setIsViewOpen,
  selectedCompetition,
  newCompetition,
  setNewCompetition,
  onCreateCompetition,
  onToggleStatus,
  onEndCompetition,
  onDeleteCompetition,
  onViewParticipants,
  getEndDate
}) => {
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return <Badge className="bg-green-100 text-green-800">Active</Badge>;
      case 'paused':
        return <Badge className="bg-yellow-100 text-yellow-800">Paused</Badge>;
      case 'ended':
        return <Badge className="bg-gray-100 text-gray-800">Ended</Badge>;
      default:
        return <Badge variant="secondary">Unknown</Badge>;
    }
  };

  if (loading) {
    return <div className="text-center p-8">Loading competitions...</div>;
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Enhanced Competition Management</h2>
          <p className="text-muted-foreground">Create and manage streak competitions with full lifecycle control</p>
        </div>
        
        <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
          <DialogTrigger asChild>
            <Button className="flex items-center gap-2">
              <Plus className="w-4 h-4" />
              Create Competition
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create New Competition</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="title">Competition Title</Label>
                <Input
                  id="title"
                  value={newCompetition.title}
                  onChange={(e) => setNewCompetition(prev => ({ ...prev, title: e.target.value }))}
                  placeholder="Enter competition title"
                />
              </div>

              <div>
                <Label htmlFor="description">Description (Optional)</Label>
                <Input
                  id="description"
                  value={newCompetition.description}
                  onChange={(e) => setNewCompetition(prev => ({ ...prev, description: e.target.value }))}
                  placeholder="Enter competition description"
                />
              </div>

              <div>
                <Label htmlFor="habit">Habit Name</Label>
                <Select value={newCompetition.habit_name} onValueChange={(value) => 
                  setNewCompetition(prev => ({ ...prev, habit_name: value }))
                }>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a habit" />
                  </SelectTrigger>
                  <SelectContent>
                    {habits.map(habit => (
                      <SelectItem key={habit} value={habit}>{habit}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="start_date">Start Date</Label>
                <Input
                  id="start_date"
                  type="date"
                  value={newCompetition.start_date}
                  onChange={(e) => setNewCompetition(prev => ({ ...prev, start_date: e.target.value }))}
                />
              </div>
              
              <div>
                <Label htmlFor="duration">Duration</Label>
                <Select value={newCompetition.duration_days.toString()} onValueChange={(value) => {
                  const days = parseInt(value);
                  setNewCompetition(prev => ({ 
                    ...prev, 
                    duration_days: days,
                    end_date: getEndDate(days)
                  }));
                }}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="7">1 Week</SelectItem>
                    <SelectItem value="14">2 Weeks</SelectItem>
                    <SelectItem value="30">1 Month</SelectItem>
                    <SelectItem value="60">2 Months</SelectItem>
                    <SelectItem value="90">3 Months</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="end_date">End Date</Label>
                <Input
                  id="end_date"
                  type="date"
                  value={newCompetition.end_date}
                  onChange={(e) => setNewCompetition(prev => ({ ...prev, end_date: e.target.value }))}
                />
              </div>

              <Button onClick={onCreateCompetition} className="w-full">
                Create Competition
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>
      {/* Competitions List */}
      <div className="grid gap-4">
        {competitions.map((competition) => (
          <Card key={competition.id}>
            <CardContent className="p-4">
              <div className="flex justify-between items-start">
                <div className="flex items-start gap-3">
                  <Flame className="w-5 h-5 text-orange-500 mt-1" />
                  <div>
                    <h3 className="font-semibold text-lg">{competition.habit_name} Competition</h3>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground mt-1">
                      <div className="flex items-center gap-1">
                        <Calendar className="w-4 h-4" />
                        Ends: {new Date(competition.end_date).toLocaleDateString()}
                      </div>
                      <div className="flex items-center gap-1">
                        <Users className="w-4 h-4" />
                        {competition.participant_count} participants
                      </div>
                    </div>
                    <div className="mt-2">
                      {getStatusBadge(competition.status)}
                    </div>
                  </div>
                </div>
                
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => onViewParticipants(competition.id)}
                    className="flex items-center gap-1"
                  >
                    <Eye className="w-4 h-4" />
                    View
                  </Button>
                  
                  {competition.status !== 'ended' && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => onToggleStatus(competition.id, competition.is_active)}
                      className="flex items-center gap-1"
                    >
                      {competition.is_active ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                      {competition.is_active ? 'Pause' : 'Resume'}
                    </Button>
                  )}
                  
                  {competition.status !== 'ended' && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => onEndCompetition(competition.id)}
                      className="flex items-center gap-1 text-orange-600 hover:text-orange-700"
                    >
                      <Square className="w-4 h-4" />
                      End
                    </Button>
                  )}
                  
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => onDeleteCompetition(competition.id)}
                    className="text-red-600 hover:text-red-700"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {competitions.length === 0 && (
        <Card>
          <CardContent className="p-8 text-center">
            <Flame className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">No Competitions Yet</h3>
            <p className="text-muted-foreground mb-4">Create your first streak competition to get started.</p>
            <Button onClick={() => setIsCreateOpen(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Create Competition
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Participants View Dialog */}
      <Dialog open={isViewOpen} onOpenChange={setIsViewOpen}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Competition Participants</DialogTitle>
          </DialogHeader>
          {selectedCompetition && (
            <CompetitionParticipantsView competition={selectedCompetition} />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};