import { useAppContext } from '@/contexts/AppContext';

interface GroupNavigationHandlerProps {
  groupId: number;
  isAdmin?: boolean;
  onNavigate: (tab: string, data?: any) => void;
  children: React.ReactNode;
}

const GroupNavigationHandler = ({ 
  groupId, 
  isAdmin = false, 
  onNavigate, 
  children 
}: GroupNavigationHandlerProps) => {
  
  const handleGroupAccess = () => {
    // Store the selected group ID in session storage for ActiveCircle to use
    sessionStorage.setItem('selectedGroupId', groupId.toString());
    
    // Navigate to active-circle tab
    onNavigate('active-circle', { groupId });
  };

  return (
    <div onClick={handleGroupAccess} style={{ cursor: 'pointer' }}>
      {children}
    </div>
  );
};

export default GroupNavigationHandler;