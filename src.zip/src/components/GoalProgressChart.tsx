import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Target, TrendingUp, Clock, CheckCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useSession } from '@/hooks/useSession';

interface GoalData {
  id: string;
  title: string;
  status: string;
  progress: number;
  targetDate: string | null;
  daysRemaining: number | null;
  category: 'on_track' | 'behind' | 'completed' | 'overdue';
}

const GoalProgressChart: React.FC = () => {
  const { session } = useSession();
  const [goals, setGoals] = useState<GoalData[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (session?.user?.id) {
      loadGoalData();
    }
  }, [session?.user?.id]);

  const loadGoalData = async () => {
    try {
      setLoading(true);
      const userId = session?.user?.id;

      // Fetch goals and their tasks separately
      const [goalsRes, tasksRes] = await Promise.all([
        supabase
          .from('goals')
          .select('id, title, status, target_date, created_at, updated_at')
          .eq('user_id', userId),
        supabase
          .from('goal_tasks')
          .select('goal_id, status')
          .eq('user_id', userId)
      ]);

      const goalsData = goalsRes.data || [];
      const tasksData = tasksRes.data || [];

      const processedGoals: GoalData[] = goalsData.map(goal => {
        // Calculate progress from tasks
        const goalTasks = tasksData.filter(task => task.goal_id === goal.id);
        const completedTasks = goalTasks.filter(task => task.status === 'done').length;
        const totalTasks = Math.max(goalTasks.length, 1);
        const progress = Math.round((completedTasks / totalTasks) * 100);

        // Calculate days remaining
        let daysRemaining = null;
        let category: 'on_track' | 'behind' | 'completed' | 'overdue' = 'on_track';

        if (goal.target_date) {
          const targetDate = new Date(goal.target_date);
          const now = new Date();
          daysRemaining = Math.ceil((targetDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
        }

        // Determine category
        if (goal.status === 'completed' || progress >= 100) {
          category = 'completed';
        } else if (daysRemaining !== null && daysRemaining < 0) {
          category = 'overdue';
        } else if (daysRemaining !== null && daysRemaining < 7 && progress < 80) {
          category = 'behind';
        } else {
          category = 'on_track';
        }

        return {
          id: goal.id,
          title: goal.title,
          status: goal.status,
          progress,
          targetDate: goal.target_date,
          daysRemaining,
          category
        };
      });

      setGoals(processedGoals.sort((a, b) => {
        // Sort by category priority, then by progress
        const categoryOrder = { completed: 0, on_track: 1, behind: 2, overdue: 3 };
        const aPriority = categoryOrder[a.category];
        const bPriority = categoryOrder[b.category];
        if (aPriority !== bPriority) return aPriority - bPriority;
        return b.progress - a.progress;
      }));
    } catch (error) {
      console.error('Error loading goal data:', error);
      setGoals([]);
    } finally {
      setLoading(false);
    }
  };

  const completedGoals = goals.filter(g => g.category === 'completed').length;
  const onTrackGoals = goals.filter(g => g.category === 'on_track').length;
  const behindGoals = goals.filter(g => g.category === 'behind').length;
  const overdueGoals = goals.filter(g => g.category === 'overdue').length;
  const avgProgress = goals.length > 0 ? Math.round(goals.reduce((sum, g) => sum + g.progress, 0) / goals.length) : 0;

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'completed': return 'bg-green-100 text-green-800 border-green-200';
      case 'on_track': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'behind': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'overdue': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'completed': return <CheckCircle className="h-4 w-4" />;
      case 'on_track': return <Target className="h-4 w-4" />;
      case 'behind': return <Clock className="h-4 w-4" />;
      case 'overdue': return <TrendingUp className="h-4 w-4" />;
      default: return <Target className="h-4 w-4" />;
    }
  };

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold">Goal Progress Analysis</h3>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <CheckCircle className="h-8 w-8 text-green-600 mx-auto mb-2" />
            <div className="text-2xl font-bold">{completedGoals}</div>
            <div className="text-sm text-gray-600">Completed</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <Target className="h-8 w-8 text-blue-600 mx-auto mb-2" />
            <div className="text-2xl font-bold">{onTrackGoals}</div>
            <div className="text-sm text-gray-600">On Track</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <Clock className="h-8 w-8 text-yellow-600 mx-auto mb-2" />
            <div className="text-2xl font-bold">{behindGoals}</div>
            <div className="text-sm text-gray-600">Behind</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <TrendingUp className="h-8 w-8 text-purple-600 mx-auto mb-2" />
            <div className="text-2xl font-bold">{avgProgress}%</div>
            <div className="text-sm text-gray-600">Avg Progress</div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Goal Status Overview</CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex justify-center p-8">
              <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary"></div>
            </div>
          ) : goals.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              No goals found. Create your first goal to see progress analysis.
            </div>
          ) : (
            <div className="space-y-3">
              {goals.map((goal) => (
                <div key={goal.id} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h4 className="font-medium">{goal.title}</h4>
                      <Badge className={getCategoryColor(goal.category)}>
                        <div className="flex items-center gap-1">
                          {getCategoryIcon(goal.category)}
                          {goal.category.replace('_', ' ')}
                        </div>
                      </Badge>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="flex-1 bg-gray-200 rounded-full h-2">
                        <div 
                          className={`h-2 rounded-full transition-all duration-300 ${
                            goal.progress >= 100 ? 'bg-green-500' : 
                            goal.progress >= 75 ? 'bg-blue-500' : 
                            goal.progress >= 50 ? 'bg-yellow-500' : 'bg-red-500'
                          }`}
                          style={{ width: `${Math.min(goal.progress, 100)}%` }}
                        />
                      </div>
                      <div className="text-sm font-medium">
                        {goal.progress}%
                      </div>
                    </div>
                    {goal.daysRemaining !== null && (
                      <div className="text-sm text-gray-600 mt-1">
                        {goal.daysRemaining > 0 
                          ? `${goal.daysRemaining} days remaining`
                          : goal.daysRemaining === 0 
                            ? 'Due today'
                            : `${Math.abs(goal.daysRemaining)} days overdue`
                        }
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default GoalProgressChart;