import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { TrendingUp, Target, Flame, Calendar, BarChart3, Award } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useOptimizedUserData } from '@/hooks/useOptimizedUserData';

interface Analytics {
  totalHabits: number;
  totalGoals: number;
  currentStreak: number;
  longestStreak: number;
  weeklyRate: number;
  monthlyRate: number;
  completedGoals: number;
  consistencyScore: number;
}

const SimpleAnalyticsDashboard: React.FC = () => {
  const { session, loading: sessionLoading, user } = useOptimizedUserData();
  const [analytics, setAnalytics] = useState<Analytics>({
    totalHabits: 0, totalGoals: 0, currentStreak: 0, longestStreak: 0,
    weeklyRate: 0, monthlyRate: 0, completedGoals: 0, consistencyScore: 0
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // Wait for session to be fully loaded and user to be available
    if (!sessionLoading && user?.id) {
      loadAnalytics();
    } else if (!sessionLoading && !user) {
      // Session loading is complete but no user found
      setLoading(false);
      setError('No user session found. Please log in to view your analytics.');
    }
    
    // Listen for goal progress updates to refresh analytics
    const handleGoalProgressUpdate = () => {
      if (user?.id) {
        loadAnalytics();
      }
    };
    
    window.addEventListener('goalProgressUpdated', handleGoalProgressUpdate);
    
    return () => {
      window.removeEventListener('goalProgressUpdated', handleGoalProgressUpdate);
    };
  }, [user?.id, sessionLoading, user]);

  const loadAnalytics = async () => {
    try {
      setLoading(true);
      setError(null);
      const userId = user?.id;
      
      // Double check we have a valid user ID before making queries
      if (!userId) {
        throw new Error('No valid user ID available');
      }
      
      console.log('Loading analytics for user:', userId);
      const [habitsRes, goalsRes, logsRes] = await Promise.all([
        supabase.from('habits').select('*').eq('user_id', userId).eq('is_active', true),
        supabase.from('goals').select(`
          *,
          goal_tasks(*)
        `).eq('user_id', userId).in('status', ['active', 'paused']),
        supabase.from('habit_logs').select('*').eq('user_id', userId)
      ]);

      if (habitsRes.error) throw habitsRes.error;
      if (goalsRes.error) throw goalsRes.error;
      if (logsRes.error) throw logsRes.error;

      const habits = habitsRes.data || [];
      const goals = goalsRes.data || [];
      const logs = logsRes.data || [];
      
      console.log('Data loaded:', { habits: habits.length, goals: goals.length, logs: logs.length });
      
      const currentStreak = Math.max(...habits.map(h => h.current_streak || 0), 0);
      const longestStreak = Math.max(...habits.map(h => h.longest_streak || 0), 0);
      
      // Calculate completed goals based on task completion
      const completedGoals = goals.filter(goal => {
        if (!goal.goal_tasks || goal.goal_tasks.length === 0) {
          return goal.status === 'completed';
        }
        const completedTasks = goal.goal_tasks.filter(task => task.status === 'done').length;
        return completedTasks === goal.goal_tasks.length;
      }).length;
      
      // Calculate completion rates from logs for ACTIVE habits only
      const today = new Date().toISOString().split('T')[0];
      const thisWeek = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
      const thisMonth = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
      
      const weeklyCompletions = logs.filter(log => log.completed_at >= thisWeek).length;
      const monthlyCompletions = logs.filter(log => log.completed_at >= thisMonth).length;
      
      const activeHabitsCount = habits.length;
      const weeklyRate = activeHabitsCount > 0 ? Math.min(Math.round((weeklyCompletions / (activeHabitsCount * 7)) * 100), 100) : 0;
      const monthlyRate = activeHabitsCount > 0 ? Math.min(Math.round((monthlyCompletions / (activeHabitsCount * 30)) * 100), 100) : 0;
      
      setAnalytics({
        totalHabits: activeHabitsCount,
        totalGoals: goals.length,
        currentStreak,
        longestStreak,
        weeklyRate,
        monthlyRate,
        completedGoals,
        consistencyScore: longestStreak > 0 ? Math.round((currentStreak / longestStreak) * 100) : 0
      });
    } catch (error) {
      console.error('Analytics error:', error);
      setError(error instanceof Error ? error.message : 'Failed to load analytics');
    } finally {
      setLoading(false);
    }
  };

  if (loading) return (
    <div className="flex justify-center p-8">
      <div className="text-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
        <p className="text-muted-foreground">Loading your analytics...</p>
      </div>
    </div>
  );

  if (error) return (
    <div className="flex justify-center p-8">
      <div className="text-center">
        <p className="text-red-500 mb-4">{error}</p>
        <button onClick={loadAnalytics} className="px-4 py-2 bg-primary text-white rounded">
          Retry
        </button>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3 mb-6">
        <BarChart3 className="h-6 w-6 text-primary" />
        <div>
          <h1 className="text-2xl font-bold">My Analytics</h1>
          <p className="text-muted-foreground">Your personal progress and insights</p>
        </div>
      </div>
      
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card><CardHeader className="pb-2"><CardTitle className="text-sm flex items-center gap-2"><Target className="h-4 w-4"/>Habits</CardTitle></CardHeader><CardContent><div className="text-2xl font-bold">{analytics.totalHabits}</div><p className="text-xs text-muted-foreground">Active habits</p></CardContent></Card>
        <Card><CardHeader className="pb-2"><CardTitle className="text-sm flex items-center gap-2"><Flame className="h-4 w-4"/>Current Streak</CardTitle></CardHeader><CardContent><div className="text-2xl font-bold text-orange-500">{analytics.currentStreak}</div><p className="text-xs text-muted-foreground">days</p></CardContent></Card>
        <Card><CardHeader className="pb-2"><CardTitle className="text-sm flex items-center gap-2"><Award className="h-4 w-4"/>Best Streak</CardTitle></CardHeader><CardContent><div className="text-2xl font-bold text-green-500">{analytics.longestStreak}</div><p className="text-xs text-muted-foreground">days</p></CardContent></Card>
        <Card><CardHeader className="pb-2"><CardTitle className="text-sm flex items-center gap-2"><BarChart3 className="h-4 w-4"/>Goals</CardTitle></CardHeader><CardContent><div className="text-2xl font-bold">{analytics.completedGoals}/{analytics.totalGoals}</div><p className="text-xs text-muted-foreground">completed</p></CardContent></Card>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card><CardHeader className="pb-2"><CardTitle className="text-sm">Weekly Rate</CardTitle></CardHeader><CardContent><div className="text-2xl font-bold text-blue-500">{analytics.weeklyRate}%</div><p className="text-xs text-muted-foreground">completion rate</p></CardContent></Card>
        <Card><CardHeader className="pb-2"><CardTitle className="text-sm">Monthly Rate</CardTitle></CardHeader><CardContent><div className="text-2xl font-bold text-purple-500">{analytics.monthlyRate}%</div><p className="text-xs text-muted-foreground">completion rate</p></CardContent></Card>
        <Card><CardHeader className="pb-2"><CardTitle className="text-sm">Consistency</CardTitle></CardHeader><CardContent><div className="text-2xl font-bold text-indigo-500">{analytics.consistencyScore}%</div><p className="text-xs text-muted-foreground">score</p></CardContent></Card>
      </div>
    </div>
  );
};

export default SimpleAnalyticsDashboard;