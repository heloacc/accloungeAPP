import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Link, Target, TrendingUp, Plus } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabase';

interface Goal {
  id: string;
  title: string;
  description?: string;
  target_value?: number;
  current_value?: number;
}

interface Habit {
  id: string;
  title: string;
  current_streak: number;
  completed_dates: string[];
}

interface HabitGoalConnectorProps {
  habits: Habit[];
  onUpdate?: () => void;
}

const HabitGoalConnector: React.FC<HabitGoalConnectorProps> = ({ habits, onUpdate }) => {
  const [goals, setGoals] = useState<Goal[]>([]);
  const [habitGoalLinks, setHabitGoalLinks] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchGoals();
    fetchHabitGoalLinks();
  }, []);

  const fetchGoals = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('goals')
        .select('id, title, description, target_value, current_value')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setGoals(data || []);
    } catch (error) {
      console.error('Error fetching goals:', error);
    }
  };

  const fetchHabitGoalLinks = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      // Check if habit_goal_links table exists, if not, use local storage
      const { data, error } = await supabase
        .from('habit_goal_links')
        .select('habit_id, goal_id')
        .eq('user_id', user.id);

      if (error) {
        // Table doesn't exist, use local storage as fallback
        const stored = localStorage.getItem(`habit_goal_links_${user.id}`);
        if (stored) {
          setHabitGoalLinks(JSON.parse(stored));
        }
        return;
      }

      const links: Record<string, string> = {};
      data?.forEach(link => {
        links[link.habit_id] = link.goal_id;
      });
      setHabitGoalLinks(links);
    } catch (error) {
      console.error('Error fetching habit-goal links:', error);
    }
  };

  const linkHabitToGoal = async (habitId: string, goalId: string) => {
    setLoading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const newLinks = { ...habitGoalLinks };
      
      if (goalId === 'none') {
        delete newLinks[habitId];
      } else {
        newLinks[habitId] = goalId;
      }

      // Try to save to database first
      try {
        if (goalId === 'none') {
          await supabase
            .from('habit_goal_links')
            .delete()
            .eq('user_id', user.id)
            .eq('habit_id', habitId);
        } else {
          await supabase
            .from('habit_goal_links')
            .upsert({
              user_id: user.id,
              habit_id: habitId,
              goal_id: goalId,
              created_at: new Date().toISOString()
            });
        }
      } catch (dbError) {
        // If database fails, use local storage
        localStorage.setItem(`habit_goal_links_${user.id}`, JSON.stringify(newLinks));
      }

      setHabitGoalLinks(newLinks);
      
      toast({
        title: "Success",
        description: goalId === 'none' ? "Habit unlinked from goal" : "Habit linked to goal successfully!",
      });

      onUpdate?.();
    } catch (error) {
      console.error('Error linking habit to goal:', error);
      toast({
        title: "Error",
        description: "Failed to link habit to goal. Please try again.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const getGoalProgress = (goalId: string) => {
    const linkedHabits = habits.filter(h => habitGoalLinks[h.id] === goalId);
    if (linkedHabits.length === 0) return 0;
    
    const totalCompletions = linkedHabits.reduce((sum, habit) => 
      sum + (habit.completed_dates?.length || 0), 0);
    const avgCompletions = totalCompletions / linkedHabits.length;
    
    return Math.min(Math.round(avgCompletions * 2), 100); // Scale to percentage
  };

  const getHabitContribution = (habit: Habit) => {
    const goalId = habitGoalLinks[habit.id];
    if (!goalId) return null;
    
    const goal = goals.find(g => g.id === goalId);
    const completions = habit.completed_dates?.length || 0;
    
    return {
      goal,
      completions,
      contribution: Math.min(completions * 5, 100) // Each completion = 5% contribution
    };
  };

  if (habits.length === 0) {
    return (
      <Card className="border-dashed">
        <CardContent className="text-center py-8">
          <Link className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-semibold mb-2">No Habits to Link</h3>
          <p className="text-muted-foreground">
            Create some habits first to link them to your goals.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Link className="h-5 w-5 text-purple-500" />
          <h3 className="text-lg font-semibold">Connect Habits to Goals</h3>
        </div>
        {goals.length === 0 && (
          <Button variant="outline" size="sm" onClick={() => window.location.href = '/goals'}>
            <Plus className="h-4 w-4 mr-2" />
            Create Goals
          </Button>
        )}
      </div>

      <div className="grid gap-4">
        {habits.map((habit) => {
          const linkedGoalId = habitGoalLinks[habit.id];
          const linkedGoal = goals.find(g => g.id === linkedGoalId);
          const contribution = getHabitContribution(habit);
          
          return (
            <Card key={habit.id} className="border-l-4 border-l-purple-500">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg">{habit.title}</CardTitle>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="flex items-center gap-1">
                      <TrendingUp className="h-3 w-3" />
                      {habit.current_streak} day streak
                    </Badge>
                    {linkedGoal && (
                      <Badge variant="secondary" className="bg-purple-100 text-purple-800">
                        Linked
                      </Badge>
                    )}
                  </div>
                </div>
              </CardHeader>
              
              <CardContent className="space-y-4">
                <div className="flex items-center gap-3">
                  <Target className="h-4 w-4 text-purple-500" />
                  <div className="flex-1">
                    <Select
                      value={linkedGoalId || 'none'}
                      onValueChange={(value) => linkHabitToGoal(habit.id, value)}
                      disabled={loading || goals.length === 0}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder={goals.length === 0 ? "No goals available" : "Select a goal to link"} />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">No goal linked</SelectItem>
                        {goals.map((goal) => (
                          <SelectItem key={goal.id} value={goal.id}>
                            {goal.title}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {contribution && (
                  <div className="bg-purple-50 p-3 rounded-lg border border-purple-200">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium text-purple-800">
                        Contributing to: {contribution.goal?.title}
                      </span>
                      <Badge variant="outline" className="text-purple-600">
                        {contribution.completions} completions
                      </Badge>
                    </div>
                    <p className="text-xs text-purple-600">
                      Your habit progress is helping you achieve this goal
                    </p>
                  </div>
                )}

                <div className="flex justify-between text-sm text-muted-foreground">
                  <span>Total completions: {habit.completed_dates?.length || 0}</span>
                  {linkedGoal && (
                    <span>Goal progress: {getGoalProgress(linkedGoal.id)}%</span>
                  )}
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {goals.length === 0 && (
        <Card className="border-dashed border-purple-200">
          <CardContent className="text-center py-6">
            <Target className="h-8 w-8 text-purple-400 mx-auto mb-3" />
            <h4 className="font-semibold text-purple-800 mb-2">No Goals Available</h4>
            <p className="text-sm text-purple-600 mb-4">
              Create some goals to link your habits and track progress together.
            </p>
            <Button variant="outline" size="sm" onClick={() => window.location.href = '/goals'}>
              Create Your First Goal
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default HabitGoalConnector;