import { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Download, Share, Plus, X, Smartphone } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';

interface MobilePWAInstallerProps {
  onDismiss?: () => void;
}

export function MobilePWAInstaller({ onDismiss }: MobilePWAInstallerProps) {
  const [showPrompt, setShowPrompt] = useState(false);
  const [showInstructions, setShowInstructions] = useState(false);
  const [isInstalled, setIsInstalled] = useState(false);
  const [browserInfo, setBrowserInfo] = useState({ isIOS: false, isSafari: false, isChrome: false });

  useEffect(() => {
    // Detect browser and platform
    const userAgent = navigator.userAgent;
    const isIOS = /iPad|iPhone|iPod/.test(userAgent);
    const isSafari = /Safari/.test(userAgent) && !/Chrome/.test(userAgent);
    const isChrome = /Chrome/.test(userAgent);
    
    setBrowserInfo({ isIOS, isSafari, isChrome });

    // Check if already installed
    const isStandalone = window.matchMedia('(display-mode: standalone)').matches;
    const isInWebAppiOS = (window.navigator as any).standalone === true;
    setIsInstalled(isStandalone || isInWebAppiOS);

    // Check if user dismissed before
    const dismissed = localStorage.getItem('mobile-pwa-install-dismissed');
    const dismissedTime = dismissed ? parseInt(dismissed) : 0;
    const daysSinceDismissed = (Date.now() - dismissedTime) / (1000 * 60 * 60 * 24);

    // Show prompt if not installed and not recently dismissed
    if (!isInstalled && (!dismissed || daysSinceDismissed > 7)) {
      // Wait a bit before showing to avoid overwhelming new users
      setTimeout(() => setShowPrompt(true), 3000);
    }
  }, []);

  const handleDismiss = () => {
    setShowPrompt(false);
    localStorage.setItem('mobile-pwa-install-dismissed', Date.now().toString());
    onDismiss?.();
  };

  const handleShowInstructions = () => {
    setShowInstructions(true);
  };

  if (isInstalled || !showPrompt) return null;

  return (
    <>
      <Card className="fixed bottom-4 left-4 right-4 z-50 mx-auto max-w-sm shadow-lg">
        <CardContent className="flex items-center gap-3 p-4">
          <Smartphone className="h-8 w-8 text-primary" />
          <div className="flex-1">
            <h3 className="font-semibold">Install ACCLOUNGE</h3>
            <p className="text-sm text-muted-foreground">
              Get the app experience on your phone
            </p>
          </div>
          <div className="flex gap-2">
            <Button size="sm" onClick={handleShowInstructions}>
              Install
            </Button>
            <Button size="sm" variant="ghost" onClick={handleDismiss}>
              <X className="h-4 w-4" />
            </Button>
          </div>
        </CardContent>
      </Card>

      <Dialog open={showInstructions} onOpenChange={setShowInstructions}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Install ACCLOUNGE</DialogTitle>
          </DialogHeader>
          
          {browserInfo.isIOS && browserInfo.isSafari ? (
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">
                To install on iPhone/iPad:
              </p>
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10">
                    <span className="text-sm font-semibold">1</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm">Tap the</span>
                    <Share className="h-4 w-4" />
                    <span className="text-sm">share button</span>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10">
                    <span className="text-sm font-semibold">2</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm">Tap</span>
                    <Plus className="h-4 w-4" />
                    <span className="text-sm">"Add to Home Screen"</span>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10">
                    <span className="text-sm font-semibold">3</span>
                  </div>
                  <span className="text-sm">Tap "Add" to confirm</span>
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">
                To install on Android:
              </p>
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10">
                    <span className="text-sm font-semibold">1</span>
                  </div>
                  <span className="text-sm">Tap the menu (⋮) in your browser</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10">
                    <span className="text-sm font-semibold">2</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm">Select</span>
                    <Download className="h-4 w-4" />
                    <span className="text-sm">"Install app" or "Add to Home screen"</span>
                  </div>
                </div>
              </div>
            </div>
          )}
          
          <Button onClick={() => setShowInstructions(false)} className="mt-4">
            Got it!
          </Button>
        </DialogContent>
      </Dialog>
    </>
  );
}