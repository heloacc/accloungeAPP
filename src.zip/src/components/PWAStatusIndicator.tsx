import { useState, useEffect } from 'react';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Smartphone, Wifi, WifiOff, Download } from 'lucide-react';
import { Card, CardContent } from './ui/card';

export function PWAStatusIndicator() {
  const [isInstalled, setIsInstalled] = useState(false);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [showStatus, setShowStatus] = useState(false);

  useEffect(() => {
    // Check if app is installed
    const checkInstalled = () => {
      const isStandalone = window.matchMedia('(display-mode: standalone)').matches;
      const isInWebAppiOS = (window.navigator as any).standalone === true;
      return isStandalone || isInWebAppiOS;
    };

    setIsInstalled(checkInstalled());

    // Monitor online status
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Show status for new users or if offline
    const hasSeenStatus = localStorage.getItem('pwa-status-seen');
    if (!hasSeenStatus || !isOnline) {
      setShowStatus(true);
      localStorage.setItem('pwa-status-seen', 'true');
    }

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const handleDismiss = () => {
    setShowStatus(false);
  };

  if (!showStatus && isOnline) return null;

  return (
    <Card className="fixed top-4 right-4 z-40 max-w-xs">
      <CardContent className="p-3">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Smartphone className="h-4 w-4" />
            <div className="flex flex-col gap-1">
              <div className="flex items-center gap-2">
                <Badge variant={isInstalled ? "default" : "secondary"}>
                  {isInstalled ? "Installed" : "Web App"}
                </Badge>
                <div className="flex items-center gap-1">
                  {isOnline ? (
                    <Wifi className="h-3 w-3 text-green-500" />
                  ) : (
                    <WifiOff className="h-3 w-3 text-red-500" />
                  )}
                  <span className="text-xs text-muted-foreground">
                    {isOnline ? "Online" : "Offline"}
                  </span>
                </div>
              </div>
              {!isInstalled && (
                <p className="text-xs text-muted-foreground">
                  Install for better experience
                </p>
              )}
              {!isOnline && (
                <p className="text-xs text-muted-foreground">
                  Some features limited offline
                </p>
              )}
            </div>
          </div>
          <Button 
            size="sm" 
            variant="ghost" 
            onClick={handleDismiss}
            className="h-6 w-6 p-0"
          >
            ×
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}