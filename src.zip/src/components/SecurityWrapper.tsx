import React, { useState, useEffect } from 'react';
import { useAppContext } from '@/contexts/AppContext';
import { supabase } from '@/lib/supabase';
import { Shield, AlertTriangle } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

interface SecurityWrapperProps {
  children: React.ReactNode;
  requireAdmin?: boolean;
  operation?: string;
}

const SecurityWrapper: React.FC<SecurityWrapperProps> = ({ 
  children, 
  requireAdmin = false, 
  operation 
}) => {
  const { currentUser } = useAppContext();
  const [isAuthorized, setIsAuthorized] = useState<boolean | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const validateAccess = async () => {
      if (!currentUser) {
        setIsAuthorized(false);
        setError('Authentication required');
        return;
      }

      try {
        // Input validation
        const { data: validationResult } = await supabase.functions.invoke('input-validation', {
          body: { 
            operation: 'validate_uuid', 
            data: { id: currentUser.id } 
          }
        });

        if (!validationResult?.data?.valid) {
          setError('Invalid user ID');
          setIsAuthorized(false);
          return;
        }

        // Security validation for admin operations
        if (requireAdmin) {
          const { data: securityResult, error: securityError } = await supabase.functions.invoke('security-validation', {
            body: { 
              operation: 'verify_admin'
            }
          });

          if (securityError || !securityResult?.data?.isAdmin) {
            setError('Admin privileges required');
            setIsAuthorized(false);
            return;
          }

          // Log admin operation
          if (operation) {
            await supabase.functions.invoke('security-validation', {
              body: { 
                operation: 'audit_action',
                data: { 
                  action: operation,
                  details: { timestamp: new Date().toISOString() }
                }
              }
            });
          }
        }

        setIsAuthorized(true);
        setError(null);
      } catch (err: any) {
        setError(err.message || 'Security validation failed');
        setIsAuthorized(false);
      }
    };

    validateAccess();
  }, [currentUser, requireAdmin, operation]);

  if (isAuthorized === null) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="flex items-center gap-2 text-muted-foreground">
          <Shield className="h-5 w-5 animate-spin" />
          <span>Validating access...</span>
        </div>
      </div>
    );
  }

  if (!isAuthorized) {
    return (
      <Card className="m-4">
        <CardContent className="p-6">
          <div className="text-center text-red-600">
            <AlertTriangle className="h-12 w-12 mx-auto mb-4" />
            <p className="font-medium">Access Denied</p>
            <p className="text-sm mt-2">{error}</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return <>{children}</>;
};

export default SecurityWrapper;