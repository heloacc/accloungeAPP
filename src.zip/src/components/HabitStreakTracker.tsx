import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Flame, Calendar, Target, TrendingUp } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface HabitStreakTrackerProps {
  habit: {
    id: string;
    title: string;
    current_streak: number;
    longest_streak: number;
    total_completions: number;
  };
}

export default function HabitStreakTracker({ habit }: HabitStreakTrackerProps) {
  const [metrics, setMetrics] = useState({
    completion_rate: 0,
    weekly_completed: 0,
    weekly_target: 7
  });

  useEffect(() => {
    calculateMetrics();
  }, [habit.id, habit.total_completions]);

  const calculateMetrics = async () => {
    try {
      const { data: user } = await supabase.auth.getUser();
      if (!user.user) return;

      const now = new Date();
      const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
      const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);

      const [thirtyDayLogs, weekLogs] = await Promise.all([
        supabase
          .from('habit_logs')
          .select('*')
          .eq('habit_id', habit.id)
          .eq('user_id', user.user.id)
          .gte('date', thirtyDaysAgo.toISOString().split('T')[0])
          .eq('status', 'done'),
        supabase
          .from('habit_logs')
          .select('*')
          .eq('habit_id', habit.id)
          .eq('user_id', user.user.id)
          .gte('date', weekAgo.toISOString().split('T')[0])
          .eq('status', 'done')
      ]);

      const completion_rate = thirtyDayLogs.data ? Math.round((thirtyDayLogs.data.length / 30) * 100) : 0;
      const weekly_completed = weekLogs.data ? weekLogs.data.length : 0;

      setMetrics({
        completion_rate,
        weekly_completed,
        weekly_target: 7
      });
    } catch (error) {
      console.error('Error calculating metrics:', error);
    }
  };

  const weeklyProgress = (metrics.weekly_completed / metrics.weekly_target) * 100;
  const streakColor = habit.current_streak >= 7 ? 'text-orange-500' : 
                     habit.current_streak >= 3 ? 'text-yellow-500' : 'text-gray-400';

  return (
    <Card className="w-full">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg">{habit.title}</CardTitle>
          <div className="flex items-center space-x-2">
            <Flame className={`w-5 h-5 ${streakColor}`} />
            <Badge variant="secondary" className="font-bold">
              {habit.current_streak} day streak
            </Badge>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="flex items-center">
              <Calendar className="w-4 h-4 mr-1" />
              This Week
            </span>
            <span>{metrics.weekly_completed}/{metrics.weekly_target}</span>
          </div>
          <Progress value={weeklyProgress} className="h-2" />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="text-center p-3 bg-muted rounded-lg">
            <div className="flex items-center justify-center mb-1">
              <Target className="w-4 h-4 mr-1 text-blue-500" />
            </div>
            <div className="text-2xl font-bold">{habit.longest_streak}</div>
            <div className="text-xs text-muted-foreground">Best Streak</div>
          </div>
          
          <div className="text-center p-3 bg-muted rounded-lg">
            <div className="flex items-center justify-center mb-1">
              <TrendingUp className="w-4 h-4 mr-1 text-green-500" />
            </div>
            <div className="text-2xl font-bold">{metrics.completion_rate}%</div>
            <div className="text-xs text-muted-foreground">Success Rate</div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}