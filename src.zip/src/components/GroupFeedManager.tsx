import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Pin, Clock, Send, CalendarIcon, MessageSquare, PinOff } from 'lucide-react';
import { format } from 'date-fns';
import { supabase } from '@/lib/supabase';
import { toast } from '@/components/ui/use-toast';
import { useAppContext } from '@/contexts/AppContext';

interface GroupPost {
  id: string;
  content: string;
  is_pinned: boolean;
  is_scheduled: boolean;
  scheduled_for: string | null;
  pinned_by: string | null;
  pinned_at: string | null;
  created_at: string;
  user_id: string;
  profiles: {
    full_name: string;
  };
}

interface GroupFeedManagerProps {
  groupId: string;
  groupName: string;
  userRole?: string;
}

const GroupFeedManager: React.FC<GroupFeedManagerProps> = ({ groupId, groupName, userRole }) => {
  const { currentUser } = useAppContext();
  const [posts, setPosts] = useState<GroupPost[]>([]);
  const [newPost, setNewPost] = useState('');
  const [scheduledDate, setScheduledDate] = useState<Date | undefined>();
  const [loading, setLoading] = useState(true);
  const [posting, setPosting] = useState(false);

  const canModerate = currentUser?.isAdmin || userRole === 'moderator' || userRole === 'admin';

  useEffect(() => {
    fetchPosts();
  }, [groupId]);

  const fetchPosts = async () => {
    try {
      const { data } = await supabase
        .from('group_posts')
        .select(`
          *,
          profiles!group_posts_user_id_fkey(full_name)
        `)
        .eq('group_id', groupId)
        .order('is_pinned', { ascending: false })
        .order('created_at', { ascending: false });

      setPosts(data || []);
    } catch (error) {
      console.error('Error fetching posts:', error);
    } finally {
      setLoading(false);
    }
  };

  const createPost = async () => {
    if (!newPost.trim()) return;

    setPosting(true);
    try {
      const { error } = await supabase
        .from('group_posts')
        .insert([{
          group_id: groupId,
          user_id: currentUser.id,
          content: newPost,
          is_scheduled: !!scheduledDate,
          scheduled_for: scheduledDate?.toISOString()
        }]);

      if (error) throw error;

      setNewPost('');
      setScheduledDate(undefined);
      fetchPosts();
      
      toast({
        title: "Success",
        description: scheduledDate ? "Post scheduled successfully" : "Post created successfully"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to create post",
        variant: "destructive"
      });
    } finally {
      setPosting(false);
    }
  };

  const togglePin = async (postId: string, currentlyPinned: boolean) => {
    if (!canModerate) return;

    try {
      const { error } = await supabase
        .from('group_posts')
        .update({
          is_pinned: !currentlyPinned,
          pinned_by: !currentlyPinned ? currentUser.id : null,
          pinned_at: !currentlyPinned ? new Date().toISOString() : null
        })
        .eq('id', postId);

      if (error) throw error;

      fetchPosts();
      toast({
        title: "Success",
        description: currentlyPinned ? "Post unpinned" : "Post pinned"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update post",
        variant: "destructive"
      });
    }
  };

  if (loading) return <div className="p-4">Loading group feed...</div>;

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MessageSquare className="h-5 w-5" />
            {groupName} - Group Feed
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Textarea
            placeholder="Share an update, ask a question, or start a discussion..."
            value={newPost}
            onChange={(e) => setNewPost(e.target.value)}
            rows={3}
          />
          
          <div className="flex items-center gap-4">
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" size="sm">
                  <CalendarIcon className="h-4 w-4 mr-2" />
                  {scheduledDate ? format(scheduledDate, "PPP") : "Schedule"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <Calendar
                  mode="single"
                  selected={scheduledDate}
                  onSelect={setScheduledDate}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
            
            <Button onClick={createPost} disabled={posting || !newPost.trim()}>
              <Send className="h-4 w-4 mr-2" />
              {scheduledDate ? 'Schedule Post' : 'Post'}
            </Button>
          </div>
        </CardContent>
      </Card>

      <div className="space-y-4">
        {posts.map((post) => (
          <Card key={post.id} className={post.is_pinned ? 'border-yellow-200 bg-yellow-50' : ''}>
            <CardContent className="p-4">
              <div className="flex justify-between items-start mb-3">
                <div className="flex items-center gap-2">
                  <span className="font-medium">{post.profiles.full_name}</span>
                  <span className="text-sm text-muted-foreground">
                    {format(new Date(post.created_at), "MMM d, yyyy 'at' h:mm a")}
                  </span>
                  {post.is_pinned && <Badge variant="secondary" className="bg-yellow-100"><Pin className="h-3 w-3 mr-1" />Pinned</Badge>}
                  {post.is_scheduled && <Badge variant="outline"><Clock className="h-3 w-3 mr-1" />Scheduled</Badge>}
                </div>
                
                {canModerate && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => togglePin(post.id, post.is_pinned)}
                  >
                    {post.is_pinned ? <PinOff className="h-4 w-4" /> : <Pin className="h-4 w-4" />}
                  </Button>
                )}
              </div>
              
              <p className="text-sm whitespace-pre-wrap">{post.content}</p>
            </CardContent>
          </Card>
        ))}
        
        {posts.length === 0 && (
          <Card>
            <CardContent className="p-6 text-center text-muted-foreground">
              No posts yet. Be the first to start a conversation!
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};

export default GroupFeedManager;