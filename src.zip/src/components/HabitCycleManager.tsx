import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { RefreshCw, Calendar, Target, TrendingUp } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabase';

interface HabitCycle {
  id: string;
  title: string;
  cycle_start_date: string | null;
  cycle_duration: number;
  cycle_completed_count: number;
  auto_renew: boolean;
  current_streak: number;
  completed_dates: string[];
}

interface HabitCycleManagerProps {
  habits: HabitCycle[];
  onHabitUpdate: () => void;
}

const HabitCycleManager: React.FC<HabitCycleManagerProps> = ({ habits, onHabitUpdate }) => {
  const [loading, setLoading] = useState(false);

  const calculateCycleProgress = (habit: HabitCycle) => {
    if (!habit.cycle_start_date) return { progress: 0, daysRemaining: habit.cycle_duration, isCompleted: false };
    
    const startDate = new Date(habit.cycle_start_date);
    const today = new Date();
    const daysPassed = Math.floor((today.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
    const progress = Math.min((daysPassed / habit.cycle_duration) * 100, 100);
    const daysRemaining = Math.max(habit.cycle_duration - daysPassed, 0);
    const isCompleted = daysPassed >= habit.cycle_duration;
    
    return { progress, daysRemaining, isCompleted };
  };

  const startNewCycle = async (habitId: string) => {
    setLoading(true);
    try {
      const today = new Date().toISOString().split('T')[0];
      
      const { error } = await supabase
        .from('habits')
        .update({
          cycle_start_date: today,
          cycle_completed_count: 0,
          updated_at: new Date().toISOString()
        })
        .eq('id', habitId);

      if (error) throw error;

      toast({
        title: "New Cycle Started",
        description: "Your habit cycle has been renewed!",
      });

      onHabitUpdate();
    } catch (error) {
      console.error('Error starting new cycle:', error);
      toast({
        title: "Error",
        description: "Failed to start new cycle. Please try again.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const toggleAutoRenew = async (habitId: string, currentAutoRenew: boolean) => {
    try {
      const { error } = await supabase
        .from('habits')
        .update({
          auto_renew: !currentAutoRenew,
          updated_at: new Date().toISOString()
        })
        .eq('id', habitId);

      if (error) throw error;

      toast({
        title: "Auto-Renew Updated",
        description: `Auto-renew ${!currentAutoRenew ? 'enabled' : 'disabled'} for this habit.`,
      });

      onHabitUpdate();
    } catch (error) {
      console.error('Error updating auto-renew:', error);
      toast({
        title: "Error",
        description: "Failed to update auto-renew setting.",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 mb-4">
        <RefreshCw className="h-5 w-5" />
        <h3 className="text-lg font-semibold">Habit Cycles</h3>
      </div>
      
      {habits.map((habit) => {
        const { progress, daysRemaining, isCompleted } = calculateCycleProgress(habit);
        
        return (
          <Card key={habit.id} className="border-l-4 border-l-blue-500">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">{habit.title}</CardTitle>
                <div className="flex items-center gap-2">
                  {isCompleted && (
                    <Badge variant="secondary" className="bg-green-100 text-green-800">
                      Cycle Complete
                    </Badge>
                  )}
                  {habit.auto_renew && (
                    <Badge variant="outline">Auto-Renew</Badge>
                  )}
                </div>
              </div>
            </CardHeader>
            
            <CardContent className="space-y-4">
              {habit.cycle_start_date ? (
                <>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Cycle Progress</span>
                      <span>{Math.round(progress)}%</span>
                    </div>
                    <Progress value={progress} className="h-2" />
                    <div className="flex justify-between text-xs text-muted-foreground">
                      <span>{habit.cycle_duration - daysRemaining} of {habit.cycle_duration} days</span>
                      <span>{daysRemaining} days remaining</span>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div className="flex items-center gap-2">
                      <TrendingUp className="h-4 w-4 text-blue-500" />
                      <span>Current Streak: {habit.current_streak}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Target className="h-4 w-4 text-green-500" />
                      <span>Completions: {habit.completed_dates?.length || 0}</span>
                    </div>
                  </div>
                  
                  <div className="flex gap-2 pt-2">
                    {isCompleted && (
                      <Button
                        onClick={() => startNewCycle(habit.id)}
                        disabled={loading}
                        size="sm"
                        className="flex-1"
                      >
                        <RefreshCw className="h-4 w-4 mr-2" />
                        Start New Cycle
                      </Button>
                    )}
                    <Button
                      onClick={() => toggleAutoRenew(habit.id, habit.auto_renew)}
                      variant="outline"
                      size="sm"
                      className="flex-1"
                    >
                      {habit.auto_renew ? 'Disable' : 'Enable'} Auto-Renew
                    </Button>
                  </div>
                </>
              ) : (
                <div className="text-center py-4">
                  <Calendar className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                  <p className="text-sm text-muted-foreground mb-3">No active cycle</p>
                  <Button
                    onClick={() => startNewCycle(habit.id)}
                    disabled={loading}
                    size="sm"
                  >
                    Start First Cycle
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
};

export default HabitCycleManager;