import GatherFeed from '@/components/GatherFeed';

const Gather = () => {
  return <GatherFeed />;
};

export default Gather;