import React from 'react';
import { Card } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';

interface MomentumSnapshotProps {
  userName: string;
  streakDays: number;
  consistencyScore: number;
  backgroundImage: string;
}

export const MomentumSnapshot: React.FC<MomentumSnapshotProps> = ({
  userName,
  streakDays,
  consistencyScore,
  backgroundImage
}) => {
  const timeOfDay = new Date().getHours() < 12 ? 'morning' : new Date().getHours() < 17 ? 'afternoon' : 'evening';
  
  return (
    <Card className="relative overflow-hidden bg-gradient-to-r from-acclounge-brown to-acclounge-sage text-white p-4 sm:p-6 lg:p-8 mb-4 sm:mb-6 lg:mb-8">
      <div 
        className="absolute inset-0 opacity-20"
        style={{ 
          backgroundImage: `url(${backgroundImage})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      />
      <div className="relative z-10">
        <h1 className="text-xl sm:text-2xl lg:text-3xl font-bold mb-2 leading-tight">
          Good {timeOfDay}, {userName || 'there'}. You're on a {streakDays}-day streak{' '}
          <span className="inline-block">💪</span>
        </h1>
        
        <div className="mt-4 sm:mt-6 space-y-3 sm:space-y-4">
          <div>
            <div className="flex justify-between items-center mb-2">
              <span className="text-base sm:text-lg font-medium">Today's Progress</span>
              <span className="text-lg sm:text-xl font-bold">{consistencyScore}%</span>
            </div>
            <Progress value={consistencyScore} className="h-2 sm:h-3 bg-white/20" />
          </div>
          
          <p className="text-sm sm:text-base lg:text-lg opacity-90 leading-relaxed">
            {consistencyScore === 100 
              ? "🎉 All habits completed today!" 
              : consistencyScore > 0 
                ? `Keep going! Complete ${Math.ceil((100 - consistencyScore) / 100 * 2)} more habit${Math.ceil((100 - consistencyScore) / 100 * 2) > 1 ? 's' : ''} today.`
                : "Mark 1 habit to keep your streak alive."
            }
          </p>
        </div>
        
        {streakDays > 0 && (
          <div className="absolute top-2 sm:top-4 right-2 sm:right-4 animate-pulse">
            <div className="w-12 h-12 sm:w-16 sm:h-16 rounded-full bg-white/20 flex items-center justify-center">
              <span className="text-xl sm:text-2xl">💪</span>
            </div>
          </div>
        )}
      </div>
    </Card>
  );
};