import React from 'react';
import { Badge } from '@/components/ui/badge';
import { useSubscriptionAccess } from '@/hooks/useSubscriptionAccess';

interface SubscriptionPlanBadgeProps {
  className?: string;
}

const SubscriptionPlanBadge: React.FC<SubscriptionPlanBadgeProps> = ({ className }) => {
  const { subscription, loading } = useSubscriptionAccess();

  if (loading) {
    return (
      <div className={`animate-pulse bg-gray-200 rounded h-6 w-16 ${className}`} />
    );
  }

  if (!subscription || subscription.status !== 'active') {
    return (
      <Badge variant="secondary" className={className}>
        Free
      </Badge>
    );
  }

  const planName = subscription.subscription_plans?.name || 'Unknown';
  const variant = planName.toLowerCase() === 'pro' ? 'default' : 'secondary';

  return (
    <Badge variant={variant} className={className}>
      {planName}
    </Badge>
  );
};

export default SubscriptionPlanBadge;