import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { toast } from '@/components/ui/use-toast';
import { AdminCompetitionUI } from './AdminCompetitionUI';

interface Competition {
  id: string;
  habit_name: string;
  end_date: string;
  created_at: string;
  is_active: boolean;
  participant_count?: number;
  status: 'active' | 'paused' | 'ended';
}

interface Participant {
  id: string;
  user_id: string;
  full_name: string;
  current_streak: number;
  best_streak: number;
  joined_at: string;
  last_completed: string;
  rank: number;
}

interface CompetitionWithParticipants extends Competition {
  participants: Participant[];
}

export const EnhancedAdminCompetitionManager = () => {
  const [competitions, setCompetitions] = useState<Competition[]>([]);
  const [selectedCompetition, setSelectedCompetition] = useState<CompetitionWithParticipants | null>(null);
  const [habits, setHabits] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [isViewOpen, setIsViewOpen] = useState(false);
  const [newCompetition, setNewCompetition] = useState({
    title: '',
    description: '',
    habit_name: '',
    start_date: new Date().toISOString().split('T')[0],
    end_date: '',
    duration_days: 30
  });

  useEffect(() => {
    let mounted = true;
    
    const loadData = async () => {
      if (mounted) {
        await fetchCompetitions();
        await fetchAvailableHabits();
      }
    };
    
    loadData();
    
    return () => {
      mounted = false;
    };
  }, []);

  const fetchCompetitions = async () => {
    try {
      const { data, error } = await supabase
        .from('streak_competitions')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;

      const competitionsWithCounts = await Promise.all(
        (data || []).map(async (comp) => {
          const { count } = await supabase
            .from('streak_competition_participants')
            .select('*', { count: 'exact' })
            .eq('competition_id', comp.id);

          const now = new Date();
          const endDate = new Date(comp.end_date);
          
          let status: 'active' | 'paused' | 'ended' = 'active';
          if (!comp.is_active) status = 'paused';
          else if (endDate < now) status = 'ended';

          return { 
            ...comp, 
            participant_count: count || 0,
            status
          };
        })
      );

      setCompetitions(competitionsWithCounts);
    } catch (error) {
      console.error('Error fetching competitions:', error);
      toast({
        title: "Error",
        description: "Failed to load competitions",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchAvailableHabits = async () => {
    try {
      const { data, error } = await supabase
        .from('habits')
        .select('title')
        .not('title', 'is', null);

      if (error) throw error;

      const uniqueHabits = [...new Set(data?.map(h => h.title) || [])];
      setHabits(uniqueHabits);
    } catch (error) {
      console.error('Error fetching habits:', error);
    }
  };

  const fetchCompetitionParticipants = async (competitionId: string) => {
    try {
      const competition = competitions.find(c => c.id === competitionId);
      if (!competition) return;

      const { data: participants, error: participantsError } = await supabase
        .from('streak_competition_participants')
        .select(`
          *,
          profile:profiles(full_name)
        `)
        .eq('competition_id', competitionId);

      if (participantsError) throw participantsError;

      const participantsWithStreaks = await Promise.all(
        (participants || []).map(async (p) => {
          try {
            const { data: streakData, error: streakError } = await supabase
              .rpc('calculate_habit_streak', {
                p_user_id: p.user_id,
                p_habit_name: competition.habit_name
              });

            if (streakError) {
              console.warn('Error calculating streak for user:', p.user_id, streakError);
            }

            return {
              id: p.id,
              user_id: p.user_id,
              full_name: p.profile?.full_name || 'Anonymous',
              current_streak: streakData || 0,
              best_streak: p.best_streak || 0,
              joined_at: p.joined_at,
              last_completed: p.last_completed,
              rank: 0
            };
          } catch (streakError) {
            console.warn('Failed to calculate streak for user:', p.user_id, streakError);
            return {
              id: p.id,
              user_id: p.user_id,
              full_name: p.profile?.full_name || 'Anonymous',
              current_streak: 0,
              best_streak: p.best_streak || 0,
              joined_at: p.joined_at,
              last_completed: p.last_completed,
              rank: 0
            };
          }
        })
      );

      const rankedParticipants = participantsWithStreaks
        .sort((a, b) => b.current_streak - a.current_streak)
        .map((p, index) => ({ ...p, rank: index + 1 }));

      setSelectedCompetition({
        ...competition,
        participants: rankedParticipants
      });
      setIsViewOpen(true);
    } catch (error) {
      console.error('Error fetching participants:', error);
      toast({
        title: "Error",
        description: "Failed to load participants",
        variant: "destructive"
      });
    }
  };

  const createCompetition = async () => {
    if (!newCompetition.title || !newCompetition.habit_name || !newCompetition.end_date) {
      toast({
        title: "Error",
        description: "Please fill in all required fields",
        variant: "destructive"
      });
      return;
    }

    try {
      const { error } = await supabase
        .from('streak_competitions')
        .insert({
          title: newCompetition.title,
          description: newCompetition.description,
          habit_name: newCompetition.habit_name,
          start_date: newCompetition.start_date,
          end_date: newCompetition.end_date,
          is_active: true
        });

      if (error) throw error;

      toast({
        title: "Success",
        description: "Competition created successfully!"
      });

      setIsCreateOpen(false);
      setNewCompetition({ 
        title: '',
        description: '',
        habit_name: '', 
        start_date: new Date().toISOString().split('T')[0],
        end_date: '', 
        duration_days: 30 
      });
      fetchCompetitions();
    } catch (error) {
      console.error('Error creating competition:', error);
      toast({
        title: "Error",
        description: "Failed to create competition",
        variant: "destructive"
      });
    }
  };

  const toggleCompetitionStatus = async (id: string, currentStatus: boolean) => {
    try {
      const { error } = await supabase
        .from('streak_competitions')
        .update({ is_active: !currentStatus })
        .eq('id', id);

      if (error) throw error;

      toast({
        title: "Success",
        description: `Competition ${!currentStatus ? 'resumed' : 'paused'} successfully`
      });

      fetchCompetitions();
    } catch (error) {
      console.error('Error updating competition:', error);
      toast({
        title: "Error",
        description: "Failed to update competition status",
        variant: "destructive"
      });
    }
  };

  const endCompetition = async (id: string) => {
    if (!confirm('Are you sure you want to end this competition? This action cannot be undone.')) return;

    try {
      const { error } = await supabase
        .from('streak_competitions')
        .update({ 
          is_active: false,
          end_date: new Date().toISOString()
        })
        .eq('id', id);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Competition ended successfully"
      });

      fetchCompetitions();
    } catch (error) {
      console.error('Error ending competition:', error);
      toast({
        title: "Error",
        description: "Failed to end competition",
        variant: "destructive"
      });
    }
  };

  const deleteCompetition = async (id: string) => {
    if (!confirm('Are you sure you want to delete this competition?')) return;

    try {
      await supabase
        .from('streak_competition_participants')
        .delete()
        .eq('competition_id', id);

      const { error } = await supabase
        .from('streak_competitions')
        .delete()
        .eq('id', id);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Competition deleted successfully"
      });

      fetchCompetitions();
    } catch (error) {
      console.error('Error deleting competition:', error);
      toast({
        title: "Error",
        description: "Failed to delete competition",
        variant: "destructive"
      });
    }
  };

  const getEndDate = (days: number) => {
    const date = new Date();
    date.setDate(date.getDate() + days);
    return date.toISOString().split('T')[0];
  };

  if (loading) {
    return <div className="text-center p-8">Loading competitions...</div>;
  }

  return (
    <AdminCompetitionUI
      competitions={competitions}
      habits={habits}
      loading={loading}
      isCreateOpen={isCreateOpen}
      setIsCreateOpen={setIsCreateOpen}
      isViewOpen={isViewOpen}
      setIsViewOpen={setIsViewOpen}
      selectedCompetition={selectedCompetition}
      newCompetition={newCompetition}
      setNewCompetition={setNewCompetition}
      onCreateCompetition={createCompetition}
      onToggleStatus={toggleCompetitionStatus}
      onEndCompetition={endCompetition}
      onDeleteCompetition={deleteCompetition}
      onViewParticipants={fetchCompetitionParticipants}
      getEndDate={getEndDate}
    />
  );
};

export default EnhancedAdminCompetitionManager;