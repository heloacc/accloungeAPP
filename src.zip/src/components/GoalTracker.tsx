import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Target, Plus, CheckCircle2, Circle, Calendar, Trash2, X } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import AsyncErrorBoundary from '@/components/AsyncErrorBoundary';

interface Goal {
  id: string;
  title: string;
  description?: string;
  target_value: number;
  current_value: number;
  unit: string;
  category: string;
  deadline?: string;
  completed: boolean;
  created_at: string;
  updated_at: string;
}

interface GoalTask {
  id: string;
  goal_id: string;
  title: string;
  description?: string;
  frequency: 'daily' | 'weekly' | 'monthly' | 'one-time';
  completed: boolean;
  completed_at?: string;
  created_at: string;
}

const GoalTracker = () => {
  const [goals, setGoals] = useState<Goal[]>([]);
  const [goalTasks, setGoalTasks] = useState<{ [goalId: string]: GoalTask[] }>({});
  const [loading, setLoading] = useState(true);
  const [isAddingGoal, setIsAddingGoal] = useState(false);
  const [selectedGoalForTasks, setSelectedGoalForTasks] = useState<string | null>(null);
  const [newGoal, setNewGoal] = useState({
    title: '',
    description: '',
    category: 'personal',
    deadline: ''
  });
  const [newTask, setNewTask] = useState({
    title: '',
    description: '',
    frequency: 'daily' as 'daily' | 'weekly' | 'monthly' | 'one-time'
  });

  useEffect(() => {
    fetchGoals();
  }, [fetchGoals]);

  const fetchGoals = useCallback(async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        console.log('No user found');
        return;
      }

      console.log('Fetching goals for user:', user.id);

      const { data, error } = await supabase
        .from('goals')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching goals:', error);
        throw error;
      }
      
      console.log('Goals data received:', data);
      setGoals(data || []);
      
      if (data && data.length > 0) {
        fetchGoalTasks(data.map(g => g.id));
      }
    } catch (error) {
      console.error('Error fetching goals:', error);
    } finally {
      setLoading(false);
    }
  }, []);

  const fetchGoalTasks = async (goalIds: string[]) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('goal_tasks')
        .select('*')
        .eq('user_id', user.id)
        .in('goal_id', goalIds)
        .order('created_at', { ascending: true });

      if (error) throw error;

      const tasksByGoal: { [goalId: string]: GoalTask[] } = {};
      const now = new Date();
      
      data?.forEach(task => {
        if (!tasksByGoal[task.goal_id]) {
          tasksByGoal[task.goal_id] = [];
        }
        
        const shouldReset = shouldTaskReset(task, now);
        const processedTask = {
          ...task,
          completed: shouldReset ? false : task.completed,
          completed_at: shouldReset ? null : task.completed_at
        };
        
        tasksByGoal[task.goal_id].push(processedTask);
      });
      
      setGoalTasks(tasksByGoal);
    } catch (error) {
      console.error('Error fetching goal tasks:', error);
    }
  };
  const shouldTaskReset = (task: GoalTask, now: Date) => {
    if (!task.completed_at) return false;
    
    const completedAt = new Date(task.completed_at);
    
    switch (task.frequency) {
      case 'daily':
        return completedAt.toDateString() !== now.toDateString();
      case 'weekly': {
        const weekStart = new Date(now);
        weekStart.setDate(now.getDate() - now.getDay() + 1);
        weekStart.setHours(0, 0, 0, 0);
        return completedAt < weekStart;
      }
      case 'monthly':
        return completedAt.getMonth() !== now.getMonth() || completedAt.getFullYear() !== now.getFullYear();
      default:
        return false;
    }
  };

  const addGoal = async () => {
    if (!newGoal.title.trim()) return;

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const goalData = {
        user_id: user.id,
        title: newGoal.title.trim(),
        description: newGoal.description.trim() || null,
        target_value: 100,
        current_value: 0,
        unit: '%',
        category: newGoal.category,
        deadline: newGoal.deadline || null,
        completed: false
      };

      const { error } = await supabase
        .from('goals')
        .insert([goalData]);

      if (error) throw error;

      setNewGoal({
        title: '',
        description: '',
        category: 'personal',
        deadline: ''
      });
      setIsAddingGoal(false);
      fetchGoals();
    } catch (error) {
      console.error('Error adding goal:', error);
      alert('Failed to create goal. Please try again.');
    }
  };

  const addTask = async () => {
    if (!newTask.title.trim() || !selectedGoalForTasks) return;

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const taskData = {
        goal_id: selectedGoalForTasks,
        user_id: user.id,
        title: newTask.title.trim(),
        description: newTask.description.trim() || null,
        frequency: newTask.frequency,
        completed: false
      };

      const { error } = await supabase
        .from('goal_tasks')
        .insert([taskData]);

      if (error) throw error;

      setNewTask({
        title: '',
        description: '',
        frequency: 'daily'
      });
      setSelectedGoalForTasks(null);
      fetchGoals();
    } catch (error) {
      console.error('Error adding task:', error);
      alert('Failed to add task. Please try again.');
    }
  };

  const toggleTask = async (taskId: string, completed: boolean) => {
    try {
      const { error } = await supabase
        .from('goal_tasks')
        .update({
          completed,
          completed_at: completed ? new Date().toISOString() : null
        })
        .eq('id', taskId);

      if (error) throw error;

      
      // Update local state immediately for better UX
      setGoalTasks(prevTasks => {
        const updatedTasks = { ...prevTasks };
        Object.keys(updatedTasks).forEach(goalId => {
          updatedTasks[goalId] = updatedTasks[goalId].map(task => 
            task.id === taskId 
              ? { ...task, completed, completed_at: completed ? new Date().toISOString() : null }
              : task
          );
        });
        return updatedTasks;
      });
      
      await updateGoalProgress();
    } catch (error) {
      console.error('Error toggling task:', error);
      alert('Failed to update task. Please try again.');
    }
  };

  const deleteTask = async (taskId: string) => {
    if (!confirm('Are you sure you want to delete this task?')) return;

    try {
      const { error } = await supabase
        .from('goal_tasks')
        .delete()
        .eq('id', taskId);

      if (error) throw error;
      fetchGoals();
    } catch (error) {
      console.error('Error deleting task:', error);
      alert('Failed to delete task. Please try again.');
    }
  };

  const updateGoalProgress = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      for (const goal of goals) {
        const tasks = goalTasks[goal.id] || [];
        if (tasks.length === 0) continue;

        // Count all completed tasks regardless of frequency type
        let completedTasks = 0;

        tasks.forEach(task => {
          if (task.completed) {
            completedTasks++;
          }
        });

        const progress = Math.round((completedTasks / tasks.length) * 100);
        const isCompleted = progress === 100;

        await supabase
          .from('goals')
          .update({
            current_value: progress,
            completed: isCompleted
          })
          .eq('id', goal.id);
      }
    } catch (error) {
      console.error('Error updating goal progress:', error);
    }
  };

  const deleteGoal = async (goalId: string) => {
    if (!confirm('Are you sure you want to delete this goal? This will also delete all associated tasks.')) {
      return;
    }

    try {
      const { error } = await supabase
        .from('goals')
        .delete()
        .eq('id', goalId);

      if (error) throw error;
      fetchGoals();
    } catch (error) {
      console.error('Error deleting goal:', error);
      alert('Failed to delete goal. Please try again.');
    }
  };

  const getCategoryColor = (category: string) => {
    const colors: { [key: string]: string } = {
      'health': 'bg-green-100 text-green-800',
      'career': 'bg-blue-100 text-blue-800',
      'personal': 'bg-purple-100 text-purple-800',
      'finance': 'bg-yellow-100 text-yellow-800',
      'learning': 'bg-orange-100 text-orange-800'
    };
    return colors[category] || 'bg-gray-100 text-gray-800';
  };

  const getFrequencyColor = (frequency: string) => {
    const colors: { [key: string]: string } = {
      'daily': 'bg-blue-50 text-blue-700 border-blue-200',
      'weekly': 'bg-green-50 text-green-700 border-green-200',
      'monthly': 'bg-purple-50 text-purple-700 border-purple-200'
    };
    return colors[frequency] || 'bg-gray-50 text-gray-700 border-gray-200';
  };

  if (loading) {
    return <div className="p-6">Loading goals...</div>;
  }
  return (
    <AsyncErrorBoundary componentName="Goal Tracker">
      <div className="space-y-6 p-6">
        <div className="flex justify-between items-center">
          <div>
            <h2 className="text-2xl font-bold">Goal Tracker</h2>
            <p className="text-muted-foreground">Break down goals into actionable tasks</p>
          </div>
          <Button 
            onClick={() => setIsAddingGoal(true)}
            className="bg-black text-white hover:bg-gray-800 font-semibold px-6 py-3"
          >
            <Plus className="h-4 w-4 mr-2" />
            Add Goal
          </Button>
        </div>

        {/* Add Goal Form */}
        {isAddingGoal && (
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                Add New Goal
                <Button variant="ghost" size="sm" onClick={() => setIsAddingGoal(false)}>
                  <X className="h-4 w-4" />
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Input
                placeholder="Goal title"
                value={newGoal.title}
                onChange={(e) => setNewGoal({...newGoal, title: e.target.value})}
              />
              <Textarea
                placeholder="Goal description (optional)"
                value={newGoal.description}
                onChange={(e) => setNewGoal({...newGoal, description: e.target.value})}
              />
              <Select value={newGoal.category} onValueChange={(value) => setNewGoal({...newGoal, category: value})}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="personal">Personal</SelectItem>
                  <SelectItem value="health">Health</SelectItem>
                  <SelectItem value="career">Career</SelectItem>
                  <SelectItem value="finance">Finance</SelectItem>
                  <SelectItem value="learning">Learning</SelectItem>
                </SelectContent>
              </Select>
              <Input
                type="date"
                value={newGoal.deadline}
                onChange={(e) => setNewGoal({...newGoal, deadline: e.target.value})}
              />
              <div className="flex gap-2">
                <Button onClick={addGoal} className="bg-black text-white hover:bg-gray-800">
                  Create Goal
                </Button>
                <Button variant="outline" onClick={() => setIsAddingGoal(false)}>
                  Cancel
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Add Task Form */}
        {selectedGoalForTasks && (
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                Add Task
                <Button variant="ghost" size="sm" onClick={() => setSelectedGoalForTasks(null)}>
                  <X className="h-4 w-4" />
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Input
                placeholder="Task title"
                value={newTask.title}
                onChange={(e) => setNewTask({...newTask, title: e.target.value})}
              />
              <Textarea
                placeholder="Task description (optional)"
                value={newTask.description}
                onChange={(e) => setNewTask({...newTask, description: e.target.value})}
              />
              <Select value={newTask.frequency} onValueChange={(value: 'daily' | 'weekly' | 'monthly' | 'one-time') => setNewTask({...newTask, frequency: value})}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="daily">Daily</SelectItem>
                  <SelectItem value="weekly">Weekly</SelectItem>
                  <SelectItem value="monthly">Monthly</SelectItem>
                  <SelectItem value="one-time">One-time</SelectItem>
                </SelectContent>
              </Select>
              <div className="flex gap-2">
                <Button onClick={addTask} className="bg-black text-white hover:bg-gray-800">
                  Add Task
                </Button>
                <Button variant="outline" onClick={() => setSelectedGoalForTasks(null)}>
                  Cancel
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {goals.length === 0 ? (
          <div className="flex items-center justify-center py-12">
            <div className="text-center">
              <Target className="h-16 w-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">No goals yet</h3>
              <p className="text-gray-500 mb-6 max-w-sm">
                Create goals and break them down into daily, weekly, or monthly tasks.
              </p>
              <Button onClick={() => setIsAddingGoal(true)} className="bg-black text-white hover:bg-gray-800">
                <Plus className="h-4 w-4 mr-2" />
                Create Your First Goal
              </Button>
            </div>
          </div>
        ) : (
          <div className="grid gap-6">
            {goals.map((goal) => {
              const tasks = goalTasks[goal.id] || [];
              const now = new Date();
              
              let completedTasks = 0;
              tasks.forEach(task => {
                if (task.frequency === 'daily') {
                  if (task.completed && task.completed_at) {
                    const completedAt = new Date(task.completed_at);
                    if (completedAt.toDateString() === now.toDateString()) {
                      completedTasks++;
                    }
                  }
                } else {
                  if (task.completed) {
                    completedTasks++;
                  }
                }
              });
              
              const progress = tasks.length > 0 ? (completedTasks / tasks.length) * 100 : 0;

              return (
                <Card key={goal.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div className="space-y-2 flex-1">
                        <CardTitle className="flex items-center gap-2">
                          <Target className="h-5 w-5" />
                          {goal.title}
                        </CardTitle>
                        {goal.description && (
                          <p className="text-muted-foreground">{goal.description}</p>
                        )}
                        <div className="flex gap-2 flex-wrap">
                          <Badge className={getCategoryColor(goal.category)}>
                            {goal.category}
                          </Badge>
                          {goal.deadline && (
                            <Badge variant="outline" className="flex items-center gap-1">
                              <Calendar className="h-3 w-3" />
                              {new Date(goal.deadline).toLocaleDateString()}
                            </Badge>
                          )}
                          {goal.completed && (
                            <Badge className="bg-green-100 text-green-800">Completed</Badge>
                          )}
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setSelectedGoalForTasks(goal.id)}
                          className="text-blue-600 hover:text-blue-800"
                        >
                          <Plus className="h-4 w-4 mr-1" />
                          Add Task
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => deleteGoal(goal.id)}
                          className="text-red-600 hover:text-red-800"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Progress</span>
                        <span>{completedTasks}/{tasks.length} tasks completed</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-black h-2 rounded-full" 
                          style={{ width: `${Math.min(progress, 100)}%` }}
                        ></div>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {tasks.length > 0 && (
                        <div className="space-y-2">
                          <h4 className="font-medium text-sm">Tasks:</h4>
                          {tasks.map((task) => (
                            <div key={task.id} className="flex items-center gap-3 p-2 rounded-lg bg-gray-50">
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => toggleTask(task.id, !task.completed)}
                                className="p-1 h-auto hover:bg-gray-200"
                                title={task.completed ? "Mark as incomplete" : "Mark as complete"}
                              >
                                {task.completed ? (
                                  <CheckCircle2 className="h-5 w-5 text-green-600" />
                                ) : (
                                  <Circle className="h-5 w-5 text-gray-400 hover:text-gray-600" />
                                )}
                              </Button>
                              <div className="flex-1">
                                <div className="flex items-center gap-2">
                                  <span className={`text-sm ${task.completed ? 'line-through text-gray-500' : ''}`}>
                                    {task.title}
                                  </span>
                                  <Badge variant="outline" className={`text-xs ${getFrequencyColor(task.frequency)}`}>
                                    {task.frequency}
                                  </Badge>
                                </div>
                                {task.description && (
                                  <p className="text-xs text-gray-500 mt-1">{task.description}</p>
                                )}
                              </div>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => deleteTask(task.id)}
                                className="p-1 h-auto text-red-500 hover:text-red-700 hover:bg-red-50"
                                title="Delete task"
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </div>
    </AsyncErrorBoundary>
  );
};

export default GoalTracker;