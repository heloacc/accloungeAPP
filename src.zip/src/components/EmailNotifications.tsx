import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Mail, Send, Users, User } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabase';

const EmailNotifications = () => {
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [recipient, setRecipient] = useState('all');
  const [specificEmail, setSpecificEmail] = useState('');
  const [loading, setLoading] = useState(false);

  const sendEmailNotification = async () => {
    if (!subject.trim() || !message.trim()) {
      toast({
        title: "Validation Error",
        description: "Please fill in subject and message fields.",
        variant: "destructive"
      });
      return;
    }

    if (recipient === 'specific' && !specificEmail.trim()) {
      toast({
        title: "Validation Error",
        description: "Please enter a specific email address.",
        variant: "destructive"
      });
      return;
    }

    setLoading(true);
    try {
      // Get recipients based on type
      let recipients = [];
      if (recipient === 'all') {
        const { data } = await supabase
          .from('profiles')
          .select('email')
          .not('email', 'is', null);
        recipients = data?.map(p => p.email) || [];
      } else if (recipient === 'active') {
        const thirtyDaysAgo = new Date();
        thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
        
        const { data } = await supabase
          .from('profiles')
          .select('email')
          .not('email', 'is', null)
          .gte('last_seen', thirtyDaysAgo.toISOString());
        recipients = data?.map(p => p.email) || [];
      } else if (recipient === 'specific') {
        recipients = [specificEmail.trim()];
      }

      // For now, just log the email sending (would need actual email service)
      console.log('Would send email to:', recipients);
      console.log('Subject:', subject);
      console.log('Message:', message);

      toast({
        title: "Email Notification Queued",
        description: `Email notification queued for ${recipients.length} recipient(s). (Email service integration needed for actual sending)`,
      });

      setSubject('');
      setMessage('');
      setSpecificEmail('');
      setRecipient('all');
    } catch (error) {
      console.error('Error preparing email notification:', error);
      toast({
        title: "Error",
        description: "Failed to prepare email notification. Please try again.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Mail className="h-5 w-5" />
            Send Email Notification
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="text-sm font-medium mb-2 block">Recipients</label>
            <Select value={recipient} onValueChange={setRecipient}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">
                  <div className="flex items-center gap-2">
                    <Users className="h-4 w-4" />
                    All Users
                  </div>
                </SelectItem>
                <SelectItem value="active">
                  <div className="flex items-center gap-2">
                    <Users className="h-4 w-4" />
                    Active Users (Last 30 days)
                  </div>
                </SelectItem>
                <SelectItem value="specific">
                  <div className="flex items-center gap-2">
                    <User className="h-4 w-4" />
                    Specific Email
                  </div>
                </SelectItem>
              </SelectContent>
            </Select>
          </div>

          {recipient === 'specific' && (
            <div>
              <label className="text-sm font-medium mb-2 block">Email Address</label>
              <Input
                type="email"
                value={specificEmail}
                onChange={(e) => setSpecificEmail(e.target.value)}
                placeholder="user@example.com"
              />
            </div>
          )}

          <div>
            <label className="text-sm font-medium mb-2 block">Subject</label>
            <Input
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              placeholder="Enter email subject..."
              maxLength={200}
            />
          </div>

          <div>
            <label className="text-sm font-medium mb-2 block">Message</label>
            <Textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Enter your email message..."
              rows={6}
              maxLength={2000}
            />
            <p className="text-xs text-muted-foreground mt-1">
              {message.length}/2000 characters
            </p>
          </div>

          <Button 
            onClick={sendEmailNotification} 
            disabled={loading}
            className="w-full bg-black text-white hover:bg-gray-800"
          >
            <Send className="h-4 w-4 mr-2" />
            {loading ? 'Sending...' : 'Send Email Notification'}
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Email Notification Guidelines</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3 text-sm">
            <div className="flex items-start gap-2">
              <Badge variant="outline" className="mt-0.5">Tip</Badge>
              <p>Keep subject lines clear and actionable for better open rates.</p>
            </div>
            <div className="flex items-start gap-2">
              <Badge variant="outline" className="mt-0.5">Note</Badge>
              <p>Email notifications are sent using Resend API and may take a few minutes to deliver.</p>
            </div>
            <div className="flex items-start gap-2">
              <Badge variant="outline" className="mt-0.5">Limit</Badge>
              <p>Avoid sending too many emails to prevent being marked as spam.</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default EmailNotifications;