import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useAppContext } from '@/contexts/OptimizedAppContext';
import { toast } from '@/components/ui/use-toast';

const SessionManager = ({ children }: { children: React.ReactNode }) => {
  const { setCurrentUser, setIsLoading } = useAppContext();
  const [sessionChecked, setSessionChecked] = useState(false);

  useEffect(() => {
    let mounted = true;
    let refreshTimer: NodeJS.Timeout | undefined;

    const handleSession = async () => {
      try {
        setIsLoading(true);
        
        // Get current session
        const { data: { session }, error } = await supabase.auth.getSession();
        
        if (error) {
          console.error('Session error:', error);
          if (mounted) {
            setCurrentUser(null);
            setSessionChecked(true);
            setIsLoading(false);
          }
          return;
        }

        if (session?.user) {
          if (mounted) {
            setCurrentUser({
              id: session.user.id,
              email: session.user.email || '',
              isAdmin: false // Will be updated by context
            });
          }
          
          // Set up token refresh
          const expiresAt = session.expires_at;
          if (expiresAt) {
            const now = Math.floor(Date.now() / 1000);
            const timeUntilExpiry = (expiresAt - now - 300) * 1000; // Refresh 5 minutes before expiry
            
            if (timeUntilExpiry > 0) {
              refreshTimer = setTimeout(async () => {
                try {
                  const { error: refreshError } = await supabase.auth.refreshSession();
                  if (refreshError) {
                    console.error('Token refresh failed:', refreshError);
                    if (mounted) {
                      setCurrentUser(null);
                      toast({
                        title: "Session Expired",
                        description: "Please log in again.",
                        variant: "destructive"
                      });
                    }
                  }
                } catch (err) {
                  console.error('Refresh error:', err);
                }
              }, timeUntilExpiry);
            }
          }
        } else {
          if (mounted) {
            setCurrentUser(null);
          }
        }
      } catch (err) {
        console.error('Session handling error:', err);
        if (mounted) {
          setCurrentUser(null);
        }
      } finally {
        if (mounted) {
          setSessionChecked(true);
          setIsLoading(false);
        }
      }
    };

    // Listen for auth state changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (!mounted) return;

      console.log('Auth state change:', event);
      
      if (event === 'SIGNED_IN' && session?.user) {
        setCurrentUser({
          id: session.user.id,
          email: session.user.email || '',
          isAdmin: false
        });
        setIsLoading(false);
      } else if (event === 'SIGNED_OUT') {
        setCurrentUser(null);
        setIsLoading(false);
        // Clear any refresh timers
        if (refreshTimer) {
          clearTimeout(refreshTimer);
        }
      } else if (event === 'TOKEN_REFRESHED' && session?.user) {
        // Session refreshed successfully
        console.log('Token refreshed successfully');
      }
    });

    // Initial session check
    handleSession();

    return () => {
      mounted = false;
      subscription.unsubscribe();
      if (refreshTimer) {
        clearTimeout(refreshTimer);
      }
    };
  }, [setCurrentUser, setIsLoading]);

  // Show loading until session is checked
  if (!sessionChecked) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Checking session...</p>
        </div>
      </div>
    );
  }

  return <>{children}</>;
};

export default SessionManager;