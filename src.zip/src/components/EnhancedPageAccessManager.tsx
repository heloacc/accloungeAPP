import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Trash2, Plus, Lock, Shield } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { toast } from '@/components/ui/use-toast';

interface PageAccessRule {
  id: string;
  page_path: string;
  required_plan_id: string | null;
  is_premium_only: boolean;
  minimum_tier: string;
  created_at: string;
  updated_at: string;
}

interface SubscriptionTier {
  id: string;
  name: string;
  price_monthly: string;
  is_active: boolean;
}

const EnhancedPageAccessManager: React.FC = () => {
  const [rules, setRules] = useState<PageAccessRule[]>([]);
  const [tiers, setTiers] = useState<SubscriptionTier[]>([]);
  const [loading, setLoading] = useState(false);
  const [newRule, setNewRule] = useState({
    page_path: '',
    minimum_tier: 'free',
    required_plan_id: null as string | null
  });

  const loadRules = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('page_access_rules')
        .select('*')
        .order('page_path');

      if (error) throw error;
      setRules(data || []);
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const loadTiers = async () => {
    try {
      const { data, error } = await supabase
        .from('subscription_tiers')
        .select('id, name, price_monthly, is_active')
        .eq('is_active', true)
        .order('price_monthly');

      if (error) throw error;
      setTiers(data || []);
    } catch (error: any) {
      console.error('Error loading tiers:', error);
    }
  };

  const addRule = async () => {
    if (!newRule.page_path.trim()) {
      toast({
        title: "Error",
        description: "Page path is required",
        variant: "destructive"
      });
      return;
    }

    try {
      const { error } = await supabase
        .from('page_access_rules')
        .insert([{
          page_path: newRule.page_path.trim(),
          minimum_tier: newRule.minimum_tier,
          required_plan_id: newRule.required_plan_id,
          is_premium_only: newRule.minimum_tier !== 'free'
        }]);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Page access rule added"
      });

      setNewRule({
        page_path: '',
        minimum_tier: 'free',
        required_plan_id: null
      });

      loadRules();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    }
  };

  const deleteRule = async (id: string) => {
    try {
      const { error } = await supabase
        .from('page_access_rules')
        .delete()
        .eq('id', id);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Page access rule deleted"
      });

      loadRules();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    }
  };

  const getTierName = (tierId: string | null) => {
    if (!tierId) return 'Any Active Plan';
    const tier = tiers.find(t => t.id === tierId);
    return tier?.name || 'Unknown Plan';
  };

  const getAccessBadgeColor = (rule: PageAccessRule) => {
    if (rule.minimum_tier === 'free') return 'secondary';
    if (rule.minimum_tier === 'premium') return 'default';
    if (rule.minimum_tier === 'pro') return 'destructive';
    return 'outline';
  };

  useEffect(() => {
    loadRules();
    loadTiers();
  }, []);

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Add Page Access Rule
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <Label htmlFor="page-path">Page Path</Label>
              <Input
                id="page-path"
                placeholder="/analytics, /premium-features, /pro-dashboard"
                value={newRule.page_path}
                onChange={(e) => setNewRule({ ...newRule, page_path: e.target.value })}
              />
            </div>
            
            <div>
              <Label htmlFor="minimum-tier">Minimum Tier Required</Label>
              <Select 
                value={newRule.minimum_tier} 
                onValueChange={(value) => setNewRule({ ...newRule, minimum_tier: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="free">Free Access</SelectItem>
                  <SelectItem value="premium">Premium Required</SelectItem>
                  <SelectItem value="pro">Pro Required</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {newRule.minimum_tier !== 'free' && (
              <div>
                <Label htmlFor="specific-plan">Specific Plan (Optional)</Label>
                <Select 
                  value={newRule.required_plan_id || 'any-active-plan'} 
                  onValueChange={(value) => setNewRule({ ...newRule, required_plan_id: value === 'any-active-plan' ? null : value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Any active plan" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="any-active-plan">Any Active Plan</SelectItem>
                    {tiers.map((tier) => (
                      <SelectItem key={tier.id} value={tier.id}>
                        {tier.name} (${tier.price_monthly}/mo)
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            <Button onClick={addRule} className="w-full">
              <Plus className="h-4 w-4 mr-2" />
              Add Access Rule
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Current Page Access Rules</CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center py-4">Loading...</div>
          ) : rules.length === 0 ? (
            <div className="text-center py-4 text-muted-foreground">
              No page access rules configured
            </div>
          ) : (
            <div className="space-y-3">
              {rules.map((rule) => (
                <div key={rule.id} className="flex items-center justify-between p-4 border rounded-lg">
                  <div>
                    <h3 className="font-medium flex items-center gap-2">
                      <Lock className="h-4 w-4" />
                      {rule.page_path}
                    </h3>
                    <div className="flex items-center gap-2 mt-2">
                      <Badge variant={getAccessBadgeColor(rule)}>
                        {rule.minimum_tier === 'free' ? 'Free Access' : 
                         rule.minimum_tier === 'premium' ? 'Premium Required' : 'Pro Required'}
                      </Badge>
                      {rule.required_plan_id && (
                        <Badge variant="outline">
                          {getTierName(rule.required_plan_id)}
                        </Badge>
                      )}
                    </div>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => deleteRule(rule.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default EnhancedPageAccessManager;