import React from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { GatherFeed } from './GatherFeed';
import { WinsWall } from './WinsWall';
import EnhancedCommunityFeed from './EnhancedCommunityFeed';

const CommunityFeedTabs: React.FC<{ onNavigate?: (tab: string) => void }> = ({ onNavigate }) => {
  return (
    <div className="w-full max-w-none mx-auto p-2 sm:p-4">
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-xl sm:text-2xl">Community Hub</CardTitle>
        </CardHeader>
        <CardContent className="px-2 sm:px-6">
          <Tabs defaultValue="gather" className="w-full">
            <TabsList className="grid w-full grid-cols-3 gap-1 h-auto p-1">
              <TabsTrigger 
                value="gather" 
                className="text-xs sm:text-sm px-2 py-2 sm:px-4 sm:py-2"
              >
                Gather
              </TabsTrigger>
              <TabsTrigger 
                value="wins" 
                className="text-xs sm:text-sm px-2 py-2 sm:px-4 sm:py-2"
              >
                Wins Wall
              </TabsTrigger>
              <TabsTrigger 
                value="community" 
                className="text-xs sm:text-sm px-2 py-2 sm:px-4 sm:py-2"
              >
                Community
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="gather" className="mt-4 sm:mt-6">
              <GatherFeed />
            </TabsContent>
            
            <TabsContent value="wins" className="mt-4 sm:mt-6">
              <WinsWall />
            </TabsContent>
            
            <TabsContent value="community" className="mt-4 sm:mt-6">
              <EnhancedCommunityFeed />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export { CommunityFeedTabs };
export default CommunityFeedTabs;