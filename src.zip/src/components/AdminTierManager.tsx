import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Plus, Edit, ExternalLink } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';

interface Tier {
  id: string;
  name: string;
  description: string;
  stripe_product_id: string;
  allowed_routes: string[];
  is_active: boolean;
  analytics_access: boolean;
}

export default function AdminTierManager() {
  const [tiers, setTiers] = useState<Tier[]>([]);
  const [isCreating, setIsCreating] = useState(false);
  const [editingTier, setEditingTier] = useState<Tier | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    stripe_product_id: '',
    allowed_routes: '',
    is_active: true,
    analytics_access: false
  });
  const { toast } = useToast();

  useEffect(() => {
    loadTiers();
  }, []);

  const loadTiers = async () => {
    try {
      const { data, error } = await supabase
        .from('subscription_tiers')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setTiers(data || []);
    } catch (error) {
      toast({
        title: "Error loading tiers",
        description: error instanceof Error ? error.message : "Unknown error",
        variant: "destructive"
      });
    }
  };

  const validateStripeProductId = (productId: string) => {
    return productId.startsWith('prod_') && productId.length > 5;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateStripeProductId(formData.stripe_product_id)) {
      toast({
        title: "Invalid Stripe Product ID",
        description: "Product ID must start with 'prod_' and be valid",
        variant: "destructive"
      });
      return;
    }

    try {
      const routes = formData.allowed_routes.split(',').map(r => r.trim()).filter(r => r);
      
      const tierData = {
        name: formData.name,
        description: formData.description,
        stripe_product_id: formData.stripe_product_id,
        allowed_routes: routes,
        is_active: formData.is_active,
        analytics_access: formData.analytics_access
      };

      if (editingTier) {
        const { error } = await supabase
          .from('subscription_tiers')
          .update(tierData)
          .eq('id', editingTier.id);
        
        if (error) throw error;
        toast({ title: "Tier updated successfully" });
      } else {
        const { error } = await supabase
          .from('subscription_tiers')
          .insert([tierData]);
        
        if (error) throw error;
        toast({ title: "Tier created successfully" });
      }

      setFormData({ name: '', description: '', stripe_product_id: '', allowed_routes: '', is_active: true, analytics_access: false });
      setIsCreating(false);
      setEditingTier(null);
      loadTiers();
    } catch (error) {
      toast({
        title: "Error saving tier",
        description: error instanceof Error ? error.message : "Unknown error",
        variant: "destructive"
      });
    }
  };

  const startEdit = (tier: Tier) => {
    setEditingTier(tier);
    setFormData({
      name: tier.name,
      description: tier.description,
      stripe_product_id: tier.stripe_product_id,
      allowed_routes: tier.allowed_routes.join(', '),
      is_active: tier.is_active,
      analytics_access: tier.analytics_access || false
    });
    setIsCreating(true);
  };

  return (
    <div className="space-y-6 p-4 max-w-7xl mx-auto">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <h2 className="text-2xl font-bold">Tier Management</h2>
        <Button onClick={() => setIsCreating(true)} className="flex items-center gap-2 w-full sm:w-auto">
          <Plus className="w-4 h-4" />
          Create Tier
        </Button>
      </div>

      {isCreating && (
        <Card>
          <CardHeader>
            <CardTitle>{editingTier ? 'Edit Tier' : 'Create New Tier'}</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="name">Tier Name</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  required
                />
              </div>
              
              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({...formData, description: e.target.value})}
                />
              </div>
              
              <div>
                <Label htmlFor="stripe_product_id">Stripe Product ID</Label>
                <Input
                  id="stripe_product_id"
                  value={formData.stripe_product_id}
                  onChange={(e) => setFormData({...formData, stripe_product_id: e.target.value})}
                  placeholder="prod_XXXXXXXXXX"
                  required
                />
                <p className="text-sm text-muted-foreground mt-1">
                  Create a Product in Stripe, add Prices (monthly/yearly), copy the Product ID (prod_XXX) and paste it here.
                  <a href="https://dashboard.stripe.com/products" target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 ml-2 text-blue-600 hover:underline">
                    Open Stripe Dashboard <ExternalLink className="w-3 h-3" />
                  </a>
                </p>
              </div>
              
              <div>
                <Label htmlFor="routes">Allowed Routes (comma-separated)</Label>
                <Input
                  id="routes"
                  value={formData.allowed_routes}
                  onChange={(e) => setFormData({...formData, allowed_routes: e.target.value})}
                  placeholder="/dashboard, /habits, /goals"
                />
                <p className="text-xs text-muted-foreground mt-1">
                  Note: /analytics route is reserved for admin users only
                </p>
              </div>
              <div className="flex items-center space-x-2">
                <Switch
                  id="active"
                  checked={formData.is_active}
                  onCheckedChange={(checked) => setFormData({...formData, is_active: checked})}
                />
                <Label htmlFor="active">Active</Label>
              </div>
              
              <div className="flex items-start space-x-2">
                <Switch
                  id="analytics"
                  checked={formData.analytics_access}
                  onCheckedChange={(checked) => setFormData({...formData, analytics_access: checked})}
                />
                <div>
                  <Label htmlFor="analytics">Analytics Access</Label>
                  <p className="text-sm text-muted-foreground">
                    Admin-level analytics including user metrics, engagement data, and platform statistics. Only enable for admin tiers.
                  </p>
                </div>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-2">
                <Button type="submit" className="w-full sm:w-auto">{editingTier ? 'Update' : 'Create'} Tier</Button>
                <Button type="button" variant="outline" className="w-full sm:w-auto" onClick={() => {
                  setIsCreating(false);
                  setEditingTier(null);
                  setFormData({ name: '', description: '', stripe_product_id: '', allowed_routes: '', is_active: true, analytics_access: false });
                }}>
                  Cancel
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      <div className="grid gap-4">
        {tiers.map((tier) => (
          <Card key={tier.id}>
            <CardContent className="p-4 sm:p-6">
               <div className="flex flex-col sm:flex-row justify-between items-start gap-4">
                 <div className="flex-1 w-full">
                   <div className="flex flex-wrap items-center gap-2 mb-2">
                     <h3 className="text-lg font-semibold">{tier.name}</h3>
                     <Badge variant={tier.is_active ? "default" : "secondary"}>
                       {tier.is_active ? "Active" : "Inactive"}
                     </Badge>
                     {tier.analytics_access && (
                       <Badge variant="destructive" className="text-xs">
                         Analytics Access
                       </Badge>
                     )}
                   </div>
                   <p className="text-muted-foreground mb-2">{tier.description}</p>
                   <p className="text-sm font-mono text-blue-600 mb-2 break-all">{tier.stripe_product_id}</p>
                   <div className="flex flex-wrap gap-1">
                     {tier.allowed_routes.map((route) => (
                       <Badge key={route} variant="outline" className="text-xs">
                         {route}
                       </Badge>
                     ))}
                   </div>
                 </div>
                <Button variant="outline" size="sm" onClick={() => startEdit(tier)} className="flex items-center gap-1 w-full sm:w-auto">
                  <Edit className="w-4 h-4" />
                  Edit
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}