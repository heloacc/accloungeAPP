import React from 'react';
import { Button } from '@/components/ui/button';
import { RefreshCw } from 'lucide-react';
import { useUserTier } from '@/hooks/useUserTier';
import { useToast } from '@/hooks/use-toast';

export default function TierRefreshButton() {
  const { refreshTier, loading } = useUserTier();
  const { toast } = useToast();

  const handleRefresh = async () => {
    try {
      await refreshTier();
      toast({
        title: "Tier Refreshed",
        description: "Your subscription tier has been updated.",
      });
    } catch (error) {
      toast({
        title: "Refresh Failed",
        description: "Could not refresh tier. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <Button
      variant="outline"
      size="sm"
      onClick={handleRefresh}
      disabled={loading}
      className="gap-2"
    >
      <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
      Refresh Tier
    </Button>
  );
}