import { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { EnhancedPWAPrompt } from './EnhancedPWAPrompt';
import { CheckCircle, ArrowRight } from 'lucide-react';

interface OnboardingPWAStepProps {
  onNext: () => void;
  onSkip: () => void;
}

export function OnboardingPWAStep({ onNext, onSkip }: OnboardingPWAStepProps) {
  const [installed, setInstalled] = useState(false);

  const handleInstall = () => {
    setInstalled(true);
    // Auto-advance after successful install
    setTimeout(() => {
      onNext();
    }, 2000);
  };

  const handleSkip = () => {
    onSkip();
  };

  return (
    <div className="max-w-2xl mx-auto p-6">
      <Card>
        <CardHeader className="text-center">
          <CardTitle className="text-2xl">Get the Full Experience</CardTitle>
          <p className="text-muted-foreground">
            Install ACCLOUNGE as an app for the best accountability experience
          </p>
        </CardHeader>
        <CardContent className="space-y-6">
          {installed ? (
            <div className="text-center py-8">
              <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-green-700">App Installed Successfully!</h3>
              <p className="text-muted-foreground mt-2">
                You can now access ACCLOUNGE from your home screen or applications.
              </p>
            </div>
          ) : (
            <>
              <EnhancedPWAPrompt 
                showOnLoad={false}
                showInOnboarding={true}
                onInstall={handleInstall}
              />
              
              <div className="bg-muted/50 rounded-lg p-4">
                <h4 className="font-medium mb-2">Why install the app?</h4>
                <ul className="space-y-1 text-sm text-muted-foreground">
                  <li>• Receive push notifications for accountability check-ins</li>
                  <li>• Access your goals and habits even when offline</li>
                  <li>• Faster loading and smoother performance</li>
                  <li>• Quick access from your home screen or desktop</li>
                </ul>
              </div>
            </>
          )}

          <div className="flex gap-3 pt-4">
            {!installed && (
              <Button variant="outline" onClick={handleSkip} className="flex-1">
                Skip for Now
              </Button>
            )}
            <Button 
              onClick={onNext} 
              className={`${installed ? 'w-full' : 'flex-1'}`}
              disabled={!installed}
            >
              Continue
              <ArrowRight className="h-4 w-4 ml-2" />
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}