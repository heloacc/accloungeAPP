import React from 'react';
import { Button } from '@/components/ui/button';
import { Pin, Trash2 } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { toast } from '@/components/ui/use-toast';

interface PostActionsProps {
  post: any;
  isAdmin: boolean;
  isModerator: boolean;
  onPostUpdate?: (updatedPost: any) => void;
  onPostDelete?: (postId: string) => void;
  table?: 'posts' | 'group_posts';
}

const PostActions: React.FC<PostActionsProps> = ({ 
  post, 
  isAdmin, 
  isModerator, 
  onPostUpdate, 
  onPostDelete,
  table = 'posts'
}) => {
  const canModerate = isAdmin || isModerator;

  const handlePin = async () => {
    try {
      const { error } = await supabase
        .from(table)
        .update({ is_pinned: !post.is_pinned })
        .eq('id', post.id);

      if (error) throw error;

      const updatedPost = { ...post, is_pinned: !post.is_pinned };
      onPostUpdate?.(updatedPost);
      
      toast({
        title: post.is_pinned ? 'Post unpinned' : 'Post pinned',
        description: post.is_pinned ? 'Post removed from top of feed' : 'Post pinned to top of feed'
      });
    } catch (error) {
      console.error('Error pinning post:', error);
      toast({
        title: 'Error',
        description: 'Failed to pin/unpin post',
        variant: 'destructive'
      });
    }
  };

  const handleDelete = async () => {
    try {
      let error;
      
      if (table === 'acircle_posts') {
        // For acircle_posts, use recovery_status
        const result = await supabase
          .from(table)
          .update({ recovery_status: 'deleted' })
          .eq('id', post.id);
        error = result.error;
      } else {
        // For other tables, use recovery_status or delete directly
        const result = await supabase
          .from(table)
          .update({ recovery_status: 'deleted' })
          .eq('id', post.id);
        error = result.error;
      }

      if (error) throw error;

      onPostDelete?.(post.id);
      
      toast({
        title: 'Post deleted',
        description: 'Post has been removed from the feed'
      });
    } catch (error) {
      console.error('Error deleting post:', error);
      toast({
        title: 'Error',
        description: 'Failed to delete post',
        variant: 'destructive'
      });
    }
  };

  if (!canModerate) return null;

  return (
    <div className="flex gap-2">
      <Button
        variant="ghost"
        size="sm"
        onClick={handlePin}
        className={post.is_pinned ? "text-blue-600" : ""}
      >
        <Pin className="h-4 w-4" />
        {post.is_pinned ? 'Unpin' : 'Pin'}
      </Button>

      {isAdmin && (
        <Button
          variant="ghost"
          size="sm"
          onClick={handleDelete}
          className="text-red-600 hover:text-red-800"
        >
          <Trash2 className="h-4 w-4" />
          Delete
        </Button>
      )}
    </div>
  );
};

export default PostActions;