import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { RefreshCw, Download, Upload, AlertTriangle, CheckCircle } from 'lucide-react';

interface DraftPost {
  id: string;
  content: string;
  category: string;
  timestamp: string;
  feedType: string;
}

const PostRecovery: React.FC = () => {
  const [drafts, setDrafts] = useState<DraftPost[]>([]);
  const [failedPosts, setFailedPosts] = useState<DraftPost[]>([]);
  const [recovering, setRecovering] = useState(false);
  const [backupStatus, setBackupStatus] = useState<string>('');

  useEffect(() => {
    loadLocalDrafts();
    loadFailedPosts();
  }, []);

  const loadLocalDrafts = () => {
    try {
      const savedDrafts = localStorage.getItem('post_drafts');
      if (savedDrafts) {
        setDrafts(JSON.parse(savedDrafts));
      }
    } catch (error) {
      console.error('Error loading drafts:', error);
    }
  };

  const loadFailedPosts = () => {
    try {
      const failed = localStorage.getItem('failed_posts');
      if (failed) {
        setFailedPosts(JSON.parse(failed));
      }
    } catch (error) {
      console.error('Error loading failed posts:', error);
    }
  };

  const recoverPost = async (post: DraftPost) => {
    setRecovering(true);
    try {
      const { error } = await supabase
        .from('posts')
        .insert([{
          content: post.content,
          category: post.category,
          author_name: 'Recovered User',
          likes: 0,
          comments: 0,
          is_intro_post: false
        }]);

      if (error) throw error;

      // Remove from failed posts
      const updatedFailed = failedPosts.filter(p => p.id !== post.id);
      setFailedPosts(updatedFailed);
      localStorage.setItem('failed_posts', JSON.stringify(updatedFailed));
      
      setBackupStatus('Post recovered successfully!');
    } catch (error) {
      console.error('Recovery failed:', error);
      setBackupStatus('Recovery failed. Post kept in backup.');
    } finally {
      setRecovering(false);
    }
  };

  const exportBackup = () => {
    const backup = {
      drafts,
      failedPosts,
      timestamp: new Date().toISOString()
    };
    
    const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `posts_backup_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const clearRecovered = () => {
    setFailedPosts([]);
    localStorage.removeItem('failed_posts');
    setBackupStatus('Cleared recovered posts');
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <RefreshCw className="h-5 w-5" />
            Post Recovery Center
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {backupStatus && (
            <Alert>
              <CheckCircle className="h-4 w-4" />
              <AlertDescription>{backupStatus}</AlertDescription>
            </Alert>
          )}

          <div className="flex gap-2">
            <Button onClick={exportBackup} variant="outline">
              <Download className="h-4 w-4 mr-2" />
              Export Backup
            </Button>
            <Button onClick={clearRecovered} variant="outline">
              Clear Recovered
            </Button>
          </div>

          {failedPosts.length > 0 && (
            <div className="space-y-2">
              <h3 className="font-semibold text-orange-600">Failed Posts ({failedPosts.length})</h3>
              {failedPosts.map(post => (
                <Card key={post.id} className="border-orange-200">
                  <CardContent className="p-3">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <Badge variant="outline" className="mb-2">{post.category}</Badge>
                        <p className="text-sm mb-2">{post.content.substring(0, 100)}...</p>
                        <p className="text-xs text-muted-foreground">{post.timestamp}</p>
                      </div>
                      <Button 
                        size="sm" 
                        onClick={() => recoverPost(post)}
                        disabled={recovering}
                      >
                        <Upload className="h-3 w-3 mr-1" />
                        Recover
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}

          {drafts.length > 0 && (
            <div className="space-y-2">
              <h3 className="font-semibold text-blue-600">Saved Drafts ({drafts.length})</h3>
              {drafts.map(draft => (
                <Card key={draft.id} className="border-blue-200">
                  <CardContent className="p-3">
                    <Badge variant="outline" className="mb-2">{draft.category}</Badge>
                    <p className="text-sm mb-2">{draft.content.substring(0, 100)}...</p>
                    <p className="text-xs text-muted-foreground">{draft.timestamp}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}

          {failedPosts.length === 0 && drafts.length === 0 && (
            <Alert>
              <CheckCircle className="h-4 w-4" />
              <AlertDescription>No posts need recovery. All posts are safely stored!</AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default PostRecovery;