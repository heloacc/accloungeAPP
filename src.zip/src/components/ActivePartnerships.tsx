import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Users, MessageCircle, UserX, Target, Calendar, Loader2 } from 'lucide-react';

interface Partnership {
  id: string;
  user1_id: string;
  user2_id: string;
  status: 'accepted';
  matched_goals: any[];
  created_at: string;
  updated_at: string;
  partner_profile?: {
    full_name: string;
    bio: string;
  };
}

interface ActivePartnershipsProps {
  onOpenChat?: (partnershipId: string, partnerName: string) => void;
}

export const ActivePartnerships: React.FC<ActivePartnershipsProps> = ({ onOpenChat }) => {
  const [partnerships, setPartnerships] = useState<Partnership[]>([]);
  const [loading, setLoading] = useState(true);
  const [endingId, setEndingId] = useState<string | null>(null);

  useEffect(() => {
    let isMounted = true;
    
    if (isMounted) {
      fetchActivePartnerships();
    }
    
    return () => {
      isMounted = false;
    };
  }, []); // Empty dependency array is fine here

  const fetchActivePartnerships = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      // Get partnerships where current user is involved and status is accepted
      const { data: partnerships, error } = await supabase
        .from('partnerships')
        .select(`
          *,
          partner_profile:profiles!user1_id(full_name, bio)
        `)
        .or(`user1_id.eq.${user.id},user2_id.eq.${user.id}`)
        .eq('status', 'accepted');

      if (error) throw error;

      // For partnerships where current user is user2, get user1's profile
      const processedPartnerships = await Promise.all(
        (partnerships || []).map(async (p) => {
          if (p.user2_id === user.id) {
            // Current user is user2, get user1's profile
            const { data: profile } = await supabase
              .from('profiles')
              .select('full_name, bio')
              .eq('id', p.user1_id)
              .single();
            return { ...p, partner_profile: profile };
          }
          return p; // Current user is user1, profile already loaded
        })
      );

      setPartnerships(processedPartnerships);
    } catch (error) {
      console.error('Error fetching partnerships:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleEndPartnership = async (partnershipId: string) => {
    setEndingId(partnershipId);
    try {
      // Update partnership status to ended
      const { error } = await supabase
        .from('partnerships')
        .update({ 
          status: 'ended',
          updated_at: new Date().toISOString()
        })
        .eq('id', partnershipId);

      if (error) throw error;

      // Remove from active partnerships
      setPartnerships(prev => prev.filter(p => p.id !== partnershipId));
    } catch (error) {
      console.error('Error ending partnership:', error);
    } finally {
      setEndingId(null);
    }
  };

  const getDaysSinceStart = (createdAt: string) => {
    const days = Math.floor((Date.now() - new Date(createdAt).getTime()) / (1000 * 60 * 60 * 24));
    return days;
  };

  if (loading) {
    return (
      <Card className="border-[#596D59]/20">
        <CardContent className="p-6 text-center">
          <Loader2 className="w-6 h-6 animate-spin mx-auto mb-2" />
          <p className="text-[#7E8E9D]">Loading active partnerships...</p>
        </CardContent>
      </Card>
    );
  }

  if (partnerships.length === 0) {
    return (
      <Card className="border-[#596D59]/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-[#001B30]">
            <Users className="w-5 h-5" />
            Active Partnerships
          </CardTitle>
        </CardHeader>
        <CardContent className="text-center py-8">
          <Users className="w-8 h-8 text-[#7E8E9D] mx-auto mb-2" />
          <p className="text-[#2C2C44] font-medium">No active partnerships</p>
          <p className="text-sm text-[#7E8E9D]">Accept partnership requests to get started</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-[#596D59]/20">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-[#001B30]">
          <Users className="w-5 h-5" />
          Active Partnerships
          <Badge className="bg-[#596D59] text-white">{partnerships.length}</Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {partnerships.map((partnership) => (
          <div key={partnership.id} className="p-4 border border-[#596D59]/20 rounded-lg">
            <div className="flex items-start justify-between mb-3">
              <div>
                <h4 className="font-medium text-[#001B30]">
                  {partnership.partner_profile?.full_name || 'Anonymous User'}
                </h4>
                <p className="text-sm text-[#7E8E9D] mt-1">
                  {partnership.partner_profile?.bio || 'No bio available'}
                </p>
              </div>
              <div className="text-right">
                <Badge variant="secondary" className="text-xs mb-1">
                  <Calendar className="w-3 h-3 mr-1" />
                  {getDaysSinceStart(partnership.created_at)} days
                </Badge>
              </div>
            </div>

            {partnership.matched_goals && partnership.matched_goals.length > 0 && (
              <div className="mb-3">
                <div className="flex items-center gap-1 mb-1">
                  <Target className="w-3 h-3 text-[#596D59]" />
                  <span className="text-xs font-medium text-[#596D59]">Shared Goals</span>
                </div>
                <div className="flex flex-wrap gap-1">
                  {partnership.matched_goals.slice(0, 3).map((goal, idx) => (
                    <Badge key={idx} variant="outline" className="text-xs">
                      {goal.category || goal.title}
                    </Badge>
                  ))}
                  {partnership.matched_goals.length > 3 && (
                    <Badge variant="outline" className="text-xs">
                      +{partnership.matched_goals.length - 3} more
                    </Badge>
                  )}
                </div>
              </div>
            )}

            <div className="flex gap-2">
              <Button
                size="sm"
                onClick={() => onOpenChat?.(partnership.id, partnership.partner_profile?.full_name || 'Partner')}
                className="flex-1 bg-[#596D59] hover:bg-[#596D59]/90 text-white"
              >
                <MessageCircle className="w-3 h-3 mr-1" />
                Chat
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => handleEndPartnership(partnership.id)}
                disabled={endingId === partnership.id}
                className="border-red-200 text-red-600 hover:bg-red-50"
              >
                {endingId === partnership.id ? (
                  <Loader2 className="w-3 h-3 mr-1 animate-spin" />
                ) : (
                  <UserX className="w-3 h-3 mr-1" />
                )}
                End
              </Button>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
};