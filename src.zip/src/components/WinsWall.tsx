import { useState, useEffect } from 'react';
import { useAppContext } from '@/contexts/AppContext';
import { supabase } from '@/lib/supabase';
import { PostPersistenceManager } from '@/utils/postPersistence';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import PostScheduler from '@/components/PostScheduler';
import PostActions from '@/components/PostActions';
import UniversalModerationActions from '@/components/UniversalModerationActions';
import { 
  Trophy, 
  Bell, 
  BellOff, 
  Share2,
  Heart,
  Star,
  Sparkles
} from 'lucide-react';
const WinsWall = () => {
  const { currentUser } = useAppContext();
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [newWin, setNewWin] = useState('');
  const [wins, setWins] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchWins();
    
    // Set up real-time subscription
    const channel = supabase
      .channel('wins_updates')
      .on('postgres_changes', 
        { event: 'INSERT', schema: 'public', table: 'posts', filter: 'category=eq.Win' },
        (payload) => {
          const newPost = payload.new;
          const win = {
            id: newPost.id,
            author: newPost.author_name || 'Anonymous',
            avatar: newPost.author_name ? newPost.author_name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase() : 'AN',
            time: formatTimeAgo(new Date(newPost.created_at)),
            content: newPost.content,
            category: 'Personal',
            likes: newPost.likes || 0,
            liked: false
          };
          setWins(prev => [win, ...prev]);
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / (1000 * 60));
    
    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins} min ago`;
    const diffHours = Math.floor(diffMins / 60);
    if (diffHours < 24) return `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`;
    const diffDays = Math.floor(diffHours / 24);
    return `${diffDays} day${diffDays > 1 ? 's' : ''} ago`;
  };

  const fetchWins = async () => {
    try {
      const { data, error } = await supabase
        .from('posts')
        .select('*')
        .eq('category', 'Win')
        .eq('recovery_status', 'active')
        .order('is_pinned', { ascending: false })
        .order('created_at', { ascending: false });

      if (error) throw error;

      const formattedWins = data.map(post => ({
        id: post.id,
        author: post.author_name || 'Anonymous',
        avatar: post.author_name ? post.author_name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase() : 'AN',
        time: formatTimeAgo(new Date(post.created_at)),
        content: post.content,
        category: 'Personal',
        likes: post.likes || 0,
        liked: false
      }));

      setWins(formattedWins);
    } catch (error) {
      console.error('Error fetching wins:', error);
      // Keep existing wins on error - don't overwrite with sample data
      if (wins.length === 0) {
        setWins([
          {
            id: 'sample-1',
            author: 'Sarah M.',
            avatar: 'SM',
            time: '1 hour ago',
            content: 'This week I finally completed my first 10K run! Been training for months and crossed the finish line with tears of joy. The accountability from this community kept me going! 🏃‍♀️✨',
            category: 'Fitness',
            likes: 34,
            liked: false
          }
        ]);
      }
    } finally {
      setLoading(false);
    }
  };

  const toggleLike = (winId: number) => {
    setWins(wins.map(win => 
      win.id === winId 
        ? { ...win, liked: !win.liked, likes: win.liked ? win.likes - 1 : win.likes + 1 }
        : win
    ));
  };

  const shareWin = async () => {
    if (newWin.trim()) {
      // Auto-save draft
      PostPersistenceManager.autoSaveDraft(newWin, 'Win', 'wins');
      
      try {
        // Use PostPersistenceManager for enhanced persistence
        const success = await PostPersistenceManager.savePost({
          content: newWin,
          category: 'Win',
          author_name: currentUser?.name || 'You',
          feedType: 'wins'
        }, 'posts');

        if (success) {
          // Clear auto-saved draft on successful save
          PostPersistenceManager.clearAutoSave('wins');
          
          // Add to local state
          const win = {
            id: `new-${Date.now()}`,
            author: currentUser?.name || 'You',
            avatar: currentUser?.name ? currentUser.name.split(' ').map(n => n[0]).join('') : 'YU',
            time: 'Just now',
            content: newWin,
            category: 'Personal',
            likes: 0,
            liked: false
          };
          
          setWins(prevWins => [win, ...prevWins]);
          setNewWin('');
        } else {
          // PostPersistenceManager handles the fallback automatically
          const win = {
            id: `temp-${Date.now()}`,
            author: currentUser?.name || 'You',
            avatar: currentUser?.name ? currentUser.name.split(' ').map(n => n[0]).join('') : 'YU',
            time: 'Just now',
            content: newWin,
            category: 'Personal',
            likes: 0,
            liked: false
          };
          
          setWins(prevWins => [win, ...prevWins]);
          setNewWin('');
        }
      } catch (error) {
        console.error('Error in shareWin:', error);
        // Final fallback
        const win = {
          id: `fallback-${Date.now()}`,
          author: currentUser?.name || 'You',
          avatar: currentUser?.name ? currentUser.name.split(' ').map(n => n[0]).join('') : 'YU',
          time: 'Just now',
          content: newWin,
          category: 'Personal',
          likes: 0,
          liked: false
        };
        
        setWins(prevWins => [win, ...prevWins]);
        setNewWin('');
      }
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'Fitness': return 'bg-green-100 text-green-800';
      case 'Career': return 'bg-blue-100 text-blue-800';
      case 'Wellness': return 'bg-purple-100 text-purple-800';
      case 'Creative': return 'bg-orange-100 text-orange-800';
      case 'Personal': return 'bg-pink-100 text-pink-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'Fitness': return '💪';
      case 'Career': return '💼';
      case 'Wellness': return '🧘';
      case 'Creative': return '🎨';
      case 'Personal': return '⭐';
      default: return '🏆';
    }
  };

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <Trophy className="h-6 w-6 text-yellow-500" />
            <h2 className="text-2xl font-bold">Wins Wall</h2>
            <Sparkles className="h-5 w-5 text-yellow-400" />
          </div>
          <p className="text-muted-foreground">
            Celebrate your weekly wins and inspire the community
          </p>
        </div>
        
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            {notificationsEnabled ? <Bell className="h-4 w-4" /> : <BellOff className="h-4 w-4" />}
            <span className="text-sm">Win Notifications</span>
            <Switch 
              checked={notificationsEnabled} 
              onCheckedChange={setNotificationsEnabled}
            />
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        <Card className="text-center">
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-yellow-500">{wins.length}</div>
            <div className="text-sm text-muted-foreground">Wins This Week</div>
          </CardContent>
        </Card>
        <Card className="text-center">
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-acclounge-sage">
              {wins.reduce((sum, win) => sum + win.likes, 0)}
            </div>
            <div className="text-sm text-muted-foreground">Total Celebrations</div>
          </CardContent>
        </Card>
        <Card className="text-center">
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-acclounge-navy">156</div>
            <div className="text-sm text-muted-foreground">Community Members</div>
          </CardContent>
        </Card>
      </div>

      {/* Notification Settings */}
      {!notificationsEnabled && (
        <Card className="border-yellow-200 bg-yellow-50">
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <BellOff className="h-4 w-4 text-yellow-600" />
              <span className="text-sm text-yellow-800">
                You've opted out of win notifications. Enable them to celebrate with the community!
              </span>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Share Win */}
      <Card className="border-yellow-200">
        <CardHeader>
          <div className="flex items-center gap-2">
            <Star className="h-5 w-5 text-yellow-500" />
            <h3 className="font-semibold">Share Your Win of the Week</h3>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <Textarea
              placeholder="What's your biggest win this week? Share your success story and inspire others..."
              value={newWin}
              onChange={(e) => setNewWin(e.target.value)}
              className="min-h-[100px]"
            />
            <div className="flex flex-wrap gap-1 sm:gap-2 mb-2">
              <div className="flex flex-wrap gap-1 sm:gap-2">
                <Badge variant="outline" className="text-xs">💪 Fitness</Badge>
                <Badge variant="outline" className="text-xs">💼 Career</Badge>
                <Badge variant="outline" className="text-xs">🧘 Wellness</Badge>
                <Badge variant="outline" className="text-xs">🎨 Creative</Badge>
              </div>
            </div>
            <div className="flex justify-between items-center">
              <PostScheduler
                isAdmin={currentUser?.isAdmin || false}
                isModerator={currentUser?.isModerator || false}
                onSchedule={(scheduledTime) => {
                  console.log('Scheduling win for:', scheduledTime);
                }}
              />
              <Button 
                onClick={shareWin} 
                className="bg-black text-white hover:bg-gray-800"
                disabled={!newWin.trim()}
              >
                <Trophy className="h-4 w-4 mr-2" />
                Share Win
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Wins */}
      <div className="space-y-4">
        {wins.map((win) => (
          <Card key={win.id} className="border-yellow-200 hover:shadow-md transition-shadow">
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <Avatar>
                    <AvatarFallback className="bg-yellow-500 text-white">
                      {win.avatar}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="flex items-center gap-2">
                      <p className="font-semibold">{win.author}</p>
                      <Badge className="bg-yellow-100 text-yellow-800 text-xs">
                        <Trophy className="h-3 w-3 mr-1" />
                        Weekly Win
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground">{win.time}</p>
                  </div>
                </div>
                <Badge className={`text-xs ${getCategoryColor(win.category)}`}>
                  {getCategoryIcon(win.category)} {win.category}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="pt-0">
              <p className="mb-4 text-left">{win.content}</p>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => toggleLike(win.id)}
                    className={`${win.liked ? 'text-red-500' : 'text-muted-foreground'}`}
                  >
                    <Heart className={`h-4 w-4 mr-1 ${win.liked ? 'fill-current' : ''}`} />
                    {win.likes}
                  </Button>
                  <Button variant="ghost" size="sm" className="text-muted-foreground">
                    <Share2 className="h-4 w-4 mr-1" />
                    Celebrate
                  </Button>
                  <UniversalModerationActions
                    postId={win.id}
                    isPinned={win.is_pinned}
                    tableName="posts"
                    onPostUpdated={fetchWins}
                    onPostDeleted={fetchWins}
                  />
                </div>
                <div className="text-xs text-muted-foreground">
                  {notificationsEnabled ? 'Notified community' : 'Silent mode'}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default WinsWall;
export { WinsWall };