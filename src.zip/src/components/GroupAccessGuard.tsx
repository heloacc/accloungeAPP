import { useState, useEffect } from 'react';
import { useAppContext } from '@/contexts/OptimizedAppContext';
import { useUserRole } from '@/hooks/useUserRole';
import { supabase } from '@/lib/supabase';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { AlertCircle, Lock } from 'lucide-react';
import GroupPreview from '@/components/GroupPreview';

interface GroupAccessGuardProps {
  groupId: string;
  children: React.ReactNode;
  onAccessDenied?: () => void;
}

interface GroupAccessInfo {
  id: string;
  name: string;
  description: string;
  is_private: boolean;
  is_member: boolean;
  has_pending_request: boolean;
  can_request_to_join: boolean;
  can_view_preview: boolean;
}

const GroupAccessGuard = ({ groupId, children, onAccessDenied }: GroupAccessGuardProps) => {
  const { currentUser } = useAppContext();
  const { isAdmin } = useUserRole();
  const [groupInfo, setGroupInfo] = useState<GroupAccessInfo | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    checkAccess();
  }, [groupId, currentUser?.id, isAdmin]);

  const checkAccess = async () => {
    if (!currentUser?.id || !groupId) {
      setError('Authentication required');
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      setError(null);

      // First check if group exists in database directly
      const { data: groupCheck, error: groupError } = await supabase
        .from('acircle_groups')
        .select('id, name, description, is_private')
        .eq('id', groupId)
        .single();

      if (groupError || !groupCheck) {
        setError('Group not found');
        setLoading(false);
        return;
      }

      // Use the backend endpoint for access info
      const { data, error: accessError } = await supabase.functions.invoke('group-access-management', {
        body: { 
          operation: 'get_access',
          groupId: groupId
        },
        headers: {
          'Content-Type': 'application/json'
        }
      });

      if (accessError || !data) {
        // Fallback to basic group info if edge function fails
        const isMember = isAdmin; // Admin can access everything
        setGroupInfo({
          ...groupCheck,
          is_member: isMember,
          has_pending_request: false,
          can_request_to_join: !isMember && currentUser?.id,
          can_view_preview: !groupCheck.is_private || isMember
        });
      } else {
        setGroupInfo(data);
      }
    } catch (err: any) {
      console.error('Error checking group access:', err);
      // Try fallback approach
      try {
        const { data: groupData } = await supabase
          .from('acircle_groups')
          .select('id, name, description, is_private')
          .eq('id', groupId)
          .single();
        
        if (groupData) {
          setGroupInfo({
            ...groupData,
            is_member: isAdmin,
            has_pending_request: false,
            can_request_to_join: !isAdmin && currentUser?.id,
            can_view_preview: !groupData.is_private || isAdmin
          });
        } else {
          setError('Group not found');
        }
      } catch {
        setError('Failed to load group information');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleRequestSent = () => {
    // Refresh group info after request is sent
    checkAccess();
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-[#7E8E9D]">Checking access...</p>
        </div>
      </div>
    );
  }

  if (error || !groupInfo) {
    return (
      <div className="flex items-center justify-center min-h-[400px] p-6">
        <Card className="max-w-md w-full">
          <CardHeader className="text-center">
            <div className="mx-auto w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mb-4">
              <AlertCircle className="h-6 w-6 text-red-600" />
            </div>
            <CardTitle className="text-xl text-[#001B30]">Error</CardTitle>
          </CardHeader>
          <CardContent className="text-center space-y-4">
            <p className="text-[#7E8E9D]">{error || 'Failed to load group information'}</p>
            <Button onClick={checkAccess}>Try Again</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Admin has access to everything
  if (isAdmin) {
    return <>{children}</>;
  }

  // Member has full access
  if (groupInfo.is_member) {
    return <>{children}</>;
  }

  // Non-member with preview access
  if (groupInfo.can_view_preview) {
    return (
      <GroupPreview 
        group={groupInfo} 
        cta={null}
        onRequestSent={handleRequestSent}
      />
    );
  }

  // No access at all
  return (
    <div className="flex items-center justify-center min-h-[400px] p-6">
      <Card className="max-w-md w-full">
        <CardHeader className="text-center">
          <div className="mx-auto w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mb-4">
            <Lock className="h-6 w-6 text-red-600" />
          </div>
          <CardTitle className="text-xl text-[#001B30]">Access Denied</CardTitle>
        </CardHeader>
        <CardContent className="text-center space-y-4">
          <p className="text-[#7E8E9D]">
            This group is not viewable. Ask an admin for access.
          </p>
          <div className="flex gap-2">
            <Button 
              variant="outline" 
              className="flex-1"
              onClick={() => {
                if (onAccessDenied) {
                  onAccessDenied();
                } else {
                  window.dispatchEvent(new CustomEvent('navigate-to-tab', { 
                    detail: { tab: 'groups' }
                  }));
                }
              }}
            >
              Back to Groups
            </Button>
            <Button 
              className="flex-1 bg-black text-white hover:bg-gray-800"
              onClick={() => {
                window.dispatchEvent(new CustomEvent('navigate-to-tab', { 
                  detail: { tab: 'dashboard' }
                }));
              }}
            >
              Dashboard
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default GroupAccessGuard;