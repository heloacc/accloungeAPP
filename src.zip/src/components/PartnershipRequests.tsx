import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Users, Check, X, Clock, Target, Loader2 } from 'lucide-react';

interface Partnership {
  id: string;
  user1_id: string;
  user2_id: string;
  status: 'pending' | 'accepted' | 'rejected' | 'ended';
  matched_goals: any[];
  created_at: string;
  profiles?: {
    full_name: string;
    bio: string;
  };
}

export const PartnershipRequests: React.FC = () => {
  const [pendingRequests, setPendingRequests] = useState<Partnership[]>([]);
  const [loading, setLoading] = useState(true);
  const [processingId, setProcessingId] = useState<string | null>(null);

  useEffect(() => {
    fetchPendingRequests();
  }, []);

  const fetchPendingRequests = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      // Get partnerships where current user is user2 (receiver) and status is pending
      const { data: partnerships, error } = await supabase
        .from('partnerships')
        .select(`
          *,
          profiles!partnerships_user1_id_fkey(full_name, bio)
        `)
        .eq('user2_id', user.id)
        .eq('status', 'pending');

      if (error) throw error;
      setPendingRequests(partnerships || []);
    } catch (error) {
      console.error('Error fetching requests:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleResponse = async (partnershipId: string, response: 'accepted' | 'rejected') => {
    setProcessingId(partnershipId);
    try {
      // Update partnership status
      const { error } = await supabase
        .from('partnerships')
        .update({ 
          status: response,
          updated_at: new Date().toISOString()
        })
        .eq('id', partnershipId);

      if (error) throw error;

      // Create notification for the requester
      const partnership = pendingRequests.find(p => p.id === partnershipId);
      if (partnership) {
        await supabase
          .from('notifications')
          .insert({
            user_id: partnership.user1_id,
            type: 'partnership_response',
            title: response === 'accepted' ? 'Partnership Accepted!' : 'Partnership Declined',
            message: response === 'accepted' 
              ? 'Your partnership request was accepted. Start your accountability journey!'
              : 'Your partnership request was declined.',
            data: { partnership_id: partnershipId, response }
          });
      }

      // Remove from pending requests
      setPendingRequests(prev => prev.filter(p => p.id !== partnershipId));
    } catch (error) {
      console.error('Error responding to request:', error);
    } finally {
      setProcessingId(null);
    }
  };

  if (loading) {
    return (
      <Card className="border-[#596D59]/20">
        <CardContent className="p-6 text-center">
          <Loader2 className="w-6 h-6 animate-spin mx-auto mb-2" />
          <p className="text-[#7E8E9D]">Loading partnership requests...</p>
        </CardContent>
      </Card>
    );
  }

  if (pendingRequests.length === 0) {
    return (
      <Card className="border-[#596D59]/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-[#001B30]">
            <Users className="w-5 h-5" />
            Partnership Requests
          </CardTitle>
        </CardHeader>
        <CardContent className="text-center py-8">
          <Clock className="w-8 h-8 text-[#7E8E9D] mx-auto mb-2" />
          <p className="text-[#2C2C44] font-medium">No pending requests</p>
          <p className="text-sm text-[#7E8E9D]">Partnership requests will appear here</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-[#596D59]/20">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-[#001B30]">
          <Users className="w-5 h-5" />
          Partnership Requests
          <Badge className="bg-[#596D59] text-white">{pendingRequests.length}</Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {pendingRequests.map((request) => (
          <div key={request.id} className="p-4 border border-[#596D59]/20 rounded-lg">
            <div className="flex items-start justify-between mb-3">
              <div>
                <h4 className="font-medium text-[#001B30]">
                  {request.profiles?.full_name || 'Anonymous User'}
                </h4>
                <p className="text-sm text-[#7E8E9D] mt-1">
                  {request.profiles?.bio || 'No bio available'}
                </p>
              </div>
              <Badge variant="secondary" className="text-xs">
                <Clock className="w-3 h-3 mr-1" />
                {new Date(request.created_at).toLocaleDateString()}
              </Badge>
            </div>

            {request.matched_goals && request.matched_goals.length > 0 && (
              <div className="mb-3">
                <div className="flex items-center gap-1 mb-1">
                  <Target className="w-3 h-3 text-[#596D59]" />
                  <span className="text-xs font-medium text-[#596D59]">Shared Goals</span>
                </div>
                <div className="flex flex-wrap gap-1">
                  {request.matched_goals.slice(0, 3).map((goal, idx) => (
                    <Badge key={idx} variant="outline" className="text-xs">
                      {goal.category || goal.title}
                    </Badge>
                  ))}
                  {request.matched_goals.length > 3 && (
                    <Badge variant="outline" className="text-xs">
                      +{request.matched_goals.length - 3} more
                    </Badge>
                  )}
                </div>
              </div>
            )}

            <div className="flex gap-2">
              <Button
                size="sm"
                onClick={() => handleResponse(request.id, 'accepted')}
                disabled={processingId === request.id}
                className="flex-1 bg-[#596D59] hover:bg-[#596D59]/90 text-white"
              >
                {processingId === request.id ? (
                  <Loader2 className="w-3 h-3 mr-1 animate-spin" />
                ) : (
                  <Check className="w-3 h-3 mr-1" />
                )}
                Accept
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => handleResponse(request.id, 'rejected')}
                disabled={processingId === request.id}
                className="flex-1 border-red-200 text-red-600 hover:bg-red-50"
              >
                <X className="w-3 h-3 mr-1" />
                Decline
              </Button>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
};