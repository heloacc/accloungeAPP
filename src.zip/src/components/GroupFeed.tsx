import React, { useState, useEffect, useCallback, useMemo, memo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { toast } from '@/components/ui/use-toast';
import { Send, MessageSquare, Users, Calendar, Clock, Trash2, Edit2, ChevronLeft, ChevronRight } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useUserData } from '@/hooks/useUserData';
import FeatureProtectionWrapper from '@/components/FeatureProtectionWrapper';
import PostScheduler from '@/components/PostScheduler';
import { usePerformanceMonitor, useDebounce } from '@/hooks/usePerformanceOptimization';


interface GroupPost {
  id: string;
  content: string;
  is_pinned: boolean;
  is_scheduled: boolean;
  scheduled_for: string | null;
  created_at: string;
  user_id: string;
  recovery_status: string;
  profiles: {
    full_name: string;
  };
}

interface GroupFeedProps {
  groupId: string;
  userRole: string;
  isAdmin: boolean;
  readOnly?: boolean;
}

const GroupFeed: React.FC<GroupFeedProps> = ({ groupId, userRole, isAdmin, readOnly = false }) => {
  const { isModerator } = useUserData();
  const [posts, setPosts] = useState<GroupPost[]>([]);
  const [newPost, setNewPost] = useState('');
  const [loading, setLoading] = useState(true);
  const [posting, setPosting] = useState(false);
  
  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const POSTS_PER_PAGE = 10;
  
  // Performance monitoring
  const { renderCount, measureRender } = usePerformanceMonitor('GroupFeed');

  useEffect(() => {
    fetchPosts(1, false);
    
    // Set up real-time subscription
    const channel = supabase
      .channel(`group_posts_${groupId}`)
      .on('postgres_changes', 
        { event: 'INSERT', schema: 'public', table: 'group_posts', filter: `group_id=eq.${groupId}` },
        () => {
          // Refresh posts when new post is added
          fetchPosts(1, false);
        }
      )
      .on('postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'group_posts', filter: `group_id=eq.${groupId}` },
        () => {
          // Refresh posts when post is updated (pinned/unpinned)
          fetchPosts(1, false);
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [groupId, fetchPosts]);

  const fetchPosts = useCallback(async (page = 1, append = false) => {
    try {
      setLoading(true);
      const offset = (page - 1) * POSTS_PER_PAGE;
      
      const { data, error, count } = await supabase
        .from('group_posts')
        .select(`
          *,
          profiles:user_id (full_name)
        `, { count: 'exact' })
        .eq('group_id', groupId)
        .neq('recovery_status', 'deleted')
        .order('is_pinned', { ascending: false })
        .order('created_at', { ascending: false })
        .range(offset, offset + POSTS_PER_PAGE - 1);

      if (error) throw error;
      
      const totalCount = count || 0;
      const totalPagesCount = Math.ceil(totalCount / POSTS_PER_PAGE);
      
      setTotalPages(totalPagesCount);
      setHasMore(page < totalPagesCount);
      
      if (append) {
        setPosts(prev => [...prev, ...(data || [])]);
      } else {
        setPosts(data || []);
      }
      
      setCurrentPage(page);
    } catch (error) {
      console.error('Error fetching posts:', error);
      toast({
        title: "Error",
        description: "Failed to load posts",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  }, [groupId, POSTS_PER_PAGE]);

  // Debounced post creation to prevent rapid submissions
  const debouncedCreatePost = useDebounce(async () => {
    if (!newPost.trim() || posting) return;

    const renderTime = measureRender(async () => {
      setPosting(true);
      try {
        const { error } = await supabase
          .from('group_posts')
          .insert([{
            group_id: groupId,
            content: newPost.trim(),
            user_id: (await supabase.auth.getUser()).data.user?.id
          }]);

        if (error) throw error;
        
        setNewPost('');
        await fetchPosts(1, false); // Refresh first page
        toast({
          title: "Success",
          description: "Post shared with the group!",
        });
      } catch (error) {
        console.error('Error creating post:', error);
        toast({
          title: "Error",
          description: "Failed to create post",
          variant: "destructive",
        });
      } finally {
        setPosting(false);
      }
    });
    
    if (renderTime > 50) {
      console.warn(`GroupFeed post creation took ${renderTime.toFixed(2)}ms`);
    }
  }, 500);

  const createPost = useCallback(async () => {
    await debouncedCreatePost();
  }, [debouncedCreatePost]);

  const loadMorePosts = useCallback(() => {
    if (hasMore && !loading) {
      fetchPosts(currentPage + 1, true);
    }
  }, [hasMore, loading, currentPage, fetchPosts]);

  const goToPage = useCallback((page: number) => {
    if (page >= 1 && page <= totalPages && page !== currentPage) {
      fetchPosts(page, false);
    }
  }, [totalPages, currentPage, fetchPosts]);
  const togglePin = async (postId: string, currentPinned: boolean) => {
    try {
      const { error } = await supabase
        .from('group_posts')
        .update({ is_pinned: !currentPinned })
        .eq('id', postId);

      if (error) throw error;
      await fetchPosts();
    } catch (error) {
      console.error('Error toggling pin:', error);
    }
  };
  const deletePost = async (postId: string) => {
    if (!isAdmin) return;
    
    try {
      const { error } = await supabase
        .from('group_posts')
        .update({ recovery_status: 'deleted' })
        .eq('id', postId);

      if (error) throw error;
      
      await fetchPosts();
    } catch (error) {
      console.error('Error deleting post:', error);
    }
  };
  const canModerate = userRole === 'admin' || userRole === 'moderator' || isAdmin;



  if (loading) {
    return <div className="text-center py-4">Loading feed...</div>;
  }
  return (
    <FeatureProtectionWrapper featureName="Group Feed">
      <div className="space-y-4 text-left">
        {/* Create Post - Hidden in read-only mode */}
        {!readOnly && (
          <Card>
            <CardContent className="pt-6">
              <div className="space-y-3">
                <Textarea
                  placeholder="Share something with the group..."
                  value={newPost}
                  onChange={(e) => setNewPost(e.target.value)}
                  rows={3}
                />
                <div className="flex justify-between items-center">
                  <PostScheduler
                    isAdmin={isAdmin || false}
                    isModerator={isModerator || false}
                    onSchedule={(scheduledTime) => {
                      console.log('Scheduling group post for:', scheduledTime);
                    }}
                  />
                  <Button 
                    onClick={createPost} 
                    disabled={!newPost.trim() || posting}
                    className="flex items-center gap-2"
                  >
                    <Send className="h-4 w-4" />
                    {posting ? 'Posting...' : 'Post'}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Read-only notice for archived groups */}
        {readOnly && (
          <Card className="bg-gray-50 border-gray-200">
            <CardContent className="pt-6">
              <p className="text-sm text-muted-foreground text-center">
                This is an archived group. You can view past posts but cannot create new ones.
              </p>
            </CardContent>
          </Card>
        )}

        {/* Posts */}
        {posts.length === 0 ? (
          <Card>
            <CardContent className="text-center py-8">
              <p className="text-muted-foreground">No posts yet. Be the first to share!</p>
            </CardContent>
          </Card>
        ) : (
          posts.map((post) => (
            <Card key={post.id} className={post.is_pinned ? 'border-yellow-500' : ''}>
              <CardContent className="pt-6">
                <div className="flex justify-between items-start mb-3">
                  <div className="flex items-center gap-3">
                    <div className="h-8 w-8 bg-blue-500 rounded-full flex items-center justify-center text-white text-sm font-medium">
                      {post.profiles?.full_name?.charAt(0) || 'U'}
                    </div>
                    <div>
                      <p className="font-medium text-sm">{post.profiles?.full_name || 'Unknown User'}</p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(post.created_at).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {post.is_pinned && (
                      <Badge variant="secondary" className="text-xs">
                        Pinned
                      </Badge>
                    )}
                  </div>
                </div>
                <p className="text-sm whitespace-pre-wrap">{post.content}</p>
              </CardContent>
            </Card>
          ))
        )}

        {/* Pagination Controls */}
        {posts.length > 0 && (
          <div className="flex flex-col items-center space-y-4">
            {/* Load More Button */}
            {hasMore && (
              <Button
                onClick={loadMorePosts}
                disabled={loading}
                variant="outline"
                className="w-full max-w-xs"
              >
                {loading ? 'Loading...' : 'Load More Posts'}
              </Button>
            )}

            {/* Page Navigation */}
            {totalPages > 1 && (
              <div className="flex items-center space-x-2">
                <Button
                  onClick={() => goToPage(currentPage - 1)}
                  disabled={currentPage === 1}
                  variant="outline"
                  size="sm"
                >
                  <ChevronLeft className="h-4 w-4" />
                  Previous
                </Button>
                
                <div className="flex items-center space-x-1">
                  {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                    const pageNum = Math.max(1, Math.min(totalPages - 4, currentPage - 2)) + i;
                    if (pageNum > totalPages) return null;
                    
                    return (
                      <Button
                        key={pageNum}
                        onClick={() => goToPage(pageNum)}
                        variant={pageNum === currentPage ? "default" : "outline"}
                        size="sm"
                        className="w-8 h-8 p-0"
                      >
                        {pageNum}
                      </Button>
                    );
                  })}
                </div>
                
                <Button
                  onClick={() => goToPage(currentPage + 1)}
                  disabled={currentPage === totalPages}
                  variant="outline"
                  size="sm"
                >
                  Next
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            )}

            {/* Page Info */}
            <p className="text-sm text-muted-foreground">
              Page {currentPage} of {totalPages} • {posts.length} posts
            </p>
          </div>
        )}
      </div>
    </FeatureProtectionWrapper>
  );
};

const MemoizedGroupFeed = memo(GroupFeed);
MemoizedGroupFeed.displayName = 'GroupFeed';

export default MemoizedGroupFeed;