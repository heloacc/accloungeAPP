import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Users, MessageSquare, Target, Shield, RefreshCw, Settings, Trophy } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useUserData } from '@/hooks/useUserData';
import { useUserRole } from '@/hooks/useUserRole';
import { toast } from '@/components/ui/use-toast';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import IsolatedErrorBoundary from '@/components/IsolatedErrorBoundary';
import ActiveCircleFeed from '@/components/ActiveCircleFeed';
import GroupFeed from '@/components/GroupFeed';
import GroupGoalTracker from '@/components/GroupGoalTracker';
import ActiveCircleTaskManager from '@/components/ActiveCircleTaskManager';
import GroupLeaderboard from '@/components/GroupLeaderboard';
import GroupAccessGuard from '@/components/GroupAccessGuard';
import { useLoadingState } from '@/hooks/useLoadingState';
import LoadingFallback from '@/components/LoadingFallback';

interface Group {
  id: string; // Changed from number to string for UUID support
  name: string;
  description: string;
  is_private: boolean;
  is_archived: boolean;
  created_at: string;
  has_goals?: boolean;
  has_tasks?: boolean;
  has_leaderboard?: boolean;
  memberCount?: number;
}

const ActiveCircle = () => {
  const { user, isAdmin } = useUserData();
  const [selectedGroup, setSelectedGroup] = useState<Group | null>(null);
  const [userGroups, setUserGroups] = useState<Group[]>([]);
  const [userRole, setUserRole] = useState<string>('member');
  const [error, setError] = useState<string | null>(null);
  const { isLoading, withLoading } = useLoadingState(['groups', 'specificGroup']);
  useEffect(() => {
    let isMounted = true;
    
    if (user?.id && isMounted) {
      // Check if there's a selected group from navigation first
      const selectedGroupId = sessionStorage.getItem('selectedGroupId');
      if (selectedGroupId) {
        loadSpecificGroup(selectedGroupId);
        sessionStorage.removeItem('selectedGroupId');
      } else {
        // Only load user groups if no specific group was requested
        loadUserGroups();
      }
    }
    
    return () => {
      isMounted = false;
    };
  }, [user?.id]); // Only depend on user.id to prevent infinite loops

  const loadUserGroups = async () => {
    await withLoading('groups', async () => {
      setError(null);

      if (isAdmin) {
        // Admin can see all groups
        const { data, error: fetchError } = await supabase
          .from('acircle_groups')
          .select('*')
          .eq('is_archived', false)
          .order('created_at', { ascending: false });

        if (fetchError) {
          throw fetchError;
        }

        setUserGroups(data || []);
        
        if (data && data.length > 0) {
          setSelectedGroup(data[0]);
          setUserRole('admin');
        }
      } else {
        // Regular user - get their group memberships
        
        // First get user's memberships
        const { data: memberships, error: memberError } = await supabase
          .from('acircle_members')
          .select('group_id, role')
          .eq('user_id', user?.id);

        if (memberError) {
          throw memberError;
        }

        if (!memberships || memberships.length === 0) {
          setUserGroups([]);
          return;
        }

        // Get group details for user's memberships
        const groupIds = memberships.map(m => m.group_id);
        const { data: groups, error: groupsError } = await supabase
          .from('acircle_groups')
          .select('*')
          .in('id', groupIds)
          .eq('is_archived', false);

        if (groupsError) {
          throw groupsError;
        }

        setUserGroups(groups || []);
        
        if (groups && groups.length > 0) {
          setSelectedGroup(groups[0]);
          const firstMembership = memberships.find(m => m.group_id === groups[0].id);
          setUserRole(firstMembership?.role || 'member');
        }
      }
    }).catch((error: any) => {
      setError(`Failed to load groups: ${error.message}`);
      toast({
        title: "Error Loading Groups",
        description: error.message || "Failed to load groups. Please try again.",
        variant: "destructive"
      });
    });
  };

  const loadSpecificGroup = async (groupId: string) => {
    await withLoading('specificGroup', async () => {
      setError(null);

      // First load the specific group
      const { data, error } = await supabase
        .from('acircle_groups')
        .select('*')
        .eq('id', groupId)
        .single();

      if (error) {
        throw error;
      }
      
      if (data) {
        setSelectedGroup(data);
        
        // Also load all user groups for the selector (but don't override the selected group)
        await loadUserGroupsForSelector();
        
        // If not admin, get user role for this group
        if (!isAdmin && user?.id) {
          const { data: memberData } = await supabase
            .from('acircle_members')
            .select('role')
            .eq('group_id', groupId)
            .eq('user_id', user.id)
            .single();
          
          if (memberData) {
            setUserRole(memberData.role || 'member');
          } else {
            setUserRole('admin'); // Admin access for non-members
          }
        } else {
          setUserRole('admin'); // Admin always has admin role
        }
      } else {
        throw new Error('Group not found');
      }
    }).catch((error: any) => {
      setError('Failed to load the selected group. Please try again.');
      toast({
        title: "Error",
        description: "Failed to load the selected group.",
        variant: "destructive"
      });
    });
  };

  const loadUserGroupsForSelector = async () => {
    try {
      if (isAdmin) {
        // Admin can see all groups
        const { data, error: fetchError } = await supabase
          .from('acircle_groups')
          .select('*')
          .eq('is_archived', false)
          .order('created_at', { ascending: false });

        if (fetchError) throw fetchError;
        setUserGroups(data || []);
      } else {
        // Regular user - get their group memberships directly without joins
        const { data: memberships, error: memberError } = await supabase
          .from('acircle_members')
          .select('group_id')
          .eq('user_id', user?.id);

        if (memberError) throw memberError;

        if (memberships && memberships.length > 0) {
          const groupIds = memberships.map(m => m.group_id);
          const { data: groups, error: groupsError } = await supabase
            .from('acircle_groups')
            .select('*')
            .in('id', groupIds)
            .eq('is_archived', false);

          if (groupsError) throw groupsError;
          setUserGroups(groups || []);
        } else {
          setUserGroups([]);
        }
      }
    } catch (error) {
    }
  };

  return (
    <LoadingFallback 
      isLoading={isLoading('groups') || isLoading('specificGroup')} 
      error={error ? new Error(error) : null}
      onRetry={loadUserGroups}
      context="Active Circle groups"
      skeleton="card"
    >
      <IsolatedErrorBoundary componentName="Active Circle">
        {!selectedGroup && userGroups.length === 0 ? (
          <div className="text-center py-8 space-y-4">
            <div className="flex items-center justify-center gap-2 mb-4">
              <Users className="h-8 w-8 text-gray-400" />
            </div>
            <p>You are not a member of any Active Circle group.</p>
            <p className="text-sm text-gray-600">
              Visit the Groups tab to browse and join available groups.
            </p>
          </div>
        ) : selectedGroup ? (
          <GroupAccessGuard 
            groupId={selectedGroup.id}
            onAccessDenied={() => {
              window.dispatchEvent(new CustomEvent('navigate-to-tab', { 
                detail: { tab: 'groups' }
              }));
            }}
          >
            <div className="p-6 max-w-6xl mx-auto space-y-6">
              {/* Group Selector for Admin or Multiple Groups */}
              {(isAdmin || userGroups.length > 1) && (
                <Card className={isAdmin ? "bg-yellow-50 border-yellow-200" : ""}>
                  <CardHeader className="pb-3">
                    <div className="flex items-center gap-2">
                      {isAdmin && <Shield className="h-5 w-5 text-yellow-600" />}
                      <CardTitle className={`text-lg ${isAdmin ? 'text-yellow-800' : ''}`}>
                        {isAdmin ? 'Admin Access - Select Group' : 'Select Group'}
                      </CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <Select 
                      onValueChange={(value) => {
                        const group = userGroups.find(g => g.id.toString() === value);
                        if (group) setSelectedGroup(group);
                      }} 
                      value={selectedGroup?.id.toString()}
                    >
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="Select a group" />
                      </SelectTrigger>
                      <SelectContent>
                        {userGroups.map((group) => (
                          <SelectItem key={group.id} value={group.id.toString()}>
                            {group.name} {group.is_archived && '(Archived)'}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </CardContent>
                </Card>
              )}

              {/* Group Header */}
              <div className="flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <h2 className={`text-2xl font-bold flex items-center gap-2 ${
                      selectedGroup.is_archived ? 'text-gray-500' : ''
                    }`}>
                      <Users className="h-6 w-6 text-[#596D59]" />
                      {selectedGroup.name}
                    </h2>
                    {selectedGroup.is_archived && (
                      <Badge variant="outline" className="text-gray-500 border-gray-300">
                        ARCHIVED
                      </Badge>
                    )}
                    {isAdmin && (
                      <Badge className="bg-yellow-600 text-white">
                        <Shield className="h-3 w-3 mr-1" />
                        Admin Access
                      </Badge>
                    )}
                  </div>
                  <p className={`text-muted-foreground ${
                    selectedGroup.is_archived ? 'text-gray-400' : ''
                  }`}>
                    {selectedGroup.description}
                  </p>
                </div>
              </div>

              {/* Archived Group Notice */}
              {selectedGroup.is_archived && (
                <Card className="bg-gray-50 border-gray-200">
                  <CardContent className="pt-4">
                    <p className="text-gray-600 flex items-center gap-2">
                      <Settings className="h-4 w-4" />
                      This group has been archived and is read-only.
                    </p>
                  </CardContent>
                </Card>
              )}

              {/* Group Tabs */}
              <Tabs defaultValue="feed" className="w-full">
                <TabsList className="grid w-full grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-1 h-auto p-1">
                  <TabsTrigger value="feed" className="flex items-center gap-1 sm:gap-2 text-xs sm:text-sm px-2 py-2 min-w-0">
                    <MessageSquare className="h-3 w-3 sm:h-4 sm:w-4 flex-shrink-0" />
                    <span className="truncate">Feed</span>
                  </TabsTrigger>
                  {selectedGroup.has_goals !== false && (
                    <TabsTrigger value="goals" className="flex items-center gap-1 sm:gap-2 text-xs sm:text-sm px-2 py-2 min-w-0">
                      <Target className="h-3 w-3 sm:h-4 sm:w-4 flex-shrink-0" />
                      <span className="truncate">Goals</span>
                    </TabsTrigger>
                  )}
                  {selectedGroup.has_tasks !== false && (
                    <TabsTrigger value="tasks" className="flex items-center gap-1 sm:gap-2 text-xs sm:text-sm px-2 py-2 min-w-0">
                      <Settings className="h-3 w-3 sm:h-4 sm:w-4 flex-shrink-0" />
                      <span className="truncate">Tasks</span>
                    </TabsTrigger>
                  )}
                  {selectedGroup.has_leaderboard !== false && (
                    <TabsTrigger value="leaderboard" className="flex items-center gap-1 sm:gap-2 text-xs sm:text-sm px-2 py-2 min-w-0">
                      <Trophy className="h-3 w-3 sm:h-4 sm:w-4 flex-shrink-0" />
                      <span className="truncate">Leaderboard</span>
                    </TabsTrigger>
                  )}
                </TabsList>
                
                <TabsContent value="feed" className="mt-6">
                  {selectedGroup.name === "Active Circle" ? (
                    <ActiveCircleFeed groupId={selectedGroup.id.toString()} />
                  ) : (
                    <GroupFeed 
                      groupId={selectedGroup.id.toString()} 
                      userRole={isAdmin ? 'admin' : userRole}
                      isAdmin={isAdmin}
                      readOnly={selectedGroup.is_archived}
                    />
                  )}
                </TabsContent>
                
                {selectedGroup.has_goals !== false && (
                  <TabsContent value="goals" className="mt-6">
                    <GroupGoalTracker 
                      groupId={selectedGroup.id.toString()} 
                      userRole={isAdmin ? 'admin' : userRole}
                      readOnly={selectedGroup.is_archived}
                    />
                  </TabsContent>
                )}
                
                {selectedGroup.has_tasks !== false && (
                  <TabsContent value="tasks" className="mt-6">
                    <Card>
                      <CardContent className="pt-6">
                        <div className="text-center text-gray-500">
                          <Settings className="h-12 w-12 mx-auto mb-4 opacity-50" />
                          <p>Task management requires a specific goal to be selected.</p>
                          <p className="text-sm mt-2">Please select a goal from the Goals tab first.</p>
                        </div>
                      </CardContent>
                    </Card>
                  </TabsContent>
                )}
                
                {selectedGroup.has_leaderboard !== false && (
                  <TabsContent value="leaderboard" className="mt-6">
                    <GroupLeaderboard 
                      groupId={selectedGroup.id.toString()} 
                      readOnly={selectedGroup.is_archived}
                    />
                  </TabsContent>
                )}
              </Tabs>
            </div>
          </GroupAccessGuard>
        ) : null}
      </IsolatedErrorBoundary>
    </LoadingFallback>
  );
};

export default ActiveCircle;