import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Users, Bell, MessageCircle } from 'lucide-react';
import { PartnershipRequests } from './PartnershipRequests';
import { ActivePartnerships } from './ActivePartnerships';
import { PartnershipChat } from './PartnershipChat';

export const PartnershipDashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState('requests');
  const [chatData, setChatData] = useState<{ partnershipId: string; partnerName: string } | null>(null);

  const handleOpenChat = (partnershipId: string, partnerName: string) => {
    setChatData({ partnershipId, partnerName });
    setActiveTab('chat');
  };

  const handleCloseChat = () => {
    setChatData(null);
    setActiveTab('active');
  };

  return (
    <div className="space-y-6">
      <Card className="border-[#596D59]/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-[#001B30]">
            <Users className="w-5 h-5" />
            Partnership Management
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="requests" className="flex items-center gap-2">
                <Bell className="w-4 h-4" />
                Requests
              </TabsTrigger>
              <TabsTrigger value="active" className="flex items-center gap-2">
                <Users className="w-4 h-4" />
                Active
              </TabsTrigger>
              <TabsTrigger value="chat" className="flex items-center gap-2" disabled={!chatData}>
                <MessageCircle className="w-4 h-4" />
                Chat
              </TabsTrigger>
            </TabsList>

            <TabsContent value="requests" className="mt-4">
              <PartnershipRequests />
            </TabsContent>

            <TabsContent value="active" className="mt-4">
              <ActivePartnerships onOpenChat={handleOpenChat} />
            </TabsContent>

            <TabsContent value="chat" className="mt-4">
              {chatData ? (
                <PartnershipChat
                  partnershipId={chatData.partnershipId}
                  partnerName={chatData.partnerName}
                  onClose={handleCloseChat}
                />
              ) : (
                <div className="text-center py-8 text-[#7E8E9D]">
                  Select a partnership to start chatting
                </div>
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default PartnershipDashboard;