import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Users, Activity, Clock, UserCheck } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface EngagementData {
  activeUsers: number;
  newUsers: number;
  averageSessionTime: number;
  retentionRate: number;
  dailyActiveUsers: number;
  weeklyActiveUsers: number;
  monthlyActiveUsers: number;
}

const UserEngagementMetrics: React.FC = () => {
  const [engagement, setEngagement] = useState<EngagementData>({
    activeUsers: 0,
    newUsers: 0,
    averageSessionTime: 0,
    retentionRate: 0,
    dailyActiveUsers: 0,
    weeklyActiveUsers: 0,
    monthlyActiveUsers: 0
  });

  useEffect(() => {
    loadEngagementMetrics();
  }, []);

  const loadEngagementMetrics = async () => {
    try {
      const now = new Date();
      const oneDayAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000);
      const oneWeekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
      const oneMonthAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);

      const [
        dailyActiveResult,
        weeklyActiveResult,
        monthlyActiveResult,
        newUsersResult,
        totalUsersResult
      ] = await Promise.all([
        // Use created_at instead of last_seen since last_seen doesn't exist
        supabase
          .from('profiles')
          .select('id')
          .gte('created_at', oneDayAgo.toISOString()),
        supabase
          .from('profiles')
          .select('id')
          .gte('created_at', oneWeekAgo.toISOString()),
        supabase
          .from('profiles')
          .select('id')
          .gte('created_at', oneMonthAgo.toISOString()),
        supabase
          .from('profiles')
          .select('id')
          .gte('created_at', oneWeekAgo.toISOString()),
        supabase
          .from('profiles')
          .select('id', { count: 'exact' })
      ]);

      // Calculate retention rate (simplified - users active in last week vs total)
      const retentionRate = totalUsersResult.count && weeklyActiveResult.data 
        ? Math.round((weeklyActiveResult.data.length / totalUsersResult.count) * 100)
        : 0;

      setEngagement({
        activeUsers: monthlyActiveResult.data?.length || 0,
        newUsers: newUsersResult.data?.length || 0,
        averageSessionTime: 25, // Placeholder - would need session tracking
        retentionRate,
        dailyActiveUsers: dailyActiveResult.data?.length || 0,
        weeklyActiveUsers: weeklyActiveResult.data?.length || 0,
        monthlyActiveUsers: monthlyActiveResult.data?.length || 0
      });
    } catch (error) {
      console.error('Error loading engagement metrics:', error);
    }
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Activity className="h-4 w-4" />
              Daily Active
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{engagement.dailyActiveUsers}</div>
            <p className="text-xs text-muted-foreground">Last 24 hours</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Users className="h-4 w-4" />
              Weekly Active
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{engagement.weeklyActiveUsers}</div>
            <p className="text-xs text-muted-foreground">Last 7 days</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <UserCheck className="h-4 w-4" />
              New Users
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{engagement.newUsers}</div>
            <p className="text-xs text-muted-foreground">This week</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Clock className="h-4 w-4" />
              Retention Rate
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{engagement.retentionRate}%</div>
            <p className="text-xs text-muted-foreground">Weekly retention</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>User Activity Overview</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-sm font-medium">Monthly Active Users</span>
              <span className="text-lg font-bold">{engagement.monthlyActiveUsers}</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div 
                className="bg-blue-600 h-2 rounded-full" 
                style={{ width: `${Math.min(100, (engagement.monthlyActiveUsers / 100) * 100)}%` }}
              ></div>
            </div>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-muted-foreground">Daily/Weekly Ratio:</span>
                <span className="ml-2 font-medium">
                  {engagement.weeklyActiveUsers > 0 
                    ? Math.round((engagement.dailyActiveUsers / engagement.weeklyActiveUsers) * 100) 
                    : 0}%
                </span>
              </div>
              <div>
                <span className="text-muted-foreground">Weekly/Monthly Ratio:</span>
                <span className="ml-2 font-medium">
                  {engagement.monthlyActiveUsers > 0 
                    ? Math.round((engagement.weeklyActiveUsers / engagement.monthlyActiveUsers) * 100) 
                    : 0}%
                </span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default UserEngagementMetrics;