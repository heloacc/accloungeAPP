import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Users, Search, RefreshCw, AlertCircle, CheckCircle } from 'lucide-react';
import UserManagementTable from './UserManagementTable';
import { toast } from '@/components/ui/use-toast';
import { Alert, AlertDescription } from '@/components/ui/alert';

interface User {
  id: string;
  name: string;
  email: string;
  role: string;
  is_admin: boolean;
  created_at: string;
  what_brings_you?: string;
  habit_excited?: string;
}

interface AdminError {
  message: string;
  code?: string;
  hint?: string;
  correlation_id?: string;
}

const UserManagement = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [error, setError] = useState<AdminError | null>(null);
  const [retryCount, setRetryCount] = useState(0);
  const [healthStatus, setHealthStatus] = useState<'checking' | 'healthy' | 'unhealthy'>('checking');

  // Check admin service health
  const checkHealth = async () => {
    try {
      setHealthStatus('checking');
      
      // Call the admin-operations function with a health check action
      const { data: response, error } = await supabase.functions.invoke('admin-operations', {
        body: { action: 'health_check' }
      });
      
      if (error || !response?.success) {
        setHealthStatus('unhealthy');
        console.warn('Admin services health check failed:', error || response);
      } else {
        setHealthStatus('healthy');
        console.log('Admin services healthy:', response);
      }
    } catch (error) {
      setHealthStatus('unhealthy');
      console.warn('Health check error:', error);
    }
  };

  const fetchUsers = async (isRetry = false) => {
    try {
      setLoading(true);
      setError(null);
      
      if (!isRetry) {
        setRetryCount(0);
      }
      
      // Get current session first
      const { data: { session }, error: sessionError } = await supabase.auth.getSession();
      if (sessionError || !session) {
        throw {
          message: 'Authentication required - please log in to access admin features',
          code: 'AUTH_REQUIRED',
          hint: 'Try refreshing the page or logging out and back in'
        };
      }

      console.log('Fetching users with session:', session.user.id);
      
      // Use admin-operations edge function with timeout
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 30000); // 30 second timeout

      try {
        const { data: response, error: functionError } = await supabase.functions.invoke('admin-operations', {
          body: { action: 'get_all_users' },
          headers: {
            'Authorization': `Bearer ${session.access_token}`,
            'Content-Type': 'application/json'
          }
        });
        
        clearTimeout(timeoutId);
        
        console.log('Admin function response:', { response, functionError });
        
        if (functionError) {
          console.error('Function invocation error:', functionError);
          throw {
            message: 'Failed to connect to admin services',
            code: 'CONNECTION_ERROR',
            hint: 'The admin service may be temporarily unavailable'
          };
        }
        
        // Handle response - function now always returns success: true
        if (!response) {
          throw {
            message: 'No response from admin service',
            code: 'NO_RESPONSE',
            hint: 'The service may be starting up'
          };
        }
        
        const usersData = response?.users || [];
        const formattedUsers = usersData.map((user: any) => ({
          id: user.id,
          name: user.full_name || 'Unknown',
          email: user.email,
          role: user.role || 'Member',
          is_admin: user.role === 'Admin',
          created_at: user.created_at,
          what_brings_you: user.intro_questions?.what_brings_you_to_acclounge || 'No response',
          habit_excited: user.intro_questions?.habit_youre_excited_to_build || 'No response'
        }));
        
        console.log('Formatted users:', formattedUsers);
        setUsers(formattedUsers);
        setError(null);
        
        // Show success message on retry
        if (isRetry) {
          toast({
            title: "Success",
            description: `Successfully loaded ${formattedUsers.length} users`,
          });
        }
        
      } catch (abortError) {
        if (abortError.name === 'AbortError') {
          throw {
            message: 'Request timed out after 30 seconds',
            code: 'TIMEOUT',
            hint: 'The admin service may be experiencing high load'
          };
        }
        throw abortError;
      }
      
    } catch (error) {
      console.error('Error fetching users:', error);
      
      const adminError: AdminError = error as AdminError || {
        message: error instanceof Error ? error.message : 'Unknown error occurred',
        code: 'UNKNOWN_ERROR'
      };
      
      setError(adminError);
      
      // Don't show toast on initial load, only on manual retries
      if (isRetry) {
        toast({
          title: "Error",
          description: adminError.message,
          variant: "destructive"
        });
      }
    } finally {
      setLoading(false);
    }
  };

  const handleRetry = async () => {
    const newRetryCount = retryCount + 1;
    setRetryCount(newRetryCount);
    
    if (newRetryCount <= 2) {
      // Exponential backoff: 1s, 2s, 4s
      const delay = Math.pow(2, newRetryCount - 1) * 1000;
      setTimeout(() => fetchUsers(true), delay);
    } else {
      await fetchUsers(true);
    }
  };

  const handleUpdateRole = async (userId: string, newRole: string) => {
    try {
      // Get current session for authorization
      const { data: { session }, error: sessionError } = await supabase.auth.getSession();
      if (sessionError || !session) {
        throw new Error('Authentication required - please log in to access admin features');
      }

      // Use admin-operations edge function for role updates
      const { data: response, error: functionError } = await supabase.functions.invoke('admin-operations', {
        body: { 
          action: 'update_user_role',
          userId: userId,
          role: newRole
        },
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json'
        }
      });

      if (functionError) {
        console.error('Function invocation error:', functionError);
        throw new Error('Failed to connect to admin services. Please try again.');
      }

      if (!response?.success) {
        const errorMessage = response?.error || response?.message || 'Failed to update role';
        throw new Error(errorMessage);
      }

      setUsers(users.map(user => 
        user.id === userId 
          ? { ...user, role: newRole, is_admin: newRole === 'Admin' }
          : user
      ));

      toast({
        title: "Success",
        description: response.message || `User role updated to ${newRole}`,
      });
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Failed to update user role';
      console.error('Error updating user role:', errorMessage);
      
      toast({
        title: "Error",
        description: errorMessage,
        variant: "destructive"
      });
    }
  };

  useEffect(() => {
    checkHealth();
    fetchUsers();
  }, []);

  const filteredUsers = users.filter(user =>
    user.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.email?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center gap-3">
        <Users className="h-8 w-8 text-primary" />
        <div>
          <h1 className="text-3xl font-bold">User Management</h1>
          <p className="text-muted-foreground">Manage user roles and permissions</p>
        </div>
        <div className="ml-auto flex items-center gap-2">
          {healthStatus === 'healthy' && <CheckCircle className="h-5 w-5 text-green-500" />}
          {healthStatus === 'unhealthy' && <AlertCircle className="h-5 w-5 text-red-500" />}
          <span className="text-sm text-muted-foreground">
            Admin Services: {healthStatus}
          </span>
        </div>
      </div>

      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription className="flex items-center justify-between">
            <div>
              <div className="font-medium">{error.message}</div>
              {error.hint && <div className="text-sm mt-1">{error.hint}</div>}
              {error.correlation_id && (
                <div className="text-xs mt-1 opacity-75">ID: {error.correlation_id}</div>
              )}
            </div>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={handleRetry}
              disabled={loading}
            >
              {loading ? 'Retrying...' : `Retry ${retryCount > 0 ? `(${retryCount}/3)` : ''}`}
            </Button>
          </AlertDescription>
        </Alert>
      )}

      <div className="flex gap-4 items-center">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
          <Input
            placeholder="Search users..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <Button onClick={() => fetchUsers(true)} variant="outline" size="sm" disabled={loading}>
          <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
          Refresh
        </Button>
        <Button onClick={checkHealth} variant="outline" size="sm">
          Check Health
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>All Users ({filteredUsers.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex justify-center items-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              <span className="ml-3 text-muted-foreground">Loading users...</span>
            </div>
          ) : error && users.length === 0 ? (
            <div className="text-center py-8">
              <AlertCircle className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">Unable to load users</p>
              <Button onClick={handleRetry} variant="outline" className="mt-4">
                Try Again
              </Button>
            </div>
          ) : (
            <UserManagementTable 
              users={filteredUsers} 
              onUpdateRole={handleUpdateRole}
            />
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default UserManagement;