import React, { memo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

// Memoized Card Component
export const MemoizedCard = memo(({ 
  title, 
  content, 
  onClick,
  className = ''
}: {
  title: string;
  content: React.ReactNode;
  onClick?: () => void;
  className?: string;
}) => (
  <Card className={`transition-all hover:shadow-md ${className}`} onClick={onClick}>
    <CardHeader>
      <CardTitle className="text-lg">{title}</CardTitle>
    </CardHeader>
    <CardContent>{content}</CardContent>
  </Card>
));

// Memoized Button Component
export const MemoizedButton = memo(({
  children,
  onClick,
  variant = 'default',
  disabled = false,
  className = ''
}: {
  children: React.ReactNode;
  onClick?: () => void;
  variant?: 'default' | 'destructive' | 'outline' | 'secondary' | 'ghost' | 'link';
  disabled?: boolean;
  className?: string;
}) => (
  <Button 
    variant={variant} 
    onClick={onClick} 
    disabled={disabled}
    className={className}
  >
    {children}
  </Button>
));

// Memoized List Item
export const MemoizedListItem = memo(({
  item,
  index,
  onSelect
}: {
  item: any;
  index: number;
  onSelect?: (item: any) => void;
}) => (
  <div 
    className="p-3 border-b hover:bg-gray-50 cursor-pointer transition-colors"
    onClick={() => onSelect?.(item)}
  >
    <div className="flex items-center justify-between">
      <span className="font-medium">{item.title || item.name || `Item ${index + 1}`}</span>
      <span className="text-sm text-gray-500">{item.status || item.date}</span>
    </div>
    {item.description && (
      <p className="text-sm text-gray-600 mt-1">{item.description}</p>
    )}
  </div>
));

MemoizedCard.displayName = 'MemoizedCard';
MemoizedButton.displayName = 'MemoizedButton';
MemoizedListItem.displayName = 'MemoizedListItem';