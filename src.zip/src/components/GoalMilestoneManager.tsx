import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Plus, Trophy, Target, CheckCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';

interface Goal {
  id: string;
  title: string;
  completion_percent: number;
}

interface Milestone {
  id: string;
  goal_id: string;
  percentage: number;
  title: string;
  description?: string;
  achieved: boolean;
  achieved_at?: string;
  goal?: Goal;
}

export default function GoalMilestoneManager() {
  const [goals, setGoals] = useState<Goal[]>([]);
  const [milestones, setMilestones] = useState<Milestone[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [milestoneForm, setMilestoneForm] = useState({
    goal_id: '',
    percentage: 25,
    title: '',
    description: ''
  });
  const { toast } = useToast();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const { data: user } = await supabase.auth.getUser();
      if (!user.user) return;

      const [goalsRes, milestonesRes] = await Promise.all([
        supabase.from('goals').select('id, title, completion_percent').eq('user_id', user.user.id),
        supabase.from('goal_milestones').select(`
          *,
          goals(id, title, completion_percent)
        `).eq('user_id', user.user.id).order('percentage', { ascending: true })
      ]);

      setGoals(goalsRes.data || []);
      setMilestones(milestonesRes.data || []);
    } catch (error) {
      console.error('Error loading data:', error);
    }
  };

  const createMilestone = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const { data: user } = await supabase.auth.getUser();
      if (!user.user) return;

      const { error } = await supabase.from('goal_milestones').insert({
        user_id: user.user.id,
        goal_id: milestoneForm.goal_id,
        percentage: milestoneForm.percentage,
        title: milestoneForm.title,
        description: milestoneForm.description,
        achieved: false
      });

      if (error) throw error;

      toast({
        title: 'Success',
        description: 'Milestone created successfully!'
      });

      setIsDialogOpen(false);
      setMilestoneForm({ goal_id: '', percentage: 25, title: '', description: '' });
      loadData();
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to create milestone',
        variant: 'destructive'
      });
    }
  };

  const deleteMilestone = async (milestoneId: string) => {
    try {
      const { error } = await supabase
        .from('goal_milestones')
        .delete()
        .eq('id', milestoneId);

      if (error) throw error;

      toast({
        title: 'Success',
        description: 'Milestone deleted successfully!'
      });

      loadData();
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to delete milestone',
        variant: 'destructive'
      });
    }
  };

  const predefinedMilestones = [
    { percentage: 25, title: 'Quarter Complete', description: 'First major milestone reached!' },
    { percentage: 50, title: 'Halfway There', description: 'You\'re making great progress!' },
    { percentage: 75, title: 'Three Quarters Done', description: 'Almost at the finish line!' },
    { percentage: 90, title: 'Nearly Complete', description: 'Just a little more to go!' }
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Trophy className="h-8 w-8 text-primary" />
          <div>
            <h2 className="text-2xl font-bold">Goal Milestones</h2>
            <p className="text-muted-foreground">Set and track progress milestones for your goals</p>
          </div>
        </div>
        
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Add Milestone
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create New Milestone</DialogTitle>
            </DialogHeader>
            <form onSubmit={createMilestone} className="space-y-4">
              <div>
                <Label htmlFor="goal">Select Goal</Label>
                <select
                  id="goal"
                  value={milestoneForm.goal_id}
                  onChange={(e) => setMilestoneForm({ ...milestoneForm, goal_id: e.target.value })}
                  className="w-full p-2 border rounded-md"
                  required
                >
                  <option value="">Choose a goal...</option>
                  {goals.map((goal) => (
                    <option key={goal.id} value={goal.id}>
                      {goal.title} ({goal.completion_percent}% complete)
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <Label htmlFor="percentage">Milestone Percentage</Label>
                <Input
                  id="percentage"
                  type="number"
                  min="1"
                  max="99"
                  value={milestoneForm.percentage}
                  onChange={(e) => setMilestoneForm({ ...milestoneForm, percentage: parseInt(e.target.value) })}
                  required
                />
              </div>

              <div>
                <Label htmlFor="title">Milestone Title</Label>
                <Input
                  id="title"
                  value={milestoneForm.title}
                  onChange={(e) => setMilestoneForm({ ...milestoneForm, title: e.target.value })}
                  placeholder="e.g., First Quarter Complete"
                  required
                />
              </div>

              <div>
                <Label htmlFor="description">Description (Optional)</Label>
                <Input
                  id="description"
                  value={milestoneForm.description}
                  onChange={(e) => setMilestoneForm({ ...milestoneForm, description: e.target.value })}
                  placeholder="Celebrate this achievement..."
                />
              </div>

              <div className="space-y-2">
                <Label>Quick Templates:</Label>
                <div className="grid grid-cols-2 gap-2">
                  {predefinedMilestones.map((preset) => (
                    <Button
                      key={preset.percentage}
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => setMilestoneForm({
                        ...milestoneForm,
                        percentage: preset.percentage,
                        title: preset.title,
                        description: preset.description
                      })}
                    >
                      {preset.percentage}% - {preset.title}
                    </Button>
                  ))}
                </div>
              </div>

              <div className="flex justify-end space-x-2">
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit">Create Milestone</Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {milestones.length === 0 ? (
        <Card>
          <CardContent className="text-center py-8">
            <Trophy className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
            <h3 className="text-lg font-semibold mb-2">No Milestones Yet</h3>
            <p className="text-muted-foreground">Create milestones to celebrate your progress along the way.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-6">
          {goals.map((goal) => {
            const goalMilestones = milestones.filter(m => m.goal_id === goal.id);
            if (goalMilestones.length === 0) return null;

            return (
              <Card key={goal.id} className="border-l-4 border-l-primary">
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>{goal.title}</span>
                    <Badge variant="secondary">{goal.completion_percent}% Complete</Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {goalMilestones.map((milestone) => (
                      <div
                        key={milestone.id}
                        className={`flex items-center justify-between p-3 border rounded-lg ${
                          milestone.achieved ? 'bg-green-50 border-green-200' : 'bg-gray-50'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          {milestone.achieved ? (
                            <CheckCircle className="h-5 w-5 text-green-600" />
                          ) : goal.completion_percent >= milestone.percentage ? (
                            <CheckCircle className="h-5 w-5 text-green-600" />
                          ) : (
                            <Target className="h-5 w-5 text-gray-400" />
                          )}
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-medium">{milestone.title}</span>
                              <Badge variant="outline" size="sm">
                                {milestone.percentage}%
                              </Badge>
                            </div>
                            {milestone.description && (
                              <p className="text-sm text-muted-foreground">{milestone.description}</p>
                            )}
                            {milestone.achieved && milestone.achieved_at && (
                              <p className="text-xs text-green-600">
                                Achieved on {new Date(milestone.achieved_at).toLocaleDateString()}
                              </p>
                            )}
                          </div>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => deleteMilestone(milestone.id)}
                          className="text-red-600 hover:text-red-800"
                        >
                          Delete
                        </Button>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}