import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAppContext } from '@/contexts/OptimizedAppContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Heart, MessageCircle, ThumbsUp, Send, Users } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';

interface Encouragement {
  id: string;
  sender_name: string;
  message: string;
  created_at: string;
  habit_name: string;
  likes_count: number;
  is_liked: boolean;
}

export const HabitEncouragement = () => {
  const { currentUser } = useAppContext();
  const [encouragements, setEncouragements] = useState<Encouragement[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [selectedHabit, setSelectedHabit] = useState('');
  const [myHabits, setMyHabits] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchEncouragements();
    fetchMyHabits();
  }, []);

  const fetchMyHabits = async () => {
    try {
      const { data } = await supabase
        .from('habits')
        .select('*')
        .eq('user_id', currentUser?.id);
      setMyHabits(data || []);
    } catch (error) {
      console.error('Error fetching habits:', error);
    }
  };

  const fetchEncouragements = async () => {
    try {
      const { data } = await supabase
        .from('habit_encouragements')
        .select(`
          *,
          sender:profiles!habit_encouragements_sender_id_fkey(full_name),
          likes:encouragement_likes(count)
        `)
        .order('created_at', { ascending: false })
        .limit(20);

      const encouragementsWithLikes = await Promise.all(
        (data || []).map(async (enc) => {
          const { data: userLike } = await supabase
            .from('encouragement_likes')
            .select('id')
            .eq('encouragement_id', enc.id)
            .eq('user_id', currentUser?.id)
            .single();

          return {
            ...enc,
            sender_name: enc.sender?.full_name || 'Anonymous',
            likes_count: enc.likes?.[0]?.count || 0,
            is_liked: !!userLike
          };
        })
      );

      setEncouragements(encouragementsWithLikes);
    } catch (error) {
      console.error('Error fetching encouragements:', error);
    } finally {
      setLoading(false);
    }
  };

  const sendEncouragement = async () => {
    if (!newMessage.trim() || !selectedHabit) return;

    try {
      const { error } = await supabase
        .from('habit_encouragements')
        .insert({
          sender_id: currentUser?.id,
          message: newMessage,
          habit_name: selectedHabit,
          created_at: new Date().toISOString()
        });

      if (error) throw error;

      setNewMessage('');
      setSelectedHabit('');
      fetchEncouragements();
      
      toast({
        title: "Encouragement Sent!",
        description: "Your message has been shared with the community.",
      });
    } catch (error) {
      console.error('Error sending encouragement:', error);
    }
  };

  const toggleLike = async (encouragementId: string, isLiked: boolean) => {
    try {
      if (isLiked) {
        await supabase
          .from('encouragement_likes')
          .delete()
          .eq('encouragement_id', encouragementId)
          .eq('user_id', currentUser?.id);
      } else {
        await supabase
          .from('encouragement_likes')
          .insert({
            encouragement_id: encouragementId,
            user_id: currentUser?.id
          });
      }

      fetchEncouragements();
    } catch (error) {
      console.error('Error toggling like:', error);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-[#001B30]">Habit Encouragement</h2>
        <p className="text-[#7E8E9D]">Share and receive motivation from the community</p>
      </div>

      {/* Send Encouragement */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Heart className="w-5 h-5 text-red-500" />
            Send Encouragement
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <select
            value={selectedHabit}
            onChange={(e) => setSelectedHabit(e.target.value)}
            className="w-full p-2 border rounded-md"
          >
            <option value="">Select a habit...</option>
            {myHabits.map((habit) => (
              <option key={habit.id} value={habit.name}>{habit.name}</option>
            ))}
          </select>
          <Textarea
            placeholder="Share some encouragement..."
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
          />
          <Button 
            onClick={sendEncouragement}
            disabled={!newMessage.trim() || !selectedHabit}
            className="bg-[#596D59] hover:bg-[#596D59]/90"
          >
            <Send className="w-4 h-4 mr-2" />
            Send Encouragement
          </Button>
        </CardContent>
      </Card>

      {/* Encouragements Feed */}
      <div className="space-y-4">
        {encouragements.map((enc) => (
          <Card key={enc.id}>
            <CardContent className="p-4">
              <div className="flex justify-between items-start mb-3">
                <div>
                  <p className="font-medium text-[#001B30]">{enc.sender_name}</p>
                  <Badge variant="outline" className="text-xs mt-1">
                    {enc.habit_name}
                  </Badge>
                </div>
                <p className="text-xs text-[#7E8E9D]">
                  {new Date(enc.created_at).toLocaleDateString()}
                </p>
              </div>
              
              <p className="text-[#2C2C44] mb-3">{enc.message}</p>
              
              <div className="flex items-center gap-4">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => toggleLike(enc.id, enc.is_liked)}
                  className={enc.is_liked ? 'text-red-500' : 'text-[#7E8E9D]'}
                >
                  <ThumbsUp className="w-4 h-4 mr-1" />
                  {enc.likes_count}
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {encouragements.length === 0 && !loading && (
        <Card>
          <CardContent className="p-8 text-center">
            <MessageCircle className="w-12 h-12 text-[#7E8E9D] mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-[#001B30] mb-2">No Encouragements Yet</h3>
            <p className="text-[#7E8E9D]">Be the first to share some motivation!</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
};