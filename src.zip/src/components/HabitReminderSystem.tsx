import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Bell, Clock, Mail, Smartphone, Settings } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAppContext } from '@/contexts/OptimizedAppContext';
import { toast } from '@/components/ui/use-toast';

interface NotificationSettings {
  habit_reminders: boolean;
  goal_reminders: boolean;
  check_in_notifications: boolean;
  email_notifications: boolean;
  push_notifications: boolean;
  reminder_time: string;
}

export const HabitReminderSystem: React.FC = () => {
  const { currentUser } = useAppContext();
  const [settings, setSettings] = useState<NotificationSettings>({
    habit_reminders: true,
    goal_reminders: true,
    check_in_notifications: true,
    email_notifications: true,
    push_notifications: false,
    reminder_time: '09:00'
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('notification_settings')
        .eq('id', currentUser?.id)
        .single();

      if (error) throw error;

      if (data?.notification_settings) {
        setSettings(prev => ({ ...prev, ...data.notification_settings }));
      }
    } catch (error) {
      console.error('Error loading notification settings:', error);
    }
  };

  const updateSettings = async (newSettings: Partial<NotificationSettings>) => {
    setLoading(true);
    try {
      const updatedSettings = { ...settings, ...newSettings };
      
      const { error } = await supabase
        .from('profiles')
        .update({ 
          notification_settings: updatedSettings,
          email_notifications: updatedSettings.email_notifications
        })
        .eq('id', currentUser?.id);

      if (error) throw error;

      setSettings(updatedSettings);
      
      toast({
        title: "Settings Updated",
        description: "Your notification preferences have been saved.",
      });

      // Schedule reminders if enabled
      if (updatedSettings.habit_reminders || updatedSettings.goal_reminders) {
        await scheduleReminders(updatedSettings);
      }
    } catch (error) {
      console.error('Error updating settings:', error);
      toast({
        title: "Error",
        description: "Failed to update notification settings.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const scheduleReminders = async (settings: NotificationSettings) => {
    try {
      // Schedule daily habit reminders
      if (settings.habit_reminders) {
        await supabase.functions.invoke('habit-reminders', {
          body: { 
            userId: currentUser?.id,
            scheduleTime: settings.reminder_time,
            enableEmail: settings.email_notifications
          }
        });
      }

      // Schedule goal reminders
      if (settings.goal_reminders) {
        await supabase.functions.invoke('goal-reminders', {
          body: { 
            userId: currentUser?.id,
            scheduleTime: settings.reminder_time,
            enableEmail: settings.email_notifications
          }
        });
      }
    } catch (error) {
      console.error('Error scheduling reminders:', error);
    }
  };

  const testNotification = async () => {
    try {
      await supabase.functions.invoke('send-email-notifications', {
        body: {
          userId: currentUser?.id,
          type: 'test',
          title: 'Test Notification',
          message: 'This is a test notification from AccLounge!'
        }
      });

      toast({
        title: "Test Sent",
        description: "Check your email and notifications for the test message.",
      });
    } catch (error) {
      console.error('Error sending test notification:', error);
      toast({
        title: "Error",
        description: "Failed to send test notification.",
        variant: "destructive"
      });
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Bell className="w-5 h-5" />
          Notification Settings
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Reminder Types */}
        <div className="space-y-4">
          <h4 className="font-medium text-sm">Reminder Types</h4>
          
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-[#596D59]" />
                <span className="text-sm font-medium">Daily Habit Reminders</span>
              </div>
              <p className="text-xs text-muted-foreground">Get reminded to complete your daily habits</p>
            </div>
            <Switch
              checked={settings.habit_reminders}
              onCheckedChange={(checked) => updateSettings({ habit_reminders: checked })}
              disabled={loading}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-[#596D59]" />
                <span className="text-sm font-medium">Goal Reminders</span>
              </div>
              <p className="text-xs text-muted-foreground">Get reminded about your goal progress</p>
            </div>
            <Switch
              checked={settings.goal_reminders}
              onCheckedChange={(checked) => updateSettings({ goal_reminders: checked })}
              disabled={loading}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <Bell className="w-4 h-4 text-[#596D59]" />
                <span className="text-sm font-medium">Check-in Notifications</span>
              </div>
              <p className="text-xs text-muted-foreground">Get notified of new messages from coaches</p>
            </div>
            <Switch
              checked={settings.check_in_notifications}
              onCheckedChange={(checked) => updateSettings({ check_in_notifications: checked })}
              disabled={loading}
            />
          </div>
        </div>

        {/* Delivery Methods */}
        <div className="space-y-4">
          <h4 className="font-medium text-sm">Delivery Methods</h4>
          
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-[#596D59]" />
                <span className="text-sm font-medium">Email Notifications</span>
              </div>
              <p className="text-xs text-muted-foreground">Receive notifications via email</p>
            </div>
            <Switch
              checked={settings.email_notifications}
              onCheckedChange={(checked) => updateSettings({ email_notifications: checked })}
              disabled={loading}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-[#596D59]" />
                <span className="text-sm font-medium">Push Notifications</span>
                <Badge variant="secondary" className="text-xs">Coming Soon</Badge>
              </div>
              <p className="text-xs text-muted-foreground">Receive push notifications on your device</p>
            </div>
            <Switch
              checked={settings.push_notifications}
              onCheckedChange={(checked) => updateSettings({ push_notifications: checked })}
              disabled={true}
            />
          </div>
        </div>

        {/* Reminder Time */}
        <div className="space-y-4">
          <h4 className="font-medium text-sm">Reminder Time</h4>
          <div className="flex items-center gap-3">
            <Clock className="w-4 h-4 text-[#596D59]" />
            <input
              type="time"
              value={settings.reminder_time}
              onChange={(e) => updateSettings({ reminder_time: e.target.value })}
              className="px-3 py-2 border rounded-md text-sm"
              disabled={loading}
            />
            <span className="text-xs text-muted-foreground">Daily reminder time</span>
          </div>
        </div>

        {/* Test Button */}
        <div className="pt-4 border-t">
          <Button
            variant="outline"
            onClick={testNotification}
            disabled={loading}
            className="w-full"
          >
            <Settings className="w-4 h-4 mr-2" />
            Send Test Notification
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};