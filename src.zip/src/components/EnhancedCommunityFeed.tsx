import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Heart, MessageCircle, Share2, Users, Target, Zap, BookOpen } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import UniversalModerationActions from './UniversalModerationActions';
interface Post {
  id: string;
  user_id: string;
  author_name: string;
  content: string;
  category: string;
  likes: number;
  comments: number;
  is_intro_post: boolean;
  created_at: string;
}

const categoryIcons = {
  'Mindset': BookOpen,
  'Gather': Users,
  'Goals': Target,
  'Habits': Zap
};

const categoryColors = {
  'Mindset': 'bg-purple-100 text-purple-800',
  'Gather': 'bg-blue-100 text-blue-800',
  'Goals': 'bg-green-100 text-green-800',
  'Habits': 'bg-orange-100 text-orange-800'
};

export default function EnhancedCommunityFeed() {
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchPosts();
  }, []);

  const fetchPosts = async () => {
    try {
      setLoading(true);
      setError(null);
      
      const { data, error: fetchError } = await supabase
        .from('posts')
        .select('*')
        .eq('recovery_status', 'active')
        .order('created_at', { ascending: false })
        .limit(20);

      if (fetchError) {
        throw fetchError;
      }

      setPosts(data || []);
    } catch (err: any) {
      console.error('Error fetching posts:', err);
      setError(err.message || 'Failed to load posts');
    } finally {
      setLoading(false);
    }
  };

  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);

    if (diffInSeconds < 60) return 'Just now';
    if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)}m ago`;
    if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)}h ago`;
    return `${Math.floor(diffInSeconds / 86400)}d ago`;
  };

  const handleLike = async (postId: string) => {
    // Optimistic update
    setPosts(prev => prev.map(post => 
      post.id === postId ? { ...post, likes: post.likes + 1 } : post
    ));
  };

  if (loading) {
    return (
      <div className="space-y-4">
        {[...Array(3)].map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardHeader className="flex flex-row items-center space-y-0 pb-2">
              <div className="w-10 h-10 bg-gray-200 rounded-full"></div>
              <div className="ml-4 space-y-2 flex-1">
                <div className="h-4 bg-gray-200 rounded w-1/4"></div>
                <div className="h-3 bg-gray-200 rounded w-1/6"></div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="h-4 bg-gray-200 rounded"></div>
                <div className="h-4 bg-gray-200 rounded w-3/4"></div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (error) {
    return (
      <Card className="p-6 text-center">
        <p className="text-red-600 mb-4">Error loading community feed: {error}</p>
        <Button onClick={fetchPosts} variant="outline">
          Try Again
        </Button>
      </Card>
    );
  }

  if (posts.length === 0) {
    return (
      <Card className="p-8 text-center">
        <Users className="w-12 h-12 text-gray-400 mx-auto mb-4" />
        <h3 className="text-lg font-semibold text-gray-900 mb-2">No posts yet</h3>
        <p className="text-gray-600 mb-4">Be the first to share something with the community!</p>
        <Button onClick={fetchPosts} variant="outline">
          Refresh Feed
        </Button>
      </Card>
    );
  }

  return (
    <div className="space-y-6 text-left">{/* Left align all content */}
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900">Community Feed</h2>
        <Button onClick={fetchPosts} variant="outline" size="sm">
          Refresh
        </Button>
      </div>

      <div className="space-y-4">
        {posts.map((post) => {
          const CategoryIcon = categoryIcons[post.category as keyof typeof categoryIcons] || Users;
          const categoryColor = categoryColors[post.category as keyof typeof categoryColors] || 'bg-gray-100 text-gray-800';
          return (
            <Card key={post.id} className="hover:shadow-md transition-shadow">
              <CardHeader className="flex flex-row items-center space-y-0 pb-2">
                <Avatar className="w-10 h-10">
                  <AvatarFallback className="bg-gradient-to-br from-purple-400 to-pink-400 text-white">
                    {post.author_name?.charAt(0)?.toUpperCase() || 'U'}
                  </AvatarFallback>
                </Avatar>
                <div className="ml-4 flex-1">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <h4 className="font-semibold text-gray-900">{post.author_name}</h4>
                      {post.is_intro_post && (
                        <Badge variant="secondary" className="text-xs">
                          👋 New Member
                        </Badge>
                      )}
                    </div>
                    <UniversalModerationActions
                      postId={post.id}
                      isPinned={post.is_pinned}
                      tableName="posts"
                      onPostUpdated={fetchPosts}
                      onPostDeleted={fetchPosts}
                    />
                  </div>
                  <div className="flex items-center space-x-2 text-sm text-gray-500">
                    <Badge variant="outline" className={`text-xs ${categoryColor}`}>
                      <CategoryIcon className="w-3 h-3 mr-1" />
                      {post.category}
                    </Badge>
                    <span>•</span>
                    <span>{formatTimeAgo(post.created_at)}</span>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-gray-800 whitespace-pre-wrap leading-relaxed">
                  {post.content}
                </p>
                <div className="flex items-center justify-between mt-4 pt-3 border-t border-gray-100">
                  <div className="flex items-center space-x-4">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleLike(post.id)}
                      className="text-gray-600 hover:text-red-500 hover:bg-red-50"
                    >
                      <Heart className="w-4 h-4 mr-1" />
                      {post.likes}
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-gray-600 hover:text-blue-500 hover:bg-blue-50"
                    >
                      <MessageCircle className="w-4 h-4 mr-1" />
                      {post.comments}
                    </Button>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-gray-600 hover:text-green-500 hover:bg-green-50"
                  >
                    <Share2 className="w-4 h-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}