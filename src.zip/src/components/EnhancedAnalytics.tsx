import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Users, Target, TrendingUp, Activity, Users as GroupIcon } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import AdvancedAdminAnalytics from './AdvancedAdminAnalytics';
interface AnalyticsData {
  totalUsers: number;
  totalGoals: number;
  totalHabits: number;
  totalSocialHabits: number;
  totalGroups: number;
  activeGroups: number;
  completedGoals: number;
  activeHabits: number;
  goalCategories: Record<string, number>;
  habitCategories: Record<string, number>;
}

const EnhancedAnalytics: React.FC = () => {
  const [analytics, setAnalytics] = useState<AnalyticsData>({
    totalUsers: 0,
    totalGoals: 0,
    totalHabits: 0,
    totalSocialHabits: 0,
    totalGroups: 0,
    activeGroups: 0,
    completedGoals: 0,
    activeHabits: 0,
    goalCategories: {},
    habitCategories: {}
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchAnalytics();
  }, []);

  const fetchAnalytics = async () => {
    try {
      console.log('Loading comprehensive analytics from database...');
      
      // Fetch all data in parallel with correct column names
      const [
        { data: profiles, error: profilesError },
        { data: goals, error: goalsError },
        { data: habits, error: habitsError },
        { data: groups, error: groupsError },
        { data: members, error: membersError }
      ] = await Promise.all([
        supabase.from('profiles').select('id, full_name'),
        supabase.from('goals').select('id, category, completed, status'),
        supabase.from('habits').select('id, is_active, title'),
        supabase.from('acircle_groups').select('id, name, is_archived'),
        supabase.from('acircle_members').select('id, group_id, user_id')
      ]);

      if (profilesError) console.error('Profiles error:', profilesError);
      if (goalsError) console.error('Goals error:', goalsError);
      if (habitsError) console.error('Habits error:', habitsError);
      if (groupsError) console.error('Groups error:', groupsError);
      if (membersError) console.error('Members error:', membersError);

      // Calculate metrics
      const totalUsers = profiles?.length || 0;
      const totalGoals = goals?.length || 0;
      const totalHabits = habits?.length || 0;
      const totalGroups = groups?.length || 0;
      const activeGroups = groups?.filter(g => !g.is_archived)?.length || 0;
      const completedGoals = goals?.filter(g => g.completed || g.status === 'completed')?.length || 0;
      const activeHabits = habits?.filter(h => h.is_active)?.length || 0;
      
      // Calculate social habits (users who are in groups)
      const usersInGroups = new Set(members?.map(m => m.user_id) || []);
      const totalSocialHabits = usersInGroups.size;

      // Goal categories
      const goalCategories: Record<string, number> = {};
      goals?.forEach(goal => {
        const category = goal.category || 'uncategorized';
        goalCategories[category] = (goalCategories[category] || 0) + 1;
      });

      // Habit categories (simplified since no category column exists)
      const habitCategories: Record<string, number> = {};
      if (totalHabits > 0) {
        habitCategories['personal'] = totalHabits;
      }
      if (totalSocialHabits > 0) {
        habitCategories['social/group'] = totalSocialHabits;
      }

      const analyticsData: AnalyticsData = {
        totalUsers,
        totalGoals,
        totalHabits,
        totalSocialHabits,
        totalGroups,
        activeGroups,
        completedGoals,
        activeHabits,
        goalCategories,
        habitCategories
      };

      console.log('Comprehensive analytics loaded:', analyticsData);
      setAnalytics(analyticsData);
    } catch (error) {
      console.error('Error fetching analytics:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
          {[...Array(5)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-6">
                <div className="h-4 bg-gray-200 rounded mb-2"></div>
                <div className="h-8 bg-gray-200 rounded"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <Tabs defaultValue="overview" className="w-full">
      <TabsList className="grid w-full grid-cols-2">
        <TabsTrigger value="overview">Overview</TabsTrigger>
        <TabsTrigger value="advanced">Advanced Analytics</TabsTrigger>
      </TabsList>

      <TabsContent value="overview" className="space-y-6">
        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <Users className="h-4 w-4 text-muted-foreground" />
                <div className="ml-2">
                  <p className="text-sm font-medium">Total Users</p>
                  <p className="text-2xl font-bold">{analytics.totalUsers}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <Target className="h-4 w-4 text-muted-foreground" />
                <div className="ml-2">
                  <p className="text-sm font-medium">Goals</p>
                  <p className="text-2xl font-bold">{analytics.totalGoals}</p>
                  <p className="text-xs text-green-600">
                    {analytics.completedGoals} completed ({analytics.totalGoals > 0 ? Math.round((analytics.completedGoals / analytics.totalGoals) * 100) : 0}%)
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
                <div className="ml-2">
                  <p className="text-sm font-medium">All Habits</p>
                  <p className="text-2xl font-bold">{analytics.totalHabits}</p>
                  <p className="text-xs text-green-600">
                    {analytics.activeHabits} active ({analytics.totalHabits > 0 ? Math.round((analytics.activeHabits / analytics.totalHabits) * 100) : 0}%)
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <Activity className="h-4 w-4 text-muted-foreground" />
                <div className="ml-2">
                  <p className="text-sm font-medium">Social Habits</p>
                  <p className="text-2xl font-bold text-blue-600">{analytics.totalSocialHabits}</p>
                  <p className="text-xs text-blue-600">Group-based habits</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <GroupIcon className="h-4 w-4 text-muted-foreground" />
                <div className="ml-2">
                  <p className="text-sm font-medium">Groups</p>
                  <p className="text-2xl font-bold">{analytics.totalGroups}</p>
                  <p className="text-xs text-green-600">{analytics.activeGroups} active</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Categories */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Goal Categories</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {Object.entries(analytics.goalCategories).map(([category, count]) => (
                  <div key={category} className="flex justify-between items-center">
                    <span className="text-sm">{category}</span>
                    <Badge variant="secondary">{count}</Badge>
                  </div>
                ))}
                {Object.keys(analytics.goalCategories).length === 0 && (
                  <p className="text-sm text-muted-foreground">No goal categories found</p>
                )}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Habit Categories</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {Object.entries(analytics.habitCategories).map(([category, count]) => (
                  <div key={category} className="flex justify-between items-center">
                    <span className="text-sm">{category}</span>
                    <Badge variant="secondary">{count}</Badge>
                  </div>
                ))}
                {Object.keys(analytics.habitCategories).length === 0 && (
                  <p className="text-sm text-muted-foreground">No habit categories found</p>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </TabsContent>

      <TabsContent value="advanced">
        <AdvancedAdminAnalytics />
      </TabsContent>
    </Tabs>
  );
};

export default EnhancedAnalytics;