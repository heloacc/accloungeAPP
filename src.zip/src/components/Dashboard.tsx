import React, { useState, useEffect, memo, useMemo, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useAppContext } from '@/contexts/OptimizedAppContext';
import { supabase } from '@/lib/supabase';
import { MessageCircle, Users, Trophy, Target, Flame, TrendingUp, Bell, CheckCircle, Clock, AlertTriangle } from 'lucide-react';
import { usePerformanceMonitor, useThrottle } from '@/hooks/usePerformanceOptimization';
import { MomentumSnapshot } from './MomentumSnapshot';
import { DynamicCoachTips } from './DynamicCoachTips';
import { PersonalCheckIns } from './PersonalCheckIns';
import { AchievementsBadges } from './AchievementsBadges';
import { CommunityFeed } from './CommunityFeed';
import { QuickActions } from './QuickActions';
import { DashboardSkeleton } from './ui/skeleton-loaders';
interface DashboardProps {
  onNavigate?: (tab: string) => void;
}

const Dashboard = ({ onNavigate }: DashboardProps) => {
  const { achievements, currentUser, notifications } = useAppContext();
  const [dashboardData, setDashboardData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [lastFetchTime, setLastFetchTime] = useState<number>(0);
  
  // Performance monitoring
  const { renderCount, measureRender } = usePerformanceMonitor('Dashboard');
  
  // Memoized calculations to prevent unnecessary re-renders
  const unlockedAchievements = useMemo(() => 
    achievements.filter(a => a.unlocked).length, 
    [achievements]
  );
  
  const unreadNotifications = useMemo(() => 
    notifications.filter(n => !n.read).length, 
    [notifications]
  );

  // Throttled data fetching to prevent excessive API calls
  const throttledFetch = useThrottle(async (force = false) => {
    const renderTime = measureRender(async () => {
      await fetchDashboardData(force);
    });
    
    if (renderTime > 100) {
      console.warn(`Dashboard data fetch took ${renderTime.toFixed(2)}ms`);
    }
  }, 2000);

  // Memoized fetch function to prevent unnecessary re-renders
  const fetchDashboardData = useCallback(async (force = false) => {
    const now = Date.now();
    // Prevent fetching more than once every 2 seconds unless forced
    if (!force && now - lastFetchTime < 2000) {
      return;
    }

    try {
      setLoading(true);
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        setDashboardData(null);
        setLoading(false);
        return;
      }

      // Fetch data directly from database tables
      const [habitsRes, goalsRes] = await Promise.all([
        supabase
          .from('habits')
          .select('id, title, current_streak, is_active, user_id, linked_goal_id')
          .eq('user_id', user.id)
          .eq('is_active', true)
          .limit(10),
        supabase
          .from('goals')
          .select('id, title, target_date, status, user_id, updated_at')
          .eq('user_id', user.id)
          .eq('status', 'active')
          .limit(10)
      ]);

      // Process the data
      const habits = habitsRes.data || [];
      const goals = goalsRes.data || [];
      
      const dashboardData = {
        habits: habits.map(habit => ({
          ...habit,
          done_today: false, // Default since we don't have habit_logs
          linked_goal_title: goals.find(g => g.id === habit.linked_goal_id)?.title || null
        })),
        goals: goals.map(goal => ({
          ...goal,
          progress_percent: 25, // Default progress
          state: 'active',
          tasks_completed_count: 0,
          linked_habits_count: habits.filter(h => h.linked_goal_id === goal.id).length
        })),
        stats: {
          current_streak: Math.max(...habits.map(h => h.current_streak), 0),
          consistency_score: 50 // Default consistency
        },
        user: {
          display_name: user.user_metadata?.full_name || user.email?.split('@')[0] || 'User'
        }
      };
      
      setDashboardData(dashboardData);
      setLastFetchTime(now);
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
      // Set minimal fallback data instead of clearing
      setDashboardData({
        habits: [],
        goals: [],
        stats: { current_streak: 0, consistency_score: 0 },
        user: { display_name: 'User' }
      });
    } finally {
      setLoading(false);
    }
  }, [lastFetchTime]);

  // Only fetch on initial mount and when currentUser actually changes
  useEffect(() => {
    if (currentUser?.id) {
      fetchDashboardData(true); // Force initial fetch
    } else {
      setDashboardData(null);
      setLoading(false);
    }
  }, [currentUser?.id]); // Only depend on user ID, not the entire user object

  // Optimized habit completion listener with proper cleanup
  useEffect(() => {
    const handleHabitCompleted = () => {
      // Immediate refetch without delay to improve UI responsiveness
      fetchDashboardData();
    };

    window.addEventListener('habitCompleted', handleHabitCompleted);
    return () => {
      window.removeEventListener('habitCompleted', handleHabitCompleted);
    };
  }, [fetchDashboardData]); // Include fetchDashboardData in dependencies

  const getGoalStateMessage = (goal: any) => {
    switch (goal.state) {
      case 'not_started':
        return `Ready to start! Create your first task.`;
      case 'overdue':
        return `This goal is overdue. Want to set a catch-up plan?`;
      case 'inactive':
        return `Your ${goal.title} hasn't moved in a week — want to restart your streak?`;
      case 'completed':
        return `🎉 Goal completed! Great work.`;
      default:
        return `Great work! You've moved your goal forward recently.`;
    }
  };

  const getGoalStateIcon = (goal: any) => {
    switch (goal.state) {
      case 'overdue':
        return <AlertTriangle className="h-4 w-4 text-red-500" />;
      case 'inactive':
        return <Clock className="h-4 w-4 text-yellow-500" />;
      case 'completed':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      default:
        return <Target className="h-4 w-4 text-blue-500" />;
    }
  };

  if (loading) {
    return <DashboardSkeleton />;
  }

  return (
    <div className="space-y-6 p-4 max-w-full overflow-hidden">
      {/* Momentum Snapshot */}
      {dashboardData && (
        <MomentumSnapshot
          userName={currentUser?.name?.split(' ')[0] || currentUser?.user_metadata?.full_name?.split(' ')[0] || dashboardData.user.display_name?.split(' ')[0] || dashboardData.user.full_name?.split(' ')[0] || "User"}
          streakDays={dashboardData.stats.current_streak}
          consistencyScore={dashboardData.stats.consistency_score}
          backgroundImage="https://images.unsplash.com/photo-1506905925346-21bda4d32df4"
        />
      )}

      {/* Today's Habits */}
      <Card className="border-[#596D59] border-l-4">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-sm">
            <Flame className="h-4 w-4 text-[#596D59]" />
            Today's Habits
          </CardTitle>
        </CardHeader>
        <CardContent>
          {dashboardData?.habits?.length > 0 ? (
            <div className="space-y-2">
              {dashboardData.habits.map((habit: any) => (
                <div key={habit.id} className="flex items-center justify-between p-2 rounded-lg bg-gray-50">
                  <div className="flex-1">
                    <p className="text-sm font-medium">{habit.title}</p>
                    <div className="text-xs text-gray-600 space-y-1">
                      <p>{habit.current_streak > 0 ? `${habit.current_streak}-day streak` : 'Start your streak'}</p>
                      {habit.linked_goal_title && (
                        <p>Linked to: {habit.linked_goal_title}</p>
                      )}
                    </div>
                  </div>
                  <CheckCircle 
                    className={`h-5 w-5 ${habit.done_today ? 'text-green-500' : 'text-gray-300'}`}
                  />
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-gray-600">No habits yet. Create your first habit!</p>
          )}
        </CardContent>
      </Card>

      {/* Goals in Progress */}
      <Card className="border-yellow-500 border-l-4">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-sm">
            <Target className="h-4 w-4 text-yellow-500" />
            Goals in Progress
          </CardTitle>
        </CardHeader>
        <CardContent>
          {dashboardData?.goals?.length > 0 ? (
            <div className="space-y-4">
              {dashboardData.goals.map((goal: any) => (
                <div key={goal.id} className="p-3 rounded-lg border">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-medium">{goal.title}</h3>
                    {getGoalStateIcon(goal)}
                  </div>
                  <div className="text-sm text-gray-600 mb-2">
                    ✅{goal.tasks_completed_count} tasks • {goal.progress_percent}% complete
                  </div>
                  <p className="text-sm text-gray-700 mb-2">
                    Fueled by {goal.linked_habits_count} daily habits
                  </p>
                  <p className="text-sm text-blue-600">
                    {getGoalStateMessage(goal)}
                  </p>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-gray-600">No goals yet. Create your first goal!</p>
          )}
        </CardContent>
      </Card>
      {/* Lounger Tip of the day */}
      <DynamicCoachTips />

      {/* Personal Check-ins */}
      <PersonalCheckIns onNavigate={onNavigate} />

      {/* Your Wins */}
      <AchievementsBadges />

      {/* Check in with others */}
      <CommunityFeed 
        feedItems={[
          { id: '1', userName: 'Sarah', achievement: 'completed her morning routine!', timeAgo: '2 hours ago', emoji: '🌅' },
          { id: '2', userName: 'Mike', achievement: 'hit his 30-day streak!', timeAgo: '4 hours ago', emoji: '🔥' },
          { id: '3', userName: 'Community', achievement: 'Welcome to our newest members!', timeAgo: '6 hours ago', emoji: '👋' }
        ]}
        groupSprints={[
          { id: '1', name: 'Morning Routine Masters', members: 24, category: 'Habits', startDate: 'Monday' },
          { id: '2', name: 'Fitness Challenge', members: 18, category: 'Health', startDate: 'Next Week' }
        ]}
        onNavigate={onNavigate}
      />

      {/* Quick Actions */}
      <QuickActions onNavigate={onNavigate} />
    </div>
  );
};

export default memo(Dashboard);