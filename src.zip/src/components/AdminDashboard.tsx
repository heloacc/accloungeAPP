import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import { supabase } from '../lib/supabase';
import { useUserRole } from '../hooks/useUserRole';
import { DatabasePerformanceMonitor } from './DatabasePerformanceMonitor';
import ComprehensiveUserManagement from './ComprehensiveUserManagement';
import BulkUserImport from './BulkUserImport';
import AdminTierManager from './AdminTierManager';
import EnhancedAnalytics from './EnhancedAnalytics';
import AllGroupsManager from './AllGroupsManager';
import EnhancedAdminCompetitionManager from './EnhancedAdminCompetitionManager';
import CompetitionAnalyticsDashboard from './CompetitionAnalyticsDashboard';
import { CompetitionErrorBoundary } from './CompetitionErrorBoundary';
import TierAssignmentManager from './TierAssignmentManager';

import { 
  Users, 
  Shield, 
  Settings, 
  BarChart3, 
  Database,
  AlertTriangle,
  TrendingUp,
  Upload,
  Crown,
  UserCog
} from 'lucide-react';

export const AdminDashboard: React.FC = () => {
  const { role, loading } = useUserRole();
  const [activeTab, setActiveTab] = useState('overview');
  const [stats, setStats] = useState({
    totalUsers: 0,
    activeGroups: 0,
    totalPosts: 0,
    systemHealth: 'good'
  });

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = async () => {
    try {
      const [usersRes, groupsRes, postsRes] = await Promise.all([
        supabase.from('profiles').select('id', { count: 'exact' }),
        supabase.from('acircle_groups').select('id', { count: 'exact' }),
        supabase.from('posts').select('id', { count: 'exact' })
      ]);

      setStats({
        totalUsers: usersRes.count || 0,
        activeGroups: groupsRes.count || 0,
        totalPosts: postsRes.count || 0,
        systemHealth: 'good'
      });
    } catch (error) {
      console.error('Failed to fetch admin stats:', error);
    }
  };

  if (loading) {
    return <div className="flex justify-center p-8">Loading admin dashboard...</div>;
  }

  if (role !== 'admin') {
    return (
      <div className="flex justify-center items-center h-64">
        <p className="text-lg text-gray-600">Access denied. Admin privileges required.</p>
      </div>
    );
  }

  return (
    <div className="p-3 sm:p-6 space-y-4 sm:space-y-6">
      <div className="flex items-center gap-3">
        <Shield className="h-6 w-6 sm:h-8 sm:w-8 text-primary" />
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold">Admin Dashboard</h1>
          <p className="text-sm sm:text-base text-muted-foreground">Complete system administration and management</p>
        </div>
      </div>
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2 sm:grid-cols-4 lg:grid-cols-10 h-auto">
          <TabsTrigger value="overview" className="text-xs sm:text-sm px-2 py-2">Overview</TabsTrigger>
          <TabsTrigger value="users" className="text-xs sm:text-sm px-2 py-2">Users</TabsTrigger>
          <TabsTrigger value="groups" className="text-xs sm:text-sm px-2 py-2">Groups</TabsTrigger>
          <TabsTrigger value="competitions" className="text-xs sm:text-sm px-2 py-2">Competitions</TabsTrigger>
          <TabsTrigger value="comp-analytics" className="text-xs sm:text-sm px-2 py-2">Comp Analytics</TabsTrigger>
          <TabsTrigger value="tiers" className="text-xs sm:text-sm px-2 py-2">Tiers</TabsTrigger>
          <TabsTrigger value="assign" className="text-xs sm:text-sm px-2 py-2">Assign</TabsTrigger>
          <TabsTrigger value="analytics" className="text-xs sm:text-sm px-2 py-2">Analytics</TabsTrigger>
          <TabsTrigger value="import" className="text-xs sm:text-sm px-2 py-2">Import</TabsTrigger>
          <TabsTrigger value="performance" className="text-xs sm:text-sm px-2 py-2">Performance</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Total Users</p>
                    <p className="text-2xl font-bold">{stats.totalUsers}</p>
                  </div>
                  <Users className="h-8 w-8 text-blue-500" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Active Groups</p>
                    <p className="text-2xl font-bold">{stats.activeGroups}</p>
                  </div>
                  <Shield className="h-8 w-8 text-green-500" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Total Posts</p>
                    <p className="text-2xl font-bold">{stats.totalPosts}</p>
                  </div>
                  <BarChart3 className="h-8 w-8 text-purple-500" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">System Health</p>
                    <Badge variant="secondary" className="bg-green-100 text-green-800">
                      {stats.systemHealth}
                    </Badge>
                  </div>
                  <TrendingUp className="h-8 w-8 text-orange-500" />
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="users">
          <ComprehensiveUserManagement />
        </TabsContent>

        <TabsContent value="groups">
          <AllGroupsManager />
        </TabsContent>

        <TabsContent value="competitions">
          <CompetitionErrorBoundary>
            <EnhancedAdminCompetitionManager />
          </CompetitionErrorBoundary>
        </TabsContent>

        <TabsContent value="comp-analytics">
          <CompetitionAnalyticsDashboard />
        </TabsContent>

        <TabsContent value="tiers">
          <AdminTierManager />
        </TabsContent>
        <TabsContent value="assign">
          <TierAssignmentManager />
        </TabsContent>

        <TabsContent value="analytics">
          <EnhancedAnalytics />
        </TabsContent>

        <TabsContent value="import">
          <BulkUserImport />
        </TabsContent>

        <TabsContent value="performance">
          <DatabasePerformanceMonitor />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default AdminDashboard;