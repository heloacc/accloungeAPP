import React from 'react';
import { useAppContext } from '@/contexts/AppContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Target, CheckSquare, BarChart3, TrendingUp } from 'lucide-react';

const TrackMyProgress = () => {
  const { setActiveTab } = useAppContext();

  const progressCards = [
    {
      id: 'habits',
      title: 'Habit Tracker',
      description: 'Build and maintain daily habits that drive your success',
      icon: Target,
      color: 'bg-blue-500',
      stats: 'Track daily progress'
    },
    {
      id: 'goals',
      title: 'Goal Tracker', 
      description: 'Set, track, and achieve your personal and professional goals',
      icon: CheckSquare,
      color: 'bg-green-500',
      stats: 'Measure achievements'
    }
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3 mb-6">
        <BarChart3 className="h-8 w-8 text-blue-600" />
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Track My Progress</h1>
          <p className="text-gray-600">Monitor your habits and goals to stay accountable</p>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        {progressCards.map((card) => {
          const IconComponent = card.icon;
          return (
            <Card key={card.id} className="hover:shadow-lg transition-shadow cursor-pointer">
              <CardHeader className="pb-3">
                <div className="flex items-center gap-3">
                  <div className={`p-3 rounded-lg ${card.color} text-white`}>
                    <IconComponent className="h-6 w-6" />
                  </div>
                  <div>
                    <CardTitle className="text-lg">{card.title}</CardTitle>
                    <p className="text-sm text-gray-500">{card.stats}</p>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="pt-0">
                <p className="text-gray-600 mb-4">{card.description}</p>
                <Button 
                  onClick={() => setActiveTab(card.id)}
                  className="w-full"
                  variant="outline"
                >
                  Open {card.title}
                  <TrendingUp className="ml-2 h-4 w-4" />
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Card className="bg-gradient-to-r from-blue-50 to-green-50">
        <CardContent className="p-6">
          <div className="flex items-center gap-3 mb-3">
            <TrendingUp className="h-6 w-6 text-blue-600" />
            <h3 className="text-lg font-semibold text-gray-900">Progress Insights</h3>
          </div>
          <p className="text-gray-700">
            Consistent tracking is the key to lasting change. Use both habit and goal tracking 
            to create a comprehensive view of your personal development journey.
          </p>
        </CardContent>
      </Card>
    </div>
  );
};

export default TrackMyProgress;