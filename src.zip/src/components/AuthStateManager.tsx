import React, { useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAppContext } from '@/contexts/AppContext';

const AuthStateManager: React.FC = () => {
  const { setCurrentUser } = useAppContext();

  useEffect(() => {
    let mounted = true;

    // Clear any stale auth state on mount
    const clearAuthState = () => {
      if (mounted) {
        setCurrentUser(null);
      }
    };

    // Enhanced auth state listener with proper cleanup
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        console.log('Auth state change:', event, session?.user?.email);
        
        if (!mounted) return;

        if (event === 'SIGNED_OUT' || !session?.user) {
          // Clear user state immediately on sign out
          setCurrentUser(null);
          return;
        }

        if (event === 'SIGNED_IN' && session?.user) {
          try {
            // Fetch user profile from database
            const { data: profile, error } = await supabase
              .from('profiles')
              .select('*')
              .eq('id', session.user.id)
              .single();

            if (error) {
              console.error('Error fetching profile:', error);
              return;
            }

            if (profile && mounted) {
              const userData = {
                id: session.user.id,
                name: profile.name || session.user.email?.split('@')[0] || 'User',
                email: session.user.email || '',
                isAdmin: profile.is_admin || false,
                joinDate: new Date(profile.created_at),
              };
              
              setCurrentUser(userData);
            }
          } catch (error) {
            console.error('Error processing auth state:', error);
          }
        }
      }
    );

    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, [setCurrentUser]);

  return null; // This component doesn't render anything
};

export default AuthStateManager;