import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Calendar, CheckCircle, Plus, Target, Flame, TrendingUp, Trash2, X } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabase';
import { useUserData } from '@/hooks/useUserData';
import AsyncErrorBoundary from '@/components/AsyncErrorBoundary';
import AnimatedHabitCard from './AnimatedHabitCard';
import HabitCycleTracker from './HabitCycleTracker';
import HabitGoalConnector from './HabitGoalConnector';

interface Habit {
  id: string;
  title: string;
  description?: string;
  frequency: string;
  target_count: number;
  current_streak: number;
  longest_streak: number;
  completed_dates: string[];
  created_at: string;
  updated_at: string;
}

const HabitTracker = () => {
  const [habits, setHabits] = useState<Habit[]>([]);
  const [loading, setLoading] = useState(true);
  const [completionStatus, setCompletionStatus] = useState<Record<string, boolean>>({});
  const [newHabit, setNewHabit] = useState({
    title: '',
    description: '',
    frequency: 'daily',
    target_count: 21,
    cycle_type: '21',
    goal_id: ''
  });
  const [isAddingHabit, setIsAddingHabit] = useState(false);

  const cycleOptions = [
    { value: '21', label: '21-Day Habit Formation', description: 'Build new neural pathways' },
    { value: '30', label: '30-Day Challenge', description: 'Monthly commitment cycle' },
    { value: '90', label: '90-Day Transformation', description: 'Deep lifestyle change' },
    { value: 'ongoing', label: 'Ongoing Practice', description: 'Continuous habit without end date' }
  ];

  const commitmentOptions = [
    { value: 7, label: '7 days - Quick Start' },
    { value: 21, label: '21 days - Habit Formation' },
    { value: 30, label: '30 days - Monthly Challenge' },
    { value: 45, label: '45 days - Extended Practice' },
    { value: 90, label: '90 days - Transformation' },
    { value: 180, label: '180 days - Lifestyle Change' }
  ];

  // Calculate current streak based on consecutive completed dates
  const calculateCurrentStreak = (completedDates: string[]): number => {
    if (completedDates.length === 0) return 0;
    
    const today = new Date();
    const todayStr = today.toISOString().split('T')[0];
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    const yesterdayStr = yesterday.toISOString().split('T')[0];
    
    // Check if today or yesterday was completed
    const completedToday = completedDates.includes(todayStr);
    const completedYesterday = completedDates.includes(yesterdayStr);
    
    // If neither today nor yesterday is completed, streak is broken
    if (!completedToday && !completedYesterday) {
      return 0;
    }
    
    // Start counting from the most recent completion (today or yesterday)
    let currentDate = new Date();
    if (completedToday) {
      currentDate = new Date(today);
    } else {
      currentDate = new Date(yesterday);
    }
    
    let streak = 0;
    const sortedDates = [...completedDates].sort((a, b) => new Date(b).getTime() - new Date(a).getTime());
    
    // Count consecutive days backwards from the starting point
    while (true) {
      const dateStr = currentDate.toISOString().split('T')[0];
      if (completedDates.includes(dateStr)) {
        streak++;
        currentDate.setDate(currentDate.getDate() - 1);
      } else {
        break;
      }
    }
    
    return streak;
  };

  useEffect(() => {
    fetchHabits();
    // Run streak maintenance when component loads
    maintainStreaks();
  }, []);

  const maintainStreaks = async () => {
    try {
      await supabase.functions.invoke('streak-maintenance');
    } catch (error) {
      console.log('Streak maintenance failed:', error);
    }
  };
  const fetchHabits = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        console.log('No user found');
        return;
      }

      console.log('Fetching habits for user:', user.id);

      const { data, error } = await supabase
        .from('habits')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching habits:', error);
        throw error;
      }
      
      console.log('Habits data received:', data);
      
      // Recalculate and update streaks for all habits to fix any incorrect values
      if (data && Array.isArray(data) && data.length > 0) {
        const updatedHabits = [];
        for (const habit of data) {
          const completedDates = habit.completed_dates || [];
          const correctStreak = calculateCurrentStreak(completedDates);
          if (correctStreak !== habit.current_streak) {
            // Update habit with correct streak in database
            await supabase
              .from('habits')
              .update({
                current_streak: correctStreak,
                longest_streak: Math.max(habit.longest_streak || 0, correctStreak),
                updated_at: new Date().toISOString()
              })
              .eq('id', habit.id);
            
            updatedHabits.push({ ...habit, current_streak: correctStreak });
          } else {
            updatedHabits.push(habit);
          }
        }
        setHabits(updatedHabits);
      } else {
        setHabits(data || []);
      }
    } catch (error) {
      console.error('Error fetching habits:', error);
    } finally {
      setLoading(false);
    }
  };

  const addHabit = async () => {
    if (!newHabit.title.trim()) {
      toast({
        title: "Error",
        description: "Please enter a habit title",
        variant: "destructive"
      });
      return;
    }

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        toast({
          title: "Error",
          description: "You must be logged in to create habits",
          variant: "destructive"
        });
        return;
      }

      const { error } = await supabase
        .from('habits')
        .insert([{
          user_id: user.id,
          title: newHabit.title,
          description: newHabit.description,
          frequency: newHabit.frequency,
          target_count: newHabit.target_count
        }]);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Habit created successfully!",
      });

      setNewHabit({ title: '', description: '', frequency: 'daily', target_count: 21, cycle_type: '21', goal_id: '' });
      setIsAddingHabit(false);
      fetchHabits();
    } catch (error) {
      console.error('Error adding habit:', error);
      toast({
        title: "Error",
        description: "Failed to create habit. Please try again.",
        variant: "destructive"
      });
    }
  };


  const toggleHabit = async (habitId: string) => {
    const today = new Date().toISOString().split('T')[0];
    const habit = habits.find(h => h.id === habitId);
    if (!habit) return;
    const completedDates = habit.completed_dates || [];
    const completedToday = completedDates.includes(today);
    let newCompletedDates = [...completedDates];

    if (completedToday) {
      newCompletedDates = newCompletedDates.filter(date => date !== today);
    } else {
      newCompletedDates.push(today);
      
      // Record habit completion in separate table for goal tracking
      try {
        const { data: { user } } = await supabase.auth.getUser();
        if (user) {
          await supabase
            .from('habit_completions')
            .insert({
              habit_id: habitId,
              user_id: user.id,
              completed_at: new Date().toISOString()
            });
          
          // Trigger goal progress update event
          const event = new CustomEvent('habitCompleted', {
            detail: { habitId, userId: user.id }
          });
          window.dispatchEvent(event);
        }
      } catch (error) {
        console.error('Error recording habit completion:', error);
      }
    }

    // Calculate the actual current streak based on consecutive dates
    const newStreak = calculateCurrentStreak(newCompletedDates);

    try {
      const { error } = await supabase
        .from('habits')
        .update({
          completed_dates: newCompletedDates,
          current_streak: newStreak,
          longest_streak: Math.max(habit.longest_streak, newStreak),
          updated_at: new Date().toISOString()
        })
        .eq('id', habitId);

      if (error) throw error;
      fetchHabits();
    } catch (error) {
      console.error('Error updating habit:', error);
    }
  };

  const deleteHabit = async (habitId: string) => {
    try {
      const { error } = await supabase
        .from('habits')
        .delete()
        .eq('id', habitId);

      if (error) throw error;
      
      toast({
        title: "Success",
        description: "Habit deleted successfully!",
      });
      
      fetchHabits();
    } catch (error) {
      console.error('Error deleting habit:', error);
      toast({
        title: "Error",
        description: "Failed to delete habit. Please try again.",
        variant: "destructive"
      });
    }
  };

  const isCompletedToday = (habit: Habit) => {
    const today = new Date().toISOString().split('T')[0];
    const completedDates = habit.completed_dates || [];
    return completedDates.includes(today);
  };

  if (loading) {
    return <div className="p-6">Loading habits...</div>;
  }

  return (
    <AsyncErrorBoundary componentName="Habit Tracker">
      <div className="space-y-6 p-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h2 className="text-2xl font-bold">Habit Tracker</h2>
            <p className="text-muted-foreground">Build lasting habits one day at a time</p>
          </div>
          <Button 
            onClick={() => setIsAddingHabit(true)}
            size="lg" 
            className="bg-black text-white hover:bg-gray-800 font-semibold px-6 py-3"
          >
            <Plus className="h-5 w-5 mr-2" />
            Add New Habit
          </Button>
        </div>
        {/* Add Habit Dialog */}
        {isAddingHabit && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg p-6 w-full max-w-md mx-4">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">Add New Habit</h3>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setIsAddingHabit(false)}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Habit Title</label>
                  <Input
                    value={newHabit.title}
                    onChange={(e) => setNewHabit({ ...newHabit, title: e.target.value })}
                    placeholder="e.g., Drink 8 glasses of water"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-2">Description (Optional)</label>
                  <Textarea
                    value={newHabit.description}
                    onChange={(e) => setNewHabit({ ...newHabit, description: e.target.value })}
                    placeholder="Why is this habit important to you?"
                    rows={3}
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-2">Frequency</label>
                  <Select
                    value={newHabit.frequency}
                    onValueChange={(value) => setNewHabit({ ...newHabit, frequency: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="daily">Daily</SelectItem>
                      <SelectItem value="weekly">Weekly</SelectItem>
                      <SelectItem value="weekdays">Weekdays Only</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-2">Habit Cycle Type</label>
                  <Select
                    value={newHabit.cycle_type}
                    onValueChange={(value) => {
                      setNewHabit({ 
                        ...newHabit, 
                        cycle_type: value,
                        target_count: value === 'ongoing' ? 365 : parseInt(value)
                      });
                    }}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {cycleOptions.map((option) => (
                        <SelectItem key={option.value} value={option.value}>
                          <div>
                            <div className="font-medium">{option.label}</div>
                            <div className="text-xs text-muted-foreground">{option.description}</div>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Commitment Duration</label>
                  <Select
                    value={newHabit.target_count.toString()}
                    onValueChange={(value) => setNewHabit({ ...newHabit, target_count: parseInt(value) })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {commitmentOptions.map((option) => (
                        <SelectItem key={option.value} value={option.value.toString()}>
                          {option.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="flex gap-3 mt-6">
                <Button
                  variant="outline"
                  onClick={() => setIsAddingHabit(false)}
                  className="flex-1"
                >
                  Cancel
                </Button>
                <Button
                  onClick={addHabit}
                  className="flex-1 bg-black text-white hover:bg-gray-800"
                  disabled={!newHabit.title.trim()}
                >
                  Add Habit
                </Button>
              </div>
            </div>
          </div>
        )}
        {habits.length === 0 ? (
          <div className="flex items-center justify-center py-12">
            <div className="text-center">
              <Target className="h-16 w-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">No habits yet</h3>
              <p className="text-gray-500 mb-6 max-w-sm">
                Start building lasting habits. Your first habit is just a click away!
              </p>
              <Button onClick={() => setIsAddingHabit(true)} className="bg-black text-white hover:bg-gray-800">
                <Plus className="h-4 w-4 mr-2" />
                Add Your First Habit
              </Button>
            </div>
          </div>
        ) : (
          <>
            <div className="grid md:grid-cols-2 gap-4">
              {habits.map((habit) => (
                <AnimatedHabitCard
                  key={habit.id}
                  habit={habit}
                  onToggle={toggleHabit}
                  onDelete={deleteHabit}
                  isCompletedToday={isCompletedToday(habit)}
                />
              ))}
            </div>
            
            {/* Habit Cycle Tracking */}
            <div className="mt-8">
              <HabitCycleTracker habits={habits} />
            </div>
            
            {/* Habit Goal Connection */}
            <div className="mt-8">
              <HabitGoalConnector habits={habits} onUpdate={fetchHabits} />
            </div>
          </>
        )}
      </div>
    </AsyncErrorBoundary>
  );
};

export default HabitTracker;