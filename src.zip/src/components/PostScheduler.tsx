import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Clock } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';

interface PostSchedulerProps {
  content?: string;
  onSchedule: (scheduledFor: string) => void;
  onPost?: () => void;
  isAdmin: boolean;
  isModerator: boolean;
}

const PostScheduler: React.FC<PostSchedulerProps> = ({ 
  onSchedule, 
  isAdmin, 
  isModerator 
}) => {
  const [scheduleDate, setScheduleDate] = useState('');
  const [scheduleTime, setScheduleTime] = useState('');
  const [isOpen, setIsOpen] = useState(false);

  const canSchedule = isAdmin || isModerator;

  const handleSchedule = () => {
    if (!scheduleDate || !scheduleTime) {
      toast({
        title: 'Error',
        description: 'Please select both date and time',
        variant: 'destructive'
      });
      return;
    }

    const scheduledFor = new Date(`${scheduleDate}T${scheduleTime}`);
    
    if (scheduledFor <= new Date()) {
      toast({
        title: 'Error',
        description: 'Scheduled time must be in the future',
        variant: 'destructive'
      });
      return;
    }

    onSchedule(scheduledFor.toISOString());
    setScheduleDate('');
    setScheduleTime('');
    setIsOpen(false);
    
    toast({
      title: 'Post scheduled',
      description: `Post will be published on ${scheduledFor.toLocaleDateString()} at ${scheduledFor.toLocaleTimeString()}`
    });
  };

  if (!canSchedule) return null;

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm">
          <Clock className="h-4 w-4 mr-2" />
          Schedule
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Schedule Post</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <Label htmlFor="date">Date</Label>
            <Input
              id="date"
              type="date"
              value={scheduleDate}
              onChange={(e) => setScheduleDate(e.target.value)}
              min={new Date().toISOString().split('T')[0]}
            />
          </div>
          <div>
            <Label htmlFor="time">Time</Label>
            <Input
              id="time"
              type="time"
              value={scheduleTime}
              onChange={(e) => setScheduleTime(e.target.value)}
            />
          </div>
          <Button onClick={handleSchedule} className="w-full">
            Schedule Post
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default PostScheduler;