import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAppContext } from '@/contexts/AppContext';
import LoadingFallback from './LoadingFallback';

interface UserDataLoaderProps {
  children: React.ReactNode;
}

const UserDataLoader = ({ children }: UserDataLoaderProps) => {
  const [loading, setLoading] = useState(true);
  const [session, setSession] = useState(null);
  const { setCurrentUser } = useAppContext();

  useEffect(() => {
    let mounted = true;

    const loadUserData = async () => {
      try {
        const { data: { session: currentSession } } = await supabase.auth.getSession();
        
        if (!mounted) return;
        
        setSession(currentSession);

        if (currentSession?.user) {
          const { data: profile } = await supabase
            .from('profiles')
            .select('*')
            .eq('id', currentSession.user.id)
            .single();

          if (!mounted) return;

          if (profile) {
            setCurrentUser({
              id: profile.id,
              name: profile.name || currentSession.user.email?.split('@')[0] || 'User',
              email: profile.email || currentSession.user.email || '',
              isAdmin: profile.is_admin || false,
              joinDate: new Date(profile.created_at),
              gatherSubscribed: true,
              winsNotifications: true,
            });
          }
        }
      } catch (error) {
        console.error('Error loading user data:', error);
      } finally {
        if (mounted) {
          setLoading(false);
        }
      }
    };

    loadUserData();

    return () => {
      mounted = false;
    };
  }, [setCurrentUser]);

  if (loading) {
    return <LoadingFallback size="large" message="Loading user data..." />;
  }

  return <>{children}</>;
};

export default UserDataLoader;