import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ExternalLink, CreditCard, Calendar, AlertCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';

interface BillingInfo {
  tierName: string | null;
  cadence: string | null;
  status: string | null;
  nextRenewalAt: string | null;
}

export default function MemberBillingPanel() {
  const [billingInfo, setBillingInfo] = useState<BillingInfo | null>(null);
  const [loading, setLoading] = useState(true);
  const [redirecting, setRedirecting] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    loadBillingInfo();
  }, []);

  const loadBillingInfo = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('member-billing-info');
      
      if (error) throw error;
      setBillingInfo(data);
    } catch (error) {
      toast({
        title: "Error loading billing info",
        description: error instanceof Error ? error.message : "Unknown error",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const openStripePortal = async () => {
    setRedirecting(true);
    try {
      const { data, error } = await supabase.functions.invoke('stripe-billing-portal');
      
      if (error) throw error;
      
      if (data?.url) {
        window.location.href = data.url;
      } else {
        throw new Error('No portal URL received');
      }
    } catch (error) {
      toast({
        title: "Error opening billing portal",
        description: error instanceof Error ? error.message : "Unknown error",
        variant: "destructive"
      });
      setRedirecting(false);
    }
  };

  const getStatusBadge = (status: string | null) => {
    if (!status) return null;
    
    const variants: Record<string, "default" | "secondary" | "destructive" | "outline"> = {
      active: "default",
      trialing: "secondary", 
      past_due: "destructive",
      canceled: "outline",
      incomplete: "destructive"
    };

    return (
      <Badge variant={variants[status] || "outline"}>
        {status.replace('_', ' ').toUpperCase()}
      </Badge>
    );
  };

  const formatDate = (dateString: string | null) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="animate-pulse space-y-4">
            <div className="h-4 bg-gray-200 rounded w-1/4"></div>
            <div className="h-4 bg-gray-200 rounded w-1/2"></div>
            <div className="h-4 bg-gray-200 rounded w-1/3"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <CreditCard className="w-5 h-5" />
          Billing Information
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {billingInfo?.tierName ? (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-muted-foreground">Current Plan</label>
                <p className="text-lg font-semibold">{billingInfo.tierName}</p>
              </div>
              
              <div>
                <label className="text-sm font-medium text-muted-foreground">Billing Cadence</label>
                <p className="text-lg capitalize">{billingInfo.cadence || 'Unknown'}</p>
              </div>
              
              <div>
                <label className="text-sm font-medium text-muted-foreground">Status</label>
                <div className="mt-1">
                  {getStatusBadge(billingInfo.status)}
                </div>
              </div>
              
              <div>
                <label className="text-sm font-medium text-muted-foreground">Next Renewal</label>
                <div className="flex items-center gap-2 mt-1">
                  <Calendar className="w-4 h-4 text-muted-foreground" />
                  <span>{formatDate(billingInfo.nextRenewalAt)}</span>
                </div>
              </div>
            </div>

            {billingInfo.status === 'past_due' && (
              <div className="flex items-center gap-2 p-3 bg-red-50 border border-red-200 rounded-md">
                <AlertCircle className="w-4 h-4 text-red-600" />
                <span className="text-sm text-red-800">
                  Your payment is past due. Please update your payment method to continue using premium features.
                </span>
              </div>
            )}

            <Button 
              onClick={openStripePortal}
              disabled={redirecting}
              className="w-full flex items-center justify-center gap-2"
            >
              <ExternalLink className="w-4 h-4" />
              {redirecting ? 'Redirecting...' : 'Manage in Stripe'}
            </Button>

            <p className="text-xs text-muted-foreground text-center">
              You'll be redirected to Stripe's secure customer portal where you can update your payment method, 
              change your plan, or cancel your subscription.
            </p>
          </>
        ) : (
          <div className="text-center py-8">
            <CreditCard className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">No Active Subscription</h3>
            <p className="text-muted-foreground mb-4">
              You don't currently have an active subscription plan.
            </p>
            <Button variant="outline">
              Browse Plans
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}