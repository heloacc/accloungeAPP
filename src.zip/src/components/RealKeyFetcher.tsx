import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';

export const RealKeyFetcher = () => {
  const [testResults, setTestResults] = useState<string>('');
  const [loading, setLoading] = useState(false);

  const testDatabaseConnection = async () => {
    setLoading(true);
    try {
      // Test the current configuration
      const response = await fetch('https://sxoshewvwyhxlavbtgog.supabase.co/rest/v1/', {
        headers: {
          'apikey': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InN4b3NoZXd2d3loeGxhdmJ0Z29nIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTQyNTc0MDEsImV4cCI6MjA2OTgzMzQwMX0.eod-beWaKgDPP9oPCbJcUaMRdq_Ea40fZ1oCfDc1eCg',
          'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InN4b3NoZXd2d3loeGxhdmJ0Z29nIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTQyNTc0MDEsImV4cCI6MjA2OTgzMzQwMX0.eod-beWaKgDPP9oPCbJcUaMRdq_Ea40fZ1oCfDc1eCg'
        }
      });

      const result = await response.text();
      setTestResults(`Status: ${response.status}\nResponse: ${result}`);
    } catch (error) {
      setTestResults(`Error: ${error}`);
    }
    setLoading(false);
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle>API Key Diagnosis</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <Alert>
          <AlertDescription>
            The current JWT anon key appears to be fake/mock. We need the REAL anon key from your Supabase project dashboard.
          </AlertDescription>
        </Alert>
        
        <Button onClick={testDatabaseConnection} disabled={loading}>
          {loading ? 'Testing...' : 'Test Current API Key'}
        </Button>
        
        {testResults && (
          <pre className="bg-gray-100 p-4 rounded text-sm overflow-auto">
            {testResults}
          </pre>
        )}
        
        <Alert>
          <AlertDescription>
            Please go to your Supabase dashboard → Settings → API → Project API keys and copy the "anon public" key.
          </AlertDescription>
        </Alert>
      </CardContent>
    </Card>
  );
};