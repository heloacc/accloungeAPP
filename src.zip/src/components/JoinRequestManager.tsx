import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { CheckCircle, XCircle, Clock, User, MessageSquare } from 'lucide-react';

interface JoinRequest {
  id: string;
  group_id: string;
  user_id: string;
  questionnaire_response: string;
  status: string;
  created_at: string;
  reviewed_at?: string;
  reviewed_by?: string;
  profiles: {
    name: string;
    email: string;
  };
  acircle_groups: {
    name: string;
  };
}

interface JoinRequestManagerProps {
  userId: string;
  isAdmin: boolean;
}

const JoinRequestManager: React.FC<JoinRequestManagerProps> = ({ userId, isAdmin }) => {
  const [requests, setRequests] = useState<JoinRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const fetchJoinRequests = async () => {
    try {
      setLoading(true);
      
      const { data, error } = await supabase
        .from('acircle_join_requests')
        .select(`
          *,
          profiles!acircle_join_requests_user_id_fkey (
            name,
            email
          ),
          acircle_groups!acircle_join_requests_group_id_fkey (
            name
          )
        `)
        .eq('status', 'pending')
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching join requests:', error);
        toast({
          title: "Error",
          description: "Failed to fetch join requests",
          variant: "destructive",
        });
        return;
      }

      setRequests(data || []);
    } catch (error) {
      console.error('Error in fetchJoinRequests:', error);
      toast({
        title: "Error",
        description: "Failed to fetch join requests",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isAdmin) {
      fetchJoinRequests();
    }
  }, [isAdmin]);

  const handleRequest = async (requestId: string, action: 'approve' | 'reject', groupId: string, requestUserId: string) => {
    try {
      // Update the request status
      const { error: updateError } = await supabase
        .from('acircle_join_requests')
        .update({
          status: action === 'approve' ? 'approved' : 'rejected',
          reviewed_at: new Date().toISOString(),
          reviewed_by: userId
        })
        .eq('id', requestId);

      if (updateError) {
        console.error('Error updating request:', updateError);
        toast({
          title: "Error",
          description: `Failed to ${action} request`,
          variant: "destructive",
        });
        return;
      }

      // Get group name for notification
      const { data: groupData } = await supabase
        .from('acircle_groups')
        .select('name')
        .eq('id', groupId)
        .single();

      const groupName = groupData?.name || 'the group';

      // If approved, add user to the group
      if (action === 'approve') {
        const { error: memberError } = await supabase
          .from('acircle_members')
          .insert({
            group_id: groupId,
            user_id: requestUserId,
            role: 'member',
            joined_at: new Date().toISOString()
          });

        if (memberError) {
          console.error('Error adding member:', memberError);
          toast({
            title: "Warning",
            description: "Request approved but failed to add member to group",
            variant: "destructive",
          });
        }
      }

      // Create notification for the user
      const notificationMessage = action === 'approve' 
        ? `Your request to join "${groupName}" has been approved! You can now access the group.`
        : `Your request to join "${groupName}" has been declined.`;

      const { error: notificationError } = await supabase
        .from('notifications')
        .insert({
          user_id: requestUserId,
          type: action === 'approve' ? 'join_request_approved' : 'join_request_rejected',
          title: `Join Request ${action === 'approve' ? 'Approved' : 'Declined'}`,
          message: notificationMessage,
          created_at: new Date().toISOString(),
          is_read: false
        });

      if (notificationError) {
        console.warn('Failed to create notification:', notificationError);
        // Don't fail the whole operation for notification errors
      }

      toast({
        title: "Success",
        description: `Request ${action}d successfully`,
      });

      // Refresh the requests list
      fetchJoinRequests();
    } catch (error) {
      console.error(`Error ${action}ing request:`, error);
      toast({
        title: "Error",
        description: `Failed to ${action} request`,
        variant: "destructive",
      });
    }
  };

  if (!isAdmin) {
    return (
      <Card>
        <CardContent className="p-6">
          <p className="text-center text-gray-500">
            You need admin privileges to manage join requests.
          </p>
        </CardContent>
      </Card>
    );
  }

  if (loading) {
    return (
      <Card>
        <CardContent className="p-6">
          <p className="text-center">Loading join requests...</p>
        </CardContent>
      </Card>
    );
  }

  if (requests.length === 0) {
    return (
      <Card>
        <CardContent className="p-6">
          <p className="text-center text-gray-500">
            No pending join requests at this time.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold">Pending Join Requests ({requests.length})</h3>
      
      {requests.map((request) => (
        <Card key={request.id}>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-base flex items-center gap-2">
                <User className="h-4 w-4" />
                {request.profiles?.name || 'Unknown User'}
              </CardTitle>
              <Badge variant="outline" className="flex items-center gap-1">
                <Clock className="h-3 w-3" />
                Pending
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div>
                <p className="text-sm text-gray-600">Email: {request.profiles?.email}</p>
                <p className="text-sm text-gray-600">Group: {request.acircle_groups?.name}</p>
                <p className="text-sm text-gray-600">
                  Requested: {new Date(request.created_at).toLocaleDateString()}
                </p>
              </div>
              
              {request.questionnaire_response && (
                <div>
                  <p className="text-sm font-medium flex items-center gap-1 mb-1">
                    <MessageSquare className="h-3 w-3" />
                    Response:
                  </p>
                  <p className="text-sm bg-gray-50 p-2 rounded">
                    {request.questionnaire_response}
                  </p>
                </div>
              )}
              
              <div className="flex gap-2 pt-2">
                <Button
                  size="sm"
                  onClick={() => handleRequest(request.id, 'approve', request.group_id, request.user_id)}
                  className="flex items-center gap-1"
                >
                  <CheckCircle className="h-3 w-3" />
                  Approve
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handleRequest(request.id, 'reject', request.group_id, request.user_id)}
                  className="flex items-center gap-1"
                >
                  <XCircle className="h-3 w-3" />
                  Reject
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

export default JoinRequestManager;
