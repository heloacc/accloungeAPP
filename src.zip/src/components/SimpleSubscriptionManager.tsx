import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Crown, Check, X, Star } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useUserTier } from '@/hooks/useUserTier';
import { useToast } from '@/hooks/use-toast';

interface SubscriptionTier {
  id: string;
  name: string;
  price_monthly: number;
  features: string[];
  is_active: boolean;
}

export default function SimpleSubscriptionManager() {
  const [tiers, setTiers] = useState<SubscriptionTier[]>([]);
  const [loading, setLoading] = useState(true);
  const { userTier, loading: tierLoading } = useUserTier();
  const { toast } = useToast();

  useEffect(() => {
    loadTiers();
  }, []);

  const loadTiers = async () => {
    try {
      const { data, error } = await supabase
        .from('subscription_tiers')
        .select('*')
        .eq('is_active', true)
        .order('price_monthly', { ascending: true });

      if (error) throw error;
      setTiers(data || []);
    } catch (error) {
      toast({
        title: "Error loading subscription tiers",
        description: error instanceof Error ? error.message : "Unknown error",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const getTierBadgeVariant = (tierName: string) => {
    switch (tierName) {
      case 'Freemium': return 'secondary';
      case 'Accountability Essentials': return 'default';
      case 'All Access': return 'default';
      default: return 'outline';
    }
  };

  const getTierIcon = (tierName: string) => {
    switch (tierName) {
      case 'All Access': return <Crown className="w-5 h-5 text-yellow-500" />;
      case 'Accountability Essentials': return <Star className="w-5 h-5 text-blue-500" />;
      default: return null;
    }
  };

  if (loading || tierLoading) {
    return (
      <div className="space-y-4">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/3 mb-4"></div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {[1, 2, 3].map(i => (
              <div key={i} className="h-64 bg-gray-200 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">Subscription Management</h1>
        <p className="text-muted-foreground">
          Choose the plan that's right for you. Upgrade or downgrade anytime.
        </p>
      </div>

      {userTier && (
        <Card className="border-blue-200 bg-blue-50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                {getTierIcon(userTier.name)}
                <div>
                  <h3 className="font-semibold">Current Plan: {userTier.name}</h3>
                  <p className="text-sm text-muted-foreground">
                    ${userTier.price_monthly}/month
                  </p>
                </div>
              </div>
              <Badge variant={getTierBadgeVariant(userTier.name)}>
                Active
              </Badge>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {tiers.map((tier) => {
          const isCurrentTier = userTier?.id === tier.id;
          const isUpgrade = userTier && tier.price_monthly > userTier.price_monthly;
          
          return (
            <Card key={tier.id} className={`relative ${isCurrentTier ? 'border-blue-500 shadow-lg' : ''}`}>
              {tier.name === 'All Access' && (
                <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                  <Badge className="bg-yellow-500 text-white">Most Popular</Badge>
                </div>
              )}
              
              <CardHeader className="text-center pb-4">
                <div className="flex items-center justify-center gap-2 mb-2">
                  {getTierIcon(tier.name)}
                  <CardTitle className="text-xl">{tier.name}</CardTitle>
                </div>
                <div className="text-3xl font-bold">
                  ${tier.price_monthly}
                  <span className="text-base font-normal text-muted-foreground">/month</span>
                </div>
              </CardHeader>
              
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  {tier.features.map((feature, index) => (
                    <div key={index} className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-green-500 flex-shrink-0" />
                      <span className="text-sm">{feature}</span>
                    </div>
                  ))}
                </div>
                
                <Button 
                  className="w-full"
                  variant={isCurrentTier ? "outline" : "default"}
                  disabled={isCurrentTier}
                >
                  {isCurrentTier ? 'Current Plan' : isUpgrade ? 'Upgrade' : 'Downgrade'}
                </Button>
                
                {isCurrentTier && (
                  <p className="text-xs text-center text-muted-foreground">
                    This is your current subscription plan
                  </p>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Need Help?</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground mb-4">
            Have questions about our plans or need to make changes to your subscription?
          </p>
          <div className="flex gap-2">
            <Button variant="outline">Contact Support</Button>
            <Button variant="outline">View FAQ</Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}