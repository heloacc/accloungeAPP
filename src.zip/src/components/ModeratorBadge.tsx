import React from 'react';
import { Badge } from '@/components/ui/badge';
import { Shield } from 'lucide-react';

interface ModeratorBadgeProps {
  userRole?: string;
  className?: string;
}

const ModeratorBadge: React.FC<ModeratorBadgeProps> = ({ 
  userRole, 
  className = "" 
}) => {
  if (userRole !== 'Moderator') return null;

  return (
    <Badge 
      className={`bg-blue-600 text-white text-xs px-2 py-1 ${className}`}
      variant="default"
    >
      <Shield className="h-3 w-3 mr-1" />
      MOD
    </Badge>
  );
};

export default ModeratorBadge;