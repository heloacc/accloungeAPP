import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useStableUserRole } from '@/hooks/useStableUserRole';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Lock, Crown, Zap } from 'lucide-react';

interface TierEnforcementProps {
  children: React.ReactNode;
  requiredTier?: string;
  pagePath: string;
  fallbackComponent?: React.ReactNode;
}

interface UserTier {
  id: string;
  name: string;
  allowed_routes: string[];
}

export const TierEnforcementSystem: React.FC<TierEnforcementProps> = ({
  children,
  requiredTier,
  pagePath,
  fallbackComponent
}) => {
  const [hasAccess, setHasAccess] = useState<boolean>(false);
  const [loading, setLoading] = useState(true);
  const [userTier, setUserTier] = useState<UserTier | null>(null);
  const [requiredTierName, setRequiredTierName] = useState<string>('');
  const { role, isAdmin } = useStableUserRole();

  useEffect(() => {
    checkAccess();
  }, [pagePath, role]);

  const checkAccess = async () => {
    setLoading(true);
    try {
      // Admin bypass - admins can access everything
      if (isAdmin) {
        setHasAccess(true);
        setLoading(false);
        return;
      }

      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        setHasAccess(false);
        setLoading(false);
        return;
      }

      // Call backend enforcement function
      const { data, error } = await supabase.functions.invoke('tier-enforcement', {
        body: {
          action: 'checkPageAccess',
          userId: user.id,
          pagePath,
          requiredTier
        }
      });

      if (error) throw error;

      setHasAccess(data.hasAccess);
      setUserTier(data.userTier);
      setRequiredTierName(data.requiredTier || '');

    } catch (error) {
      console.error('Access check failed:', error);
      setHasAccess(false);
    } finally {
      setLoading(false);
    }
  };

  const handleUpgrade = () => {
    window.dispatchEvent(new CustomEvent('navigate-to-tab', { 
      detail: { tab: 'billing' }
    }));
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[200px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (hasAccess) {
    return <>{children}</>;
  }

  if (fallbackComponent) {
    return <>{fallbackComponent}</>;
  }

  const getTierIcon = (tier: string) => {
    switch (tier.toLowerCase()) {
      case 'all access':
        return <Crown className="h-8 w-8 text-yellow-500" />;
      case 'accountability essentials':
        return <Zap className="h-8 w-8 text-purple-500" />;
      default:
        return <Lock className="h-8 w-8 text-gray-500" />;
    }
  };

  return (
    <div className="flex items-center justify-center min-h-[400px] p-4">
      <Card className="max-w-md w-full">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            {getTierIcon(requiredTierName)}
          </div>
          <CardTitle>Upgrade Required</CardTitle>
        </CardHeader>
        <CardContent className="text-center space-y-4">
          <p className="text-muted-foreground">
            This feature requires a <strong>{requiredTierName}</strong> subscription.
          </p>
          <p className="text-sm text-muted-foreground">
            Your current plan: <strong>{userTier?.name || 'Freemium'}</strong>
          </p>
          <div className="flex gap-2 justify-center">
            <Button onClick={handleUpgrade}>
              Upgrade Now
            </Button>
            <Button variant="outline" onClick={() => window.history.back()}>
              Go Back
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};