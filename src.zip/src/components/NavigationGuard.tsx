import React from 'react';
import { useStableUserRole } from '@/hooks/useStableUserRole';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Shield, AlertTriangle, ArrowLeft } from 'lucide-react';

interface NavigationGuardProps {
  children: React.ReactNode;
  requiredRole?: 'admin' | 'moderator';
  requiredCapability?: string;
  fallbackMessage?: string;
  onAccessDenied?: () => void;
}

const NavigationGuard: React.FC<NavigationGuardProps> = ({
  children,
  requiredRole,
  requiredCapability,
  fallbackMessage,
  onAccessDenied
}) => {
  const { 
    role, 
    loading, 
    isAdmin, 
    isModerator,
    canCreateGroups,
    canAccessMemberMomentum,
    canAccessCheckIns
  } = useStableUserRole();

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  // Check role-based access
  if (requiredRole) {
    if (requiredRole === 'admin' && !isAdmin) {
      return <AccessDenied message="Admin access required" onGoBack={onAccessDenied} />;
    }
    if (requiredRole === 'moderator' && !isModerator && !isAdmin) {
      return <AccessDenied message="Moderator or Admin access required" onGoBack={onAccessDenied} />;
    }
  }

  // Check capability-based access
  if (requiredCapability) {
    let hasCapability = false;
    
    switch (requiredCapability) {
      case 'admin_panel':
        hasCapability = isAdmin;
        break;
      case 'tier_mgmt':
        hasCapability = isAdmin;
        break;
      case 'member_momentum':
        hasCapability = canAccessMemberMomentum;
        break;
      case 'checkins':
        hasCapability = canAccessCheckIns;
        break;
      default:
        hasCapability = false;
    }

    if (!hasCapability) {
      return <AccessDenied message={fallbackMessage || "Insufficient permissions"} onGoBack={onAccessDenied} />;
    }
  }

  return <>{children}</>;
};

const AccessDenied: React.FC<{ message: string; onGoBack?: () => void }> = ({ message, onGoBack }) => (
  <Card className="max-w-md mx-auto mt-8">
    <CardHeader className="text-center">
      <div className="mx-auto w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mb-4">
        <Shield className="w-6 h-6 text-red-600" />
      </div>
      <CardTitle className="text-red-600">Access Denied</CardTitle>
    </CardHeader>
    <CardContent className="text-center space-y-4">
      <div className="flex items-center justify-center text-amber-600 mb-2">
        <AlertTriangle className="w-5 h-5 mr-2" />
        <span className="text-sm">{message}</span>
      </div>
      <p className="text-sm text-muted-foreground">
        You don't have the required permissions to access this feature.
      </p>
      {onGoBack && (
        <Button onClick={onGoBack} variant="outline" className="w-full">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Go Back
        </Button>
      )}
    </CardContent>
  </Card>
);

export default NavigationGuard;