import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import FeatureGuard from './FeatureGuard';
import TierBadge from './TierBadge';
import PremiumFeatureWrapper from './PremiumFeatureWrapper';
import { BarChart3, Users, Zap, Crown, Star } from 'lucide-react';

export const TierBasedFeatureDemo: React.FC = () => {
  return (
    <div className="space-y-6 p-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Tier-Based Access Demo</h1>
        <TierBadge showIcon />
      </div>

      <Tabs defaultValue="guards" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="guards">Feature Guards</TabsTrigger>
          <TabsTrigger value="wrappers">Content Wrappers</TabsTrigger>
          <TabsTrigger value="examples">Real Examples</TabsTrigger>
        </TabsList>

        <TabsContent value="guards" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            
            <FeatureGuard requiredTier="freemium" featureName="Basic Dashboard">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Star className="h-5 w-5" />
                    Free Feature
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p>This content is available to all users.</p>
                </CardContent>
              </Card>
            </FeatureGuard>

            <FeatureGuard requiredTier="premium" featureName="Advanced Analytics">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BarChart3 className="h-5 w-5" />
                    Premium Analytics
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p>Advanced charts and insights for premium users.</p>
                </CardContent>
              </Card>
            </FeatureGuard>

            <FeatureGuard requiredTier="enterprise" featureName="Team Management">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="h-5 w-5" />
                    Enterprise Tools
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p>Team collaboration and management tools.</p>
                </CardContent>
              </Card>
            </FeatureGuard>
          </div>
        </TabsContent>

        <TabsContent value="wrappers" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            <PremiumFeatureWrapper requiredTier="premium">
              <Card>
                <CardHeader>
                  <CardTitle>Premium Chart</CardTitle>
                </CardHeader>
                <CardContent className="h-32 bg-gradient-to-r from-blue-100 to-purple-100 rounded flex items-center justify-center">
                  <BarChart3 className="h-12 w-12 text-blue-600" />
                </CardContent>
              </Card>
            </PremiumFeatureWrapper>

            <PremiumFeatureWrapper requiredTier="enterprise" blurContent={false}>
              <Card>
                <CardHeader>
                  <CardTitle>Enterprise Dashboard</CardTitle>
                </CardHeader>
                <CardContent className="h-32 bg-gradient-to-r from-purple-100 to-pink-100 rounded flex items-center justify-center">
                  <Zap className="h-12 w-12 text-purple-600" />
                </CardContent>
              </Card>
            </PremiumFeatureWrapper>
          </div>
        </TabsContent>

        <TabsContent value="examples" className="space-y-4">
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>How It Works</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <h4 className="font-semibold">1. Database-Driven Tiers</h4>
                  <p className="text-sm text-muted-foreground">
                    User tiers are stored in the profiles.subscription_tier column (freemium, premium, enterprise)
                  </p>
                </div>
                <div className="space-y-2">
                  <h4 className="font-semibold">2. Component-Level Guards</h4>
                  <p className="text-sm text-muted-foreground">
                    FeatureGuard components check user tier and show upgrade prompts for restricted content
                  </p>
                </div>
                <div className="space-y-2">
                  <h4 className="font-semibold">3. Content Wrappers</h4>
                  <p className="text-sm text-muted-foreground">
                    PremiumFeatureWrapper blurs content and shows overlay for premium features
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};