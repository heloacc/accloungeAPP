import React, { Suspense, lazy } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { UnifiedAuthProvider, useUnifiedAuthContext } from '@/contexts/UnifiedAuthContext';
import { ThemeProvider } from '@/components/theme-provider';
import { Toaster } from '@/components/ui/toaster';
import FastAuth from '@/components/FastAuth';
import LoadingScreen from '@/components/LoadingScreen';
import './App.css';

// Lazy load heavy components
const Index = lazy(() => import('@/pages/Index'));
const NotFound = lazy(() => import('@/pages/NotFound'));
const AdminSetup = lazy(() => import('@/components/AdminSetup'));
const PasswordReset = lazy(() => import('@/components/PasswordReset'));

const AppContent = () => {
      const { currentUser, isLoading } = useUnifiedAuthContext();

  return (
    <Router>
      <Suspense fallback={<LoadingScreen />}>
        <Routes>
          {/* Public routes - accessible without authentication */}
          <Route path="/reset-password" element={<PasswordReset />} />
          
          {/* Protected routes - require authentication */}
          <Route path="/" element={
            isLoading ? <LoadingScreen /> : 
            !currentUser ? <FastAuth /> : <Index />
          } />
          <Route path="/subscription" element={
            isLoading ? <LoadingScreen /> : 
            !currentUser ? <FastAuth /> : <Index />
          } />
          <Route path="/billing" element={
            isLoading ? <LoadingScreen /> : 
            !currentUser ? <FastAuth /> : <Index />
          } />
          <Route path="/admin-setup" element={
            isLoading ? <LoadingScreen /> : 
            !currentUser ? <FastAuth /> : <AdminSetup />
          } />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </Suspense>
      <Toaster />
    </Router>
  );
};

function App() {
  return (
        <ThemeProvider defaultTheme="light" storageKey="vite-ui-theme">
          <UnifiedAuthProvider>
            <AppContent />
          </UnifiedAuthProvider>
        </ThemeProvider>
  );
}

export default App;