// CSRF protection utilities
import { supabase } from './supabase';

interface CSRFToken {
  token: string;
  userId: string;
  expiresAt: number;
}

const csrfTokens = new Map<string, CSRFToken>();

export class CSRFProtection {
  private static readonly TOKEN_EXPIRY = 3600000; // 1 hour

  // Generate CSRF token for user
  static async generateToken(userId: string): Promise<string> {
    const token = crypto.randomUUID();
    const expiresAt = Date.now() + this.TOKEN_EXPIRY;
    
    csrfTokens.set(token, {
      token,
      userId,
      expiresAt
    });
    
    // Clean up expired tokens
    this.cleanupExpiredTokens();
    
    return token;
  }

  // Validate CSRF token
  static validateToken(token: string, userId: string): boolean {
    const storedToken = csrfTokens.get(token);
    
    if (!storedToken) return false;
    if (storedToken.userId !== userId) return false;
    if (Date.now() > storedToken.expiresAt) {
      csrfTokens.delete(token);
      return false;
    }
    
    return true;
  }

  // Remove token after use (single-use tokens)
  static consumeToken(token: string): boolean {
    const exists = csrfTokens.has(token);
    if (exists) {
      csrfTokens.delete(token);
    }
    return exists;
  }

  // Clean up expired tokens
  private static cleanupExpiredTokens() {
    const now = Date.now();
    for (const [token, data] of csrfTokens.entries()) {
      if (now > data.expiresAt) {
        csrfTokens.delete(token);
      }
    }
  }

  // Middleware for CSRF validation
  static async validateRequest(request: Request): Promise<{ valid: boolean; userId?: string }> {
    const token = request.headers.get('x-csrf-token');
    const authHeader = request.headers.get('authorization');
    
    if (!token || !authHeader) {
      return { valid: false };
    }

    try {
      const jwt = authHeader.replace('Bearer ', '');
      const { data: { user } } = await supabase.auth.getUser(jwt);
      
      if (!user) return { valid: false };
      
      const isValid = this.validateToken(token, user.id);
      return { valid: isValid, userId: user.id };
    } catch {
      return { valid: false };
    }
  }
}

// React hook for CSRF token management
export const useCSRFToken = () => {
  const generateCSRFToken = async (): Promise<string | null> => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return null;
      
      const { data } = await supabase.functions.invoke('generate-csrf-token', {
        body: { userId: user.id }
      });
      
      return data?.token || null;
    } catch {
      return null;
    }
  };
  
  return { generateCSRFToken };
};