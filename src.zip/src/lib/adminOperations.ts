import { supabase } from '@/lib/supabase';
import { AdminAction, AdminOperationRequest, AdminOperationResponse } from '@/types/adminOperations';

/**
 * Type-safe wrapper for admin operations edge function calls
 */
export class AdminOperationsClient {
  
  /**
   * Make a type-safe call to the admin-operations edge function
   */
  static async invoke<T extends AdminOperationResponse>(
    action: AdminAction,
    additionalParams: Record<string, any> = {}
  ): Promise<T> {
    try {
      // Get current session
      const { data: { session }, error: sessionError } = await supabase.auth.getSession();
      if (sessionError || !session) {
        throw new Error('No valid session found');
      }

      // Create type-safe request payload
      const requestPayload: AdminOperationRequest = {
        action,
        ...additionalParams
      };

      console.log(`Admin operation [${action}] request:`, requestPayload);

      // Make the function call - let Supabase handle JSON serialization
      const { data, error } = await supabase.functions.invoke('admin-operations', {
        body: requestPayload
        // Remove manual headers - let Supabase client handle Content-Type
      });

      console.log(`Admin operation [${action}] response:`, { data, error });

      // Handle Supabase client errors (network, auth, etc.)
      if (error) {
        const correlationId = data?.correlation_id || 'unknown';
        console.error(`Admin operation [${action}] client error [${correlationId}]:`, error);
        
        let displayMessage = `Failed to execute ${action}`;
        if (error.message) {
          displayMessage = error.message;
        } else if (typeof error === 'string') {
          displayMessage = error.includes('Edge Function') 
            ? 'Server connection error. Please try again.' 
            : error;
        }
        
        throw new Error(`${displayMessage} (ID: ${correlationId})`);
      }

      // Handle server-side errors (returned in successful response)
      if (data && !data.success) {
        const correlationId = data.correlation_id || 'unknown';
        const errorMessage = data.message || `Unknown server error for ${action}`;
        throw new Error(`${errorMessage} (ID: ${correlationId})`);
      }

      // Ensure we have valid data
      if (!data) {
        throw new Error(`No data received from ${action} service`);
      }

      return data as T;

    } catch (error) {
      // Re-throw with context
      const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
      console.error(`Admin operation [${action}] failed:`, errorMessage);
      throw error;
    }
  }

  /**
   * Get analytics data
   */
  static async getAnalytics() {
    return this.invoke<AdminOperationResponse & {
      totalUsers: number;
      totalGoals: number;
      totalHabits: number;
      completedGoals: number;
      completedHabits: number;
    }>('get_analytics');
  }

  /**
   * Health check
   */
  static async healthCheck() {
    return this.invoke<AdminOperationResponse>('health_check');
  }
}