import { logger } from './logger';

export interface AppError {
  message: string;
  code?: string;
  statusCode?: number;
  originalError?: any;
}

export class AppError extends Error {
  code?: string;
  statusCode?: number;
  originalError?: any;

  constructor(message: string, code?: string, statusCode?: number, originalError?: any) {
    super(message);
    this.name = 'AppError';
    this.code = code;
    this.statusCode = statusCode;
    this.originalError = originalError;
  }
}

export const handleError = (error: any, context?: string): AppError => {
  const contextMsg = context ? `[${context}] ` : '';
  
  if (error instanceof AppError) {
    logger.error(`${contextMsg}${error.message}`, error);
    return error;
  }

  // Sanitize error information to prevent information leakage
  const sanitizedError = sanitizeError(error);
  logger.error(`${contextMsg}${sanitizedError.message}`, sanitizedError);
  return sanitizedError;
};

// Sanitize error to prevent information leakage
const sanitizeError = (error: any): AppError => {
  // Don't expose internal error details
  if (error?.code === 'PGRST301' || error?.code === 'PGRST116') {
    return new AppError('Database connection error. Please try again.', 'DB_CONNECTION_ERROR', 500);
  }
  
  if (error?.message?.includes('JWT') || error?.message?.includes('token')) {
    return new AppError('Authentication error. Please sign in again.', 'AUTH_ERROR', 401);
  }
  
  if (error?.message?.includes('permission') || error?.message?.includes('unauthorized')) {
    return new AppError('Access denied. You do not have permission for this action.', 'PERMISSION_ERROR', 403);
  }
  
  // Generic error for unknown issues
  return new AppError('An unexpected error occurred. Please try again.', 'UNKNOWN_ERROR', 500);
};

export const getUserFriendlyMessage = (error: AppError): string => {
  switch (error.code) {
    case 'NETWORK_ERROR':
      return 'Network connection issue. Please check your internet connection.';
    case 'AUTH_ERROR':
      return 'Authentication failed. Please log in again.';
    case 'PERMISSION_DENIED':
      return 'You do not have permission to perform this action.';
    case 'VALIDATION_ERROR':
      return 'Please check your input and try again.';
    case 'RATE_LIMIT_EXCEEDED':
      return 'Too many requests. Please wait a moment and try again.';
    default:
      return 'Something went wrong. Please try again later.';
  }
};