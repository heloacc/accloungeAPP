// Production-safe logging utility with security measures
interface LogLevel {
  DEBUG: 0;
  INFO: 1;
  WARN: 2;
  ERROR: 3;
}

const LOG_LEVELS: LogLevel = {
  DEBUG: 0,
  INFO: 1,
  WARN: 2,
  ERROR: 3
};

// Sanitize sensitive data from logs
const sanitizeData = (data: any): any => {
  if (typeof data === 'string') {
    // Remove potential sensitive patterns
    return data
      .replace(/password[=:]\s*[^\s&]+/gi, 'password=***')
      .replace(/token[=:]\s*[^\s&]+/gi, 'token=***')
      .replace(/key[=:]\s*[^\s&]+/gi, 'key=***')
      .replace(/secret[=:]\s*[^\s&]+/gi, 'secret=***');
  }
  
  if (typeof data === 'object' && data !== null) {
    const sanitized = { ...data };
    Object.keys(sanitized).forEach(key => {
      if (/password|token|key|secret/i.test(key)) {
        sanitized[key] = '***';
      }
    });
    return sanitized;
  }
  
  return data;
};

class SecureLogger {
  private currentLevel: number;
  
  constructor() {
    this.currentLevel = false ? LOG_LEVELS.WARN : LOG_LEVELS.DEBUG; // Change false to true for production
  }
  
  private shouldLog(level: number): boolean {
    return level >= this.currentLevel;
  }
  
  private formatMessage(level: string, message: string, data?: any): void {
    if (import.meta.env.PROD) {
      // In production, only log errors and warnings to avoid console pollution
      if (level === 'ERROR' || level === 'WARN') {
        console[level.toLowerCase() as 'error' | 'warn'](`[${level}]`, message, data ? sanitizeData(data) : '');
      }
    } else {
      // In development, log everything for debugging
      console.log(`[${level}]`, message, data ? sanitizeData(data) : '');
    }
  }
  
  debug(message: string, data?: any): void {
    if (this.shouldLog(LOG_LEVELS.DEBUG)) {
      this.formatMessage('DEBUG', message, data);
    }
  }
  
  info(message: string, data?: any): void {
    if (this.shouldLog(LOG_LEVELS.INFO)) {
      this.formatMessage('INFO', message, data);
    }
  }
  
  warn(message: string, data?: any): void {
    if (this.shouldLog(LOG_LEVELS.WARN)) {
      this.formatMessage('WARN', message, data);
    }
  }
  
  error(message: string, data?: any): void {
    if (this.shouldLog(LOG_LEVELS.ERROR)) {
      this.formatMessage('ERROR', message, data);
    }
  }
}

export const logger = new SecureLogger();