import { logger } from './secureLogger';

// Unified error types
export interface UnifiedError {
  message: string;
  code: string;
  statusCode: number;
  timestamp: string;
  context?: string;
  originalError?: any;
}

export class UnifiedErrorHandler {
  private static readonly ERROR_CODES = {
    // Authentication errors
    AUTH_REQUIRED: 'AUTH_REQUIRED',
    AUTH_INVALID: 'AUTH_INVALID',
    AUTH_EXPIRED: 'AUTH_EXPIRED',
    AUTH_PERMISSION_DENIED: 'AUTH_PERMISSION_DENIED',
    
    // Validation errors
    VALIDATION_ERROR: 'VALIDATION_ERROR',
    INVALID_INPUT: 'INVALID_INPUT',
    MISSING_REQUIRED_FIELD: 'MISSING_REQUIRED_FIELD',
    
    // Database errors
    DATABASE_ERROR: 'DATABASE_ERROR',
    DATABASE_CONNECTION_ERROR: 'DATABASE_CONNECTION_ERROR',
    DATABASE_QUERY_ERROR: 'DATABASE_QUERY_ERROR',
    DATABASE_CONSTRAINT_ERROR: 'DATABASE_CONSTRAINT_ERROR',
    
    // Network errors
    NETWORK_ERROR: 'NETWORK_ERROR',
    TIMEOUT_ERROR: 'TIMEOUT_ERROR',
    CONNECTION_ERROR: 'CONNECTION_ERROR',
    
    // Rate limiting
    RATE_LIMIT_EXCEEDED: 'RATE_LIMIT_EXCEEDED',
    
    // Generic errors
    UNKNOWN_ERROR: 'UNKNOWN_ERROR',
    INTERNAL_ERROR: 'INTERNAL_ERROR'
  };

  private static readonly USER_FRIENDLY_MESSAGES = {
    [this.ERROR_CODES.AUTH_REQUIRED]: 'Please sign in to continue.',
    [this.ERROR_CODES.AUTH_INVALID]: 'Invalid authentication. Please sign in again.',
    [this.ERROR_CODES.AUTH_EXPIRED]: 'Your session has expired. Please sign in again.',
    [this.ERROR_CODES.AUTH_PERMISSION_DENIED]: 'You do not have permission to perform this action.',
    
    [this.ERROR_CODES.VALIDATION_ERROR]: 'Please check your input and try again.',
    [this.ERROR_CODES.INVALID_INPUT]: 'Invalid input provided.',
    [this.ERROR_CODES.MISSING_REQUIRED_FIELD]: 'Please fill in all required fields.',
    
    [this.ERROR_CODES.DATABASE_ERROR]: 'A database error occurred. Please try again.',
    [this.ERROR_CODES.DATABASE_CONNECTION_ERROR]: 'Database connection error. Please try again.',
    [this.ERROR_CODES.DATABASE_QUERY_ERROR]: 'Database query error. Please try again.',
    [this.ERROR_CODES.DATABASE_CONSTRAINT_ERROR]: 'Data constraint error. Please check your input.',
    
    [this.ERROR_CODES.NETWORK_ERROR]: 'Network error. Please check your connection.',
    [this.ERROR_CODES.TIMEOUT_ERROR]: 'Request timeout. Please try again.',
    [this.ERROR_CODES.CONNECTION_ERROR]: 'Connection error. Please try again.',
    
    [this.ERROR_CODES.RATE_LIMIT_EXCEEDED]: 'Too many requests. Please wait a moment and try again.',
    
    [this.ERROR_CODES.UNKNOWN_ERROR]: 'An unexpected error occurred. Please try again.',
    [this.ERROR_CODES.INTERNAL_ERROR]: 'An internal error occurred. Please try again later.'
  };

  // Main error handling method
  static handleError(error: any, context?: string): UnifiedError {
    const timestamp = new Date().toISOString();
    
    // Log the full error for debugging
    logger.error(`Error in ${context || 'unknown context'}:`, {
      error,
      context,
      timestamp,
      stack: error?.stack
    });

    // Determine error type and create unified error
    const unifiedError = this.classifyError(error, context, timestamp);
    
    return unifiedError;
  }

  // Classify error and determine appropriate response
  private static classifyError(error: any, context?: string, timestamp?: string): UnifiedError {
    // Check for specific error patterns
    if (error?.code === 'PGRST301' || error?.code === 'PGRST116') {
      return {
        message: this.USER_FRIENDLY_MESSAGES[this.ERROR_CODES.DATABASE_CONNECTION_ERROR],
        code: this.ERROR_CODES.DATABASE_CONNECTION_ERROR,
        statusCode: 500,
        timestamp: timestamp || new Date().toISOString(),
        context,
        originalError: this.sanitizeError(error)
      };
    }

    if (error?.message?.includes('JWT') || error?.message?.includes('token')) {
      return {
        message: this.USER_FRIENDLY_MESSAGES[this.ERROR_CODES.AUTH_INVALID],
        code: this.ERROR_CODES.AUTH_INVALID,
        statusCode: 401,
        timestamp: timestamp || new Date().toISOString(),
        context,
        originalError: this.sanitizeError(error)
      };
    }

    if (error?.message?.includes('permission') || error?.message?.includes('unauthorized')) {
      return {
        message: this.USER_FRIENDLY_MESSAGES[this.ERROR_CODES.AUTH_PERMISSION_DENIED],
        code: this.ERROR_CODES.AUTH_PERMISSION_DENIED,
        statusCode: 403,
        timestamp: timestamp || new Date().toISOString(),
        context,
        originalError: this.sanitizeError(error)
      };
    }

    if (error?.message?.includes('validation') || error?.message?.includes('invalid')) {
      return {
        message: this.USER_FRIENDLY_MESSAGES[this.ERROR_CODES.VALIDATION_ERROR],
        code: this.ERROR_CODES.VALIDATION_ERROR,
        statusCode: 400,
        timestamp: timestamp || new Date().toISOString(),
        context,
        originalError: this.sanitizeError(error)
      };
    }

    if (error?.message?.includes('timeout') || error?.message?.includes('TIMEOUT')) {
      return {
        message: this.USER_FRIENDLY_MESSAGES[this.ERROR_CODES.TIMEOUT_ERROR],
        code: this.ERROR_CODES.TIMEOUT_ERROR,
        statusCode: 408,
        timestamp: timestamp || new Date().toISOString(),
        context,
        originalError: this.sanitizeError(error)
      };
    }

    if (error?.message?.includes('rate limit') || error?.message?.includes('too many')) {
      return {
        message: this.USER_FRIENDLY_MESSAGES[this.ERROR_CODES.RATE_LIMIT_EXCEEDED],
        code: this.ERROR_CODES.RATE_LIMIT_EXCEEDED,
        statusCode: 429,
        timestamp: timestamp || new Date().toISOString(),
        context,
        originalError: this.sanitizeError(error)
      };
    }

    // Default to unknown error
    return {
      message: this.USER_FRIENDLY_MESSAGES[this.ERROR_CODES.UNKNOWN_ERROR],
      code: this.ERROR_CODES.UNKNOWN_ERROR,
      statusCode: 500,
      timestamp: timestamp || new Date().toISOString(),
      context,
      originalError: this.sanitizeError(error)
    };
  }

  // Sanitize error to prevent information leakage
  private static sanitizeError(error: any): any {
    if (!error) return null;

    // Remove sensitive information
    const sanitized = {
      message: error.message || 'Unknown error',
      code: error.code || 'UNKNOWN',
      name: error.name || 'Error'
    };

    // Remove stack trace in production
    if (process.env.NODE_ENV === 'production') {
      return sanitized;
    }

    return {
      ...sanitized,
      stack: error.stack
    };
  }

  // Get user-friendly message for display
  static getUserFriendlyMessage(error: UnifiedError): string {
    return error.message;
  }

  // Check if error is retryable
  static isRetryableError(error: UnifiedError): boolean {
    const retryableCodes = [
      this.ERROR_CODES.NETWORK_ERROR,
      this.ERROR_CODES.TIMEOUT_ERROR,
      this.ERROR_CODES.CONNECTION_ERROR,
      this.ERROR_CODES.DATABASE_CONNECTION_ERROR
    ];

    return retryableCodes.includes(error.code);
  }

  // Get retry delay for retryable errors
  static getRetryDelay(error: UnifiedError, attempt: number): number {
    if (!this.isRetryableError(error)) return 0;

    // Exponential backoff: 1s, 2s, 4s, 8s, 16s
    return Math.min(1000 * Math.pow(2, attempt - 1), 16000);
  }
}

// Export error codes for use in other files
export const ERROR_CODES = UnifiedErrorHandler['ERROR_CODES'];
