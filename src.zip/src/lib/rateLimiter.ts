// Rate limiting implementation for edge functions
interface RateLimitEntry {
  count: number;
  resetTime: number;
}

const rateLimitStore = new Map<string, RateLimitEntry>();

export class RateLimiter {
  private limit: number;
  private windowMs: number;

  constructor(limit: number, windowMs = 60000) { // 1 minute default
    this.limit = limit;
    this.windowMs = windowMs;
  }

  async checkLimit(identifier: string): Promise<{ allowed: boolean; remaining: number }> {
    const now = Date.now();
    const key = `${identifier}:${Math.floor(now / this.windowMs)}`;
    
    // Clean up old entries
    this.cleanup(now);
    
    const entry = rateLimitStore.get(key) || { count: 0, resetTime: now + this.windowMs };
    
    if (entry.count >= this.limit) {
      return { allowed: false, remaining: 0 };
    }
    
    entry.count++;
    rateLimitStore.set(key, entry);
    
    return { allowed: true, remaining: this.limit - entry.count };
  }

  private cleanup(now: number) {
    for (const [key, entry] of rateLimitStore.entries()) {
      if (now > entry.resetTime) {
        rateLimitStore.delete(key);
      }
    }
  }
}

// Rate limiter instances for different endpoints
export const rateLimiters = {
  default: new RateLimiter(100), // 100 requests per minute
  auth: new RateLimiter(5),      // 5 auth attempts per minute
  admin: new RateLimiter(50),    // 50 admin operations per minute
  api: new RateLimiter(200),     // 200 API calls per minute
};

// Middleware function for rate limiting
export const applyRateLimit = async (
  request: Request, 
  limiterType: keyof typeof rateLimiters = 'default'
): Promise<Response | null> => {
  const clientIP = request.headers.get('x-forwarded-for') || 
                   request.headers.get('x-real-ip') || 
                   'unknown';
  
  const limiter = rateLimiters[limiterType];
  const { allowed, remaining } = await limiter.checkLimit(clientIP);
  
  if (!allowed) {
    return new Response(JSON.stringify({
      error: 'Rate limit exceeded',
      message: 'Too many requests. Please try again later.'
    }), {
      status: 429,
      headers: {
        'Content-Type': 'application/json',
        'Retry-After': '60'
      }
    });
  }
  
  return null; // No rate limit hit, continue
};