import { supabase } from './supabase';

// SQL injection prevention utilities
export class SQLSecurity {
  // Whitelist of allowed table names
  private static readonly ALLOWED_TABLES = [
    'users', 'profiles', 'posts', 'habits', 'goals', 'goal_tasks',
    'acircle_groups', 'acircle_members', 'acircle_join_requests',
    'notifications', 'partnerships', 'partnership_messages',
    'group_posts', 'group_leaderboard', 'audit_logs',
    'subscription_plans', 'user_roles', 'subscription_tiers'
  ];

  // Whitelist of allowed column names
  private static readonly ALLOWED_COLUMNS = [
    'id', 'user_id', 'title', 'content', 'status', 'created_at',
    'updated_at', 'name', 'email', 'role', 'progress', 'completed',
    'description', 'category', 'priority', 'due_date', 'is_public'
  ];

  // Sanitize table name
  static sanitizeTableName(tableName: string): string {
    if (!this.ALLOWED_TABLES.includes(tableName)) {
      throw new Error('Invalid table name');
    }
    return tableName;
  }

  // Sanitize column name
  static sanitizeColumnName(columnName: string): string {
    if (!this.ALLOWED_COLUMNS.includes(columnName)) {
      throw new Error('Invalid column name');
    }
    return columnName;
  }

  // Sanitize ORDER BY clause
  static sanitizeOrderBy(orderBy: string): string {
    const validPattern = /^[a-zA-Z_][a-zA-Z0-9_]*(\s+(ASC|DESC))?$/i;
    if (!validPattern.test(orderBy.trim())) {
      throw new Error('Invalid ORDER BY clause');
    }
    return orderBy.trim();
  }

  // Safe query builder for SELECT operations
  static async safeSelect(
    table: string,
    columns: string[] = ['*'],
    conditions: Record<string, any> = {},
    options: { orderBy?: string; limit?: number } = {}
  ) {
    try {
      const safeTable = this.sanitizeTableName(table);
      let query = supabase.from(safeTable);

      // Apply select columns
      if (columns[0] !== '*') {
        const safeColumns = columns.map(col => this.sanitizeColumnName(col));
        query = query.select(safeColumns.join(','));
      } else {
        query = query.select('*');
      }

      // Apply conditions using Supabase's built-in parameterization
      Object.entries(conditions).forEach(([key, value]) => {
        const safeKey = this.sanitizeColumnName(key);
        query = query.eq(safeKey, value);
      });

      // Apply ordering
      if (options.orderBy) {
        const safeOrderBy = this.sanitizeOrderBy(options.orderBy);
        const [column, direction] = safeOrderBy.split(/\s+/);
        query = query.order(column, { 
          ascending: direction?.toUpperCase() !== 'DESC' 
        });
      }

      // Apply limit
      if (options.limit && options.limit > 0 && options.limit <= 1000) {
        query = query.limit(options.limit);
      }

      return await query;
    } catch (error) {
      console.error('SQL Security Error:', error);
      throw new Error('Database query failed');
    }
  }

  // Safe insert operation
  static async safeInsert(
    table: string,
    data: Record<string, any>
  ) {
    try {
      const safeTable = this.sanitizeTableName(table);
      
      // Validate all column names
      Object.keys(data).forEach(key => {
        this.sanitizeColumnName(key);
      });

      return await supabase
        .from(safeTable)
        .insert(data)
        .select();
    } catch (error) {
      console.error('SQL Security Error:', error);
      throw new Error('Database insert failed');
    }
  }

  // Safe update operation
  static async safeUpdate(
    table: string,
    data: Record<string, any>,
    conditions: Record<string, any>
  ) {
    try {
      const safeTable = this.sanitizeTableName(table);
      
      // Validate column names
      Object.keys(data).forEach(key => {
        this.sanitizeColumnName(key);
      });
      
      Object.keys(conditions).forEach(key => {
        this.sanitizeColumnName(key);
      });

      let query = supabase.from(safeTable).update(data);
      
      Object.entries(conditions).forEach(([key, value]) => {
        query = query.eq(key, value);
      });

      return await query.select();
    } catch (error) {
      console.error('SQL Security Error:', error);
      throw new Error('Database update failed');
    }
  }
}