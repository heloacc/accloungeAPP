// Production-safe logging utility
// Environment configuration
const DEV = true; // Change to false for production builds

export const logger = {
  info: (message: string, data?: any) => {
    if (DEV) {
      console.log(`[INFO] ${message}`, data);
    }
  },
  
  warn: (message: string, data?: any) => {
    if (DEV) {
      console.warn(`[WARN] ${message}`, data);
    }
  },
  
  error: (message: string, error?: any) => {
    if (DEV) {
      console.error(`[ERROR] ${message}`, error);
    }
    // In production, you might want to send to error tracking service
    // Example: Sentry.captureException(error);
  },
  
  debug: (message: string, data?: any) => {
    if (DEV) {
      console.debug(`[DEBUG] ${message}`, data);
    }
  }
};

export default logger;