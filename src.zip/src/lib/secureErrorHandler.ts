// Secure error handling to prevent information leakage

export interface SecureError {
  message: string;
  code: string;
  timestamp: string;
  requestId?: string;
}

export class SecureErrorHandler {
  private static readonly GENERIC_MESSAGES = {
    AUTH_ERROR: 'Authentication failed. Please try again.',
    VALIDATION_ERROR: 'Invalid input provided.',
    PERMISSION_ERROR: 'You do not have permission to perform this action.',
    RATE_LIMIT_ERROR: 'Too many requests. Please try again later.',
    DATABASE_ERROR: 'A database error occurred. Please try again.',
    NETWORK_ERROR: 'Network error. Please check your connection.',
    UNKNOWN_ERROR: 'An unexpected error occurred. Please try again.'
  };

  // Sanitize error for client response
  static sanitizeError(error: any, context?: string): SecureError {
    const timestamp = new Date().toISOString();
    const requestId = this.generateRequestId();

    // Log full error details server-side for debugging
    this.logSecurityEvent(error, context, requestId);

    // Determine safe error message for client
    let message = this.GENERIC_MESSAGES.UNKNOWN_ERROR;
    let code = 'UNKNOWN_ERROR';

    if (error?.message?.includes('auth')) {
      message = this.GENERIC_MESSAGES.AUTH_ERROR;
      code = 'AUTH_ERROR';
    } else if (error?.message?.includes('permission') || error?.message?.includes('unauthorized')) {
      message = this.GENERIC_MESSAGES.PERMISSION_ERROR;
      code = 'PERMISSION_ERROR';
    } else if (error?.message?.includes('validation') || error?.message?.includes('invalid')) {
      message = this.GENERIC_MESSAGES.VALIDATION_ERROR;
      code = 'VALIDATION_ERROR';
    } else if (error?.message?.includes('rate limit')) {
      message = this.GENERIC_MESSAGES.RATE_LIMIT_ERROR;
      code = 'RATE_LIMIT_ERROR';
    } else if (error?.message?.includes('database') || error?.message?.includes('sql')) {
      message = this.GENERIC_MESSAGES.DATABASE_ERROR;
      code = 'DATABASE_ERROR';
    } else if (error?.message?.includes('network') || error?.message?.includes('fetch')) {
      message = this.GENERIC_MESSAGES.NETWORK_ERROR;
      code = 'NETWORK_ERROR';
    }

    return {
      message,
      code,
      timestamp,
      requestId
    };
  }

  // Generate unique request ID for error tracking
  private static generateRequestId(): string {
    return `req_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  // Log security events (implement based on your logging system)
  private static logSecurityEvent(error: any, context?: string, requestId?: string): void {
    const logEntry = {
      timestamp: new Date().toISOString(),
      requestId,
      context,
      error: {
        message: error?.message,
        stack: error?.stack,
        name: error?.name
      },
      level: 'ERROR'
    };

    // In production, send to your logging service
    console.error('Security Event:', logEntry);
  }

  // Validate error response before sending to client
  static validateErrorResponse(response: any): boolean {
    // Check for potential information leakage
    const sensitivePatterns = [
      /password/i,
      /secret/i,
      /key/i,
      /token/i,
      /database/i,
      /sql/i,
      /stack trace/i,
      /file path/i,
      /server/i,
      /internal/i
    ];

    const responseStr = JSON.stringify(response);
    return !sensitivePatterns.some(pattern => pattern.test(responseStr));
  }

  // Create safe error response for API endpoints
  static createSafeResponse(error: any, context?: string): Response {
    const secureError = this.sanitizeError(error, context);
    
    // Validate response doesn't leak sensitive info
    if (!this.validateErrorResponse(secureError)) {
      secureError.message = this.GENERIC_MESSAGES.UNKNOWN_ERROR;
      secureError.code = 'UNKNOWN_ERROR';
    }

    return new Response(JSON.stringify(secureError), {
      status: 500,
      headers: {
        'Content-Type': 'application/json',
        'X-Request-ID': secureError.requestId || 'unknown'
      }
    });
  }
}