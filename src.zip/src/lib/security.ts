// Production security configuration and utilities
export const PRODUCTION_CONFIG = {
  ALLOWED_ORIGINS: ['https://acclounge.org', 'https://www.acclounge.org'],
  RATE_LIMITS: {
    DEFAULT: 100, // requests per minute
    AUTH: 5,      // login attempts per minute
    ADMIN: 50,    // admin operations per minute
    API: 200      // general API calls per minute
  },
  CSRF_TOKEN_EXPIRY: 3600000, // 1 hour in ms
} as const;

// Secure CORS headers for production
export const getSecureCorsHeaders = () => ({
  'Access-Control-Allow-Origin': 'https://acclounge.org',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-csrf-token',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Credentials': 'true',
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'X-XSS-Protection': '1; mode=block',
  'Strict-Transport-Security': 'max-age=31536000; includeSubDomains',
});

// Input sanitization utilities
export const sanitizeInput = {
  string: (input: string, maxLength = 1000): string => {
    if (typeof input !== 'string') throw new Error('Invalid input type');
    return input.trim().slice(0, maxLength).replace(/[<>]/g, '');
  },
  
  email: (email: string): string => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) throw new Error('Invalid email format');
    return email.toLowerCase().trim();
  },
  
  uuid: (uuid: string): string => {
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
    if (!uuidRegex.test(uuid)) throw new Error('Invalid UUID format');
    return uuid;
  },
  
  number: (num: any, min = 0, max = Number.MAX_SAFE_INTEGER): number => {
    const parsed = parseInt(num);
    if (isNaN(parsed) || parsed < min || parsed > max) {
      throw new Error('Invalid number');
    }
    return parsed;
  }
};

// Secure error response without data leaks
export const createSecureErrorResponse = (error: any, statusCode = 500) => {
  const isDev = Deno.env.get('ENVIRONMENT') === 'development';
  
  return new Response(JSON.stringify({
    error: true,
    message: isDev ? error.message : 'An error occurred',
    code: statusCode
  }), {
    status: statusCode,
    headers: {
      'Content-Type': 'application/json',
      ...getSecureCorsHeaders()
    }
  });
};