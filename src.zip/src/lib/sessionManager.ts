import { supabase } from './supabase';

// Global session manager for connection pooling and cleanup
class SessionManager {
  private static instance: SessionManager;
  private activeConnections = new Set<string>();
  private connectionPool = new Map<string, Promise<any>>();
  private maxConnections = 50; // Limit concurrent connections
  private heartbeatInterval: NodeJS.Timeout | null = null;
  private sessionCleanupInterval: NodeJS.Timeout | null = null;

  private constructor() {
    this.startGlobalHeartbeat();
    this.startSessionCleanup();
  }

  static getInstance(): SessionManager {
    if (!SessionManager.instance) {
      SessionManager.instance = new SessionManager();
    }
    return SessionManager.instance;
  }

  // Connection pooling for auth requests
  async executeWithPool<T>(key: string, fn: () => Promise<T>): Promise<T> {
    // If same request is already running, return existing promise
    if (this.connectionPool.has(key)) {
      return this.connectionPool.get(key);
    }

    // Wait if too many concurrent connections
    while (this.activeConnections.size >= this.maxConnections) {
      await new Promise(resolve => setTimeout(resolve, 100));
    }

    this.activeConnections.add(key);
    
    const promise = fn()
      .finally(() => {
        this.activeConnections.delete(key);
        this.connectionPool.delete(key);
      });

    this.connectionPool.set(key, promise);
    return promise;
  }

  // Global heartbeat to monitor all sessions
  private startGlobalHeartbeat() {
    if (this.heartbeatInterval) {
      clearInterval(this.heartbeatInterval);
    }

    this.heartbeatInterval = setInterval(async () => {
      try {
        // Check if we have too many stale connections
        if (this.activeConnections.size > this.maxConnections * 0.8) {
          console.warn('High connection usage detected, cleaning up...');
          this.cleanupStaleConnections();
        }

        // Ping Supabase to keep connection alive
        await supabase.auth.getSession();
      } catch (error) {
        console.warn('Global heartbeat failed:', error);
      }
    }, 30000); // Every 30 seconds
  }

  // Cleanup stale sessions and connections
  private startSessionCleanup() {
    if (this.sessionCleanupInterval) {
      clearInterval(this.sessionCleanupInterval);
    }

    this.sessionCleanupInterval = setInterval(() => {
      this.cleanupStaleConnections();
    }, 5 * 60 * 1000); // Every 5 minutes
  }

  private cleanupStaleConnections() {
    // Clear old connection pool entries
    const now = Date.now();
    const maxAge = 10 * 60 * 1000; // 10 minutes

    this.connectionPool.forEach((promise, key) => {
      // If promise is old, remove it
      if (key.includes('_') && now - parseInt(key.split('_')[1]) > maxAge) {
        this.connectionPool.delete(key);
        this.activeConnections.delete(key);
      }
    });
  }

  // Enhanced retry with circuit breaker pattern
  async withRetry<T>(
    fn: () => Promise<T>,
    context: string,
    maxRetries = 3,
    baseDelay = 1000
  ): Promise<T> {
    let lastError: Error;

    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      try {
        return await fn();
      } catch (error) {
        lastError = error as Error;
        
        // Don't retry on certain errors
        if (error instanceof Error && (
          error.message.includes('Invalid token') ||
          error.message.includes('Unauthorized') ||
          error.message.includes('403')
        )) {
          throw error;
        }

        if (attempt === maxRetries) {
          console.error(`${context} failed after ${maxRetries} attempts:`, error);
          throw error;
        }

        // Exponential backoff with jitter
        const delay = baseDelay * Math.pow(2, attempt - 1) + Math.random() * 1000;
        const cappedDelay = Math.min(delay, 30000); // Cap at 30 seconds
        
        console.warn(`${context} attempt ${attempt} failed, retrying in ${cappedDelay}ms:`, error);
        await new Promise(resolve => setTimeout(resolve, cappedDelay));
      }
    }

    throw lastError!;
  }

  // Graceful shutdown
  destroy() {
    if (this.heartbeatInterval) {
      clearInterval(this.heartbeatInterval);
    }
    if (this.sessionCleanupInterval) {
      clearInterval(this.sessionCleanupInterval);
    }
    
    this.activeConnections.clear();
    this.connectionPool.clear();
  }

  // Get connection stats for monitoring
  getStats() {
    return {
      activeConnections: this.activeConnections.size,
      pooledConnections: this.connectionPool.size,
      maxConnections: this.maxConnections
    };
  }
}

export const sessionManager = SessionManager.getInstance();

// Cleanup on page unload
if (typeof window !== 'undefined') {
  window.addEventListener('beforeunload', () => {
    sessionManager.destroy();
  });
}