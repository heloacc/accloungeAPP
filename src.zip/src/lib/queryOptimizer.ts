import { supabase } from './supabase';

// Query performance monitoring
export interface QueryMetrics {
  query: string;
  duration: number;
  timestamp: number;
  table: string;
  operation: string;
}

class QueryOptimizer {
  private queryCache = new Map<string, { data: any; timestamp: number; ttl: number }>();
  private metrics: QueryMetrics[] = [];
  private slowQueryThreshold = 1000; // 1 second

  // Cache management
  setCache(key: string, data: any, ttl = 300000) { // 5 minutes default
    this.queryCache.set(key, {
      data,
      timestamp: Date.now(),
      ttl
    });
  }

  getCache(key: string) {
    const cached = this.queryCache.get(key);
    if (!cached) return null;
    
    if (Date.now() - cached.timestamp > cached.ttl) {
      this.queryCache.delete(key);
      return null;
    }
    
    return cached.data;
  }

  clearCache(pattern?: string) {
    if (pattern) {
      for (const key of this.queryCache.keys()) {
        if (key.includes(pattern)) {
          this.queryCache.delete(key);
        }
      }
    } else {
      this.queryCache.clear();
    }
  }

  // Performance monitoring
  async executeQuery<T>(
    queryFn: () => Promise<T>,
    queryInfo: { table: string; operation: string; query: string }
  ): Promise<T> {
    const startTime = Date.now();
    
    try {
      const result = await queryFn();
      const duration = Date.now() - startTime;
      
      this.recordMetric({
        ...queryInfo,
        duration,
        timestamp: startTime
      });
      
      if (duration > this.slowQueryThreshold) {
        console.warn(`Slow query detected: ${queryInfo.table}.${queryInfo.operation} took ${duration}ms`);
      }
      
      return result;
    } catch (error) {
      const duration = Date.now() - startTime;
      this.recordMetric({
        ...queryInfo,
        duration,
        timestamp: startTime
      });
      throw error;
    }
  }

  private recordMetric(metric: QueryMetrics) {
    this.metrics.push(metric);
    // Keep only last 1000 metrics
    if (this.metrics.length > 1000) {
      this.metrics = this.metrics.slice(-1000);
    }
  }

  getSlowQueries(threshold = this.slowQueryThreshold) {
    return this.metrics.filter(m => m.duration > threshold);
  }

  getQueryStats() {
    const stats = this.metrics.reduce((acc, metric) => {
      const key = `${metric.table}.${metric.operation}`;
      if (!acc[key]) {
        acc[key] = { count: 0, totalDuration: 0, avgDuration: 0 };
      }
      acc[key].count++;
      acc[key].totalDuration += metric.duration;
      acc[key].avgDuration = acc[key].totalDuration / acc[key].count;
      return acc;
    }, {} as Record<string, any>);
    
    return Object.entries(stats).map(([key, data]) => ({ query: key, ...data }));
  }
}

export const queryOptimizer = new QueryOptimizer();