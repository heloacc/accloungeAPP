// Production environment configuration and validation
interface EnvironmentConfig {
  supabaseUrl: string;
  supabaseAnonKey: string;
  environment: 'development' | 'production';
  allowedOrigins: string[];
  rateLimits: {
    default: number;
    auth: number;
    admin: number;
  };
}

// Environment configuration - hardcoded values
const VITE_SUPABASE_URL = 'https://sxoshewvwyhxlavbtgog.supabase.co'; // Add your Supabase URL here
const VITE_SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InN4b3NoZXd2d3loeGxhdmJ0Z29nIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MjI3NjY0NzMsImV4cCI6MjAzODM0MjQ3M30.UhEp8Rnr9OTqBOCFxJUlKrXKhDO2qGDHfqyqCxG-sSE'; // Add your Supabase anon key here
const NODE_ENV = 'development'; // Change to 'production' for production builds

// Validate required environment variables with fallbacks for platforms without env support
const getEnvVar = (name: string, fallback?: string): string => {
  // Use hardcoded values instead of environment variables
  switch (name) {
    case 'VITE_SUPABASE_URL':
      return VITE_SUPABASE_URL;
    case 'VITE_SUPABASE_ANON_KEY':
      return VITE_SUPABASE_ANON_KEY;
    default:
      if (fallback && fallback.trim() !== '') {
        return fallback.trim();
      }
      throw new Error(`Missing required configuration: ${name} and no fallback provided`);
  }
};

// Secure environment configuration with fallbacks for Famous AI/similar platforms
export const getEnvironmentConfig = (): EnvironmentConfig => {
  const config: EnvironmentConfig = {
    // Use env vars if available, otherwise fallback to hardcoded (for Famous AI)
    supabaseUrl: getEnvVar('VITE_SUPABASE_URL', 'https://sxoshewvwyhxlavbtgog.supabase.co'),
    supabaseAnonKey: getEnvVar('VITE_SUPABASE_ANON_KEY', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InN4b3NoZXd2d3loeGxhdmJ0Z29nIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MjI3NjY0NzMsImV4cCI6MjAzODM0MjQ3M30.UhEp8Rnr9OTqBOCFxJUlKrXKhDO2qGDHfqyqCxG-sSE'),
    environment: NODE_ENV === 'development' ? 'development' : 'production',
    allowedOrigins: [
      'https://acclounge.org', 
      'https://www.acclounge.org', 
      'https://preview-x0ihf5u6--growth-action-support.deploypad.app',
      'http://localhost:5173', 
      'http://localhost:3000'
    ],
    rateLimits: {
      default: 100,
      auth: 5,
      admin: 50
    }
  };

  return config;
};

// Validate configuration on startup
export const validateEnvironment = (): void => {
  try {
    const config = getEnvironmentConfig();
    
    // Validate URLs
    new URL(config.supabaseUrl);
    
    // Validate allowed origins
    config.allowedOrigins.forEach(origin => {
      new URL(origin);
    });
    
    console.log('Environment configuration validated successfully');
  } catch (error) {
    console.error('Environment validation failed:', error);
    throw error;
  }
};

// Check if origin is allowed
export const isOriginAllowed = (origin: string | null): boolean => {
  if (!origin) return false;
  const config = getEnvironmentConfig();
  return config.allowedOrigins.includes(origin);
};

// Get rate limit for specific endpoint type
export const getRateLimit = (type: keyof EnvironmentConfig['rateLimits']): number => {
  const config = getEnvironmentConfig();
  return config.rateLimits[type];
};