import { supabase } from './supabase';
import { queryOptimizer } from './queryOptimizer';

// Optimized queries for accountability groups
export const optimizedGroupQueries = {
  // Get user's groups with member count (optimized with single query)
  async getUserGroupsWithStats(userId: string) {
    const cacheKey = `user_groups_${userId}`;
    const cached = queryOptimizer.getCache(cacheKey);
    if (cached) return cached;

    const result = await queryOptimizer.executeQuery(
      async () => {
        const { data, error } = await supabase
          .from('acircle_members')
          .select(`
            acircle_groups!inner (
              id, name, description, created_at, creator_id,
              member_count:acircle_members(count)
            )
          `)
          .eq('user_id', userId)
          .eq('status', 'active');
        
        if (error) throw error;
        return data;
      },
      { table: 'acircle_members', operation: 'getUserGroupsWithStats', query: 'user groups with member count' }
    );

    queryOptimizer.setCache(cacheKey, result, 180000); // 3 minutes
    return result;
  },

  // Get group members with profiles (optimized join)
  async getGroupMembersOptimized(groupId: string) {
    const cacheKey = `group_members_${groupId}`;
    const cached = queryOptimizer.getCache(cacheKey);
    if (cached) return cached;

    const result = await queryOptimizer.executeQuery(
      async () => {
        const { data, error } = await supabase
          .from('acircle_members')
          .select(`
            user_id, status, joined_at, role,
            profiles!inner (
              id, username, avatar_url, full_name
            )
          `)
          .eq('group_id', groupId)
          .eq('status', 'active')
          .order('joined_at', { ascending: true });
        
        if (error) throw error;
        return data;
      },
      { table: 'acircle_members', operation: 'getGroupMembers', query: 'group members with profiles' }
    );

    queryOptimizer.setCache(cacheKey, result, 300000); // 5 minutes
    return result;
  },

  // Get group posts with engagement metrics
  async getGroupPostsOptimized(groupId: string, limit = 20) {
    const cacheKey = `group_posts_${groupId}_${limit}`;
    const cached = queryOptimizer.getCache(cacheKey);
    if (cached) return cached;

    const result = await queryOptimizer.executeQuery(
      async () => {
        const { data, error } = await supabase
          .from('group_posts')
          .select(`
            id, content, created_at, user_id, post_type,
            profiles!inner (username, avatar_url, full_name),
            likes:post_likes(count),
            comments:post_comments(count)
          `)
          .eq('group_id', groupId)
          .order('created_at', { ascending: false })
          .limit(limit);
        
        if (error) throw error;
        return data;
      },
      { table: 'group_posts', operation: 'getGroupPosts', query: 'group posts with engagement' }
    );

    queryOptimizer.setCache(cacheKey, result, 60000); // 1 minute
    return result;
  }
};

// Optimized user management queries
export const optimizedUserQueries = {
  // Get user profile with subscription info
  async getUserProfileOptimized(userId: string) {
    const cacheKey = `user_profile_${userId}`;
    const cached = queryOptimizer.getCache(cacheKey);
    if (cached) return cached;

    const result = await queryOptimizer.executeQuery(
      async () => {
        const { data, error } = await supabase
          .from('profiles')
          .select(`
            *, 
            subscription_tiers (tier_name, features),
            user_roles (role_name, permissions)
          `)
          .eq('id', userId)
          .single();
        
        if (error) throw error;
        return data;
      },
      { table: 'profiles', operation: 'getUserProfile', query: 'user profile with subscription' }
    );

    queryOptimizer.setCache(cacheKey, result, 600000); // 10 minutes
    return result;
  },

  // Get user's habits and goals efficiently
  async getUserHabitsGoalsOptimized(userId: string) {
    const cacheKey = `user_habits_goals_${userId}`;
    const cached = queryOptimizer.getCache(cacheKey);
    if (cached) return cached;

    const result = await queryOptimizer.executeQuery(
      async () => {
        const [habitsResult, goalsResult] = await Promise.all([
          supabase
            .from('habits')
            .select('id, title, description, frequency, streak_count, last_completed_at')
            .eq('user_id', userId)
            .eq('is_active', true)
            .order('created_at', { ascending: false }),
          
          supabase
            .from('goals')
            .select(`
              id, title, description, target_date, progress, status,
              goal_tasks (id, title, completed, due_date)
            `)
            .eq('user_id', userId)
            .neq('status', 'completed')
            .order('created_at', { ascending: false })
        ]);

        if (habitsResult.error) throw habitsResult.error;
        if (goalsResult.error) throw goalsResult.error;

        return {
          habits: habitsResult.data,
          goals: goalsResult.data
        };
      },
      { table: 'habits_goals', operation: 'getUserHabitsGoals', query: 'user habits and goals' }
    );

    queryOptimizer.setCache(cacheKey, result, 300000); // 5 minutes
    return result;
  }
};

// Cache invalidation helpers
export const cacheInvalidation = {
  invalidateUserCache(userId: string) {
    queryOptimizer.clearCache(`user_${userId}`);
    queryOptimizer.clearCache(`user_profile_${userId}`);
    queryOptimizer.clearCache(`user_habits_goals_${userId}`);
  },

  invalidateGroupCache(groupId: string) {
    queryOptimizer.clearCache(`group_${groupId}`);
    queryOptimizer.clearCache(`group_members_${groupId}`);
    queryOptimizer.clearCache(`group_posts_${groupId}`);
  },

  invalidateAllUserGroups(userId: string) {
    queryOptimizer.clearCache(`user_groups_${userId}`);
  }
};