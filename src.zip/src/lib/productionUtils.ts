// Quick production fixes - replace all console.log with safe logging
// Environment configuration
const DEV = true; // Change to false for production builds
const PROD = false; // Change to true for production builds
const VITE_SUPABASE_URL = 'https://sxoshewvwyhxlavbtgog.supabase.co'; // Add your Supabase URL here
const VITE_SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InN4b3NoZXd2d3loeGxhdmJ0Z29nIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MjI3NjY0NzMsImV4cCI6MjAzODM0MjQ3M30.UhEp8Rnr9OTqBOCFxJUlKrXKhDO2qGDHfqyqCxG-sSE'; // Add your Supabase anon key here

export const safeLog = {
  info: (msg: string, data?: any) => {
    if (DEV) console.log(msg, data);
  },
  error: (msg: string, error?: any) => {
    if (DEV) console.error(msg, error);
  },
  warn: (msg: string, data?: any) => {
    if (DEV) console.warn(msg, data);
  }
};

// Replace console.log globally for production
if (PROD) {
  console.log = () => {};
  console.debug = () => {};
  console.info = () => {};
}

// Basic error boundary for production
export const handleProductionError = (error: any, context: string) => {
  if (PROD) {
    // In production, just return generic message
    return 'An error occurred. Please try again.';
  }
  return error?.message || 'Unknown error';
};

// Environment validation
export const validateEnvironment = () => {
  if (PROD) {
    const required = ['VITE_SUPABASE_URL', 'VITE_SUPABASE_ANON_KEY'];
    const missing = required.filter(key => {
      switch(key) {
        case 'VITE_SUPABASE_URL': return !VITE_SUPABASE_URL;
        case 'VITE_SUPABASE_ANON_KEY': return !VITE_SUPABASE_ANON_KEY;
        default: return true;
      }
    });
    if (missing.length > 0) {
      throw new Error(`Missing environment variables: ${missing.join(', ')}`);
    }
  }
};