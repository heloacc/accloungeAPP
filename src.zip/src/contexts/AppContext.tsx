// Redirect to UnifiedAuthContext for backward compatibility
export { useUnifiedAuthContext as useAppContext, UnifiedAuthProvider as AppProvider } from './UnifiedAuthContext';
export type { User, Achievement, AppNotification, UnifiedAuthContextType as AppContextType } from './UnifiedAuthContext';
