import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { logger } from '@/lib/secureLogger';

type AuthState = 
  | { status: 'unauthenticated' }
  | { status: 'authenticated'; session: any; user: any }
  | { status: 'refreshing'; prevSession: any; prevUser: any }
  | { status: 'error'; error: string; prevSession?: any; prevUser?: any };

interface AuthContextType {
  authState: AuthState;
  refreshAuth: () => Promise<boolean>;
  signOut: () => Promise<void>;
  clearError: () => void;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType>({} as AuthContextType);

export const useAuthState = () => useContext(AuthContext);

export const AuthStateProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [authState, setAuthState] = useState<AuthState>({ status: 'unauthenticated' });
  const [isLoading, setIsLoading] = useState(true);

  const refreshAuth = useCallback(async (): Promise<boolean> => {
    try {
      // If we have a previous session, keep it during refresh
      if (authState.status === 'authenticated') {
        setAuthState({
          status: 'refreshing',
          prevSession: authState.session,
          prevUser: authState.user
        });
      }

      const { data: { session }, error } = await supabase.auth.refreshSession();
      
      if (error) {
        logger.error('Auth refresh failed:', error);
        
        // If we had a previous session, try to keep it with error state
        if (authState.status === 'refreshing') {
          setAuthState({
            status: 'error',
            error: error.message,
            prevSession: authState.prevSession,
            prevUser: authState.prevUser
          });
        } else {
          setAuthState({
            status: 'error',
            error: error.message
          });
        }
        return false;
      }

      if (session?.user) {
        const userData = {
          id: session.user.id,
          name: session.user.email?.split('@')[0] || 'User',
          full_name: session.user.email?.split('@')[0] || 'User',
          email: session.user.email || '',
          isAdmin: session.user.email === 'hello@acclounge.org',
          joinDate: new Date(session.user.created_at),
          gatherSubscribed: false,
          winsNotifications: true,
        };

        setAuthState({
          status: 'authenticated',
          session,
          user: userData
        });
        return true;
      } else {
        setAuthState({ status: 'unauthenticated' });
        return false;
      }
    } catch (err) {
      logger.error('Auth refresh error:', err);
      setAuthState({
        status: 'error',
        error: err instanceof Error ? err.message : 'Auth refresh failed'
      });
      return false;
    }
  }, [authState]);

  const signOut = useCallback(async () => {
    try {
      await supabase.auth.signOut();
      setAuthState({ status: 'unauthenticated' });
    } catch (error) {
      logger.error('Sign out error:', error);
      // Force unauthenticated state even if sign out fails
      setAuthState({ status: 'unauthenticated' });
    }
  }, []);

  const clearError = useCallback(() => {
    if (authState.status === 'error') {
      if (authState.prevSession && authState.prevUser) {
        setAuthState({
          status: 'authenticated',
          session: authState.prevSession,
          user: authState.prevUser
        });
      } else {
        setAuthState({ status: 'unauthenticated' });
      }
    }
  }, [authState]);

  // Initialize auth state
  useEffect(() => {
    let isMounted = true;
    let initTimeout: NodeJS.Timeout;

    const initializeAuth = async () => {
      try {
        setIsLoading(true);

        // Set hard timeout to prevent infinite loading
        initTimeout = setTimeout(() => {
          if (isMounted) {
            logger.warn('Auth initialization timed out');
            setAuthState({
              status: 'error',
              error: 'Authentication timeout - please refresh the page'
            });
            setIsLoading(false);
          }
        }, 5000);

        const { data: { session }, error } = await supabase.auth.getSession();
        
        if (!isMounted) return;
        
        clearTimeout(initTimeout);

        if (error) {
          logger.error('Initial session error:', error);
          setAuthState({
            status: 'error',
            error: error.message
          });
        } else if (session?.user) {
          const userData = {
            id: session.user.id,
            name: session.user.email?.split('@')[0] || 'User',
            full_name: session.user.email?.split('@')[0] || 'User',
            email: session.user.email || '',
            isAdmin: session.user.email === 'hello@acclounge.org',
            joinDate: new Date(session.user.created_at),
            gatherSubscribed: false,
            winsNotifications: true,
          };

          setAuthState({
            status: 'authenticated',
            session,
            user: userData
          });
        } else {
          setAuthState({ status: 'unauthenticated' });
        }
      } catch (err) {
        if (isMounted) {
          logger.error('Auth initialization error:', err);
          setAuthState({
            status: 'error',
            error: err instanceof Error ? err.message : 'Auth initialization failed'
          });
        }
      } finally {
        if (isMounted) {
          setIsLoading(false);
        }
      }
    };

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        if (!isMounted) return;

        logger.info('Auth state change:', event);

        if (event === 'SIGNED_IN' && session?.user) {
          const userData = {
            id: session.user.id,
            name: session.user.email?.split('@')[0] || 'User',
            full_name: session.user.email?.split('@')[0] || 'User',
            email: session.user.email || '',
            isAdmin: session.user.email === 'hello@acclounge.org',
            joinDate: new Date(session.user.created_at),
            gatherSubscribed: false,
            winsNotifications: true,
          };

          setAuthState({
            status: 'authenticated',
            session,
            user: userData
          });
        } else if (event === 'SIGNED_OUT') {
          setAuthState({ status: 'unauthenticated' });
        } else if (event === 'TOKEN_REFRESHED' && session?.user) {
          // Keep existing user data during token refresh
          if (authState.status === 'authenticated' || authState.status === 'refreshing') {
            const currentUser = authState.status === 'authenticated' ? authState.user : authState.prevUser;
            setAuthState({
              status: 'authenticated',
              session,
              user: currentUser
            });
          }
        }
      }
    );

    initializeAuth();

    return () => {
      isMounted = false;
      clearTimeout(initTimeout);
      subscription.unsubscribe();
    };
  }, []);

  return (
    <AuthContext.Provider value={{
      authState,
      refreshAuth,
      signOut,
      clearError,
      isLoading
    }}>
      {children}
    </AuthContext.Provider>
  );
};