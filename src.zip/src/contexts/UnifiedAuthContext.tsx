import React, { createContext, useContext, useState, useEffect, useCallback, useRef } from 'react';
import { toast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabase';
import { logger } from '@/lib/secureLogger';

// Unified interfaces
export interface User {
  id: string;
  name: string;
  full_name?: string;
  email: string;
  isAdmin: boolean;
  joinDate: Date;
  lastPartnerMatch?: Date;
  currentPartner?: string;
  gatherSubscribed?: boolean;
  winsNotifications?: boolean;
}

export interface Achievement {
  id: string;
  name: string;
  description: string;
  icon: string;
  category: 'habits' | 'social' | 'streaks' | 'goals';
  rarity: 'common' | 'rare' | 'epic' | 'legendary';
  unlocked: boolean;
  unlockedAt?: Date;
  progress?: number;
  target?: number;
  reward?: string;
}

export interface AppNotification {
  id: string;
  title: string;
  message: string;
  type: 'motivational' | 'reminder' | 'announcement' | 'gather' | 'wins';
  createdAt: Date;
  createdBy: string;
  isActive: boolean;
  dismissed?: boolean;
}

// Comprehensive unified context interface
export interface UnifiedAuthContextType {
  // UI State
  sidebarOpen: boolean;
  toggleSidebar: () => void;
  activeTab: string;
  setActiveTab: (tab: string, data?: any) => void;
  
  // Authentication State
  currentUser: User | null;
  isLoading: boolean;
  authError: string | null;
  isAuthenticated: boolean;
  
  // Data Collections
  users: User[];
  achievements: Achievement[];
  notifications: AppNotification[];
  
  // Authentication Actions
  signOut: () => Promise<void>;
  refreshUser: () => Promise<void>;
  setCurrentUser: (user: User | null) => void;
  setIsLoading: (loading: boolean) => void;
  clearAuthError: () => void;
  
  // User Management
  addUser: (user: Omit<User, 'id' | 'joinDate'>) => Promise<void>;
  updateUser: (id: string, updates: Partial<User>) => Promise<void>;
  
  // Achievement System
  unlockAchievement: (id: string) => Promise<void>;
  updateAchievementProgress: (id: string, progress: number) => Promise<void>;
  
  // Notification System
  addNotification: (notification: Omit<AppNotification, 'id' | 'createdAt'>) => Promise<void>;
  removeNotification: (id: string) => Promise<void>;
  dismissNotification: (id: string) => Promise<void>;
  
  // Partnership System
  matchPartners: () => Promise<void>;
  removePartnership: () => Promise<void>;
  
  // Subscription Management
  updateGatherSubscription: (subscribed: boolean) => Promise<void>;
  updateWinsNotifications: (enabled: boolean) => Promise<void>;
  
  // Notification Broadcasting
  notifyGatherSubscribers: (message: string, author: string) => Promise<void>;
  notifyWinsSubscribers: (message: string, author: string) => Promise<void>;
  
  // App Management
  refreshApp: () => Promise<void>;
  
  // Compatibility properties for existing components
  canCreateGroups: boolean;
  
  // Error Handling
  handleError: (error: any, context?: string) => void;
}

// Create context
const UnifiedAuthContext = createContext<UnifiedAuthContextType | undefined>(undefined);

// Custom hook for using the context
export const useUnifiedAuthContext = () => {
  const context = useContext(UnifiedAuthContext);
  if (context === undefined) {
    throw new Error('useUnifiedAuthContext must be used within a UnifiedAuthProvider');
  }
  return context;
};

// Backward compatibility hook for existing components
export const useAppContext = () => {
  return useUnifiedAuthContext();
};

// Service layer for data operations
class DataService {
  static async fetchUsers(): Promise<User[]> {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data || [];
    } catch (error) {
      logger.error('Error fetching users:', error);
      throw error;
    }
  }

  static async fetchAchievements(userId: string): Promise<Achievement[]> {
    try {
      const { data, error } = await supabase
        .from('achievements')
        .select('*')
        .eq('user_id', userId);
      
      if (error) throw error;
      return data || [];
    } catch (error) {
      logger.error('Error fetching achievements:', error);
      throw error;
    }
  }

  static async fetchNotifications(userId: string): Promise<AppNotification[]> {
    try {
      const { data, error } = await supabase
        .from('notifications')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data || [];
    } catch (error) {
      logger.error('Error fetching notifications:', error);
      throw error;
    }
  }

  static async createUser(userData: Omit<User, 'id' | 'joinDate'>): Promise<User> {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .insert([{
          ...userData,
          joinDate: new Date().toISOString()
        }])
        .select()
        .single();
      
      if (error) throw error;
      return data;
    } catch (error) {
      logger.error('Error creating user:', error);
      throw error;
    }
  }

  static async updateUserProfile(id: string, updates: Partial<User>): Promise<User> {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .update(updates)
        .eq('id', id)
        .select()
        .single();
      
      if (error) throw error;
      return data;
    } catch (error) {
      logger.error('Error updating user:', error);
      throw error;
    }
  }

  static async createAchievement(achievementData: Omit<Achievement, 'id'>): Promise<Achievement> {
    try {
      const { data, error } = await supabase
        .from('achievements')
        .insert([achievementData])
        .select()
        .single();
      
      if (error) throw error;
      return data;
    } catch (error) {
      logger.error('Error creating achievement:', error);
      throw error;
    }
  }

  static async createNotification(notificationData: Omit<AppNotification, 'id' | 'createdAt'>): Promise<AppNotification> {
    try {
      const { data, error } = await supabase
        .from('notifications')
        .insert([{
          ...notificationData,
          createdAt: new Date().toISOString()
        }])
        .select()
        .single();
      
      if (error) throw error;
      return data;
    } catch (error) {
      logger.error('Error creating notification:', error);
      throw error;
    }
  }
}

// Main provider component
export const UnifiedAuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // UI State
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('dashboard');
  
  // Authentication State
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [authError, setAuthError] = useState<string | null>(null);
  
  // Data Collections
  const [users, setUsers] = useState<User[]>([]);
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  
  // Refs for preventing race conditions
  const isInitializedRef = useRef(false);
  const authSubscriptionRef = useRef<any>(null);

  // Initialize authentication
  const initializeAuth = useCallback(async () => {
    if (isInitializedRef.current) return;
    isInitializedRef.current = true;

    try {
      setIsLoading(true);
      setAuthError(null);

      // Get current session
      const { data: { session }, error } = await supabase.auth.getSession();
      if (error) throw error;

      if (session?.user) {
        // Load user data
        const { data: profile, error: profileError } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', session.user.id)
          .single();

        if (profileError) throw profileError;

        const user: User = {
          id: profile.id,
          name: profile.name || profile.full_name || session.user.email?.split('@')[0] || 'User',
          full_name: profile.full_name,
          email: session.user.email || '',
          isAdmin: profile.isAdmin || false,
          joinDate: new Date(profile.created_at || Date.now()),
          gatherSubscribed: profile.gatherSubscribed || false,
          winsNotifications: profile.winsNotifications || false,
          lastPartnerMatch: profile.lastPartnerMatch ? new Date(profile.lastPartnerMatch) : undefined,
          currentPartner: profile.currentPartner
        };

        setCurrentUser(user);
        
        // Load user-specific data
        await loadUserData(user.id);
      }
    } catch (error) {
      console.error('Auth initialization error:', error);
      setAuthError(error instanceof Error ? error.message : 'Authentication failed');
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Load user-specific data
  const loadUserData = useCallback(async (userId: string) => {
    try {
      const [achievementsData, notificationsData] = await Promise.all([
        DataService.fetchAchievements(userId),
        DataService.fetchNotifications(userId)
      ]);

      setAchievements(achievementsData);
      setNotifications(notificationsData);
    } catch (error) {
      console.error('Error loading user data:', error);
    }
  }, []);

  // Set up auth state listener
  useEffect(() => {
    initializeAuth();

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
      console.log('Auth state change:', event, session?.user?.id);
      
      if (event === 'SIGNED_IN' && session?.user) {
        try {
          const { data: profile, error } = await supabase
            .from('profiles')
            .select('*')
            .eq('id', session.user.id)
            .single();

          if (error) throw error;

          const user: User = {
            id: profile.id,
            name: profile.name || profile.full_name || session.user.email?.split('@')[0] || 'User',
            full_name: profile.full_name,
            email: session.user.email || '',
            isAdmin: profile.isAdmin || false,
            joinDate: new Date(profile.created_at || Date.now()),
            gatherSubscribed: profile.gatherSubscribed || false,
            winsNotifications: profile.winsNotifications || false,
            lastPartnerMatch: profile.lastPartnerMatch ? new Date(profile.lastPartnerMatch) : undefined,
            currentPartner: profile.currentPartner
          };

          setCurrentUser(user);
          await loadUserData(user.id);
        } catch (error) {
          console.error('Error handling sign in:', error);
          setAuthError(error instanceof Error ? error.message : 'Sign in failed');
        }
      } else if (event === 'SIGNED_OUT') {
        setCurrentUser(null);
        setAchievements([]);
        setNotifications([]);
        setAuthError(null);
      }
    });

    authSubscriptionRef.current = subscription;

    return () => {
      if (authSubscriptionRef.current) {
        authSubscriptionRef.current.unsubscribe();
      }
    };
  }, [initializeAuth, loadUserData]);

  // UI Actions
  const toggleSidebar = useCallback(() => {
    setSidebarOpen(prev => !prev);
  }, []);

  const setActiveTabWithData = useCallback((tab: string, data?: any) => {
    setActiveTab(tab);
    // Handle any additional data if needed
    if (data) {
      console.log('Tab data:', data);
    }
  }, []);

  // Authentication Actions
  const signOut = useCallback(async () => {
    try {
      setIsLoading(true);
      const { error } = await supabase.auth.signOut();
      if (error) throw error;
      
      setCurrentUser(null);
      setAchievements([]);
      setNotifications([]);
      setAuthError(null);
      
      toast({
        title: "Signed out successfully",
        description: "You have been signed out of your account."
      });
    } catch (error) {
      console.error('Sign out error:', error);
      setAuthError(error instanceof Error ? error.message : 'Sign out failed');
    } finally {
      setIsLoading(false);
    }
  }, []);

  const refreshUser = useCallback(async () => {
    if (!currentUser) return;
    
    try {
      setIsLoading(true);
      await loadUserData(currentUser.id);
    } catch (error) {
      console.error('Error refreshing user:', error);
    } finally {
      setIsLoading(false);
    }
  }, [currentUser, loadUserData]);

  const refreshApp = useCallback(async () => {
    await refreshUser();
  }, [refreshUser]);

  const clearAuthError = useCallback(() => {
    setAuthError(null);
  }, []);

  // User Management
  const addUser = useCallback(async (userData: Omit<User, 'id' | 'joinDate'>) => {
    try {
      const newUser = await DataService.createUser(userData);
      setUsers(prev => [...prev, newUser]);
      toast({
        title: "User added",
        description: `${newUser.name} has been added to the system.`
      });
    } catch (error) {
      console.error('Error adding user:', error);
      toast({
        title: "Error",
        description: "Failed to add user",
        variant: "destructive"
      });
    }
  }, []);

  const updateUser = useCallback(async (id: string, updates: Partial<User>) => {
    try {
      const updatedUser = await DataService.updateUserProfile(id, updates);
      setUsers(prev => prev.map(user => user.id === id ? updatedUser : user));
      
      if (currentUser?.id === id) {
        setCurrentUser(updatedUser);
      }
      
      toast({
        title: "User updated",
        description: "User profile has been updated."
      });
    } catch (error) {
      console.error('Error updating user:', error);
      toast({
        title: "Error",
        description: "Failed to update user",
        variant: "destructive"
      });
    }
  }, [currentUser]);

  // Achievement System
  const unlockAchievement = useCallback(async (id: string) => {
    try {
      setAchievements(prev => prev.map(achievement => 
        achievement.id === id 
          ? { ...achievement, unlocked: true, unlockedAt: new Date() }
          : achievement
      ));
      
      toast({
        title: "Achievement Unlocked!",
        description: "Congratulations on your new achievement!"
      });
    } catch (error) {
      console.error('Error unlocking achievement:', error);
    }
  }, []);

  const updateAchievementProgress = useCallback(async (id: string, progress: number) => {
    try {
      setAchievements(prev => prev.map(achievement => 
        achievement.id === id 
          ? { ...achievement, progress }
          : achievement
      ));
    } catch (error) {
      console.error('Error updating achievement progress:', error);
    }
  }, []);

  // Notification System
  const addNotification = useCallback(async (notificationData: Omit<AppNotification, 'id' | 'createdAt'>) => {
    try {
      const newNotification = await DataService.createNotification(notificationData);
      setNotifications(prev => [newNotification, ...prev]);
    } catch (error) {
      console.error('Error adding notification:', error);
    }
  }, []);

  const removeNotification = useCallback(async (id: string) => {
    try {
      setNotifications(prev => prev.filter(notification => notification.id !== id));
    } catch (error) {
      console.error('Error removing notification:', error);
    }
  }, []);

  const dismissNotification = useCallback(async (id: string) => {
    try {
      setNotifications(prev => prev.map(notification => 
        notification.id === id 
          ? { ...notification, dismissed: true }
          : notification
      ));
    } catch (error) {
      console.error('Error dismissing notification:', error);
    }
  }, []);

  // Partnership System
  const matchPartners = useCallback(async () => {
    if (!currentUser) return;
    
    try {
      // Implementation for partner matching
      toast({
        title: "Partner Matching",
        description: "Looking for compatible partners..."
      });
    } catch (error) {
      console.error('Error matching partners:', error);
    }
  }, [currentUser]);

  const removePartnership = useCallback(async () => {
    if (!currentUser) return;
    
    try {
      // Implementation for removing partnership
      toast({
        title: "Partnership Removed",
        description: "Your partnership has been removed."
      });
    } catch (error) {
      console.error('Error removing partnership:', error);
    }
  }, [currentUser]);

  // Subscription Management
  const updateGatherSubscription = useCallback(async (subscribed: boolean) => {
    if (!currentUser) return;
    
    try {
      await updateUser(currentUser.id, { gatherSubscribed: subscribed });
    } catch (error) {
      console.error('Error updating gather subscription:', error);
    }
  }, [currentUser, updateUser]);

  const updateWinsNotifications = useCallback(async (enabled: boolean) => {
    if (!currentUser) return;
    
    try {
      await updateUser(currentUser.id, { winsNotifications: enabled });
    } catch (error) {
      console.error('Error updating wins notifications:', error);
    }
  }, [currentUser, updateUser]);

  // Notification Broadcasting
  const notifyGatherSubscribers = useCallback(async (message: string, author: string) => {
    try {
      // Implementation for notifying gather subscribers
      toast({
        title: "Gather Notification Sent",
        description: "Your message has been sent to gather subscribers."
      });
    } catch (error) {
      console.error('Error notifying gather subscribers:', error);
    }
  }, []);

  const notifyWinsSubscribers = useCallback(async (message: string, author: string) => {
    try {
      // Implementation for notifying wins subscribers
      toast({
        title: "Wins Notification Sent",
        description: "Your message has been sent to wins subscribers."
      });
    } catch (error) {
      console.error('Error notifying wins subscribers:', error);
    }
  }, []);

  // Error Handling
  const handleError = useCallback((error: any, context?: string) => {
    console.error(`Error in ${context || 'unknown context'}:`, error);
    setAuthError(error instanceof Error ? error.message : 'An error occurred');
  }, []);

  // Computed properties
  const isAuthenticated = !!currentUser;
  const canCreateGroups = currentUser?.isAdmin || false;

  const contextValue: UnifiedAuthContextType = {
    // UI State
    sidebarOpen,
    toggleSidebar,
    activeTab,
    setActiveTab: setActiveTabWithData,
    
    // Authentication State
    currentUser,
    isLoading,
    authError,
    isAuthenticated,
    
    // Data Collections
    users,
    achievements,
    notifications,
    
    // Authentication Actions
    signOut,
    refreshUser,
    setCurrentUser,
    setIsLoading,
    clearAuthError,
    
    // User Management
    addUser,
    updateUser,
    
    // Achievement System
    unlockAchievement,
    updateAchievementProgress,
    
    // Notification System
    addNotification,
    removeNotification,
    dismissNotification,
    
    // Partnership System
    matchPartners,
    removePartnership,
    
    // Subscription Management
    updateGatherSubscription,
    updateWinsNotifications,
    
    // Notification Broadcasting
    notifyGatherSubscribers,
    notifyWinsSubscribers,
    
    // App Management
    refreshApp,
    
    // Compatibility properties
    canCreateGroups,
    
    // Error Handling
    handleError
  };

  return (
    <UnifiedAuthContext.Provider value={contextValue}>
      {children}
    </UnifiedAuthContext.Provider>
  );
};

export default UnifiedAuthProvider;
