import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { toast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabase';
import { logger } from '@/lib/secureLogger';

// Unified interfaces
export interface User {
  id: string;
  name: string;
  full_name?: string;
  email: string;
  isAdmin: boolean;
  joinDate: Date;
  lastPartnerMatch?: Date;
  currentPartner?: string;
  gatherSubscribed?: boolean;
  winsNotifications?: boolean;
}

export interface Achievement {
  id: string;
  name: string;
  description: string;
  icon: string;
  category: 'habits' | 'social' | 'streaks' | 'goals';
  rarity: 'common' | 'rare' | 'epic' | 'legendary';
  unlocked: boolean;
  unlockedAt?: Date;
  progress?: number;
  target?: number;
  reward?: string;
}

export interface AppNotification {
  id: string;
  title: string;
  message: string;
  type: 'motivational' | 'reminder' | 'announcement' | 'gather' | 'wins';
  createdAt: Date;
  createdBy: string;
  isActive: boolean;
  dismissed?: boolean;
}

// Unified context interface
export interface UnifiedContextType {
  // UI State
  sidebarOpen: boolean;
  toggleSidebar: () => void;
  activeTab: string;
  setActiveTab: (tab: string, data?: any) => void;
  
  // User State
  currentUser: User | null;
  isLoading: boolean;
  authError: string | null;
  
  // Data Collections
  users: User[];
  achievements: Achievement[];
  notifications: AppNotification[];
  
  // User Actions
  signOut: () => Promise<void>;
  refreshUser: () => Promise<void>;
  
  // User Management
  addUser: (user: Omit<User, 'id' | 'joinDate'>) => Promise<void>;
  updateUser: (id: string, updates: Partial<User>) => Promise<void>;
  
  // Achievement System
  unlockAchievement: (id: string) => Promise<void>;
  updateAchievementProgress: (id: string, progress: number) => Promise<void>;
  
  // Notification System
  addNotification: (notification: Omit<AppNotification, 'id' | 'createdAt'>) => Promise<void>;
  removeNotification: (id: string) => Promise<void>;
  dismissNotification: (id: string) => Promise<void>;
  
  // Partnership System
  matchPartners: () => Promise<void>;
  removePartnership: () => Promise<void>;
  
  // Subscription Management
  updateGatherSubscription: (subscribed: boolean) => Promise<void>;
  updateWinsNotifications: (enabled: boolean) => Promise<void>;
  
  // Notification Broadcasting
  notifyGatherSubscribers: (message: string, author: string) => Promise<void>;
  notifyWinsSubscribers: (message: string, author: string) => Promise<void>;
  
  // Error Handling
  clearAuthError: () => void;
  handleError: (error: any, context?: string) => void;
}

// Create context
const UnifiedContext = createContext<UnifiedContextType | undefined>(undefined);

// Custom hook for using the context
export const useUnifiedContext = () => {
  const context = useContext(UnifiedContext);
  if (context === undefined) {
    throw new Error('useUnifiedContext must be used within a UnifiedProvider');
  }
  return context;
};

// Service layer for data operations
class DataService {
  static async fetchUsers(): Promise<User[]> {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data || [];
    } catch (error) {
      logger.error('Error fetching users:', error);
      throw error;
    }
  }

  static async fetchAchievements(userId: string): Promise<Achievement[]> {
    try {
      const { data, error } = await supabase
        .from('achievements')
        .select('*')
        .eq('user_id', userId);
      
      if (error) throw error;
      return data || [];
    } catch (error) {
      logger.error('Error fetching achievements:', error);
      throw error;
    }
  }

  static async fetchNotifications(userId: string): Promise<AppNotification[]> {
    try {
      const { data, error } = await supabase
        .from('notifications')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data || [];
    } catch (error) {
      logger.error('Error fetching notifications:', error);
      throw error;
    }
  }

  static async addUser(user: Omit<User, 'id' | 'joinDate'>): Promise<void> {
    try {
      const { error } = await supabase
        .from('profiles')
        .insert({
          ...user,
          created_at: new Date().toISOString()
        });
      
      if (error) throw error;
    } catch (error) {
      logger.error('Error adding user:', error);
      throw error;
    }
  }

  static async updateUser(id: string, updates: Partial<User>): Promise<void> {
    try {
      const { error } = await supabase
        .from('profiles')
        .update(updates)
        .eq('id', id);
      
      if (error) throw error;
    } catch (error) {
      logger.error('Error updating user:', error);
      throw error;
    }
  }

  static async unlockAchievement(userId: string, achievementId: string): Promise<void> {
    try {
      const { error } = await supabase
        .from('user_achievements')
        .insert({
          user_id: userId,
          achievement_id: achievementId,
          unlocked_at: new Date().toISOString()
        });
      
      if (error) throw error;
    } catch (error) {
      logger.error('Error unlocking achievement:', error);
      throw error;
    }
  }

  static async addNotification(notification: Omit<AppNotification, 'id' | 'createdAt'>): Promise<void> {
    try {
      const { error } = await supabase
        .from('notifications')
        .insert({
          ...notification,
          created_at: new Date().toISOString()
        });
      
      if (error) throw error;
    } catch (error) {
      logger.error('Error adding notification:', error);
      throw error;
    }
  }
}

// Main provider component
export const UnifiedProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // UI State
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('dashboard');
  
  // User State
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [authError, setAuthError] = useState<string | null>(null);
  
  // Data Collections
  const [users, setUsers] = useState<User[]>([]);
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);

  // Initialize user session
  useEffect(() => {
    const initializeSession = async () => {
      try {
        setIsLoading(true);
        const { data: { user } } = await supabase.auth.getUser();
        
        if (user) {
          setCurrentUser(user as User);
          await loadUserData(user.id);
        }
      } catch (error) {
        logger.error('Error initializing session:', error);
        setAuthError('Failed to initialize session');
      } finally {
        setIsLoading(false);
      }
    };

    initializeSession();
  }, []);

  // Load user data
  const loadUserData = useCallback(async (userId: string) => {
    try {
      const [usersData, achievementsData, notificationsData] = await Promise.all([
        DataService.fetchUsers(),
        DataService.fetchAchievements(userId),
        DataService.fetchNotifications(userId)
      ]);
      
      setUsers(usersData);
      setAchievements(achievementsData);
      setNotifications(notificationsData);
    } catch (error) {
      logger.error('Error loading user data:', error);
    }
  }, []);

  // UI Actions
  const toggleSidebar = useCallback(() => {
    setSidebarOpen(prev => !prev);
  }, []);

  const handleSetActiveTab = useCallback((tab: string, data?: any) => {
    setActiveTab(tab);
    // Handle any additional data if needed
    if (data) {
      // Process additional data
    }
  }, []);

  // User Actions
  const signOut = useCallback(async () => {
    try {
      await supabase.auth.signOut();
      setCurrentUser(null);
      setUsers([]);
      setAchievements([]);
      setNotifications([]);
    } catch (error) {
      logger.error('Error signing out:', error);
      throw error;
    }
  }, []);

  const refreshUser = useCallback(async () => {
    if (currentUser) {
      await loadUserData(currentUser.id);
    }
  }, [currentUser, loadUserData]);

  // User Management
  const addUser = useCallback(async (user: Omit<User, 'id' | 'joinDate'>) => {
    try {
      await DataService.addUser(user);
      await refreshUser();
      toast({ title: "User added successfully" });
    } catch (error) {
      logger.error('Error adding user:', error);
      toast({ title: "Error adding user", variant: "destructive" });
    }
  }, [refreshUser]);

  const updateUser = useCallback(async (id: string, updates: Partial<User>) => {
    try {
      await DataService.updateUser(id, updates);
      await refreshUser();
      toast({ title: "User updated successfully" });
    } catch (error) {
      logger.error('Error updating user:', error);
      toast({ title: "Error updating user", variant: "destructive" });
    }
  }, [refreshUser]);

  // Achievement System
  const unlockAchievement = useCallback(async (id: string) => {
    if (!currentUser) return;
    
    try {
      await DataService.unlockAchievement(currentUser.id, id);
      await refreshUser();
      toast({ title: "Achievement unlocked!" });
    } catch (error) {
      logger.error('Error unlocking achievement:', error);
      toast({ title: "Error unlocking achievement", variant: "destructive" });
    }
  }, [currentUser, refreshUser]);

  const updateAchievementProgress = useCallback(async (id: string, progress: number) => {
    try {
      // Update achievement progress logic
      await refreshUser();
    } catch (error) {
      logger.error('Error updating achievement progress:', error);
    }
  }, [refreshUser]);

  // Notification System
  const addNotification = useCallback(async (notification: Omit<AppNotification, 'id' | 'createdAt'>) => {
    try {
      await DataService.addNotification(notification);
      await refreshUser();
    } catch (error) {
      logger.error('Error adding notification:', error);
    }
  }, [refreshUser]);

  const removeNotification = useCallback(async (id: string) => {
    try {
      const { error } = await supabase
        .from('notifications')
        .delete()
        .eq('id', id);
      
      if (error) throw error;
      await refreshUser();
    } catch (error) {
      logger.error('Error removing notification:', error);
    }
  }, [refreshUser]);

  const dismissNotification = useCallback(async (id: string) => {
    try {
      const { error } = await supabase
        .from('notifications')
        .update({ dismissed: true })
        .eq('id', id);
      
      if (error) throw error;
      await refreshUser();
    } catch (error) {
      logger.error('Error dismissing notification:', error);
    }
  }, [refreshUser]);

  // Partnership System
  const matchPartners = useCallback(async () => {
    try {
      // Partnership matching logic
      await refreshUser();
      toast({ title: "Partners matched successfully" });
    } catch (error) {
      logger.error('Error matching partners:', error);
      toast({ title: "Error matching partners", variant: "destructive" });
    }
  }, [refreshUser]);

  const removePartnership = useCallback(async () => {
    try {
      // Remove partnership logic
      await refreshUser();
      toast({ title: "Partnership removed" });
    } catch (error) {
      logger.error('Error removing partnership:', error);
      toast({ title: "Error removing partnership", variant: "destructive" });
    }
  }, [refreshUser]);

  // Subscription Management
  const updateGatherSubscription = useCallback(async (subscribed: boolean) => {
    if (!currentUser) return;
    
    try {
      await DataService.updateUser(currentUser.id, { gatherSubscribed: subscribed });
      await refreshUser();
    } catch (error) {
      logger.error('Error updating gather subscription:', error);
    }
  }, [currentUser, refreshUser]);

  const updateWinsNotifications = useCallback(async (enabled: boolean) => {
    if (!currentUser) return;
    
    try {
      await DataService.updateUser(currentUser.id, { winsNotifications: enabled });
      await refreshUser();
    } catch (error) {
      logger.error('Error updating wins notifications:', error);
    }
  }, [currentUser, refreshUser]);

  // Notification Broadcasting
  const notifyGatherSubscribers = useCallback(async (message: string, author: string) => {
    try {
      // Notify gather subscribers logic
      await refreshUser();
    } catch (error) {
      logger.error('Error notifying gather subscribers:', error);
    }
  }, [refreshUser]);

  const notifyWinsSubscribers = useCallback(async (message: string, author: string) => {
    try {
      // Notify wins subscribers logic
      await refreshUser();
    } catch (error) {
      logger.error('Error notifying wins subscribers:', error);
    }
  }, [refreshUser]);

  // Error Handling
  const clearAuthError = useCallback(() => {
    setAuthError(null);
  }, []);

  const handleError = useCallback((error: any, context?: string) => {
    logger.error(`Error in ${context || 'unknown context'}:`, error);
    setAuthError(error.message || 'An unexpected error occurred');
  }, []);

  const contextValue: UnifiedContextType = {
    // UI State
    sidebarOpen,
    toggleSidebar,
    activeTab,
    setActiveTab: handleSetActiveTab,
    
    // User State
    currentUser,
    isLoading,
    authError,
    
    // Data Collections
    users,
    achievements,
    notifications,
    
    // User Actions
    signOut,
    refreshUser,
    
    // User Management
    addUser,
    updateUser,
    
    // Achievement System
    unlockAchievement,
    updateAchievementProgress,
    
    // Notification System
    addNotification,
    removeNotification,
    dismissNotification,
    
    // Partnership System
    matchPartners,
    removePartnership,
    
    // Subscription Management
    updateGatherSubscription,
    updateWinsNotifications,
    
    // Notification Broadcasting
    notifyGatherSubscribers,
    notifyWinsSubscribers,
    
    // Error Handling
    clearAuthError,
    handleError
  };

  return (
    <UnifiedContext.Provider value={contextValue}>
      {children}
    </UnifiedContext.Provider>
  );
};

export default UnifiedProvider;
