import { supabase } from '@/lib/supabase';
import { logger } from '@/lib/secureLogger';

// User service
export class UserService {
  static async getCurrentUser() {
    try {
      const { data: { user }, error } = await supabase.auth.getUser();
      if (error) throw error;
      return user;
    } catch (error) {
      logger.error('Error getting current user:', error);
      throw error;
    }
  }

  static async updateUserProfile(userId: string, updates: any) {
    try {
      const { error } = await supabase
        .from('profiles')
        .update(updates)
        .eq('id', userId);
      
      if (error) throw error;
    } catch (error) {
      logger.error('Error updating user profile:', error);
      throw error;
    }
  }

  static async getAllUsers() {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data || [];
    } catch (error) {
      logger.error('Error fetching users:', error);
      throw error;
    }
  }
}

// Habit service
export class HabitService {
  static async getUserHabits(userId: string) {
    try {
      const { data, error } = await supabase
        .from('habits')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data || [];
    } catch (error) {
      logger.error('Error fetching user habits:', error);
      throw error;
    }
  }

  static async createHabit(habit: any) {
    try {
      const { data, error } = await supabase
        .from('habits')
        .insert(habit)
        .select()
        .single();
      
      if (error) throw error;
      return data;
    } catch (error) {
      logger.error('Error creating habit:', error);
      throw error;
    }
  }

  static async updateHabit(habitId: string, updates: any) {
    try {
      const { error } = await supabase
        .from('habits')
        .update(updates)
        .eq('id', habitId);
      
      if (error) throw error;
    } catch (error) {
      logger.error('Error updating habit:', error);
      throw error;
    }
  }

  static async deleteHabit(habitId: string) {
    try {
      const { error } = await supabase
        .from('habits')
        .delete()
        .eq('id', habitId);
      
      if (error) throw error;
    } catch (error) {
      logger.error('Error deleting habit:', error);
      throw error;
    }
  }

  static async logHabitCompletion(habitId: string, userId: string, date: string, status: string) {
    try {
      const { error } = await supabase
        .from('habit_logs')
        .upsert({
          habit_id: habitId,
          user_id: userId,
          date,
          status
        });
      
      if (error) throw error;
    } catch (error) {
      logger.error('Error logging habit completion:', error);
      throw error;
    }
  }
}

// Goal service
export class GoalService {
  static async getUserGoals(userId: string) {
    try {
      const { data, error } = await supabase
        .from('goals')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data || [];
    } catch (error) {
      logger.error('Error fetching user goals:', error);
      throw error;
    }
  }

  static async createGoal(goal: any) {
    try {
      const { data, error } = await supabase
        .from('goals')
        .insert(goal)
        .select()
        .single();
      
      if (error) throw error;
      return data;
    } catch (error) {
      logger.error('Error creating goal:', error);
      throw error;
    }
  }

  static async updateGoal(goalId: string, updates: any) {
    try {
      const { error } = await supabase
        .from('goals')
        .update(updates)
        .eq('id', goalId);
      
      if (error) throw error;
    } catch (error) {
      logger.error('Error updating goal:', error);
      throw error;
    }
  }

  static async deleteGoal(goalId: string) {
    try {
      const { error } = await supabase
        .from('goals')
        .delete()
        .eq('id', goalId);
      
      if (error) throw error;
    } catch (error) {
      logger.error('Error deleting goal:', error);
      throw error;
    }
  }
}

// Group service
export class GroupService {
  static async getUserGroups(userId: string) {
    try {
      const { data, error } = await supabase
        .from('group_members')
        .select(`
          *,
          group:groups(*)
        `)
        .eq('user_id', userId);
      
      if (error) throw error;
      return data || [];
    } catch (error) {
      logger.error('Error fetching user groups:', error);
      throw error;
    }
  }

  static async createGroup(group: any) {
    try {
      const { data, error } = await supabase
        .from('groups')
        .insert(group)
        .select()
        .single();
      
      if (error) throw error;
      return data;
    } catch (error) {
      logger.error('Error creating group:', error);
      throw error;
    }
  }

  static async joinGroup(groupId: string, userId: string) {
    try {
      const { error } = await supabase
        .from('group_members')
        .insert({
          group_id: groupId,
          user_id: userId,
          joined_at: new Date().toISOString()
        });
      
      if (error) throw error;
    } catch (error) {
      logger.error('Error joining group:', error);
      throw error;
    }
  }

  static async leaveGroup(groupId: string, userId: string) {
    try {
      const { error } = await supabase
        .from('group_members')
        .delete()
        .eq('group_id', groupId)
        .eq('user_id', userId);
      
      if (error) throw error;
    } catch (error) {
      logger.error('Error leaving group:', error);
      throw error;
    }
  }
}

// Notification service
export class NotificationService {
  static async getUserNotifications(userId: string) {
    try {
      const { data, error } = await supabase
        .from('notifications')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data || [];
    } catch (error) {
      logger.error('Error fetching notifications:', error);
      throw error;
    }
  }

  static async createNotification(notification: any) {
    try {
      const { data, error } = await supabase
        .from('notifications')
        .insert(notification)
        .select()
        .single();
      
      if (error) throw error;
      return data;
    } catch (error) {
      logger.error('Error creating notification:', error);
      throw error;
    }
  }

  static async markNotificationAsRead(notificationId: string) {
    try {
      const { error } = await supabase
        .from('notifications')
        .update({ read: true })
        .eq('id', notificationId);
      
      if (error) throw error;
    } catch (error) {
      logger.error('Error marking notification as read:', error);
      throw error;
    }
  }

  static async deleteNotification(notificationId: string) {
    try {
      const { error } = await supabase
        .from('notifications')
        .delete()
        .eq('id', notificationId);
      
      if (error) throw error;
    } catch (error) {
      logger.error('Error deleting notification:', error);
      throw error;
    }
  }
}

// Achievement service
export class AchievementService {
  static async getUserAchievements(userId: string) {
    try {
      const { data, error } = await supabase
        .from('user_achievements')
        .select(`
          *,
          achievement:achievements(*)
        `)
        .eq('user_id', userId);
      
      if (error) throw error;
      return data || [];
    } catch (error) {
      logger.error('Error fetching user achievements:', error);
      throw error;
    }
  }

  static async unlockAchievement(userId: string, achievementId: string) {
    try {
      const { error } = await supabase
        .from('user_achievements')
        .insert({
          user_id: userId,
          achievement_id: achievementId,
          unlocked_at: new Date().toISOString()
        });
      
      if (error) throw error;
    } catch (error) {
      logger.error('Error unlocking achievement:', error);
      throw error;
    }
  }

  static async updateAchievementProgress(userId: string, achievementId: string, progress: number) {
    try {
      const { error } = await supabase
        .from('user_achievements')
        .update({ progress })
        .eq('user_id', userId)
        .eq('achievement_id', achievementId);
      
      if (error) throw error;
    } catch (error) {
      logger.error('Error updating achievement progress:', error);
      throw error;
    }
  }
}
