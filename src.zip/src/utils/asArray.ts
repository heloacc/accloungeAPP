/**
 * Centralized Array Safety Utility
 * Ensures all array operations are safe from undefined/null values
 */

export function asArray<T>(v: T[] | undefined | null): T[] {
  return Array.isArray(v) ? v : [];
}

/**
 * Safe array operations with built-in logging
 */
export function safeFilter<T>(
  array: T[] | undefined | null, 
  predicate: (item: T) => boolean,
  context?: string
): T[] {
  const safeArray = asArray(array);
  if (context && !Array.isArray(array)) {
    console.warn(`[Array Safety] ${context}: Converting ${typeof array} to empty array`);
  }
  return safeArray.filter(predicate);
}

export function safeMap<T, U>(
  array: T[] | undefined | null,
  mapper: (item: T) => U,
  context?: string
): U[] {
  const safeArray = asArray(array);
  if (context && !Array.isArray(array)) {
    console.warn(`[Array Safety] ${context}: Converting ${typeof array} to empty array`);
  }
  return safeArray.map(mapper);
}

export function safeReduce<T, U>(
  array: T[] | undefined | null,
  reducer: (acc: U, item: T) => U,
  initialValue: U,
  context?: string
): U {
  const safeArray = asArray(array);
  if (context && !Array.isArray(array)) {
    console.warn(`[Array Safety] ${context}: Converting ${typeof array} to empty array`);
  }
  return safeArray.reduce(reducer, initialValue);
}

/**
 * Validate and normalize array data structures
 */
export function normalizeArrayData<T>(data: any, fallback: T[] = []): T[] {
  if (Array.isArray(data)) return data;
  if (data?.items && Array.isArray(data.items)) return data.items;
  if (data?.data && Array.isArray(data.data)) return data.data;
  return fallback;
}