import { supabase } from '@/lib/supabase';

export const safeInvokeEdgeFunction = async (
  functionName: string,
  options: { body?: any; headers?: Record<string, string> } = {}
) => {
  try {
    const { data, error } = await supabase.functions.invoke(functionName, options);
    
    if (error) {
      console.warn(`Edge function ${functionName} error:`, error);
      return { data: null, error };
    }
    
    return { data, error: null };
  } catch (err) {
    console.warn(`Edge function ${functionName} failed:`, err);
    // Return a graceful fallback instead of throwing
    return { 
      data: null, 
      error: { 
        message: `Failed to connect to ${functionName}`,
        fallback: true 
      } 
    };
  }
};