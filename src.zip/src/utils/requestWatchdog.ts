/**
 * Request Watchdog - Timeout and retry mechanism for async operations
 */

export interface WatchdogOptions {
  timeout?: number;
  retries?: number;
  retryDelay?: number;
  onTimeout?: () => void;
  onRetry?: (attempt: number) => void;
  context?: string;
}

export class RequestWatchdog {
  private abortController: AbortController;
  private timeoutId?: NodeJS.Timeout;
  private retryCount = 0;

  constructor(private options: WatchdogOptions = {}) {
    this.abortController = new AbortController();
  }

  async execute<T>(operation: (signal: AbortSignal) => Promise<T>): Promise<T> {
    const {
      timeout = 10000,
      retries = 2,
      retryDelay = 1000,
      onTimeout,
      onRetry,
      context = 'Unknown operation'
    } = this.options;

    while (this.retryCount <= retries) {
      try {
        // Set up timeout
        const timeoutPromise = new Promise<never>((_, reject) => {
          this.timeoutId = setTimeout(() => {
            this.abortController.abort();
            onTimeout?.();
            reject(new Error(`Operation timed out after ${timeout}ms`));
          }, timeout);
        });

        // Execute operation with timeout race
        const result = await Promise.race([
          operation(this.abortController.signal),
          timeoutPromise
        ]);

        // Clear timeout on success
        if (this.timeoutId) {
          clearTimeout(this.timeoutId);
        }

        // Log successful completion
        if (this.retryCount > 0) {
          console.log(`[Watchdog] ${context}: Succeeded after ${this.retryCount} retries`);
        }

        return result;

      } catch (error) {
        // Clear timeout
        if (this.timeoutId) {
          clearTimeout(this.timeoutId);
        }

        // Check if we should retry
        if (this.retryCount < retries && !this.abortController.signal.aborted) {
          this.retryCount++;
          onRetry?.(this.retryCount);
          
          console.warn(`[Watchdog] ${context}: Retry ${this.retryCount}/${retries} after error:`, error);
          
          // Wait before retry
          await new Promise(resolve => setTimeout(resolve, retryDelay * this.retryCount));
          
          // Create new abort controller for retry
          this.abortController = new AbortController();
          continue;
        }

        // Log final failure
        console.error(`[Watchdog] ${context}: Failed after ${this.retryCount} retries:`, error);
        throw error;
      }
    }

    throw new Error(`Max retries (${retries}) exceeded`);
  }

  abort() {
    if (this.timeoutId) {
      clearTimeout(this.timeoutId);
    }
    this.abortController.abort();
  }

  get signal() {
    return this.abortController.signal;
  }
}

/**
 * Utility function for simple timeout operations
 */
export function withTimeout<T>(
  promise: Promise<T>,
  timeout: number = 10000,
  context?: string
): Promise<T> {
  const watchdog = new RequestWatchdog({ timeout, context });
  return watchdog.execute(() => promise);
}

/**
 * Safe async operation wrapper with loading state management
 */
export async function safeAsync<T>(
  operation: () => Promise<T>,
  options: {
    setLoading?: (loading: boolean) => void;
    onError?: (error: Error) => void;
    context?: string;
    timeout?: number;
  } = {}
): Promise<T | null> {
  const { setLoading, onError, context, timeout } = options;
  
  try {
    setLoading?.(true);
    const result = await withTimeout(operation(), timeout, context);
    return result;
  } catch (error) {
    const err = error instanceof Error ? error : new Error(String(error));
    console.error(`[Safe Async] ${context || 'Operation'} failed:`, err);
    onError?.(err);
    return null;
  } finally {
    setLoading?.(false);
  }
}