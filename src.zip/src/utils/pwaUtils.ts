// PWA utility functions
export const registerServiceWorker = async (): Promise<void> => {
  if ('serviceWorker' in navigator) {
    try {
      const registration = await navigator.serviceWorker.register('/sw.js');
      console.log('Service Worker registered successfully:', registration.scope);
      
      // Check for updates
      registration.addEventListener('updatefound', () => {
        const newWorker = registration.installing;
        if (newWorker) {
          newWorker.addEventListener('statechange', () => {
            if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
              // New version available
              if (confirm('New version available! Reload to update?')) {
                window.location.reload();
              }
            }
          });
        }
      });
    } catch (error) {
      console.error('Service Worker registration failed:', error);
    }
  }
};

export const requestNotificationPermission = async (): Promise<boolean> => {
  if ('Notification' in window) {
    const permission = await Notification.requestPermission();
    return permission === 'granted';
  }
  return false;
};

export const sendPWANotification = (title: string, message: string, options?: NotificationOptions): void => {
  if ('Notification' in window && Notification.permission === 'granted') {
    new Notification(title, {
      body: message,
      icon: '/placeholder.svg',
      badge: '/placeholder.svg',
      tag: 'admin-notification',
      requireInteraction: false,
      ...options
    });
  }
};

export const isInstallable = (): boolean => {
  return 'serviceWorker' in navigator && 'PushManager' in window;
};

export const getInstallPrompt = (): any => {
  return (window as any).deferredPrompt;
};

export const showInstallPrompt = async (): Promise<boolean> => {
  console.log('showInstallPrompt called');
  const deferredPrompt = getInstallPrompt();
  console.log('deferredPrompt:', deferredPrompt);
  
  if (deferredPrompt) {
    try {
      console.log('Showing install prompt...');
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      console.log('User choice outcome:', outcome);
      
      // Clear the deferred prompt after use
      (window as any).deferredPrompt = null;
      
      return outcome === 'accepted';
    } catch (error) {
      console.error('Error showing install prompt:', error);
      return false;
    }
  } else {
    console.log('No deferred prompt available - trying fallback methods');
    
    // Fallback: Check if we can trigger install in other ways
    if ('getInstalledRelatedApps' in navigator) {
      try {
        const relatedApps = await (navigator as any).getInstalledRelatedApps();
        console.log('Related apps:', relatedApps);
        if (relatedApps.length === 0) {
          // Show manual install instructions
          alert('To install this app:\n\n• Chrome: Click the install icon in the address bar\n• Safari: Share → Add to Home Screen\n• Firefox: Look for "Install" in the menu');
        }
      } catch (e) {
        console.log('getInstalledRelatedApps not supported');
      }
    }
    
    // Show manual instructions as fallback
    const userAgent = navigator.userAgent;
    if (userAgent.includes('Chrome')) {
      alert('To install: Look for the install icon in your browser\'s address bar, or click the three dots menu → "Install ACCLOUNGE"');
    } else if (userAgent.includes('Safari')) {
      alert('To install: Click the Share button and select "Add to Home Screen"');
    } else {
      alert('To install: Look for "Install" or "Add to Home Screen" in your browser menu');
    }
    
    return false;
  }
};