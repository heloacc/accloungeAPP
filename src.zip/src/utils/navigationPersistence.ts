/**
 * Navigation Persistence Utility
 * Ensures navigation fixes persist across application updates and errors
 */

export interface NavigationRoute {
  id: string;
  component: string;
  label: string;
  protected: boolean;
}

// Core protected routes that must always work
// Core protected routes that must always work
export const PROTECTED_ROUTES: NavigationRoute[] = [
  { id: 'dashboard', component: 'SimpleDashboard', label: 'Dashboard', protected: true },
  { id: 'community', component: 'CommunityFeed', label: 'Community', protected: true },
  { id: 'active-circle', component: 'ActiveCircle', label: 'Your Active Groups', protected: true },
  { id: 'groups', component: 'AccountabilityGroups', label: 'Groups', protected: true },
  { id: 'wins-wall', component: 'WinsWall', label: 'Wins Wall', protected: true },
  { id: 'gather', component: 'Gather', label: 'Gather', protected: true },
  { id: 'track-progress', component: 'TrackMyProgress', label: 'Track My Progress', protected: true },
  { id: 'profile', component: 'UserProfile', label: 'Profile', protected: true },
];

// Validate route configuration
export const validateRoute = (routeId: string): boolean => {
  return PROTECTED_ROUTES.some(route => route.id === routeId);
};

// Get fallback route for invalid routes
export const getFallbackRoute = (): string => {
  return 'dashboard';
};

// Ensure route is valid and protected
export const ensureValidRoute = (routeId: string): string => {
  if (validateRoute(routeId)) {
    return routeId;
  }
  console.warn(`Invalid route: ${routeId}, falling back to dashboard`);
  return getFallbackRoute();
};