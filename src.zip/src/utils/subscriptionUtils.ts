// Utility functions for subscription management

export const SUBSCRIPTION_PLANS = {
  FREE: 'Free',
  PREMIUM: 'Premium',
  PRO: 'Pro'
} as const;

export type SubscriptionPlan = typeof SUBSCRIPTION_PLANS[keyof typeof SUBSCRIPTION_PLANS];

export const isFreePlan = (planName?: string): boolean => {
  return !planName || planName === SUBSCRIPTION_PLANS.FREE;
};

export const isPremiumPlan = (planName?: string): boolean => {
  return planName === SUBSCRIPTION_PLANS.PREMIUM;
};

export const isProPlan = (planName?: string): boolean => {
  return planName === SUBSCRIPTION_PLANS.PRO;
};

export const hasFeatureAccess = (
  userPlan: string | undefined,
  requiredPlan: SubscriptionPlan
): boolean => {
  if (!userPlan) return requiredPlan === SUBSCRIPTION_PLANS.FREE;
  
  const planHierarchy = {
    [SUBSCRIPTION_PLANS.FREE]: 0,
    [SUBSCRIPTION_PLANS.PREMIUM]: 1,
    [SUBSCRIPTION_PLANS.PRO]: 2
  };
  
  const userLevel = planHierarchy[userPlan as SubscriptionPlan] ?? 0;
  const requiredLevel = planHierarchy[requiredPlan] ?? 0;
  
  return userLevel >= requiredLevel;
};

export const getUpgradeMessage = (currentPlan?: string): string => {
  if (isFreePlan(currentPlan)) {
    return 'Upgrade to Premium to unlock this feature';
  }
  if (isPremiumPlan(currentPlan)) {
    return 'Upgrade to Pro for advanced features';
  }
  return 'Feature not available';
};