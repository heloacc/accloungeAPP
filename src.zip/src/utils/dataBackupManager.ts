import { supabase } from '@/lib/supabase';

export interface BackupData {
  id: string;
  content: string;
  metadata: any;
  type: 'post' | 'message' | 'chat' | 'draft';
  timestamp: string;
  user_id?: string;
}

export class DataBackupManager {
  // Backup any content to post_backups table
  static async backupContent(
    originalId: string,
    content: string,
    type: 'post' | 'message' | 'chat' | 'draft',
    metadata: any = {}
  ): Promise<boolean> {
    try {
      const { error } = await supabase
        .from('post_backups')
        .insert([{
          original_post_id: originalId,
          backup_content: content,
          backup_type: type,
          backup_metadata: {
            ...metadata,
            backup_timestamp: new Date().toISOString(),
            user_agent: navigator.userAgent,
            url: window.location.href
          }
        }]);

      if (error) throw error;
      return true;
    } catch (error) {
      console.error('Backup failed:', error);
      // Fallback to localStorage
      this.localBackup(originalId, content, type, metadata);
      return false;
    }
  }

  // Local backup fallback
  static localBackup(id: string, content: string, type: string, metadata: any): void {
    try {
      const backups = JSON.parse(localStorage.getItem('content_backups') || '[]');
      backups.push({
        id,
        content,
        type,
        metadata,
        timestamp: new Date().toISOString()
      });
      
      // Keep only last 100 backups
      if (backups.length > 100) {
        backups.splice(0, backups.length - 100);
      }
      
      localStorage.setItem('content_backups', JSON.stringify(backups));
    } catch (error) {
      console.error('Local backup failed:', error);
    }
  }

  // Recover content from backups
  static async recoverContent(originalId: string): Promise<string | null> {
    try {
      const { data, error } = await supabase
        .from('post_backups')
        .select('backup_content')
        .eq('original_post_id', originalId)
        .order('created_at', { ascending: false })
        .limit(1);

      if (error) throw error;
      return data?.[0]?.backup_content || null;
    } catch (error) {
      console.error('Recovery failed:', error);
      return this.localRecover(originalId);
    }
  }

  // Local recovery fallback
  static localRecover(id: string): string | null {
    try {
      const backups = JSON.parse(localStorage.getItem('content_backups') || '[]');
      const backup = backups.find((b: any) => b.id === id);
      return backup?.content || null;
    } catch (error) {
      console.error('Local recovery failed:', error);
      return null;
    }
  }

  // Auto-backup during typing
  static async autoBackup(id: string, content: string, type: string): Promise<void> {
    if (content.trim().length > 5) {
      // Debounced backup
      clearTimeout((window as any)[`backup_${id}`]);
      (window as any)[`backup_${id}`] = setTimeout(() => {
        this.backupContent(id, content, type as any, { auto_backup: true });
      }, 2000);
    }
  }

  // Get all backups for user
  static async getUserBackups(userId: string): Promise<BackupData[]> {
    try {
      const { data, error } = await supabase
        .from('post_backups')
        .select('*')
        .eq('backup_metadata->>user_id', userId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('Failed to get user backups:', error);
      return [];
    }
  }
}