import { supabase } from '@/lib/supabase';

export interface Task {
  id: string;
  title: string;
  type: string;
  status: string;
  auto_config?: {
    habit_id: string;
    rule: string;
    target_number: number;
    current_count?: number;
  };
}

export interface Goal {
  id: string;
  title: string;
  completion_percent: number;
  status: string;
  goal_tasks?: Task[];
}

/**
 * Centralized function to calculate and update goal completion percentage
 */
export const calculateAndUpdateGoalProgress = async (goalId: string): Promise<number> => {
  try {
    // Get all tasks for this goal
    const { data: tasks, error: tasksError } = await supabase
      .from('goal_tasks')
      .select('*')
      .eq('goal_id', goalId);

    if (tasksError) throw tasksError;

    if (!tasks || tasks.length === 0) {
      // No tasks means 0% completion
      await supabase
        .from('goals')
        .update({ completion_percent: 0 })
        .eq('id', goalId);
      return 0;
    }

    // Calculate completion percentage based on completed tasks
    const completedTasks = tasks.filter(task => task.status === 'done').length;
    const completionPercent = Math.round((completedTasks / tasks.length) * 100);

    // Update the goal's completion percentage in the database
    const { error: updateError } = await supabase
      .from('goals')
      .update({ completion_percent: completionPercent })
      .eq('id', goalId);

    if (updateError) throw updateError;

    // Dispatch custom event to notify other components
    window.dispatchEvent(new CustomEvent('goalProgressUpdated', {
      detail: { goalId, completionPercent }
    }));

    return completionPercent;
  } catch (error) {
    console.error('Error calculating goal progress:', error);
    throw error;
  }
};

/**
 * Update auto task progress based on habit completions
 */
export const updateAutoTaskProgress = async (habitId: string, userId: string): Promise<void> => {
  try {
    // Get habit completion count
    const { data: completions } = await supabase
      .from('habit_completions')
      .select('*')
      .eq('habit_id', habitId)
      .eq('user_id', userId);

    const completionCount = completions?.length || 0;

    // Find all auto tasks linked to this habit
    const { data: autoTasks } = await supabase
      .from('goal_tasks')
      .select('*')
      .eq('type', 'auto')
      .contains('auto_config', { habit_id: habitId });

    if (!autoTasks || autoTasks.length === 0) return;

    // Update each auto task
    const goalIds = new Set<string>();
    for (const task of autoTasks) {
      const targetCount = task.auto_config?.target_number || 1;
      const newStatus = completionCount >= targetCount ? 'done' : 'open';
      
      if (task.status !== newStatus) {
        await supabase
          .from('goal_tasks')
          .update({ 
            status: newStatus,
            auto_config: {
              ...task.auto_config,
              current_count: completionCount
            }
          })
          .eq('id', task.id);
        
        goalIds.add(task.goal_id);
      }
    }

    // Recalculate completion for affected goals
    for (const goalId of goalIds) {
      await calculateAndUpdateGoalProgress(goalId);
    }
  } catch (error) {
    console.error('Error updating auto task progress:', error);
    throw error;
  }
};