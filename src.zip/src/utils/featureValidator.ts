import { supabase } from '@/lib/supabase';

export interface FeatureValidationResult {
  isValid: boolean;
  errors: string[];
  warnings: string[];
}

export class FeatureValidator {
  static async validateDatabaseConnection(): Promise<FeatureValidationResult> {
    try {
      const { error } = await supabase.from('users').select('id').limit(1);
      return {
        isValid: !error,
        errors: error ? [`Database connection failed: ${error.message}`] : [],
        warnings: []
      };
    } catch (err) {
      return {
        isValid: false,
        errors: [`Database validation error: ${err instanceof Error ? err.message : 'Unknown error'}`],
        warnings: []
      };
    }
  }

  static validateUserSession(user: any): FeatureValidationResult {
    const errors: string[] = [];
    const warnings: string[] = [];

    if (!user) {
      errors.push('User session is null or undefined');
    } else {
      if (!user.id) errors.push('User ID is missing');
      if (!user.email) warnings.push('User email is missing');
    }

    return {
      isValid: errors.length === 0,
      errors,
      warnings
    };
  }

  static validateComponentProps(props: Record<string, any>, requiredProps: string[]): FeatureValidationResult {
    const errors: string[] = [];
    const warnings: string[] = [];

    requiredProps.forEach(prop => {
      if (props[prop] === undefined || props[prop] === null) {
        errors.push(`Required prop '${prop}' is missing`);
      }
    });

    return {
      isValid: errors.length === 0,
      errors,
      warnings
    };
  }

  static async validateCriticalFeatures(): Promise<Record<string, FeatureValidationResult>> {
    const results: Record<string, FeatureValidationResult> = {};

    // Validate database connection
    results.database = await this.validateDatabaseConnection();

    // Validate essential tables exist
    const tables = ['users', 'profiles', 'habits', 'goals', 'posts'];
    for (const table of tables) {
      try {
        const { error } = await supabase.from(table).select('*').limit(1);
        results[`table_${table}`] = {
          isValid: !error,
          errors: error ? [`Table ${table} validation failed: ${error.message}`] : [],
          warnings: []
        };
      } catch (err) {
        results[`table_${table}`] = {
          isValid: false,
          errors: [`Table ${table} error: ${err instanceof Error ? err.message : 'Unknown error'}`],
          warnings: []
        };
      }
    }

    return results;
  }
}

export default FeatureValidator;