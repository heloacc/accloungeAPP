import { supabase } from '@/lib/supabase';

export interface PostData {
  content: string;
  category: string;
  author_name?: string;
  feedType?: string;
  group_id?: string;
  user_id?: string;
}

export interface LocalPost extends PostData {
  id: string;
  timestamp: string;
  retryCount: number;
}

// Local storage keys
const DRAFTS_KEY = 'post_drafts';
const FAILED_POSTS_KEY = 'failed_posts';
const OFFLINE_POSTS_KEY = 'offline_posts';

export class PostPersistenceManager {
  // Save draft to local storage
  static saveDraft(content: string, category: string, feedType: string): string {
    const draft = {
      id: `draft_${Date.now()}`,
      content,
      category,
      feedType,
      timestamp: new Date().toISOString(),
      retryCount: 0
    };

    const drafts = this.getDrafts();
    drafts.push(draft);
    localStorage.setItem(DRAFTS_KEY, JSON.stringify(drafts));
    return draft.id;
  }

  // Get all drafts
  static getDrafts(): LocalPost[] {
    try {
      const drafts = localStorage.getItem(DRAFTS_KEY);
      return drafts ? JSON.parse(drafts) : [];
    } catch {
      return [];
    }
  }

  // Remove draft
  static removeDraft(draftId: string): void {
    const drafts = this.getDrafts().filter(d => d.id !== draftId);
    localStorage.setItem(DRAFTS_KEY, JSON.stringify(drafts));
  }

  // Save failed post for retry
  static saveFailedPost(postData: PostData): void {
    const failedPost: LocalPost = {
      ...postData,
      id: `failed_${Date.now()}`,
      timestamp: new Date().toISOString(),
      retryCount: 0
    };

    const failed = this.getFailedPosts();
    failed.push(failedPost);
    localStorage.setItem(FAILED_POSTS_KEY, JSON.stringify(failed));
  }

  // Get failed posts
  static getFailedPosts(): LocalPost[] {
    try {
      const failed = localStorage.getItem(FAILED_POSTS_KEY);
      return failed ? JSON.parse(failed) : [];
    } catch {
      return [];
    }
  }

  // Retry failed posts
  static async retryFailedPosts(): Promise<void> {
    const failedPosts = this.getFailedPosts();
    const successful: string[] = [];

    for (const post of failedPosts) {
      try {
        if (post.feedType === 'acircle' && post.group_id) {
          await supabase.from('acircle_posts').insert([{
            group_id: post.group_id,
            user_id: post.user_id,
            content: post.content,
            post_type: 'user_post'
          }]);
        } else {
          await supabase.from('posts').insert([{
            author_name: post.author_name || 'User',
            content: post.content,
            category: post.category,
            likes: 0,
            comments: 0,
            is_intro_post: false
          }]);
        }
        successful.push(post.id);
      } catch (error) {
        console.error(`Retry failed for post ${post.id}:`, error);
        // Increment retry count
        post.retryCount = (post.retryCount || 0) + 1;
      }
    }

    // Remove successful posts
    const remaining = failedPosts.filter(p => !successful.includes(p.id));
    localStorage.setItem(FAILED_POSTS_KEY, JSON.stringify(remaining));
  }

  // Save post with automatic fallback
  static async savePost(postData: PostData, table: string = 'posts'): Promise<boolean> {
    try {
      let insertData: any = {
        content: postData.content,
        category: postData.category
      };

      if (table === 'acircle_posts') {
        insertData = {
          group_id: postData.group_id,
          user_id: postData.user_id,
          content: postData.content,
          post_type: 'user_post'
        };
      } else {
        insertData = {
          author_name: postData.author_name || 'User',
          content: postData.content,
          category: postData.category,
          likes: 0,
          comments: 0,
          is_intro_post: false
        };
      }

      const { error } = await supabase.from(table).insert([insertData]);
      
      if (error) throw error;
      return true;
    } catch (error) {
      console.error('Post save failed:', error);
      this.saveFailedPost(postData);
      return false;
    }
  }

  // Auto-save draft while typing
  static autoSaveDraft(content: string, category: string, feedType: string): void {
    if (content.trim().length > 10) {
      const draftId = `autosave_${feedType}`;
      const draft = {
        id: draftId,
        content,
        category,
        feedType,
        timestamp: new Date().toISOString(),
        retryCount: 0
      };

      const drafts = this.getDrafts().filter(d => d.id !== draftId);
      drafts.push(draft);
      localStorage.setItem(DRAFTS_KEY, JSON.stringify(drafts));
    }
  }

  // Clear auto-saved draft
  static clearAutoSave(feedType: string): void {
    const draftId = `autosave_${feedType}`;
    this.removeDraft(draftId);
  }

  // Get backup data for export
  static getBackupData() {
    return {
      drafts: this.getDrafts(),
      failedPosts: this.getFailedPosts(),
      timestamp: new Date().toISOString()
    };
  }
}

// Initialize background retry with proper cleanup
let retryInterval: NodeJS.Timeout | null = null;

if (typeof window !== 'undefined') {
  // Retry failed posts every 10 minutes (reduced from 5 to reduce server load)
  retryInterval = setInterval(() => {
    PostPersistenceManager.retryFailedPosts();
  }, 10 * 60 * 1000);

  // Clean up on page unload
  window.addEventListener('beforeunload', () => {
    if (retryInterval) {
      clearInterval(retryInterval);
      retryInterval = null;
    }
  });
}