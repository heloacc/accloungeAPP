// Cache management utilities to prevent initialization hangs
export const APP_VERSION = '1.0.2'; // Increment this when deploying updates

export const clearAppCache = async () => {
  try {
    console.log('Clearing app cache...');
    
    // Clear localStorage (keep auth token)
    const keysToKeep = ['supabase.auth.token', 'sb-'];
    const allKeys = Object.keys(localStorage);
    allKeys.forEach(key => {
      if (!keysToKeep.some(keepKey => key.includes(keepKey))) {
        localStorage.removeItem(key);
      }
    });

    // Clear sessionStorage
    sessionStorage.clear();

    // Clear React Query cache if available
    if ((window as any).queryClient) {
      (window as any).queryClient.clear();
    }

    // Clear service worker caches
    if ('serviceWorker' in navigator && 'caches' in window) {
      const cacheNames = await caches.keys();
      await Promise.all(
        cacheNames.map(cacheName => caches.delete(cacheName))
      );
      
      // Send message to service worker to clear its caches
      if (navigator.serviceWorker.controller) {
        navigator.serviceWorker.controller.postMessage({
          type: 'CLEAR_CACHE'
        });
      }
    }

    console.log('Cache cleared, reloading...');
    // Force reload without cache
    window.location.reload();
  } catch (error) {
    console.error('Error clearing cache:', error);
    // Fallback: just reload
    window.location.reload();
  }
};

export const checkCacheVersion = () => {
  const storedVersion = localStorage.getItem('app_version');
  if (storedVersion !== APP_VERSION) {
    console.log(`Version changed: ${storedVersion} -> ${APP_VERSION}`);
    localStorage.setItem('app_version', APP_VERSION);
    if (storedVersion) {
      // Version changed, clear cache
      clearAppCache();
      return false;
    }
  }
  return true;
};

export const isInitializationHung = () => {
  const initStart = sessionStorage.getItem('init_start_time');
  if (initStart) {
    const elapsed = Date.now() - parseInt(initStart);
    return elapsed > 10000; // Reduced to 10 seconds for mobile
  }
  return false;
};

export const markInitializationStart = () => {
  sessionStorage.setItem('init_start_time', Date.now().toString());
};

export const clearInitializationMark = () => {
  sessionStorage.removeItem('init_start_time');
};

// Mobile-specific cache clearing
export const clearMobileCache = async () => {
  try {
    // Clear all storage
    localStorage.clear();
    sessionStorage.clear();
    
    // Clear IndexedDB if available
    if ('indexedDB' in window) {
      const databases = await indexedDB.databases();
      await Promise.all(
        databases.map(db => {
          return new Promise((resolve, reject) => {
            const deleteReq = indexedDB.deleteDatabase(db.name!);
            deleteReq.onsuccess = () => resolve(undefined);
            deleteReq.onerror = () => reject(deleteReq.error);
          });
        })
      );
    }
    
    // Clear service worker caches
    if ('caches' in window) {
      const cacheNames = await caches.keys();
      await Promise.all(cacheNames.map(name => caches.delete(name)));
    }
    
    // Unregister service worker
    if ('serviceWorker' in navigator) {
      const registrations = await navigator.serviceWorker.getRegistrations();
      await Promise.all(registrations.map(reg => reg.unregister()));
    }
    
    console.log('Mobile cache fully cleared');
    window.location.href = '/';
  } catch (error) {
    console.error('Error clearing mobile cache:', error);
    window.location.reload();
  }
};