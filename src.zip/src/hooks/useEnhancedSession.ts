import { useState, useEffect, useCallback, useRef } from 'react';
import { supabase } from '@/lib/supabase';
import { Session } from '@supabase/supabase-js';

interface EnhancedSessionData {
  user: Session['user'] | null;
  session: Session | null;
  loading: boolean;
  error: string | null;
  connectionStatus: 'connected' | 'reconnecting' | 'disconnected';
}

// Enhanced session manager for production stability
export const useEnhancedSession = () => {
  const [data, setData] = useState<EnhancedSessionData>({
    user: null,
    session: null,
    loading: true,
    error: null,
    connectionStatus: 'disconnected'
  });
  
  const refreshTimeoutRef = useRef<NodeJS.Timeout>();
  const heartbeatIntervalRef = useRef<NodeJS.Timeout>();
  const reconnectTimeoutRef = useRef<NodeJS.Timeout>();
  const retryCountRef = useRef(0);
  const isRefreshingRef = useRef(false);
  const maxRetries = 5;
  const heartbeatInterval = 30000; // 30 seconds

  // Cleanup all timers and intervals
  const cleanup = useCallback(() => {
    [refreshTimeoutRef, heartbeatIntervalRef, reconnectTimeoutRef].forEach(ref => {
      if (ref.current) {
        clearTimeout(ref.current);
        clearInterval(ref.current);
      }
    });
  }, []);

  // Enhanced retry with exponential backoff and jitter
  const withEnhancedRetry = useCallback(async <T>(
    fn: () => Promise<T>,
    context: string,
    maxAttempts = maxRetries
  ): Promise<T> => {
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      try {
        const result = await fn();
        retryCountRef.current = 0;
        setData(prev => ({ ...prev, connectionStatus: 'connected' }));
        return result;
      } catch (error) {
        console.warn(`${context} attempt ${attempt}/${maxAttempts} failed:`, error);
        
        if (attempt === maxAttempts) {
          setData(prev => ({ ...prev, connectionStatus: 'disconnected' }));
          throw error;
        }
        
        // Exponential backoff with jitter: base delay * 2^attempt + random(0-1000)ms
        const baseDelay = 1000;
        const exponentialDelay = baseDelay * Math.pow(2, attempt - 1);
        const jitter = Math.random() * 1000;
        const delay = Math.min(exponentialDelay + jitter, 30000); // Cap at 30 seconds
        
        setData(prev => ({ ...prev, connectionStatus: 'reconnecting' }));
        await new Promise(resolve => setTimeout(resolve, delay));
      }
    }
    throw new Error(`${context} failed after ${maxAttempts} attempts`);
  }, []);

  // Session heartbeat with connection monitoring
  const startHeartbeat = useCallback(() => {
    if (heartbeatIntervalRef.current) {
      clearInterval(heartbeatIntervalRef.current);
    }
    
    heartbeatIntervalRef.current = setInterval(async () => {
      try {
        const { data: { session }, error } = await supabase.auth.getSession();
        
        if (error) {
          throw error;
        }
        
        if (!session) {
          setData(prev => ({
            ...prev,
            session: null,
            user: null,
            connectionStatus: 'disconnected'
          }));
          cleanup();
          return;
        }
        
        // Check if token is near expiry (within 10 minutes)
        if (session.expires_at) {
          const expiresAt = session.expires_at * 1000;
          const now = Date.now();
          const timeUntilExpiry = expiresAt - now;
          
          if (timeUntilExpiry < 10 * 60 * 1000 && !isRefreshingRef.current) {
            console.log('Token near expiry, refreshing...');
            await refreshSession();
          }
        }
        
        setData(prev => ({ ...prev, connectionStatus: 'connected' }));
      } catch (error) {
        console.warn('Heartbeat failed:', error);
        setData(prev => ({ ...prev, connectionStatus: 'reconnecting' }));
        
        // Try to reconnect after heartbeat failure
        reconnectTimeoutRef.current = setTimeout(async () => {
          try {
            await initializeSession();
          } catch (err) {
            console.error('Reconnection failed:', err);
          }
        }, 5000);
      }
    }, heartbeatInterval);
  }, []);

  // Initialize session with enhanced error handling
  const initializeSession = useCallback(async () => {
    try {
      setData(prev => ({ ...prev, loading: true, error: null }));
      
      const session = await withEnhancedRetry(async () => {
        const { data: { session }, error } = await supabase.auth.getSession();
        if (error) throw error;
        return session;
      }, 'Session initialization');
      
      if (session) {
        setData({
          session,
          user: session.user,
          loading: false,
          error: null,
          connectionStatus: 'connected'
        });
        
        scheduleTokenRefresh(session);
        startHeartbeat();
      } else {
        setData({
          session: null,
          user: null,
          loading: false,
          error: null,
          connectionStatus: 'disconnected'
        });
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Session initialization failed';
      setData({
        session: null,
        user: null,
        loading: false,
        error: errorMessage,
        connectionStatus: 'disconnected'
      });
    }
  }, [withEnhancedRetry, startHeartbeat]);

  // Enhanced token refresh with better error handling
  const refreshSession = useCallback(async (): Promise<boolean> => {
    if (isRefreshingRef.current) return false;
    
    isRefreshingRef.current = true;
    try {
      const session = await withEnhancedRetry(async () => {
        const { data: { session }, error } = await supabase.auth.refreshSession();
        if (error) throw error;
        return session;
      }, 'Token refresh', 3); // Fewer retries for refresh
      
      if (session) {
        setData(prev => ({
          ...prev,
          session,
          user: session.user,
          error: null,
          connectionStatus: 'connected'
        }));
        
        scheduleTokenRefresh(session);
        return true;
      }
      
      return false;
    } catch (error) {
      console.error('Token refresh failed:', error);
      setData(prev => ({
        ...prev,
        error: 'Session refresh failed',
        connectionStatus: 'disconnected'
      }));
      return false;
    } finally {
      isRefreshingRef.current = false;
    }
  }, [withEnhancedRetry]);

  // Smart token refresh scheduling
  const scheduleTokenRefresh = useCallback((session: Session) => {
    if (refreshTimeoutRef.current) {
      clearTimeout(refreshTimeoutRef.current);
    }
    
    if (!session?.expires_at) return;
    
    const expiresAt = session.expires_at * 1000;
    const now = Date.now();
    const timeUntilExpiry = expiresAt - now;
    
    // Refresh 5 minutes before expiry, but at least after 1 minute
    const refreshTime = Math.max(timeUntilExpiry - 5 * 60 * 1000, 60 * 1000);
    
    if (refreshTime > 0) {
      refreshTimeoutRef.current = setTimeout(async () => {
        console.log('Scheduled token refresh triggered');
        await refreshSession();
      }, refreshTime);
    }
  }, [refreshSession]);

  useEffect(() => {
    initializeSession();

    // Remove redundant auth listener - OptimizedAppContext handles this
    // const { data: { subscription } } = supabase.auth.onAuthStateChange(
    //   async (event, session) => {
    //     console.log('Auth state change:', event);
    //     
    //     switch (event) {
    //       case 'SIGNED_IN':
    //       case 'TOKEN_REFRESHED':
    //         if (session) {
    //           setData(prev => ({
    //             ...prev,
    //             session,
    //             user: session.user,
    //             loading: false,
    //             error: null,
    //             connectionStatus: 'connected'
    //           }));
    //           scheduleTokenRefresh(session);
    //           startHeartbeat();
    //         }
    //         break;
    //         
    //       case 'SIGNED_OUT':
    //         cleanup();
    //         setData({
    //           session: null,
    //           user: null,
    //           loading: false,
    //           error: null,
    //           connectionStatus: 'disconnected'
    //         });
    //         break;
    //         
    //       case 'USER_UPDATED':
    //         if (session) {
    //           setData(prev => ({
    //             ...prev,
    //             session,
    //             user: session.user
    //           }));
    //         }
    //         break;
    //     }
    //   }
    // );

    return () => {
      cleanup();
      // subscription.unsubscribe();
    };
  }, []);

  return {
    ...data,
    refreshSession,
    isAuthenticated: !!data.session,
    retryConnection: initializeSession
  };
};