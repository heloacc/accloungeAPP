import { useState, useEffect, useCallback, useRef } from 'react';
import { supabase } from '@/lib/supabase';
import { Session } from '@supabase/supabase-js';
import { UnifiedErrorHandler } from '@/lib/UnifiedErrorHandler';

interface UnifiedSessionData {
  user: Session['user'] | null;
  session: Session | null;
  loading: boolean;
  error: string | null;
  connectionStatus: 'connected' | 'reconnecting' | 'disconnected';
}

interface SessionOptions {
  enableHeartbeat?: boolean;
  heartbeatInterval?: number;
  maxRetries?: number;
  retryDelay?: number;
}

// Unified session hook that combines all session management functionality
export const useUnifiedSession = (options: SessionOptions = {}) => {
  const {
    enableHeartbeat = true,
    heartbeatInterval = 30000, // 30 seconds
    maxRetries = 3,
    retryDelay = 1000
  } = options;

  const [data, setData] = useState<UnifiedSessionData>({
    user: null,
    session: null,
    loading: true,
    error: null,
    connectionStatus: 'disconnected'
  });

  const refreshTimeoutRef = useRef<NodeJS.Timeout>();
  const heartbeatIntervalRef = useRef<NodeJS.Timeout>();
  const reconnectTimeoutRef = useRef<NodeJS.Timeout>();
  const retryCountRef = useRef(0);
  const isRefreshingRef = useRef(false);

  // Cleanup function
  const cleanup = useCallback(() => {
    if (refreshTimeoutRef.current) {
      clearTimeout(refreshTimeoutRef.current);
    }
    if (heartbeatIntervalRef.current) {
      clearInterval(heartbeatIntervalRef.current);
    }
    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current);
    }
  }, []);

  // Initialize session
  const initializeSession = useCallback(async () => {
    try {
      setData(prev => ({ ...prev, loading: true, error: null }));
      
      const { data: { session }, error } = await supabase.auth.getSession();
      
      if (error) throw error;

      if (session) {
        setData({
          user: session.user,
          session,
          loading: false,
          error: null,
          connectionStatus: 'connected'
        });
        
        // Schedule token refresh
        scheduleTokenRefresh(session);
        
        // Start heartbeat if enabled
        if (enableHeartbeat) {
          startHeartbeat();
        }
      } else {
        setData({
          user: null,
          session: null,
          loading: false,
          error: null,
          connectionStatus: 'disconnected'
        });
      }
    } catch (error) {
      const unifiedError = UnifiedErrorHandler.handleError(error, 'initializeSession');
      setData(prev => ({
        ...prev,
        loading: false,
        error: unifiedError.message,
        connectionStatus: 'disconnected'
      }));
    }
  }, [enableHeartbeat]);

  // Schedule token refresh
  const scheduleTokenRefresh = useCallback((session: Session) => {
    if (!session.expires_at) return;

    const expiresAt = new Date(session.expires_at).getTime();
    const now = Date.now();
    const timeUntilExpiry = expiresAt - now;
    
    // Refresh 5 minutes before expiry
    const refreshTime = Math.max(timeUntilExpiry - 300000, 60000);
    
    refreshTimeoutRef.current = setTimeout(async () => {
      await refreshSession();
    }, refreshTime);
  }, []);

  // Refresh session
  const refreshSession = useCallback(async () => {
    if (isRefreshingRef.current) return;
    
    try {
      isRefreshingRef.current = true;
      setData(prev => ({ ...prev, connectionStatus: 'reconnecting' }));
      
      const { data: { session }, error } = await supabase.auth.refreshSession();
      
      if (error) throw error;

      if (session) {
        setData(prev => ({
          ...prev,
          user: session.user,
          session,
          error: null,
          connectionStatus: 'connected'
        }));
        
        // Schedule next refresh
        scheduleTokenRefresh(session);
      } else {
        setData(prev => ({
          ...prev,
          user: null,
          session: null,
          connectionStatus: 'disconnected'
        }));
      }
    } catch (error) {
      const unifiedError = UnifiedErrorHandler.handleError(error, 'refreshSession');
      
      if (UnifiedErrorHandler.isRetryableError(unifiedError) && retryCountRef.current < maxRetries) {
        retryCountRef.current++;
        const delay = UnifiedErrorHandler.getRetryDelay(unifiedError, retryCountRef.current);
        
        reconnectTimeoutRef.current = setTimeout(() => {
          refreshSession();
        }, delay);
      } else {
        setData(prev => ({
          ...prev,
          error: unifiedError.message,
          connectionStatus: 'disconnected'
        }));
        retryCountRef.current = 0;
      }
    } finally {
      isRefreshingRef.current = false;
    }
  }, [maxRetries, scheduleTokenRefresh]);

  // Start heartbeat
  const startHeartbeat = useCallback(() => {
    if (heartbeatIntervalRef.current) {
      clearInterval(heartbeatIntervalRef.current);
    }

    heartbeatIntervalRef.current = setInterval(async () => {
      try {
        const { data: { session } } = await supabase.auth.getSession();
        
        if (!session) {
          setData(prev => ({
            ...prev,
            user: null,
            session: null,
            connectionStatus: 'disconnected'
          }));
          cleanup();
        }
      } catch (error) {
        console.warn('Heartbeat check failed:', error);
      }
    }, heartbeatInterval);
  }, [heartbeatInterval, cleanup]);

  // Sign out
  const signOut = useCallback(async () => {
    try {
      await supabase.auth.signOut();
      setData({
        user: null,
        session: null,
        loading: false,
        error: null,
        connectionStatus: 'disconnected'
      });
      cleanup();
    } catch (error) {
      const unifiedError = UnifiedErrorHandler.handleError(error, 'signOut');
      setData(prev => ({
        ...prev,
        error: unifiedError.message
      }));
    }
  }, [cleanup]);

  // Initialize on mount
  useEffect(() => {
    initializeSession();

    return () => {
      cleanup();
    };
  }, [initializeSession, cleanup]);

  // Listen for auth state changes
  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        if (event === 'SIGNED_IN' && session) {
          setData({
            user: session.user,
            session,
            loading: false,
            error: null,
            connectionStatus: 'connected'
          });
          
          scheduleTokenRefresh(session);
          
          if (enableHeartbeat) {
            startHeartbeat();
          }
        } else if (event === 'SIGNED_OUT') {
          setData({
            user: null,
            session: null,
            loading: false,
            error: null,
            connectionStatus: 'disconnected'
          });
          cleanup();
        } else if (event === 'TOKEN_REFRESHED' && session) {
          setData(prev => ({
            ...prev,
            user: session.user,
            session,
            error: null,
            connectionStatus: 'connected'
          }));
          
          scheduleTokenRefresh(session);
        }
      }
    );

    return () => {
      subscription.unsubscribe();
    };
  }, [scheduleTokenRefresh, startHeartbeat, enableHeartbeat, cleanup]);

  return {
    ...data,
    signOut,
    refreshSession,
    isConnected: data.connectionStatus === 'connected',
    isReconnecting: data.connectionStatus === 'reconnecting',
    isDisconnected: data.connectionStatus === 'disconnected'
  };
};
