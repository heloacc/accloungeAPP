import { useEffect } from 'react';
import { supabase } from '@/lib/supabase';

export const useHabitCompletion = () => {
  useEffect(() => {
    // Listen for habit completion events from the database
    const channel = supabase
      .channel('habit_completions')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'habit_completions'
        },
        (payload) => {
          // Dispatch custom event for goal progress tracking
          const event = new CustomEvent('habitCompleted', {
            detail: {
              habitId: payload.new.habit_id,
              userId: payload.new.user_id,
              completedAt: payload.new.completed_at
            }
          });
          window.dispatchEvent(event);
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const triggerHabitCompletion = (habitId: string) => {
    // Manually trigger habit completion event for immediate UI updates
    const event = new CustomEvent('habitCompleted', {
      detail: { habitId }
    });
    window.dispatchEvent(event);
  };

  return { triggerHabitCompletion };
};