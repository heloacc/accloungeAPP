import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';

export type UserRole = 'Member' | 'Moderator' | 'Admin';

interface UseUserRoleResult {
  role: UserRole;
  isAdmin: boolean;
  isModerator: boolean;
  loading: boolean;
  error: string | null;
}

export const useUserRole = (): UseUserRoleResult => {
  const [role, setRole] = useState<UserRole>('Member');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchUserRole = async () => {
      try {
        setLoading(true);
        setError(null);

        const { data: { user }, error: userError } = await supabase.auth.getUser();
        
        if (userError || !user) {
          setRole('Member');
          return;
        }

        // Quick role check with shorter timeout
        try {
          const { data: roleData } = await supabase
            .from('user_roles')
            .select('role')
            .eq('user_id', user.id)
            .single()
            .abortSignal(AbortSignal.timeout(3000));

          if (roleData?.role) {
            setRole(roleData.role as UserRole);
            return;
          }
        } catch (roleErr) {
          // Fallback to profile check
        }

        // Fallback to profile
        try {
          const { data: profileData } = await supabase
            .from('profiles')
            .select('is_admin, role')
            .eq('id', user.id)
            .single()
            .abortSignal(AbortSignal.timeout(3000));
          
          if (profileData?.role) {
            setRole(profileData.role as UserRole);
          } else {
            setRole(profileData?.is_admin ? 'Admin' : 'Member');
          }
        } catch (profileErr) {
          setRole('Member');
        }
      } catch (err) {
        setError('Failed to determine user role');
        setRole('Member');
      } finally {
        setLoading(false);
      }
    };

    fetchUserRole();

    const { data: { subscription } } = supabase.auth.onAuthStateChange(() => {
      fetchUserRole();
    });

    return () => subscription.unsubscribe();
  }, []);

  return {
    role,
    isAdmin: role === 'Admin',
    isModerator: role === 'Moderator',
    loading,
    error
  };
};