import { useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useCSRFToken } from '@/lib/csrf';
import { sanitizeInput } from '@/lib/security';

interface SecureRequestOptions {
  requireCSRF?: boolean;
  sanitizeData?: boolean;
  rateLimitKey?: string;
}

export const useSecureRequest = () => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { generateCSRFToken } = useCSRFToken();

  const makeSecureRequest = async (
    functionName: string,
    data: any,
    options: SecureRequestOptions = {}
  ) => {
    const { requireCSRF = true, sanitizeData = true } = options;
    
    setLoading(true);
    setError(null);

    try {
      let sanitizedData = data;
      
      // Sanitize input data if required
      if (sanitizeData && typeof data === 'object') {
        sanitizedData = Object.entries(data).reduce((acc, [key, value]) => {
          if (typeof value === 'string') {
            acc[key] = sanitizeInput.string(value);
          } else {
            acc[key] = value;
          }
          return acc;
        }, {} as any);
      }

      // Prepare headers
      const headers: Record<string, string> = {};
      
      // Add CSRF token if required
      if (requireCSRF) {
        const csrfToken = await generateCSRFToken();
        if (csrfToken) {
          headers['x-csrf-token'] = csrfToken;
        }
      }

      // Make the request
      const { data: response, error: requestError } = await supabase.functions.invoke(
        functionName,
        {
          body: sanitizedData,
          headers
        }
      );

      if (requestError) {
        throw new Error(requestError.message || 'Request failed');
      }

      setLoading(false);
      return response;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'An error occurred';
      setError(errorMessage);
      setLoading(false);
      throw err;
    }
  };

  return {
    makeSecureRequest,
    loading,
    error,
    clearError: () => setError(null)
  };
};