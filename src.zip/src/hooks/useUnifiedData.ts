import { useState, useEffect, useCallback } from 'react';
import { UserService, HabitService, GoalService, GroupService, NotificationService, AchievementService } from '@/services/DataService';
import { UnifiedErrorHandler } from '@/lib/UnifiedErrorHandler';

interface UnifiedDataState {
  habits: any[];
  goals: any[];
  groups: any[];
  notifications: any[];
  achievements: any[];
  users: any[];
  loading: boolean;
  error: string | null;
}

interface UnifiedDataActions {
  refreshHabits: () => Promise<void>;
  refreshGoals: () => Promise<void>;
  refreshGroups: () => Promise<void>;
  refreshNotifications: () => Promise<void>;
  refreshAchievements: () => Promise<void>;
  refreshUsers: () => Promise<void>;
  refreshAll: () => Promise<void>;
  
  createHabit: (habit: any) => Promise<void>;
  updateHabit: (id: string, updates: any) => Promise<void>;
  deleteHabit: (id: string) => Promise<void>;
  logHabitCompletion: (habitId: string, date: string, status: string) => Promise<void>;
  
  createGoal: (goal: any) => Promise<void>;
  updateGoal: (id: string, updates: any) => Promise<void>;
  deleteGoal: (id: string) => Promise<void>;
  
  joinGroup: (groupId: string) => Promise<void>;
  leaveGroup: (groupId: string) => Promise<void>;
  
  markNotificationAsRead: (id: string) => Promise<void>;
  deleteNotification: (id: string) => Promise<void>;
  
  unlockAchievement: (achievementId: string) => Promise<void>;
  updateAchievementProgress: (achievementId: string, progress: number) => Promise<void>;
}

// Unified data hook that consolidates all data management
export const useUnifiedData = (userId: string | null) => {
  const [state, setState] = useState<UnifiedDataState>({
    habits: [],
    goals: [],
    groups: [],
    notifications: [],
    achievements: [],
    users: [],
    loading: false,
    error: null
  });

  // Generic data fetcher with error handling
  const fetchData = useCallback(async <T>(
    fetcher: () => Promise<T>,
    setter: (data: T) => void,
    context: string
  ) => {
    try {
      const data = await fetcher();
      setter(data);
    } catch (error) {
      const unifiedError = UnifiedErrorHandler.handleError(error, context);
      setState(prev => ({ ...prev, error: unifiedError.message }));
    }
  }, []);

  // Refresh habits
  const refreshHabits = useCallback(async () => {
    if (!userId) return;
    
    setState(prev => ({ ...prev, loading: true }));
    await fetchData(
      () => HabitService.getUserHabits(userId),
      (data) => setState(prev => ({ ...prev, habits: data, loading: false })),
      'refreshHabits'
    );
  }, [userId, fetchData]);

  // Refresh goals
  const refreshGoals = useCallback(async () => {
    if (!userId) return;
    
    setState(prev => ({ ...prev, loading: true }));
    await fetchData(
      () => GoalService.getUserGoals(userId),
      (data) => setState(prev => ({ ...prev, goals: data, loading: false })),
      'refreshGoals'
    );
  }, [userId, fetchData]);

  // Refresh groups
  const refreshGroups = useCallback(async () => {
    if (!userId) return;
    
    setState(prev => ({ ...prev, loading: true }));
    await fetchData(
      () => GroupService.getUserGroups(userId),
      (data) => setState(prev => ({ ...prev, groups: data, loading: false })),
      'refreshGroups'
    );
  }, [userId, fetchData]);

  // Refresh notifications
  const refreshNotifications = useCallback(async () => {
    if (!userId) return;
    
    setState(prev => ({ ...prev, loading: true }));
    await fetchData(
      () => NotificationService.getUserNotifications(userId),
      (data) => setState(prev => ({ ...prev, notifications: data, loading: false })),
      'refreshNotifications'
    );
  }, [userId, fetchData]);

  // Refresh achievements
  const refreshAchievements = useCallback(async () => {
    if (!userId) return;
    
    setState(prev => ({ ...prev, loading: true }));
    await fetchData(
      () => AchievementService.getUserAchievements(userId),
      (data) => setState(prev => ({ ...prev, achievements: data, loading: false })),
      'refreshAchievements'
    );
  }, [userId, fetchData]);

  // Refresh users (admin only)
  const refreshUsers = useCallback(async () => {
    setState(prev => ({ ...prev, loading: true }));
    await fetchData(
      () => UserService.getAllUsers(),
      (data) => setState(prev => ({ ...prev, users: data, loading: false })),
      'refreshUsers'
    );
  }, [fetchData]);

  // Refresh all data
  const refreshAll = useCallback(async () => {
    if (!userId) return;
    
    setState(prev => ({ ...prev, loading: true }));
    
    try {
      await Promise.all([
        refreshHabits(),
        refreshGoals(),
        refreshGroups(),
        refreshNotifications(),
        refreshAchievements()
      ]);
    } catch (error) {
      const unifiedError = UnifiedErrorHandler.handleError(error, 'refreshAll');
      setState(prev => ({ ...prev, error: unifiedError.message, loading: false }));
    }
  }, [userId, refreshHabits, refreshGoals, refreshGroups, refreshNotifications, refreshAchievements]);

  // Habit actions
  const createHabit = useCallback(async (habit: any) => {
    try {
      await HabitService.createHabit({ ...habit, user_id: userId });
      await refreshHabits();
    } catch (error) {
      const unifiedError = UnifiedErrorHandler.handleError(error, 'createHabit');
      setState(prev => ({ ...prev, error: unifiedError.message }));
    }
  }, [userId, refreshHabits]);

  const updateHabit = useCallback(async (id: string, updates: any) => {
    try {
      await HabitService.updateHabit(id, updates);
      await refreshHabits();
    } catch (error) {
      const unifiedError = UnifiedErrorHandler.handleError(error, 'updateHabit');
      setState(prev => ({ ...prev, error: unifiedError.message }));
    }
  }, [refreshHabits]);

  const deleteHabit = useCallback(async (id: string) => {
    try {
      await HabitService.deleteHabit(id);
      await refreshHabits();
    } catch (error) {
      const unifiedError = UnifiedErrorHandler.handleError(error, 'deleteHabit');
      setState(prev => ({ ...prev, error: unifiedError.message }));
    }
  }, [refreshHabits]);

  const logHabitCompletion = useCallback(async (habitId: string, date: string, status: string) => {
    if (!userId) return;
    
    try {
      await HabitService.logHabitCompletion(habitId, userId, date, status);
      await refreshHabits();
    } catch (error) {
      const unifiedError = UnifiedErrorHandler.handleError(error, 'logHabitCompletion');
      setState(prev => ({ ...prev, error: unifiedError.message }));
    }
  }, [userId, refreshHabits]);

  // Goal actions
  const createGoal = useCallback(async (goal: any) => {
    try {
      await GoalService.createGoal({ ...goal, user_id: userId });
      await refreshGoals();
    } catch (error) {
      const unifiedError = UnifiedErrorHandler.handleError(error, 'createGoal');
      setState(prev => ({ ...prev, error: unifiedError.message }));
    }
  }, [userId, refreshGoals]);

  const updateGoal = useCallback(async (id: string, updates: any) => {
    try {
      await GoalService.updateGoal(id, updates);
      await refreshGoals();
    } catch (error) {
      const unifiedError = UnifiedErrorHandler.handleError(error, 'updateGoal');
      setState(prev => ({ ...prev, error: unifiedError.message }));
    }
  }, [refreshGoals]);

  const deleteGoal = useCallback(async (id: string) => {
    try {
      await GoalService.deleteGoal(id);
      await refreshGoals();
    } catch (error) {
      const unifiedError = UnifiedErrorHandler.handleError(error, 'deleteGoal');
      setState(prev => ({ ...prev, error: unifiedError.message }));
    }
  }, [refreshGoals]);

  // Group actions
  const joinGroup = useCallback(async (groupId: string) => {
    if (!userId) return;
    
    try {
      await GroupService.joinGroup(groupId, userId);
      await refreshGroups();
    } catch (error) {
      const unifiedError = UnifiedErrorHandler.handleError(error, 'joinGroup');
      setState(prev => ({ ...prev, error: unifiedError.message }));
    }
  }, [userId, refreshGroups]);

  const leaveGroup = useCallback(async (groupId: string) => {
    if (!userId) return;
    
    try {
      await GroupService.leaveGroup(groupId, userId);
      await refreshGroups();
    } catch (error) {
      const unifiedError = UnifiedErrorHandler.handleError(error, 'leaveGroup');
      setState(prev => ({ ...prev, error: unifiedError.message }));
    }
  }, [userId, refreshGroups]);

  // Notification actions
  const markNotificationAsRead = useCallback(async (id: string) => {
    try {
      await NotificationService.markNotificationAsRead(id);
      await refreshNotifications();
    } catch (error) {
      const unifiedError = UnifiedErrorHandler.handleError(error, 'markNotificationAsRead');
      setState(prev => ({ ...prev, error: unifiedError.message }));
    }
  }, [refreshNotifications]);

  const deleteNotification = useCallback(async (id: string) => {
    try {
      await NotificationService.deleteNotification(id);
      await refreshNotifications();
    } catch (error) {
      const unifiedError = UnifiedErrorHandler.handleError(error, 'deleteNotification');
      setState(prev => ({ ...prev, error: unifiedError.message }));
    }
  }, [refreshNotifications]);

  // Achievement actions
  const unlockAchievement = useCallback(async (achievementId: string) => {
    if (!userId) return;
    
    try {
      await AchievementService.unlockAchievement(userId, achievementId);
      await refreshAchievements();
    } catch (error) {
      const unifiedError = UnifiedErrorHandler.handleError(error, 'unlockAchievement');
      setState(prev => ({ ...prev, error: unifiedError.message }));
    }
  }, [userId, refreshAchievements]);

  const updateAchievementProgress = useCallback(async (achievementId: string, progress: number) => {
    if (!userId) return;
    
    try {
      await AchievementService.updateAchievementProgress(userId, achievementId, progress);
      await refreshAchievements();
    } catch (error) {
      const unifiedError = UnifiedErrorHandler.handleError(error, 'updateAchievementProgress');
      setState(prev => ({ ...prev, error: unifiedError.message }));
    }
  }, [userId, refreshAchievements]);

  // Initialize data on mount
  useEffect(() => {
    if (userId) {
      refreshAll();
    }
  }, [userId, refreshAll]);

  const actions: UnifiedDataActions = {
    refreshHabits,
    refreshGoals,
    refreshGroups,
    refreshNotifications,
    refreshAchievements,
    refreshUsers,
    refreshAll,
    
    createHabit,
    updateHabit,
    deleteHabit,
    logHabitCompletion,
    
    createGoal,
    updateGoal,
    deleteGoal,
    
    joinGroup,
    leaveGroup,
    
    markNotificationAsRead,
    deleteNotification,
    
    unlockAchievement,
    updateAchievementProgress
  };

  return {
    ...state,
    ...actions
  };
};
