import { useQuery, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';

// Optimized React Query configurations
export const queryConfig = {
  // Default stale time: 5 minutes
  staleTime: 5 * 60 * 1000,
  // Cache time: 10 minutes  
  cacheTime: 10 * 60 * 1000,
  // Retry failed requests 2 times
  retry: 2,
  // Retry delay: exponential backoff
  retryDelay: (attemptIndex: number) => Math.min(1000 * 2 ** attemptIndex, 30000),
  // Refetch on window focus for critical data only
  refetchOnWindowFocus: false,
  // Background refetch interval: 10 minutes for active queries
  refetchInterval: 10 * 60 * 1000,
};

// User profile query with optimized caching
export function useOptimizedUserProfile(userId?: string) {
  return useQuery({
    queryKey: ['userProfile', userId],
    queryFn: async () => {
      if (!userId) return null;
      const { data, error } = await supabase
        .from('profiles')
        .select(`
          id, full_name, avatar_url, subscription_tier,
          created_at, updated_at
        `)
        .eq('id', userId)
        .single();
      
      if (error) throw error;
      return data;
    },
    enabled: !!userId,
    ...queryConfig,
    staleTime: 2 * 60 * 1000, // 2 minutes for user data
  });
}

// Groups query with optimized caching
export function useOptimizedUserGroups(userId?: string) {
  return useQuery({
    queryKey: ['userGroups', userId],
    queryFn: async () => {
      if (!userId) return [];
      const { data, error } = await supabase
        .from('group_members')
        .select(`
          group_id,
          role,
          groups:group_id (
            id, name, description, privacy_level,
            member_count, created_at
          )
        `)
        .eq('user_id', userId)
        .eq('status', 'active');
      
      if (error) throw error;
      return data?.map(item => item.groups) || [];
    },
    enabled: !!userId,
    ...queryConfig,
  });
}

// Habits query with background sync
export function useOptimizedUserHabits(userId?: string) {
  return useQuery({
    queryKey: ['userHabits', userId],
    queryFn: async () => {
      if (!userId) return [];
      const { data, error } = await supabase
        .from('habits')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data || [];
    },
    enabled: !!userId,
    ...queryConfig,
    refetchInterval: 5 * 60 * 1000, // 5 minutes for habits
  });
}