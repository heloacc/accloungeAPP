import { useState, useEffect, useRef } from 'react';
import { supabase } from '@/lib/supabase';

export type UserRole = 'Member' | 'Moderator' | 'Admin';

interface UseStableUserRoleResult {
  role: UserRole;
  isAdmin: boolean;
  isModerator: boolean;
  loading: boolean;
  error: string | null;
  canCreateGroups: boolean;
  canAccessMemberMomentum: boolean;
  canAccessCheckIns: boolean;
}

export const useStableUserRole = (): UseStableUserRoleResult => {
  const [role, setRole] = useState<UserRole>('Member');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);
  
  // Stable references to prevent role downgrades during refresh
  const stableRoleRef = useRef<UserRole>('Member');
  const lastValidRoleRef = useRef<UserRole>('Member');
  const userIdRef = useRef<string | null>(null);

  useEffect(() => {
    const fetchUserRole = async (preserveRole = false) => {
      try {
        if (!preserveRole) {
          setLoading(true);
        } else {
          setIsRefreshing(true);
        }
        setError(null);

        const { data: { user }, error: userError } = await supabase.auth.getUser();
        
        if (userError || !user) {
          console.log('No user found, setting Member role');
          if (!preserveRole) {
            setRole('Member');
            stableRoleRef.current = 'Member';
            lastValidRoleRef.current = 'Member';
          }
          return;
        }

        // If user changed, reset everything
        if (userIdRef.current && userIdRef.current !== user.id) {
          console.log('User changed, resetting role cache');
          stableRoleRef.current = 'Member';
          lastValidRoleRef.current = 'Member';
        }
        userIdRef.current = user.id;

        // Check localStorage cache first for immediate response
        const cacheKey = `admin_status_${user.id}`;
        const cachedAdminStatus = localStorage.getItem(cacheKey);
        
        if (cachedAdminStatus === 'true' && !preserveRole) {
          console.log('Found cached admin status, setting Admin role immediately');
          setRole('Admin');
          stableRoleRef.current = 'Admin';
          lastValidRoleRef.current = 'Admin';
          setLoading(false);
        }

        // Always verify with database (with proper error handling)
        let finalRole: UserRole = 'Member';
        
        try {
          const { data: roleData, error: roleError } = await supabase
            .from('user_roles')
            .select('role')
            .eq('user_id', user.id)
            .single();

          if (!roleError && roleData?.role) {
            finalRole = roleData.role?.toLowerCase?.() === 'admin' ? 'Admin' : (roleData.role as UserRole);
            console.log('Database role found:', finalRole);
          } else if (cachedAdminStatus === 'true') {
            finalRole = 'Admin';
          } else if (preserveRole && stableRoleRef.current) {
            finalRole = stableRoleRef.current;
          }
        } catch (err) {
          console.log('Role fetch error, using fallback:', err);
          if (cachedAdminStatus === 'true') {
            finalRole = 'Admin';
          } else if (preserveRole && stableRoleRef.current) {
            finalRole = stableRoleRef.current;
          }
        }

        // Cache admin status
        if (finalRole === 'Admin') {
          localStorage.setItem(cacheKey, 'true');
        } else {
          localStorage.removeItem(cacheKey);
        }

        // Only update if role actually changed or this is initial load
        if (!preserveRole || finalRole !== stableRoleRef.current) {
          console.log(`Role update: ${stableRoleRef.current} -> ${finalRole}`);
          setRole(finalRole);
          stableRoleRef.current = finalRole;
          lastValidRoleRef.current = finalRole;
        }

      } catch (err) {
        console.error('Error in useStableUserRole:', err);
        setError('Failed to determine user role');
        
        // During refresh, preserve existing role on error
        if (preserveRole && stableRoleRef.current) {
          console.log('Preserving role during refresh error:', stableRoleRef.current);
        } else {
          setRole('Member');
          stableRoleRef.current = 'Member';
        }
      } finally {
        setLoading(false);
        setIsRefreshing(false);
      }
    };

    // Initial load
    fetchUserRole(false);

    // Remove redundant auth listener - OptimizedAppContext handles this
    // const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
    //   console.log('Auth state change in useStableUserRole:', event);
    //   
    //   if (event === 'SIGNED_IN' && session?.user) {
    //     // On sign in, do fresh load
    //     await fetchUserRole(false);
    //   } else if (event === 'TOKEN_REFRESHED' && session?.user) {
    //     // On token refresh, preserve existing role
    //     console.log('Token refreshed, preserving role:', stableRoleRef.current);
    //     await fetchUserRole(true);
    //   } else if (event === 'SIGNED_OUT') {
    //     console.log('User signed out, clearing role');
    //     setRole('Member');
    //     stableRoleRef.current = 'Member';
    //     lastValidRoleRef.current = 'Member';
    //     userIdRef.current = null;
    //     setLoading(false);
    //   }
    // });

    // return () => subscription.unsubscribe();
    return () => {};
  }, []);

  const currentRole = isRefreshing ? stableRoleRef.current : role;

  return {
    role: currentRole,
    isAdmin: currentRole === 'Admin',
    isModerator: currentRole === 'Moderator',
    loading,
    error,
    canCreateGroups: currentRole === 'Admin' || currentRole === 'Moderator',
    canAccessMemberMomentum: currentRole === 'Admin' || currentRole === 'Moderator',
    canAccessCheckIns: true // All users can access check-ins
  };
};