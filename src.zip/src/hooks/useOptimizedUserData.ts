import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import { useAppContext } from '@/contexts/AppContext';
import { useEffect, useRef } from 'react';

export const useOptimizedUserData = () => {
  const { setCurrentUser } = useAppContext();
  const hasSetUser = useRef(false);

  const { data: session, isLoading: sessionLoading, error: sessionError } = useQuery({
    queryKey: ['session'],
    queryFn: async () => {
      try {
        const { data, error } = await supabase.auth.getSession();
        if (error) throw error;
        return data.session;
      } catch (error) {
        console.error('Session fetch error:', error);
        throw error;
      }
    },
    staleTime: 10 * 60 * 1000, // 10 minutes
    retry: 2,
  });

  const { data: userProfile, isLoading: profileLoading, error: profileError } = useQuery({
    queryKey: ['userProfile', session?.user?.id],
    queryFn: async () => {
      if (!session?.user?.id) return null;
      
      try {
        const { data, error } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', session.user.id)
          .single();
        
        if (error && error.code !== 'PGRST116') { // Ignore "not found" errors
          throw error;
        }
        
        return data;
      } catch (error) {
        console.error('Profile fetch error:', error);
        return null; // Return null instead of throwing to prevent error boundary
      }
    },
    enabled: !!session?.user?.id,
    staleTime: 5 * 60 * 1000, // 5 minutes
    retry: 1,
  });

  // Update context when data changes - but only once to prevent loops
  useEffect(() => {
    if (session?.user && userProfile && !hasSetUser.current) {
      setCurrentUser({
        id: userProfile.id,
        name: userProfile.name || session.user.email?.split('@')[0] || 'User',
        email: userProfile.email || session.user.email || '',
        isAdmin: userProfile.is_admin || false,
        joinDate: new Date(userProfile.created_at),
        gatherSubscribed: true,
        winsNotifications: true,
      });
      hasSetUser.current = true;
    } else if (!session && hasSetUser.current) {
      hasSetUser.current = false; // Reset when logged out
    }
  }, [session, userProfile, setCurrentUser]);

  return {
    loading: sessionLoading || (session && profileLoading),
    user: session?.user || null,
    userProfile,
    isAdmin: userProfile?.is_admin || false,
    session,
    error: sessionError || profileError,
  };
};