import { useState, useEffect, useCallback, useRef } from 'react';
import { supabase } from '@/lib/supabase';
import { Session } from '@supabase/supabase-js';

interface StableSessionData {
  user: Session['user'] | null;
  session: Session | null;
  loading: boolean;
  error: string | null;
}

// Stable session hook with connection pooling and retry logic
export const useStableSession = () => {
  const [data, setData] = useState<StableSessionData>({
    user: null,
    session: null,
    loading: true,
    error: null
  });
  
  const refreshTimeoutRef = useRef<NodeJS.Timeout>();
  const retryCountRef = useRef(0);
  const maxRetries = 3;
  const isRefreshingRef = useRef(false);

  // Cleanup function
  const cleanup = useCallback(() => {
    if (refreshTimeoutRef.current) {
      clearTimeout(refreshTimeoutRef.current);
    }
  }, []);

  // Get session with retry logic
  const getSessionWithRetry = useCallback(async (): Promise<Session | null> => {
    try {
      const { data: { session }, error } = await supabase.auth.getSession();
      
      if (error) {
        throw error;
      }
      
      retryCountRef.current = 0; // Reset retry count on success
      return session;
    } catch (error) {
      console.error('Session fetch error:', error);
      
      if (retryCountRef.current < maxRetries) {
        retryCountRef.current++;
        // Exponential backoff: 1s, 2s, 4s
        const delay = Math.pow(2, retryCountRef.current - 1) * 1000;
        await new Promise(resolve => setTimeout(resolve, delay));
        return getSessionWithRetry();
      }
      
      throw error;
    }
  }, []);

  // Schedule token refresh before expiry
  const scheduleTokenRefresh = useCallback((session: Session) => {
    cleanup();
    
    if (!session?.expires_at) return;
    
    const expiresAt = session.expires_at * 1000; // Convert to milliseconds
    const now = Date.now();
    const timeUntilExpiry = expiresAt - now;
    
    // Refresh 5 minutes before expiry, but at least after 1 minute
    const refreshTime = Math.max(timeUntilExpiry - 5 * 60 * 1000, 60 * 1000);
    
    if (refreshTime > 0) {
      refreshTimeoutRef.current = setTimeout(async () => {
        if (!isRefreshingRef.current) {
          isRefreshingRef.current = true;
          try {
            const { data: { session: newSession }, error } = await supabase.auth.refreshSession();
            if (!error && newSession) {
              setData(prev => ({ ...prev, session: newSession, user: newSession.user }));
              scheduleTokenRefresh(newSession);
            }
          } catch (err) {
            console.error('Token refresh error:', err);
          } finally {
            isRefreshingRef.current = false;
          }
        }
      }, refreshTime);
    }
  }, [cleanup]);

  // Initialize session
  const initializeSession = useCallback(async () => {
    try {
      setData(prev => ({ ...prev, loading: true, error: null }));
      
      const session = await getSessionWithRetry();
      
      if (session) {
        setData({
          session,
          user: session.user,
          loading: false,
          error: null
        });
        scheduleTokenRefresh(session);
      } else {
        setData({
          session: null,
          user: null,
          loading: false,
          error: null
        });
      }
    } catch (error) {
      setData({
        session: null,
        user: null,
        loading: false,
        error: error instanceof Error ? error.message : 'Session initialization failed'
      });
    }
  }, [getSessionWithRetry, scheduleTokenRefresh]);

  // Manual refresh function
  const refreshSession = useCallback(async () => {
    if (isRefreshingRef.current) return;
    
    isRefreshingRef.current = true;
    try {
      const { data: { session }, error } = await supabase.auth.refreshSession();
      if (!error && session) {
        setData({
          session,
          user: session.user,
          loading: false,
          error: null
        });
        scheduleTokenRefresh(session);
      }
      return !error;
    } catch (err) {
      console.error('Manual refresh error:', err);
      return false;
    } finally {
      isRefreshingRef.current = false;
    }
  }, [scheduleTokenRefresh]);

  useEffect(() => {
    initializeSession();

    // Subscribe to auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        switch (event) {
          case 'SIGNED_IN':
          case 'TOKEN_REFRESHED':
            if (session) {
              setData({
                session,
                user: session.user,
                loading: false,
                error: null
              });
              scheduleTokenRefresh(session);
            }
            break;
          case 'SIGNED_OUT':
            cleanup();
            setData({
              session: null,
              user: null,
              loading: false,
              error: null
            });
            break;
        }
      }
    );

    return () => {
      cleanup();
      subscription.unsubscribe();
    };
  }, []);

  return {
    ...data,
    refreshSession,
    isAuthenticated: !!data.session
  };
};