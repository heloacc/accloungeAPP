import { useQuery, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';

// Generic hook for cached data fetching
export const useDataCache = <T>(
  queryKey: string[],
  queryFn: () => Promise<T>,
  options?: {
    enabled?: boolean;
    staleTime?: number;
    refetchInterval?: number;
  }
) => {
  return useQuery({
    queryKey,
    queryFn,
    staleTime: options?.staleTime || 5 * 60 * 1000, // 5 minutes default
    enabled: options?.enabled !== false,
    refetchInterval: options?.refetchInterval,
    retry: 1,
  });
};

// Specific hooks for common data patterns
export const useUserPosts = (userId?: string) => {
  return useDataCache(
    ['posts', userId],
    async () => {
      if (!userId) return [];
      const { data } = await supabase
        .from('posts')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false })
        .limit(20);
      return data || [];
    },
    { enabled: !!userId }
  );
};

export const useUserGroups = (userId?: string) => {
  return useDataCache(
    ['userGroups', userId],
    async () => {
      if (!userId) return [];
      try {
        const { data, error } = await supabase
          .from('acircle_members')
          .select(`
            group_id,
            role,
            acircle_groups (
              id, name, description, created_at, member_count
            )
          `)
          .eq('user_id', userId);
        
        if (error) {
          console.error('Error fetching user groups:', error);
          return [];
        }
        
        return data?.map(item => item.acircle_groups).filter(Boolean) || [];
      } catch (err) {
        console.error('Exception in useUserGroups:', err);
        return [];
      }
    },
    { enabled: !!userId }
  );
};

export const useUserHabits = (userId?: string) => {
  return useDataCache(
    ['habits', userId],
    async () => {
      if (!userId) return [];
      const { data } = await supabase
        .from('habits')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });
      return data || [];
    },
    { enabled: !!userId }
  );
};