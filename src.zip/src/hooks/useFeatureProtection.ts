import { useState, useEffect, useCallback } from 'react';
import { FeatureValidator, FeatureValidationResult } from '@/utils/featureValidator';

interface UseFeatureProtectionOptions {
  featureName: string;
  validateOnMount?: boolean;
  validationInterval?: number;
  requiredProps?: string[];
}

interface UseFeatureProtectionReturn {
  isValid: boolean;
  errors: string[];
  warnings: string[];
  isValidating: boolean;
  validate: () => Promise<void>;
  lastValidation: Date | null;
}

export const useFeatureProtection = (
  props: Record<string, any>,
  options: UseFeatureProtectionOptions
): UseFeatureProtectionReturn => {
  const [validationResult, setValidationResult] = useState<FeatureValidationResult>({
    isValid: true,
    errors: [],
    warnings: []
  });
  const [isValidating, setIsValidating] = useState(false);
  const [lastValidation, setLastValidation] = useState<Date | null>(null);

  const validate = useCallback(async () => {
    setIsValidating(true);
    try {
      // Validate props if required props are specified
      if (options.requiredProps) {
        const propsValidation = FeatureValidator.validateComponentProps(props, options.requiredProps);
        if (!propsValidation.isValid) {
          setValidationResult(propsValidation);
          setLastValidation(new Date());
          return;
        }
      }

      // Validate database connection for critical features
      const dbValidation = await FeatureValidator.validateDatabaseConnection();
      setValidationResult(dbValidation);
      setLastValidation(new Date());
    } catch (error) {
      setValidationResult({
        isValid: false,
        errors: [`Validation failed: ${error instanceof Error ? error.message : 'Unknown error'}`],
        warnings: []
      });
    } finally {
      setIsValidating(false);
    }
  }, [props, options.requiredProps]);

  useEffect(() => {
    if (options.validateOnMount) {
      validate();
    }
  }, [validate, options.validateOnMount]);

  useEffect(() => {
    if (options.validationInterval && options.validationInterval > 0) {
      const interval = setInterval(validate, options.validationInterval);
      return () => clearInterval(interval);
    }
  }, [validate, options.validationInterval]);

  return {
    isValid: validationResult.isValid,
    errors: validationResult.errors,
    warnings: validationResult.warnings,
    isValidating,
    validate,
    lastValidation
  };
};

export default useFeatureProtection;