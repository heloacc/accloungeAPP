import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';

interface SubscriptionTier {
  id: string;
  name: string;
  price_monthly: string;
  is_active: boolean;
}

interface AccessCheckResult {
  hasAccess: boolean;
  tier: string;
  requiredTier?: string;
}

export const useSubscriptionAccess = () => {
  const [userTier, setUserTier] = useState<SubscriptionTier | null>(null);
  const [loading, setLoading] = useState(false);
  const [pageAccessCache, setPageAccessCache] = useState<Record<string, AccessCheckResult>>({});
  const [isAdmin, setIsAdmin] = useState<boolean | null>(null);

  const checkAdminStatus = async (): Promise<boolean> => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return false;

      const { data: userRole } = await supabase
        .from('user_roles')
        .select('role')
        .eq('user_id', user.id)
        .single();

      const role = userRole?.role?.toLowerCase();
      const adminOrMod = role === 'admin' || role === 'moderator';
      setIsAdmin(adminOrMod);
      return adminOrMod;
    } catch (error) {
      console.error('Error checking admin status:', error);
      setIsAdmin(false);
      return false;
    }
  };

  const checkPageAccess = async (path: string): Promise<AccessCheckResult> => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        return { hasAccess: false, tier: 'none' };
      }

      // Check admin/moderator status first - they bypass all subscription checks
      const { data: userRole } = await supabase
        .from('user_roles')
        .select('role')
        .eq('user_id', user.id)
        .single();

      const role = userRole?.role?.toLowerCase();
      if (role === 'admin' || role === 'moderator') {
        return { hasAccess: true, tier: role === 'admin' ? 'Admin' : 'Moderator' };
      }

      // Get user's current tier for regular users
      const { data: userSubscription, error: subError } = await supabase
        .from('user_subscription_links')
        .select(`
          tier_id,
          subscription_tiers (
            id,
            name,
            price_monthly
          )
        `)
        .eq('user_id', user.id)
        .single();

      if (subError && subError.code !== 'PGRST116') {
        throw subError;
      }

      const currentTier = userSubscription?.subscription_tiers?.name || 'Freemium';

      // Check access rules for this path
      const { data: accessRule, error: ruleError } = await supabase
        .from('page_access_rules')
        .select(`
          minimum_tier_id,
          is_premium_only,
          subscription_tiers!minimum_tier_id (
            name,
            price_monthly
          )
        `)
        .eq('route_path', path)
        .eq('is_active', true)
        .single();

      if (ruleError && ruleError.code !== 'PGRST116') {
        // If there's an error fetching rules, allow access by default
        return { hasAccess: true, tier: currentTier };
      }

      if (!accessRule) {
        // No rule found, allow access
        return { hasAccess: true, tier: currentTier };
      }

      const requiredTier = accessRule.subscription_tiers?.name || 'Freemium';
      const requiredTierLevel = getTierLevel(requiredTier);
      const currentTierLevel = getTierLevel(currentTier);

      const hasAccess = currentTierLevel >= requiredTierLevel;

      return {
        hasAccess,
        tier: currentTier,
        requiredTier: hasAccess ? undefined : requiredTier
      };
    } catch (error) {
      console.error('Error checking page access:', error);
      return { hasAccess: false, tier: 'error' };
    }
  };

  const getTierLevel = (tierName: string): number => {
    switch (tierName) {
      case 'Freemium': return 1;
      case 'Accountability Essentials': return 2;
      case 'All Access': return 3;
      default: return 0;
    }
  };

  const hasAccessToPage = (path: string): boolean => {
    // Admin and Moderator users have access to all pages
    if (isAdmin === true) {
      return true;
    }
    
    // For admin paths, check actual admin status
    if (path.includes('/admin')) {
      return isAdmin === true;
    }
    
    // For other paths, check if we have cached access or default to true
    const cached = pageAccessCache[path];
    return cached ? cached.hasAccess : true;
  };

  const getAccessMessage = (path: string): string => {
    if (path.includes('/admin')) {
      return 'This feature requires admin access.';
    }
    return 'This feature requires a premium subscription.';
  };

  const getUserTier = async () => {
    setLoading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase.functions.invoke('subscription-management', {
        body: {
          action: 'getUserTier',
          userId: user.id
        }
      });

      if (error) throw error;
      setUserTier(data.tier);
    } catch (error) {
      console.error('Error getting user tier:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    checkAdminStatus();
  }, []);

  return {
    userTier,
    loading,
    isAdmin,
    checkPageAccess,
    refreshUserTier: getUserTier,
    hasAccessToPage,
    getAccessMessage,
    checkAdminStatus
  };
};
