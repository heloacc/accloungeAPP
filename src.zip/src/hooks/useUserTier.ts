import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { safeInvokeEdgeFunction } from '@/utils/edgeFunctionWrapper';

export const useUserTier = (userRole?: string) => {
  const [userTier, setUserTier] = useState<string>('Free');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchUserTier = async () => {
      try {
        setLoading(true);
        const { data: { user } } = await supabase.auth.getUser();
        
        if (!user) {
          setUserTier('Free');
          return;
        }

        // Check admin/moderator status first
        const { data: userRoleData } = await supabase
          .from('user_roles')
          .select('role')
          .eq('user_id', user.id)
          .single();

        const role = userRoleData?.role?.toLowerCase() || userRole?.toLowerCase();
        
        // Admin and Moderator get full access
        if (role === 'admin' || role === 'moderator') {
          setUserTier(role === 'admin' ? 'Admin' : 'Moderator');
          return;
        }

        // Try to get subscription tier with fallback
        const { data, error } = await safeInvokeEdgeFunction('subscription-management', {
          body: { action: 'getUserTier', userId: user.id }
        });

        if (error?.fallback) {
          // Fallback to direct database query
          const { data: tierData } = await supabase
            .from('user_subscription_links')
            .select('subscription_tiers(name)')
            .eq('user_id', user.id)
            .single();
          
          setUserTier(tierData?.subscription_tiers?.name || 'Free');
        } else {
          setUserTier(data?.tier || 'Free');
        }
      } catch (err) {
        console.warn('Tier fetch failed, defaulting to Free:', err);
        setUserTier('Free');
      } finally {
        setLoading(false);
      }
    };

    fetchUserTier();
  }, [userRole]);

  const getTierLevel = (tier: string): number => {
    switch (tier) {
      case 'Admin': return 999;
      case 'Moderator': return 998;
      case 'All Access': return 3;
      case 'Accountability Essentials': return 2;
      case 'Freemium': return 1;
      default: return 0;
    }
  };

  const canAccessTier = (requiredTier: string): boolean => {
    return getTierLevel(userTier) >= getTierLevel(requiredTier);
  };

  return { userTier, loading, canAccessTier, getTierLevel };
};