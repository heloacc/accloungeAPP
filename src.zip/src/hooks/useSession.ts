import { useState, useEffect, useCallback, useRef } from 'react';
import { supabase } from '@/lib/supabase';
import { sessionManager } from '@/lib/sessionManager';

export interface SessionData {
  user_id: string;
  role: 'admin' | 'moderator' | 'member';
  capabilities: {
    admin_panel: boolean;
    tier_mgmt: boolean;
    member_momentum: boolean;
    checkins: boolean;
    create_groups: boolean;
    delete_groups: boolean;
    global_group_access: boolean;
  };
  expires_at: string;
}

// Connection pool for managing concurrent requests
class ConnectionPool {
  private activeRequests = new Map<string, Promise<any>>();
  private maxConcurrent = 10;
  
  async execute<T>(key: string, fn: () => Promise<T>): Promise<T> {
    // If same request is already running, return the existing promise
    if (this.activeRequests.has(key)) {
      return this.activeRequests.get(key);
    }
    
    // Wait if too many concurrent requests
    while (this.activeRequests.size >= this.maxConcurrent) {
      await new Promise(resolve => setTimeout(resolve, 100));
    }
    
    const promise = fn().finally(() => {
      this.activeRequests.delete(key);
    });
    
    this.activeRequests.set(key, promise);
    return promise;
  }
}

const connectionPool = new ConnectionPool();

export const useSession = () => {
  const [session, setSession] = useState<SessionData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const retryCountRef = useRef(0);
  const heartbeatIntervalRef = useRef<NodeJS.Timeout>();
  const refreshTimeoutRef = useRef<NodeJS.Timeout>();
  const isRefreshingRef = useRef(false);
  const maxRetries = 3;

  // Cleanup function for stale sessions and intervals
  const cleanup = useCallback(() => {
    if (heartbeatIntervalRef.current) {
      clearInterval(heartbeatIntervalRef.current);
    }
    if (refreshTimeoutRef.current) {
      clearTimeout(refreshTimeoutRef.current);
    }
  }, []);

  // Exponential backoff retry logic
  const withRetry = useCallback(async <T>(
    fn: () => Promise<T>,
    context: string
  ): Promise<T> => {
    try {
      const result = await fn();
      retryCountRef.current = 0; // Reset on success
      return result;
    } catch (err) {
      if (retryCountRef.current < maxRetries) {
        retryCountRef.current++;
        const delay = Math.pow(2, retryCountRef.current - 1) * 1000; // 1s, 2s, 4s
        console.warn(`${context} failed, retrying in ${delay}ms (attempt ${retryCountRef.current})`);
        await new Promise(resolve => setTimeout(resolve, delay));
        return withRetry(fn, context);
      }
      throw err;
    }
  }, []);

  // Session heartbeat to keep connection alive
  const startHeartbeat = useCallback(() => {
    cleanup();
    heartbeatIntervalRef.current = setInterval(async () => {
      try {
        const { data: { session: authSession } } = await supabase.auth.getSession();
        if (!authSession) {
          setSession(null);
          cleanup();
        }
      } catch (err) {
        console.warn('Heartbeat failed:', err);
      }
    }, 30000); // Every 30 seconds
  }, [cleanup]);

  const fetchSession = useCallback(async () => {
    return sessionManager.executeWithPool('fetchSession', async () => {
      return sessionManager.withRetry(async () => {
        setLoading(true);
        setError(null);

        const { data: { session: authSession } } = await supabase.auth.getSession();
        
        if (!authSession?.access_token) {
          setSession(null);
          cleanup();
          return;
        }

        // Get server-side session data with role and capabilities
        const { data, error: fnError } = await supabase.functions.invoke('session-management', {
          headers: {
            Authorization: `Bearer ${authSession.access_token}`
          }
        });

        if (fnError) {
          throw new Error(fnError.message);
        }

        setSession(data);
        startHeartbeat();
      }, 'Session fetch');
    });
  }, [cleanup, startHeartbeat]);

  const refreshSession = useCallback(async () => {
    if (isRefreshingRef.current) return false;
    
    isRefreshingRef.current = true;
    try {
      return await connectionPool.execute('refreshSession', async () => {
        return withRetry(async () => {
          const { error } = await supabase.auth.refreshSession();
          if (error) {
            throw error;
          }
          
          await fetchSession();
          return true;
        }, 'Session refresh');
      });
    } catch (err) {
      console.error('Refresh session error:', err);
      setSession(null);
      cleanup();
      return false;
    } finally {
      isRefreshingRef.current = false;
      setLoading(false);
    }
  }, [fetchSession, withRetry, cleanup]);

  // Schedule automatic token refresh
  const scheduleTokenRefresh = useCallback((authSession: any) => {
    if (refreshTimeoutRef.current) {
      clearTimeout(refreshTimeoutRef.current);
    }
    
    if (!authSession?.expires_at) return;
    
    const expiresAt = authSession.expires_at * 1000;
    const now = Date.now();
    const timeUntilExpiry = expiresAt - now;
    
    // Refresh 5 minutes before expiry, but at least after 1 minute
    const refreshTime = Math.max(timeUntilExpiry - 5 * 60 * 1000, 60 * 1000);
    
    if (refreshTime > 0) {
      refreshTimeoutRef.current = setTimeout(() => {
        refreshSession();
      }, refreshTime);
    }
  }, [refreshSession]);

  useEffect(() => {
    fetchSession().catch(err => {
      console.error('Initial session fetch failed:', err);
      setError(err instanceof Error ? err.message : 'Session error');
      setLoading(false);
    });

    // Remove redundant auth listener - OptimizedAppContext handles this
    // const { data: { subscription } } = supabase.auth.onAuthStateChange(
    //   async (event, authSession) => {
    //     if (event === 'SIGNED_IN' || event === 'TOKEN_REFRESHED') {
    //       if (authSession) {
    //         scheduleTokenRefresh(authSession);
    //       }
    //       await fetchSession();
    //     } else if (event === 'SIGNED_OUT') {
    //       setSession(null);
    //       setLoading(false);
    //       cleanup();
    //     }
    //   }
    // );

    return () => {
      cleanup();
      // subscription.unsubscribe();
    };
  }, [fetchSession, scheduleTokenRefresh, cleanup]);

  return {
    session,
    loading,
    error,
    refetch: fetchSession,
    refresh: refreshSession,
    isAdmin: session?.role === 'admin',
    isModerator: session?.role === 'moderator',
    capabilities: session?.capabilities || {}
  };
};