import { useState, useEffect, useCallback } from 'react';
import { optimizedGroupQueries, optimizedUserQueries, cacheInvalidation } from '../lib/databaseOptimizer';
import { queryOptimizer } from '../lib/queryOptimizer';

// Hook for optimized group data
export function useOptimizedGroupData(userId: string) {
  const [groups, setGroups] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchGroups = useCallback(async () => {
    try {
      setLoading(true);
      const data = await optimizedGroupQueries.getUserGroupsWithStats(userId);
      setGroups(data || []);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch groups');
    } finally {
      setLoading(false);
    }
  }, [userId]);

  const refreshGroups = useCallback(() => {
    cacheInvalidation.invalidateAllUserGroups(userId);
    fetchGroups();
  }, [userId, fetchGroups]);

  useEffect(() => {
    if (userId) {
      fetchGroups();
    }
  }, [userId, fetchGroups]);

  return { groups, loading, error, refreshGroups };
}

// Hook for optimized group members
export function useOptimizedGroupMembers(groupId: string) {
  const [members, setMembers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchMembers = useCallback(async () => {
    try {
      setLoading(true);
      const data = await optimizedGroupQueries.getGroupMembersOptimized(groupId);
      setMembers(data || []);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch members');
    } finally {
      setLoading(false);
    }
  }, [groupId]);

  const refreshMembers = useCallback(() => {
    cacheInvalidation.invalidateGroupCache(groupId);
    fetchMembers();
  }, [groupId, fetchMembers]);

  useEffect(() => {
    if (groupId) {
      fetchMembers();
    }
  }, [groupId, fetchMembers]);

  return { members, loading, error, refreshMembers };
}

// Hook for optimized user profile
export function useOptimizedUserProfile(userId: string) {
  const [profile, setProfile] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchProfile = useCallback(async () => {
    try {
      setLoading(true);
      const data = await optimizedUserQueries.getUserProfileOptimized(userId);
      setProfile(data);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch profile');
    } finally {
      setLoading(false);
    }
  }, [userId]);

  const refreshProfile = useCallback(() => {
    cacheInvalidation.invalidateUserCache(userId);
    fetchProfile();
  }, [userId, fetchProfile]);

  useEffect(() => {
    if (userId) {
      fetchProfile();
    }
  }, [userId, fetchProfile]);

  return { profile, loading, error, refreshProfile };
}

// Hook for query performance monitoring
export function useQueryPerformance() {
  const [metrics, setMetrics] = useState<any[]>([]);
  const [slowQueries, setSlowQueries] = useState<any[]>([]);

  const refreshMetrics = useCallback(() => {
    setMetrics(queryOptimizer.getQueryStats());
    setSlowQueries(queryOptimizer.getSlowQueries());
  }, []);

  useEffect(() => {
    refreshMetrics();
    const interval = setInterval(refreshMetrics, 30000); // Update every 30 seconds
    return () => clearInterval(interval);
  }, [refreshMetrics]);

  return { metrics, slowQueries, refreshMetrics };
}