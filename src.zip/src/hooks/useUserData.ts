import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAppContext } from '@/contexts/AppContext';

export const useUserData = () => {
  const { setCurrentUser, currentUser } = useAppContext();
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState<any>(null);
  const [userProfile, setUserProfile] = useState<any>(null);
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    const loadUserData = async () => {
      try {
        const { data: { session } } = await supabase.auth.getSession();
        
        if (session?.user) {
          setUser(session.user);
          
          // Get user profile from database
          const { data: profile } = await supabase
            .from('profiles')
            .select('*')
            .eq('id', session.user.id)
            .single();

          if (profile) {
            setUserProfile(profile);
            setIsAdmin(profile.is_admin || false);
            
            // Update context with real user data including admin status
            setCurrentUser({
              id: profile.id,
              name: profile.name || session.user.email?.split('@')[0] || 'User',
              email: profile.email || session.user.email || '',
              isAdmin: profile.is_admin || false,
              joinDate: new Date(profile.created_at),
              gatherSubscribed: true,
              winsNotifications: true,
            });
          }
        }
      } catch (error) {
        console.error('Error loading user data:', error);
      } finally {
        setLoading(false);
      }
    };

    loadUserData();

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (event === 'SIGNED_IN' && session?.user) {
        setUser(session.user);
        
        const { data: profile } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', session.user.id)
          .single();

        if (profile) {
          setUserProfile(profile);
          setIsAdmin(profile.is_admin || false);
          
          setCurrentUser({
            id: profile.id,
            name: profile.name || session.user.email?.split('@')[0] || 'User',
            email: profile.email || session.user.email || '',
            isAdmin: profile.is_admin || false,
            joinDate: new Date(profile.created_at),
            gatherSubscribed: true,
            winsNotifications: true,
          });
        }
      } else if (event === 'SIGNED_OUT') {
        setUser(null);
        setUserProfile(null);
        setIsAdmin(false);
      }
    });

    return () => subscription.unsubscribe();
  }, [setCurrentUser]);

  return { 
    loading, 
    user, 
    userProfile, 
    isAdmin,
    isModerator: userProfile?.is_moderator || false
  };
};