import { useState, useCallback } from 'react';
import { supabase } from '@/lib/supabase';

interface ValidationResult {
  isValid: boolean;
  sanitized: string;
  error?: string;
}

export const useSecureInput = () => {
  const [isValidating, setIsValidating] = useState(false);

  const validateAndSanitize = useCallback(async (
    text: string,
    type: 'text' | 'email' | 'post' = 'text'
  ): Promise<ValidationResult> => {
    setIsValidating(true);
    
    try {
      let operation: string;
      let data: any;

      switch (type) {
        case 'email':
          operation = 'validate_email';
          data = { email: text };
          break;
        case 'post':
          operation = 'validate_post_data';
          data = { content: text, category: 'general' };
          break;
        default:
          operation = 'sanitize_text';
          data = { text };
      }

      const { data: result, error } = await supabase.functions.invoke('input-validation', {
        body: { operation, data }
      });

      if (error) {
        return {
          isValid: false,
          sanitized: '',
          error: error.message
        };
      }

      if (type === 'email') {
        return {
          isValid: result.data.valid,
          sanitized: text,
          error: result.data.valid ? undefined : 'Invalid email format'
        };
      }

      if (type === 'post') {
        return {
          isValid: result.data.valid,
          sanitized: result.data.content,
          error: result.data.valid ? undefined : 'Post content is invalid or too long'
        };
      }

      return {
        isValid: true,
        sanitized: result.data.sanitized,
        error: undefined
      };

    } catch (err: any) {
      return {
        isValid: false,
        sanitized: '',
        error: err.message || 'Validation failed'
      };
    } finally {
      setIsValidating(false);
    }
  }, []);

  return {
    validateAndSanitize,
    isValidating
  };
};

export default useSecureInput;